const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');
const { playerQueries } = require('../../src/functions/utility/database');
const { fetchPlayerData } = require('../../src/functions/utility/apiClient');

const DB_PATH = path.join(__dirname, 'webpanel.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const RESERVATION_CATEGORIES = ['buildings', 'research', 'troops'];
const CATEGORY_CONFIG = {
    buildings: {
        label: 'Buildings',
        positionName: 'Vice President',
    },
    research: {
        label: 'Research',
        positionName: 'Vice President',
    },
    troops: {
        label: 'Troops',
        positionName: 'Minister of Education',
    },
};

db.exec(`
    CREATE TABLE IF NOT EXISTS position_reservation_lists (
        id TEXT PRIMARY KEY,
        state_number INTEGER NOT NULL CHECK (state_number > 0),
        status TEXT NOT NULL CHECK (status IN ('draft', 'published', 'unpublished', 'archived')) DEFAULT 'draft',
        public_slug TEXT NOT NULL UNIQUE,
        created_by_user_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        published_at TEXT
    );

    CREATE TABLE IF NOT EXISTS position_reservation_category_configs (
        id TEXT PRIMARY KEY,
        list_id TEXT NOT NULL REFERENCES position_reservation_lists(id) ON DELETE CASCADE,
        category TEXT NOT NULL CHECK (category IN ('buildings', 'research', 'troops')),
        event_date_utc TEXT,
        reservation_start_utc TEXT,
        reservation_end_utc TEXT,
        default_slot_minutes INTEGER NOT NULL DEFAULT 30,
        first_slot_minutes INTEGER,
        last_slot_minutes INTEGER,
        max_slot_minutes INTEGER,
        allowed_slot_count INTEGER NOT NULL DEFAULT 1,
        enabled INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE(list_id, category)
    );

    CREATE TABLE IF NOT EXISTS position_reservation_slots (
        id TEXT PRIMARY KEY,
        list_id TEXT NOT NULL REFERENCES position_reservation_lists(id) ON DELETE CASCADE,
        category TEXT NOT NULL CHECK (category IN ('buildings', 'research', 'troops')),
        starts_at_utc TEXT NOT NULL,
        ends_at_utc TEXT NOT NULL,
        duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
        status TEXT NOT NULL CHECK (status IN ('available', 'reserved', 'locked')) DEFAULT 'available',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE(list_id, category, starts_at_utc, ends_at_utc),
        CHECK (julianday(ends_at_utc) > julianday(starts_at_utc))
    );

    CREATE TABLE IF NOT EXISTS position_reservations (
        id TEXT PRIMARY KEY,
        slot_id TEXT NOT NULL UNIQUE REFERENCES position_reservation_slots(id) ON DELETE CASCADE,
        list_id TEXT NOT NULL REFERENCES position_reservation_lists(id) ON DELETE CASCADE,
        category TEXT NOT NULL CHECK (category IN ('buildings', 'research', 'troops')),
        player_id TEXT NOT NULL,
        player_name TEXT,
        alliance_tag TEXT NOT NULL,
        created_at TEXT NOT NULL,
        created_by_type TEXT NOT NULL CHECK (created_by_type IN ('public', 'admin')),
        updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS position_reservation_list_admins (
        list_id TEXT NOT NULL REFERENCES position_reservation_lists(id) ON DELETE CASCADE,
        user_id TEXT NOT NULL,
        assigned_by_user_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        PRIMARY KEY (list_id, user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_position_reservation_lists_status ON position_reservation_lists(status);
    CREATE INDEX IF NOT EXISTS idx_position_reservation_slots_list_category ON position_reservation_slots(list_id, category);
    CREATE INDEX IF NOT EXISTS idx_position_reservations_list_category ON position_reservations(list_id, category);
    CREATE INDEX IF NOT EXISTS idx_position_reservation_list_admins_user ON position_reservation_list_admins(user_id);
`);

const stmts = {
    createList: db.prepare(`
        INSERT INTO position_reservation_lists (
            id, state_number, status, public_slug, created_by_user_id, created_at, updated_at
        ) VALUES (?, ?, 'draft', ?, ?, ?, ?)
    `),
    createCategoryConfig: db.prepare(`
        INSERT INTO position_reservation_category_configs (
            id, list_id, category, event_date_utc, reservation_start_utc, reservation_end_utc,
            default_slot_minutes, first_slot_minutes, last_slot_minutes, max_slot_minutes, allowed_slot_count, enabled, created_at, updated_at
        ) VALUES (?, ?, ?, NULL, NULL, NULL, 30, NULL, NULL, NULL, 1, 0, ?, ?)
    `),
    getListSummaryRows: db.prepare(`
        SELECT
            l.*,
            COUNT(DISTINCT s.id) AS slot_count,
            COUNT(DISTINCT r.id) AS reservation_count
        FROM position_reservation_lists l
        LEFT JOIN position_reservation_slots s ON s.list_id = l.id
        LEFT JOIN position_reservations r ON r.list_id = l.id
        GROUP BY l.id
        ORDER BY l.created_at DESC
    `),
    getListById: db.prepare(`SELECT * FROM position_reservation_lists WHERE id = ?`),
    getListBySlug: db.prepare(`SELECT * FROM position_reservation_lists WHERE public_slug = ?`),
    getListAssignments: db.prepare(`
        SELECT list_id, user_id, assigned_by_user_id, created_at
        FROM position_reservation_list_admins
        WHERE list_id = ?
        ORDER BY created_at ASC
    `),
    getAssignedListIdsByUser: db.prepare(`
        SELECT list_id
        FROM position_reservation_list_admins
        WHERE user_id = ?
    `),
    deleteAssignmentsByList: db.prepare(`DELETE FROM position_reservation_list_admins WHERE list_id = ?`),
    insertAssignment: db.prepare(`
        INSERT INTO position_reservation_list_admins (list_id, user_id, assigned_by_user_id, created_at)
        VALUES (?, ?, ?, ?)
    `),
    updateListMeta: db.prepare(`
        UPDATE position_reservation_lists
        SET state_number = ?, updated_at = ?
        WHERE id = ?
    `),
    publishList: db.prepare(`
        UPDATE position_reservation_lists
        SET status = 'published', published_at = ?, updated_at = ?
        WHERE id = ?
    `),
    unpublishList: db.prepare(`
        UPDATE position_reservation_lists
        SET status = 'unpublished', updated_at = ?
        WHERE id = ?
    `),
    archiveList: db.prepare(`
        UPDATE position_reservation_lists
        SET status = 'archived', updated_at = ?
        WHERE id = ?
    `),
    deleteList: db.prepare(`DELETE FROM position_reservation_lists WHERE id = ?`),
    getCategoryConfigs: db.prepare(`
        SELECT * FROM position_reservation_category_configs
        WHERE list_id = ?
        ORDER BY CASE category
            WHEN 'buildings' THEN 1
            WHEN 'research' THEN 2
            WHEN 'troops' THEN 3
            ELSE 9
        END
    `),
    upsertCategoryConfig: db.prepare(`
        INSERT INTO position_reservation_category_configs (
            id, list_id, category, event_date_utc, reservation_start_utc, reservation_end_utc,
            default_slot_minutes, first_slot_minutes, last_slot_minutes, max_slot_minutes,
            allowed_slot_count, enabled, created_at, updated_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
        ON CONFLICT(list_id, category) DO UPDATE SET
            event_date_utc = excluded.event_date_utc,
            reservation_start_utc = excluded.reservation_start_utc,
            reservation_end_utc = excluded.reservation_end_utc,
            default_slot_minutes = excluded.default_slot_minutes,
            first_slot_minutes = excluded.first_slot_minutes,
            last_slot_minutes = excluded.last_slot_minutes,
            max_slot_minutes = excluded.max_slot_minutes,
            allowed_slot_count = excluded.allowed_slot_count,
            enabled = excluded.enabled,
            updated_at = excluded.updated_at
    `),
    getSlotsByList: db.prepare(`
        SELECT
            s.*,
            r.id AS reservation_id,
            r.player_id,
            r.player_name,
            r.alliance_tag,
            r.created_by_type,
            r.created_at AS reservation_created_at,
            r.updated_at AS reservation_updated_at
        FROM position_reservation_slots s
        LEFT JOIN position_reservations r ON r.slot_id = s.id
        WHERE s.list_id = ?
        ORDER BY s.category, s.starts_at_utc
    `),
    deleteReservationsByList: db.prepare(`DELETE FROM position_reservations WHERE list_id = ?`),
    deleteReservationsByListCategory: db.prepare(`
        DELETE FROM position_reservations
        WHERE list_id = ? AND category = ?
    `),
    deleteSlotsByList: db.prepare(`DELETE FROM position_reservation_slots WHERE list_id = ?`),
    deleteSlotsByListCategory: db.prepare(`
        DELETE FROM position_reservation_slots
        WHERE list_id = ? AND category = ?
    `),
    countReservationsByList: db.prepare(`SELECT COUNT(*) AS count FROM position_reservations WHERE list_id = ?`),
    countReservationsByListCategory: db.prepare(`
        SELECT COUNT(*) AS count
        FROM position_reservations
        WHERE list_id = ? AND category = ?
    `),
    insertSlot: db.prepare(`
        INSERT INTO position_reservation_slots (
            id, list_id, category, starts_at_utc, ends_at_utc, duration_minutes, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `),
    getSlotById: db.prepare(`
        SELECT s.*, l.status AS list_status, l.public_slug
        FROM position_reservation_slots s
        JOIN position_reservation_lists l ON l.id = s.list_id
        WHERE s.id = ?
    `),
    getReservationBySlotId: db.prepare(`SELECT * FROM position_reservations WHERE slot_id = ?`),
    getReservationById: db.prepare(`SELECT * FROM position_reservations WHERE id = ?`),
    getCategoryConfigByListCategory: db.prepare(`
        SELECT * FROM position_reservation_category_configs
        WHERE list_id = ? AND category = ?
    `),
    countReservationsByPlayerInCategory: db.prepare(`
        SELECT COUNT(*) AS count
        FROM position_reservations
        WHERE list_id = ? AND category = ? AND player_id = ?
    `),
    createReservation: db.prepare(`
        INSERT INTO position_reservations (
            id, slot_id, list_id, category, player_id, player_name, alliance_tag, created_at, created_by_type, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `),
    updateSlotStatus: db.prepare(`
        UPDATE position_reservation_slots
        SET status = ?, updated_at = ?
        WHERE id = ?
    `),
    updateReservation: db.prepare(`
        UPDATE position_reservations
        SET player_id = ?, player_name = ?, alliance_tag = ?, updated_at = ?, created_by_type = ?
        WHERE id = ?
    `),
    updateReservationPlayerName: db.prepare(`
        UPDATE position_reservations
        SET player_name = ?, updated_at = ?
        WHERE id = ?
    `),
    deleteReservationById: db.prepare(`DELETE FROM position_reservations WHERE id = ?`),
    deleteReservationBySlotId: db.prepare(`DELETE FROM position_reservations WHERE slot_id = ?`),
    getPublishedPublicData: db.prepare(`
        SELECT id, state_number, status, public_slug, published_at
        FROM position_reservation_lists
        WHERE public_slug = ? AND status = 'published'
    `),
};

function nowIso() {
    return new Date().toISOString();
}

function asNullable(value) {
    if (value === undefined || value === null || value === '') return null;
    return value;
}

function ensureCategory(category) {
    if (!RESERVATION_CATEGORIES.includes(category)) {
        throw new Error(`Invalid category: ${category}`);
    }
    return category;
}

function parseUtc(value, fieldName) {
    if (!value) return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
        throw new Error(`${fieldName} must be a valid UTC datetime`);
    }
    return date;
}

function minutesBetween(start, end) {
    return Math.round((end.getTime() - start.getTime()) / 60000);
}

function addMinutes(date, minutes) {
    return new Date(date.getTime() + minutes * 60000);
}

function createStableSlotId(listId, category, startsAtUtc, endsAtUtc) {
    return crypto
        .createHash('sha1')
        .update(`${listId}:${category}:${startsAtUtc}:${endsAtUtc}`)
        .digest('hex');
}

function normalizeCategoryConfig(input) {
    const category = ensureCategory(input.category);
    const reservationStart = parseUtc(input.reservationStartUtc, `${category} reservationStartUtc`);
    const reservationEnd = parseUtc(input.reservationEndUtc, `${category} reservationEndUtc`);
    const eventDate = input.eventDateUtc ? parseUtc(input.eventDateUtc, `${category} eventDateUtc`) : null;
    const defaultSlotMinutes = Number(input.defaultSlotMinutes);
    const firstSlotMinutes = asNullable(input.firstSlotMinutes) === null ? null : Number(input.firstSlotMinutes);
    const lastSlotMinutes = asNullable(input.lastSlotMinutes) === null ? null : Number(input.lastSlotMinutes);
    const maxSlotMinutes = asNullable(input.maxSlotMinutes) === null ? null : Number(input.maxSlotMinutes);
    const allowedSlotCount = Number(asNullable(input.allowedSlotCount) ?? 1);
    const enabled = input.enabled === undefined ? true : !!input.enabled;

    if (reservationStart && reservationEnd && reservationEnd <= reservationStart) {
        throw new Error(`${category} reservationEndUtc must be after reservationStartUtc`);
    }
    if (!Number.isInteger(defaultSlotMinutes) || defaultSlotMinutes <= 0 || defaultSlotMinutes > 60) {
        throw new Error(`${category} defaultSlotMinutes must be between 1 and 60`);
    }
    if (firstSlotMinutes !== null && (!Number.isInteger(firstSlotMinutes) || firstSlotMinutes < 5 || firstSlotMinutes > 60)) {
        throw new Error(`${category} firstSlotMinutes must be between 5 and 60`);
    }
    if (lastSlotMinutes !== null && (!Number.isInteger(lastSlotMinutes) || lastSlotMinutes < 5 || lastSlotMinutes > 60)) {
        throw new Error(`${category} lastSlotMinutes must be between 5 and 60`);
    }
    if (maxSlotMinutes !== null && (!Number.isInteger(maxSlotMinutes) || maxSlotMinutes < 5 || maxSlotMinutes > 60)) {
        throw new Error(`${category} maxSlotMinutes must be between 5 and 60`);
    }
    if (!Number.isInteger(allowedSlotCount) || allowedSlotCount < 1 || allowedSlotCount > 48) {
        throw new Error(`${category} allowedSlotCount must be between 1 and 48`);
    }

    return {
        category,
        eventDateUtc: eventDate ? eventDate.toISOString() : null,
        reservationStartUtc: reservationStart ? reservationStart.toISOString() : null,
        reservationEndUtc: reservationEnd ? reservationEnd.toISOString() : null,
        defaultSlotMinutes,
        firstSlotMinutes,
        lastSlotMinutes,
        maxSlotMinutes,
        allowedSlotCount,
        enabled,
    };
}

function validateStateNumber(stateNumber) {
    const parsed = Number(stateNumber);
    if (!Number.isInteger(parsed) || parsed <= 0 || parsed > 9999) {
        throw new Error('stateNumber must be a positive integer up to 4 digits');
    }
    return parsed;
}

function validateReservationInput({ playerId, allianceTag }) {
    const normalizedPlayerId = String(playerId || '').trim();
    const normalizedAllianceTag = String(allianceTag || '').trim().toUpperCase();

    if (normalizedPlayerId.length < 3 || normalizedPlayerId.length > 32) {
        throw new Error('playerId must be between 3 and 32 characters');
    }
    if (normalizedAllianceTag.length < 2 || normalizedAllianceTag.length > 12) {
        throw new Error('allianceTag must be between 2 and 12 characters');
    }
    if (!/^[A-Z0-9 _-]+$/.test(normalizedAllianceTag)) {
        throw new Error('allianceTag contains unsupported characters');
    }

    return {
        playerId: normalizedPlayerId,
        allianceTag: normalizedAllianceTag,
    };
}

function normalizePlayerName(value, fallbackPlayerId = '') {
    const text = String(value || '').trim();
    return text || String(fallbackPlayerId || '').trim();
}

async function resolvePlayerName(playerId) {
    const normalizedPlayerId = String(playerId || '').trim();
    const numericPlayerId = Number(normalizedPlayerId);
    const cachedPlayer = Number.isInteger(numericPlayerId)
        ? playerQueries.getPlayer(numericPlayerId)
        : null;
    const fallbackName = normalizePlayerName(cachedPlayer?.nickname, normalizedPlayerId);

    try {
        const apiData = await fetchPlayerData(normalizedPlayerId, { returnErrorObject: true });
        if (apiData && !apiData.error && !apiData.playerNotExist) {
            return normalizePlayerName(apiData.nickname, fallbackName);
        }
    } catch {
        // Keep reservations working even if the live lookup fails.
    }

    return fallbackName;
}

async function refreshReservationPlayerName(reservationId, playerId) {
    try {
        const resolvedName = await resolvePlayerName(playerId);
        const normalizedPlayerId = String(playerId || '').trim();
        if (!resolvedName || resolvedName === normalizedPlayerId) {
            return;
        }
        stmts.updateReservationPlayerName.run(resolvedName, nowIso(), reservationId);
    } catch {
        // Best effort only. Reservation creation should not depend on name lookup.
    }
}

function shapeConfigRow(row) {
    return {
        id: row.id,
        listId: row.list_id,
        category: row.category,
        eventDateUtc: row.event_date_utc,
        reservationStartUtc: row.reservation_start_utc,
        reservationEndUtc: row.reservation_end_utc,
        defaultSlotMinutes: row.default_slot_minutes,
        firstSlotMinutes: row.first_slot_minutes,
        lastSlotMinutes: row.last_slot_minutes,
        maxSlotMinutes: row.max_slot_minutes,
        allowedSlotCount: row.allowed_slot_count || 1,
        enabled: !!row.enabled,
    };
}

function shapeSlotRow(row) {
    return {
        id: row.id,
        listId: row.list_id,
        category: row.category,
        startsAtUtc: row.starts_at_utc,
        endsAtUtc: row.ends_at_utc,
        durationMinutes: row.duration_minutes,
        status: row.status,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        reservation: row.reservation_id ? {
            id: row.reservation_id,
            playerId: row.player_id,
            playerName: normalizePlayerName(row.player_name, row.player_id),
            allianceTag: row.alliance_tag,
            createdByType: row.created_by_type,
            createdAt: row.reservation_created_at,
            updatedAt: row.reservation_updated_at,
        } : null,
    };
}

function shapeListRow(row) {
    return {
        id: row.id,
        stateNumber: row.state_number,
        status: row.status,
        publicSlug: row.public_slug,
        createdByUserId: row.created_by_user_id,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        publishedAt: row.published_at,
        slotCount: row.slot_count ?? 0,
        reservationCount: row.reservation_count ?? 0,
    };
}

function shapeAssignmentRow(row) {
    return {
        listId: row.list_id,
        userId: row.user_id,
        assignedByUserId: row.assigned_by_user_id,
        createdAt: row.created_at,
    };
}

function groupSlotsByCategory(slots) {
    return RESERVATION_CATEGORIES.reduce((acc, category) => {
        acc[category] = slots.filter(slot => slot.category === category);
        return acc;
    }, {});
}

function isListCreatedByUser(listRow, userId) {
    return !!(listRow && userId && listRow.created_by_user_id === userId);
}

function getAssignmentsForList(listId) {
    return stmts.getListAssignments.all(listId).map(shapeAssignmentRow);
}

function isUserAssignedToList(listId, userId) {
    if (!listId || !userId) return false;
    return getAssignmentsForList(listId).some((assignment) => assignment.userId === userId);
}

function canUserAccessList(listId, userId, hasFullAccess = false) {
    const list = stmts.getListById.get(listId);
    if (!list) return false;
    if (hasFullAccess) return true;
    return isListCreatedByUser(list, userId) || isUserAssignedToList(listId, userId);
}

function generateSlots(config, listId = 'preview') {
    const normalized = normalizeCategoryConfig(config);
    if (!normalized.reservationStartUtc || !normalized.reservationEndUtc) {
        return [];
    }

    const start = new Date(normalized.reservationStartUtc);
    const end = new Date(normalized.reservationEndUtc);
    const slots = [];
    let cursor = start;
    let index = 0;

    while (cursor < end) {
        const isFirst = index === 0;
        let duration = normalized.defaultSlotMinutes;

        if (isFirst && normalized.firstSlotMinutes) {
            duration = normalized.firstSlotMinutes;
        }

        if (normalized.maxSlotMinutes) {
            duration = Math.min(duration, normalized.maxSlotMinutes);
        }

        let next = addMinutes(cursor, duration);
        if (next > end) {
            next = end;
        }

        if (normalized.lastSlotMinutes && addMinutes(cursor, normalized.lastSlotMinutes) === end) {
            next = end;
        }

        const durationMinutes = minutesBetween(cursor, next);
        if (durationMinutes <= 0) break;

        slots.push({
            id: createStableSlotId(listId, normalized.category, cursor.toISOString(), next.toISOString()),
            category: normalized.category,
            startsAtUtc: cursor.toISOString(),
            endsAtUtc: next.toISOString(),
            durationMinutes,
            status: 'available',
        });

        cursor = next;
        index++;
    }

    if (normalized.lastSlotMinutes && slots.length > 1) {
        const lastSlot = slots[slots.length - 1];
        if (lastSlot.durationMinutes !== normalized.lastSlotMinutes) {
            const recomputedStart = addMinutes(end, -normalized.lastSlotMinutes);
            if (recomputedStart > new Date(slots[slots.length - 2].endsAtUtc)) {
                lastSlot.startsAtUtc = recomputedStart.toISOString();
                lastSlot.endsAtUtc = end.toISOString();
                lastSlot.durationMinutes = normalized.lastSlotMinutes;
                lastSlot.id = createStableSlotId(listId, normalized.category, lastSlot.startsAtUtc, lastSlot.endsAtUtc);
            }
        }
    }

    return slots.filter((slot, idx, arr) => {
        if (idx === 0) return slot.durationMinutes > 0;
        return slot.durationMinutes > 0 && slot.startsAtUtc >= arr[idx - 1].endsAtUtc;
    });
}

const createListTx = db.transaction(({ stateNumber, createdByUserId }) => {
    const id = crypto.randomUUID();
    const now = nowIso();
    const publicSlug = crypto.randomUUID();
    stmts.createList.run(id, validateStateNumber(stateNumber), publicSlug, createdByUserId, now, now);

    for (const category of RESERVATION_CATEGORIES) {
        stmts.createCategoryConfig.run(
            crypto.randomUUID(),
            id,
            category,
            now,
            now
        );
    }

    return id;
});

const upsertCategoryConfigsTx = db.transaction((listId, configs) => {
    const list = stmts.getListById.get(listId);
    if (!list) throw new Error('Reservation list not found');

    const now = nowIso();
    for (const rawConfig of configs) {
        const normalized = normalizeCategoryConfig(rawConfig);
        const existing = stmts.getCategoryConfigs.all(listId).find(cfg => cfg.category === normalized.category);
        stmts.upsertCategoryConfig.run(
            existing?.id || crypto.randomUUID(),
            listId,
            normalized.category,
            normalized.eventDateUtc,
            normalized.reservationStartUtc,
            normalized.reservationEndUtc,
            normalized.defaultSlotMinutes,
            normalized.firstSlotMinutes,
            normalized.lastSlotMinutes,
            normalized.maxSlotMinutes,
            normalized.allowedSlotCount,
            normalized.enabled ? 1 : 0,
            existing?.created_at || now,
            now
        );
    }

    return getListDetail(listId);
});

const regenerateSlotsTx = db.transaction((listId, { force = false, categories = null } = {}) => {
    const list = stmts.getListById.get(listId);
    if (!list) throw new Error('Reservation list not found');

    const scopedCategories = Array.isArray(categories) && categories.length
        ? [...new Set(categories.map(ensureCategory))]
        : null;

    const reservationCount = scopedCategories
        ? scopedCategories.reduce(
            (total, category) => total + Number(stmts.countReservationsByListCategory.get(listId, category)?.count || 0),
            0
        )
        : Number(stmts.countReservationsByList.get(listId).count || 0);

    if (reservationCount > 0 && !force) {
        return { requiresForce: true, reservationCount };
    }

    if (force) {
        if (scopedCategories) {
            for (const category of scopedCategories) {
                stmts.deleteReservationsByListCategory.run(listId, category);
            }
        } else {
            stmts.deleteReservationsByList.run(listId);
        }
    }

    if (scopedCategories) {
        for (const category of scopedCategories) {
            stmts.deleteSlotsByListCategory.run(listId, category);
        }
    } else {
        stmts.deleteSlotsByList.run(listId);
    }

    const now = nowIso();
    const configRows = stmts.getCategoryConfigs.all(listId).map(shapeConfigRow);
    let insertedCount = 0;

    for (const config of configRows) {
        if (scopedCategories && !scopedCategories.includes(config.category)) continue;
        if (!config.enabled) continue;
        const slots = generateSlots(config, listId);
        for (const slot of slots) {
            stmts.insertSlot.run(
                slot.id,
                listId,
                slot.category,
                slot.startsAtUtc,
                slot.endsAtUtc,
                slot.durationMinutes,
                slot.status,
                now,
                now
            );
            insertedCount++;
        }
    }

    return {
        requiresForce: false,
        insertedCount,
        detail: getListDetail(listId),
    };
});

const reserveSlotTx = db.transaction(({ publicSlug, slotIds, slotId, category, playerId, playerName, allianceTag, createdByType = 'public' }) => {
    const normalized = validateReservationInput({ playerId, allianceTag });
    const requestedSlotIds = [...new Set(
        (Array.isArray(slotIds) ? slotIds : [slotId])
            .map((value) => String(value || '').trim())
            .filter(Boolean)
    )];

    if (!requestedSlotIds.length) {
        throw new Error('Select at least one slot.');
    }

    const publicList = publicSlug ? stmts.getPublishedPublicData.get(publicSlug) : null;
    if (publicSlug && !publicList) {
        throw new Error('Reservation list not found or unavailable');
    }

    const slots = requestedSlotIds.map((id) => {
        const slot = stmts.getSlotById.get(id);
        if (!slot) throw new Error('Slot not found');
        if (slot.category !== category) throw new Error('Slot category mismatch');
        if (slot.list_status !== 'published') throw new Error('Reservation list is not published');
        if (publicList && slot.list_id !== publicList.id) {
            throw new Error('Slot does not belong to this reservation list');
        }
        if (slot.status !== 'available') throw new Error('One or more selected slots were already reserved. Select another slot.');
        return slot;
    });

    const configRow = stmts.getCategoryConfigByListCategory.get(slots[0].list_id, category);
    if (!configRow || !configRow.enabled) {
        throw new Error('This reservation category is not available.');
    }
    const allowedSlotCount = Number(configRow?.allowed_slot_count) || 1;
    const existingReservationCount = Number(
        stmts.countReservationsByPlayerInCategory.get(slots[0].list_id, category, normalized.playerId)?.count || 0
    );

    if (existingReservationCount + requestedSlotIds.length > allowedSlotCount) {
        const remaining = Math.max(0, allowedSlotCount - existingReservationCount);
        throw new Error(
            remaining > 0
                ? `This player can only reserve ${allowedSlotCount} slot${allowedSlotCount === 1 ? '' : 's'} in ${category}. ${remaining} slot${remaining === 1 ? '' : 's'} remaining.`
                : `This player already reached the ${allowedSlotCount}-slot limit for ${category}.`
        );
    }

    const now = nowIso();
    const reservations = slots.map((slot) => {
        const reservationId = crypto.randomUUID();
        stmts.createReservation.run(
            reservationId,
            slot.id,
            slot.list_id,
            category,
            normalized.playerId,
            normalizePlayerName(playerName, normalized.playerId),
            normalized.allianceTag,
            now,
            createdByType,
            now
        );
        stmts.updateSlotStatus.run('reserved', now, slot.id);

        return {
            id: reservationId,
            slotId: slot.id,
            listId: slot.list_id,
            category,
            playerId: normalized.playerId,
            playerName: normalizePlayerName(playerName, normalized.playerId),
            allianceTag: normalized.allianceTag,
            createdAt: now,
            createdByType,
            updatedAt: now,
        };
    });

    return {
        reservations,
        listId: slots[0].list_id,
        category,
        playerId: normalized.playerId,
        playerName: normalizePlayerName(playerName, normalized.playerId),
        allianceTag: normalized.allianceTag,
        allowedSlotCount,
        totalReservedForPlayer: existingReservationCount + reservations.length,
    };
});

const setSlotStateTx = db.transaction(({ slotId, status, reservation, createdByType = 'admin' }) => {
    const slot = stmts.getSlotById.get(slotId);
    if (!slot) throw new Error('Slot not found');
    const now = nowIso();
    const currentReservation = stmts.getReservationBySlotId.get(slotId);

    if (status === 'available') {
        if (currentReservation) {
            stmts.deleteReservationBySlotId.run(slotId);
        }
        stmts.updateSlotStatus.run('available', now, slotId);
        return;
    }

    if (status === 'locked') {
        if (currentReservation) {
            stmts.deleteReservationBySlotId.run(slotId);
        }
        stmts.updateSlotStatus.run('locked', now, slotId);
        return;
    }

    if (status !== 'reserved') {
        throw new Error('Invalid slot status');
    }

    const normalized = validateReservationInput(reservation || {});
    const playerName = normalizePlayerName(reservation?.playerName, normalized.playerId);
    let reservationId = currentReservation?.id || null;
    if (currentReservation) {
        stmts.updateReservation.run(
            normalized.playerId,
            playerName,
            normalized.allianceTag,
            now,
            createdByType,
            currentReservation.id
        );
    } else {
        reservationId = crypto.randomUUID();
        stmts.createReservation.run(
            reservationId,
            slotId,
            slot.list_id,
            slot.category,
            normalized.playerId,
            playerName,
            normalized.allianceTag,
            now,
            createdByType,
            now
        );
    }
    stmts.updateSlotStatus.run('reserved', now, slotId);
    return {
        reservationId,
        listId: slot.list_id,
        playerId: normalized.playerId,
    };
});

const deleteReservationTx = db.transaction((reservationId) => {
    const reservation = stmts.getReservationById.get(reservationId);
    if (!reservation) throw new Error('Reservation not found');
    stmts.deleteReservationById.run(reservationId);
    stmts.updateSlotStatus.run('available', nowIso(), reservation.slot_id);
});

const deleteListTx = db.transaction((listId) => {
    const list = stmts.getListById.get(listId);
    if (!list) throw new Error('Reservation list not found');
    stmts.deleteList.run(listId);
    return shapeListRow({
        ...list,
        slot_count: 0,
        reservation_count: 0,
    });
});

function getListDetail(listId) {
    const listRow = stmts.getListById.get(listId);
    if (!listRow) return null;

    const configs = stmts.getCategoryConfigs.all(listId).map(shapeConfigRow);
    const slots = stmts.getSlotsByList.all(listId).map(shapeSlotRow);
    const assignees = getAssignmentsForList(listId);

    return {
        ...shapeListRow(listRow),
        assignees,
        categories: RESERVATION_CATEGORIES.map((category) => {
            const config = configs.find(item => item.category === category) || {
                category,
                enabled: false,
                defaultSlotMinutes: 30,
                allowedSlotCount: 1,
            };
            return {
                ...config,
                positionName: CATEGORY_CONFIG[category].positionName,
                display: CATEGORY_CONFIG[category],
                slots: slots.filter(slot => slot.category === category),
            };
        }),
    };
}

function getPublicList(publicSlug) {
    const list = stmts.getPublishedPublicData.get(publicSlug);
    if (!list) return null;

    const detail = getListDetail(list.id);
    if (!detail) return null;

    return {
        id: detail.id,
        stateNumber: detail.stateNumber,
        publicSlug: detail.publicSlug,
        status: detail.status,
        categories: detail.categories
            .filter(category => category.enabled)
            .map(category => ({
                category: category.category,
                label: category.display.label,
                positionName: category.display.positionName,
                allowedSlotCount: category.allowedSlotCount || 1,
                slots: category.slots
                    .filter(slot => slot.status === 'available')
                    .map(slot => ({
                        id: slot.id,
                        category: slot.category,
                        startsAtUtc: slot.startsAtUtc,
                        endsAtUtc: slot.endsAtUtc,
                        durationMinutes: slot.durationMinutes,
                        status: slot.status,
                    })),
            })),
    };
}

function getLists({ userId = null, hasFullAccess = false } = {}) {
    const rows = stmts.getListSummaryRows.all().map(shapeListRow);
    if (hasFullAccess) return rows;

    const assignedListIds = new Set(
        userId
            ? stmts.getAssignedListIdsByUser.all(userId).map((row) => row.list_id)
            : []
    );

    return rows.filter((row) => row.createdByUserId === userId || assignedListIds.has(row.id));
}

const setListAssignmentsTx = db.transaction((listId, userIds, assignedByUserId) => {
    const list = stmts.getListById.get(listId);
    if (!list) throw new Error('Reservation list not found');

    const normalizedUserIds = [...new Set(
        (Array.isArray(userIds) ? userIds : [])
            .map((value) => String(value || '').trim())
            .filter(Boolean)
    )].filter((userId) => userId !== list.created_by_user_id);

    stmts.deleteAssignmentsByList.run(listId);
    const now = nowIso();
    for (const userId of normalizedUserIds) {
        stmts.insertAssignment.run(listId, userId, assignedByUserId, now);
    }

    return getListDetail(listId);
});

module.exports = {
    CATEGORY_CONFIG,
    RESERVATION_CATEGORIES,
    validateStateNumber,
    validateReservationInput,
    generateSlots,
    getLists,
    getListDetail,
    getPublicList,
    canUserAccessList,
    getSlot(slotId) {
        const row = stmts.getSlotById.get(slotId);
        return row ? {
            id: row.id,
            listId: row.list_id,
            category: row.category,
            status: row.status,
        } : null;
    },
    getReservation(reservationId) {
        const row = stmts.getReservationById.get(reservationId);
        return row ? {
            id: row.id,
            listId: row.list_id,
            slotId: row.slot_id,
            category: row.category,
        } : null;
    },
    createList(input) {
        const listId = createListTx(input);
        return getListDetail(listId);
    },
    updateListMeta(listId, { stateNumber }) {
        const now = nowIso();
        const result = stmts.updateListMeta.run(validateStateNumber(stateNumber), now, listId);
        if (!result.changes) throw new Error('Reservation list not found');
        return getListDetail(listId);
    },
    upsertCategoryConfigs(listId, configs) {
        return upsertCategoryConfigsTx(listId, configs);
    },
    regenerateSlots(listId, options) {
        return regenerateSlotsTx(listId, options);
    },
    publishList(listId) {
        const detail = getListDetail(listId);
        if (!detail) throw new Error('Reservation list not found');
        const enabledCategories = detail.categories.filter(category => category.enabled);
        if (enabledCategories.length === 0) throw new Error('Enable at least one category before publishing');
        if (enabledCategories.some(category => category.slots.length === 0)) {
            throw new Error('Generate slots for all enabled categories before publishing');
        }
        const now = nowIso();
        stmts.publishList.run(now, now, listId);
        return getListDetail(listId);
    },
    unpublishList(listId) {
        const result = stmts.unpublishList.run(nowIso(), listId);
        if (!result.changes) throw new Error('Reservation list not found');
        return getListDetail(listId);
    },
    archiveList(listId) {
        const result = stmts.archiveList.run(nowIso(), listId);
        if (!result.changes) throw new Error('Reservation list not found');
        return getListDetail(listId);
    },
    deleteList(listId) {
        return deleteListTx(listId);
    },
    setListAssignments(listId, userIds, assignedByUserId) {
        return setListAssignmentsTx(listId, userIds, assignedByUserId);
    },
    async reservePublicSlot(input) {
        const normalized = validateReservationInput(input || {});
        const result = reserveSlotTx({
            ...input,
            ...normalized,
            playerName: normalized.playerId,
            createdByType: 'public',
        });
        for (const reservation of result.reservations) {
            void refreshReservationPlayerName(reservation.id, reservation.playerId);
        }
        return result;
    },
    async setSlotState(input) {
        const result = setSlotStateTx({
            ...input,
            reservation: input?.reservation ? {
                ...input.reservation,
                playerName: input.reservation.playerId || input.reservation.playerName,
            } : input?.reservation,
        });
        if (input?.status === 'reserved' && result?.reservationId && result?.playerId) {
            void refreshReservationPlayerName(result.reservationId, result.playerId);
        }
        return getListDetail(result?.listId || stmts.getSlotById.get(input.slotId).list_id);
    },
    deleteReservation(reservationId) {
        const reservation = stmts.getReservationById.get(reservationId);
        if (!reservation) throw new Error('Reservation not found');
        deleteReservationTx(reservationId);
        return getListDetail(reservation.list_id);
    },
    close() {
        if (db.open) db.close();
    },
};
