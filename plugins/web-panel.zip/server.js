const express = require('express');
const multer = require('multer');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const {
    validateLoginToken, JWT_SECRET, JWT_EXPIRY,
    isOAuth2Configured, getClientSecret, buildOAuth2Url,
    exchangeCode, fetchDiscordUser,
    generateOAuth2State, validateOAuth2State
} = require('./auth');
const centralProxy = require('./centralProxy');
const { getSelfHostedPublicUrl, getOAuthRedirectUri } = require('./oauthUrl');
const wsClient = require('./wsClient');
const pluginDb = require('./pluginDb');
const positionReservations = require('./positionReservations');
const guides = require('./guides');
const attendance = require('./attendance');

const {
    adminQueries,
    playerQueries,
    allianceQueries,
    notificationQueries,
    processQueries,
    giftCodeQueries,
    giftCodeUsageQueries,
    settingsQueries,
    systemLogQueries,
    userQueries,
    adminLogQueries
} = require('../../src/functions/utility/database');

const { PERMISSIONS } = require('../../src/functions/Settings/admin/permissions');
const { LOG_CODES } = require('../../src/functions/utility/AdminLogs');
const { createProcess, PROCESS_PRIORITIES } = require('../../src/functions/Processes/createProcesses');
const { queueManager } = require('../../src/functions/Processes/queueManager');
const { resolveProcessGameType } = require('../../src/functions/Processes/createProcesses');
const { createAddPlayerProcess } = require('../../src/functions/Players/addPlayer');
const { createRedeemProcess, getValidationFailureKind } = require('../../src/functions/GiftCode/redeemFunction');
const { notificationScheduler } = require('../../src/functions/Notification/notificationScheduler');
const { updateBoardsForGuild } = require('../../src/functions/Notification/scheduleView');
const { getActiveGameTypes, getDefaultGameType, getRuntimeGameMode, isMultiGameModeEnabled } = require('../../src/functions/utility/gameRuntime');
const { getGameProfile, normalizeGameType } = require('../../src/functions/utility/gameProfiles');
const { MAX_NICKNAME_LENGTH } = require('../../src/functions/Players/playerDisplay');

const { ChannelType } = require('discord.js');

const WEB_PANEL_PERMISSIONS = {
    RESERVATIONS_MANAGEMENT: 1 << 5,
    GUIDE_MANAGEMENT: 1 << 6,
};

// ── Panel Access Level ────────────────────────────────────────────────────────
/** Who is allowed to log in to the web panel. Persisted in pluginDb. */
const PANEL_ACCESS = {
    EVERYONE:    'everyone',    // Anyone with the URL can log in via Discord OAuth2
    BOT_USERS:   'bot_users',  // Only users registered in the bot's users table
    ADMINS_ONLY: 'admins_only',// Only admins
    OWNER_ONLY:  'owner_only', // Only the bot owner
};
const PANEL_ACCESS_KEY = 'panel_access_level';
const PANEL_ACCESS_DEFAULT = PANEL_ACCESS.EVERYONE;
const GUEST_PUBLIC_TOOLS_KEY = 'guest_public_tools_enabled';
const PANEL_THEME_KEY = 'panel_theme';
const PANEL_THEME = {
    DARK_BLUE_PREMIUM: 'dark-blue-premium',
    BLACK_PREMIUM: 'black-premium',
    DARK_GOLD_PREMIUM: 'dark-gold-premium',
};
const PANEL_THEME_DEFAULT = PANEL_THEME.DARK_BLUE_PREMIUM;
const PANEL_GAME_HEADER = 'x-game-type';
/** Returns the configured panel access level. */
function getPanelAccessLevel() {
    return pluginDb.get(PANEL_ACCESS_KEY) || PANEL_ACCESS_DEFAULT;
}

function isGuestPublicToolsEnabled() {
    return pluginDb.get(GUEST_PUBLIC_TOOLS_KEY) === 'true';
}

function getPanelTheme() {
    const value = pluginDb.get(PANEL_THEME_KEY);
    return Object.values(PANEL_THEME).includes(value) ? value : PANEL_THEME_DEFAULT;
}

function normalizeOptionalText(value) {
    if (typeof value !== 'string') return null;
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : null;
}

function normalizeNotificationFields(fields) {
    if (fields === undefined || fields === null) return null;

    if (typeof fields === 'string') {
        return fields.trim().length > 0 ? fields : null;
    }

    if (!Array.isArray(fields)) return null;

    const normalized = fields
        .map(field => ({
            name: typeof field?.name === 'string' ? field.name.trim() : '',
            value: typeof field?.value === 'string' ? field.value.trim() : '',
            inline: !!field?.inline
        }))
        .filter(field => field.name || field.value);

    return normalized.length > 0 ? JSON.stringify(normalized) : null;
}

function normalizeNotificationMention(mention) {
    if (mention === undefined || mention === null) return null;
    if (typeof mention === 'string') {
        return mention.trim().length > 0 ? mention : null;
    }
    if (typeof mention !== 'object') return null;
    return JSON.stringify(mention);
}

function isValidNotificationPattern(pattern) {
    const normalized = normalizeOptionalText(pattern) || 'time';
    const parts = normalized.split(',').map(part => part.trim());
    if (parts.some(part => part !== 'time' && (!/^\d+$/.test(part) || Number(part) <= 0))) return false;
    return new Set(parts).size === parts.length;
}

function isValidNotificationRepeat(repeatStatus, repeatFrequency) {
    if (!repeatStatus) return true;

    if (typeof repeatFrequency === 'string' && repeatFrequency.startsWith('weekly:')) {
        const rawDays = repeatFrequency.slice(7).split(',');
        if (rawDays.length === 0 || rawDays.some(day => !/^[0-6]$/.test(day))) return false;
        return new Set(rawDays).size === rawDays.length;
    }

    const seconds = Number(repeatFrequency);
    return Number.isInteger(seconds) && seconds > 0;
}

function getNotificationPayloadError({
    messageContent,
    title,
    description,
    footer,
    author,
    imageUrl,
    thumbnailUrl,
    fields,
    embedToggle
}) {
    const message = normalizeOptionalText(messageContent);
    if (message && message.length > 2000) return 'Message content cannot exceed 2000 characters';
    if (!embedToggle) return null;

    const embedParts = {
        title: normalizeOptionalText(title),
        description: normalizeOptionalText(description),
        footer: normalizeOptionalText(footer),
        author: normalizeOptionalText(author)
    };
    if (embedParts.title && embedParts.title.length > 256) return 'Embed title cannot exceed 256 characters';
    if (embedParts.description && embedParts.description.length > 4096) return 'Embed description cannot exceed 4096 characters';
    if (embedParts.footer && embedParts.footer.length > 2048) return 'Embed footer cannot exceed 2048 characters';
    if (embedParts.author && embedParts.author.length > 256) return 'Embed author cannot exceed 256 characters';

    for (const [label, value] of [['image', imageUrl], ['thumbnail', thumbnailUrl]]) {
        const normalized = normalizeOptionalText(value);
        if (!normalized) continue;
        try {
            const parsed = new URL(normalized);
            if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Unsupported protocol');
        } catch {
            return `Embed ${label} must be a valid HTTP or HTTPS URL`;
        }
    }

    let parsedFields = [];
    if (fields) {
        try {
            parsedFields = typeof fields === 'string' ? JSON.parse(fields) : fields;
        } catch {
            return 'Embed fields are invalid';
        }
        if (!Array.isArray(parsedFields)) return 'Embed fields are invalid';
    }
    if (parsedFields.length > 25) return 'Embed cannot contain more than 25 fields';

    let embedSize = Object.values(embedParts).reduce((total, value) => total + (value?.length || 0), 0);
    for (let index = 0; index < parsedFields.length; index += 1) {
        const fieldName = normalizeOptionalText(parsedFields[index]?.name);
        const fieldValue = normalizeOptionalText(parsedFields[index]?.value);
        if (!!fieldName !== !!fieldValue) return `Embed field ${index + 1} requires both a name and value`;
        if (!fieldName) continue;
        if (fieldName.length > 256) return `Embed field ${index + 1} name cannot exceed 256 characters`;
        if (fieldValue.length > 1024) return `Embed field ${index + 1} value cannot exceed 1024 characters`;
        embedSize += fieldName.length + fieldValue.length;
    }
    if (embedSize > 6000) return 'Total embed content cannot exceed 6000 characters';

    return null;
}

async function startGiftCodeAutoRedeem(giftCode, adminId, gameType = getDefaultGameType()) {
    const resolvedGameType = normalizeGameType(gameType, getDefaultGameType());
    const autoRedeemAlliances = allianceQueries.getAlliancesWithAutoRedeem(resolvedGameType);
    if (!Array.isArray(autoRedeemAlliances) || autoRedeemAlliances.length === 0) {
        return;
    }

    for (const alliance of autoRedeemAlliances) {
        try {
            const players = playerQueries.getPlayersByAlliance(alliance.id, resolvedGameType);
            if (!Array.isArray(players) || players.length === 0) {
                continue;
            }

            const redeemData = players.map((player) => ({
                id: player.fid,
                giftCode,
                status: 'redeem'
            }));

            const result = await createRedeemProcess(redeemData, {
                adminId,
                allianceContext: {
                    id: alliance.id,
                    name: alliance.name,
                    channelId: alliance.channel_id || null,
                    gameType: resolvedGameType
                }
            });

            if (!result?.success) {
                console.error(
                    `[Web Panel Gift Codes] Auto-redeem failed for alliance "${alliance.name}" and code "${giftCode}": ${result?.message || 'Unknown error'}`
                );
            }
        } catch (error) {
            console.error(
                `[Web Panel Gift Codes] Auto-redeem crashed for alliance "${alliance?.name || alliance?.id || 'unknown'}" and code "${giftCode}":`,
                error
            );
        }
    }
}

function hasCompletedNotificationContent({
    messageContent,
    title,
    description,
    footer,
    author,
    imageUrl,
    thumbnailUrl,
    fields,
    embedToggle
}) {
    if (!embedToggle) {
        return !!normalizeOptionalText(messageContent);
    }

    if (normalizeOptionalText(title)) return true;
    if (normalizeOptionalText(description)) return true;
    if (normalizeOptionalText(footer)) return true;
    if (normalizeOptionalText(author)) return true;
    if (normalizeOptionalText(imageUrl)) return true;
    if (normalizeOptionalText(thumbnailUrl)) return true;
    if (fields) {
        try {
            const parsedFields = typeof fields === 'string' ? JSON.parse(fields) : fields;
            if (Array.isArray(parsedFields) && parsedFields.length > 0) {
                return parsedFields.some(field =>
                    normalizeOptionalText(field?.name) && normalizeOptionalText(field?.value)
                );
            }
        } catch {
            return false;
        }
    }

    return false;
}

function isNotificationRecordComplete(notification) {
    if (!notification) return false;

    return hasCompletedNotificationContent({
        messageContent: notification.message_content,
        title: notification.title,
        description: notification.description,
        footer: notification.footer,
        author: notification.author,
        imageUrl: notification.image_url,
        thumbnailUrl: notification.thumbnail_url,
        fields: notification.fields,
        embedToggle: !!notification.embed_toggle
    });
}

async function refreshNotificationBoardsForGuilds(client, guildIds = []) {
    const uniqueGuildIds = [...new Set(guildIds.filter(Boolean))];

    await Promise.all(uniqueGuildIds.map(async guildId => {
        try {
            await updateBoardsForGuild(guildId, client);
        } catch (error) {
            console.error(`[Web Panel] Failed to refresh schedule boards for guild ${guildId}:`, error.message);
        }
    }));
}

/**
 * Returns true if the given user is allowed to access the panel based on
 * the current panel access level.
 * @param {{ adminData: object|null, isOwner: boolean, inUsersTable: boolean }} ctx
 */
function isAllowedByAccessLevel(ctx) {
    const level = getPanelAccessLevel();
    if (level === PANEL_ACCESS.EVERYONE) return true;
    if (level === PANEL_ACCESS.BOT_USERS) return ctx.inUsersTable || !!ctx.adminData;
    if (level === PANEL_ACCESS.ADMINS_ONLY) return !!ctx.adminData;
    if (level === PANEL_ACCESS.OWNER_ONLY) return ctx.isOwner;
    return false;
}

const DEFAULT_PORT = parseInt(process.env.PORT, 10) || 3010;
const MAX_PORT_RETRIES = 10;
const BASE_PATH = (process.env.WEB_PANEL_BASE_PATH || '').replace(/\/+$/, '');
const GUIDE_IMAGE_UPLOAD_LIMIT_BYTES = 8 * 1024 * 1024;
const GUIDE_VIEWER_COOKIE_NAME = 'guide_viewer_token';
const GUIDE_PASSWORD_COOKIE_PREFIX = 'guide_unlock_';

/**
 * Safely parse a JSON string, returning a fallback value on parse failure.
 * @param {string} jsonString
 * @param {*} fallback
 */
function parseJsonSafe(jsonString, fallback) {
    try {
        return JSON.parse(jsonString);
    } catch {
        return fallback;
    }
}

function buildPanelGameConfig() {
    return {
        gameMode: getRuntimeGameMode(),
        enabledGames: getActiveGameTypes(),
        defaultGame: getDefaultGameType(),
    };
}

function resolvePanelGameType(req, { strict = false } = {}) {
    const { gameMode, enabledGames, defaultGame } = buildPanelGameConfig();
    const headerValue = req.headers[PANEL_GAME_HEADER];
    const queryValue = typeof req.query?._game === 'string' ? req.query._game : null;
    const requestedGameType = typeof headerValue === 'string' && headerValue.trim()
        ? headerValue
        : queryValue;

    if (!isMultiGameModeEnabled()) {
        return { ok: true, gameType: defaultGame };
    }

    if (typeof requestedGameType !== 'string' || !requestedGameType.trim()) {
        if (strict) {
            return { ok: false, status: 400, error: 'Game context is required in both mode' };
        }
        return { ok: true, gameType: null };
    }

    const resolvedGameType = normalizeGameType(requestedGameType, null);
    if (!resolvedGameType || !enabledGames.includes(resolvedGameType)) {
        return { ok: false, status: 400, error: `Invalid game type. Expected one of: ${enabledGames.join(', ')}` };
    }

    return { ok: true, gameType: resolvedGameType, gameMode };
}

function ensurePanelGameContext(req, res, next) {
    const result = resolvePanelGameType(req, { strict: true });
    if (!result.ok) {
        return res.status(result.status).json({ error: result.error });
    }

    req.panelGameType = result.gameType;
    next();
}

function getAccessibleAlliances(adminData, gameType = getDefaultGameType()) {
    const isOwner = adminData.is_owner;
    const hasFullAccess = isOwner || (adminData.permissions & PERMISSIONS.FULL_ACCESS);

    if (hasFullAccess) {
        return allianceQueries.getAllAlliances(gameType);
    }

    const assignedIds = parseJsonSafe(adminData.alliances, []);
    return allianceQueries.getAllAlliances(gameType).filter(alliance => assignedIds.includes(alliance.id));
}

function getAttendanceAccessibleAlliances(adminData, gameType = getDefaultGameType()) {
    if (!adminData) return [];
    const isOwner = !!adminData.is_owner;
    const hasFullAccess = isOwner || (adminData.permissions & PERMISSIONS.FULL_ACCESS);

    if (hasFullAccess) {
        return allianceQueries.getAllAlliances(gameType);
    }

    const assignedIds = parseJsonSafe(adminData.alliances, []).map(Number);
    return allianceQueries
        .getAllAlliances(gameType)
        .filter(alliance => assignedIds.includes(alliance.id));
}

function canAccessAttendanceForAnyGame(adminData) {
    if (!adminData) return false;
    return getActiveGameTypes().some(gameType => getAttendanceAccessibleAlliances(adminData, gameType).length > 0);
}

function canAccessAttendancePanel(req) {
    return !!req?.isAdmin && getAttendanceAccessibleAlliances(req.adminData, req.panelGameType).length > 0;
}

function enrichProcessForPanel(process) {
    const gameType = resolveProcessGameType(process);
    let progressPercent = 0;
    try {
        const progress = JSON.parse(process.progress || '{}');
        const pendingCount = progress.pending?.length || 0;
        const doneCount = progress.done?.length || 0;
        const failedCount = progress.failed?.length || 0;
        const existingCount = progress.existing?.length || 0;
        const changedCount = progress.changed?.length || 0;
        const unchangedCount = progress.unchanged?.length || 0;
        const processedCount = doneCount + failedCount + existingCount + changedCount + unchangedCount;
        const total = pendingCount + processedCount;
        progressPercent = total > 0 ? Math.round((processedCount / total) * 100) : 0;
    } catch {
        progressPercent = 0;
    }

    return {
        ...process,
        game_type: gameType,
        game_label: getGameProfile(gameType).shortLabel,
        progressPercent,
    };
}

function enrichSystemLogForPanel(log) {
    let details = null;
    try {
        details = JSON.parse(log.extra_details || '{}');
    } catch {
        details = null;
    }

    let gameType = normalizeGameType(details?.game_type || details?.gameType, null);
    const processId = parseInt(details?.process_id || details?.processId, 10);
    if (!gameType && !isNaN(processId)) {
        const process = processQueries.getProcessById(processId);
        if (process) {
            gameType = resolveProcessGameType(process);
        }
    }

    return {
        ...log,
        game_type: gameType || null,
        game_label: gameType ? getGameProfile(gameType).shortLabel : null,
    };
}

function matchesPanelGameOrGlobal(recordGameType, selectedGameType) {
    return !recordGameType || recordGameType === selectedGameType;
}

function buildProcessStatsForPanel(gameType) {
    const processes = [
        ...processQueries.getProcessesByStatus('active'),
        ...processQueries.getProcessesByStatus('queued')
    ]
        .map(enrichProcessForPanel)
        .filter(process => process.game_type === gameType);

    const statsMap = new Map();
    for (const process of processes) {
        const current = statsMap.get(process.status) || {
            status: process.status,
            count: 0,
            avg_priority: 0,
            priorityTotal: 0
        };

        current.count += 1;
        current.priorityTotal += Number(process.priority) || 0;
        statsMap.set(process.status, current);
    }

    return [...statsMap.values()].map(stat => ({
        status: stat.status,
        count: stat.count,
        avg_priority: stat.count > 0 ? stat.priorityTotal / stat.count : 0
    }));
}

function getPanelLogsQueryBatch(typeFilter, limit, offset) {
    return typeFilter
        ? systemLogQueries.getLogsByTypePage(typeFilter, limit, offset)
        : systemLogQueries.getLogsPage(limit, offset);
}

function getPanelLogsTotalRows(typeFilter) {
    return typeFilter
        ? systemLogQueries.countLogsByType(typeFilter)
        : systemLogQueries.countAllLogs();
}

function getPanelLogsPageData(selectedGameType, typeFilter, page, limit) {
    const batchSize = Math.max(200, limit * 4);
    const targetStart = page * limit;
    const targetEnd = targetStart + limit;
    const totalRows = getPanelLogsTotalRows(typeFilter);

    let scannedOffset = 0;
    let filteredCount = 0;
    const pagedLogs = [];

    while (scannedOffset < totalRows) {
        const batch = getPanelLogsQueryBatch(typeFilter, batchSize, scannedOffset);
        if (!batch.length) {
            break;
        }

        for (const rawLog of batch) {
            const log = enrichSystemLogForPanel(rawLog);
            if (!matchesPanelGameOrGlobal(log.game_type, selectedGameType)) {
                continue;
            }

            if (filteredCount >= targetStart && filteredCount < targetEnd) {
                pagedLogs.push(log);
            }
            filteredCount += 1;
        }

        scannedOffset += batch.length;
    }

    return { logs: pagedLogs, total: filteredCount };
}

/**
 * Escape a string for safe insertion into HTML attributes/content.
 * Prevents XSS from user-controlled values like x-forwarded-prefix.
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

let serverInstance = null;
let runningPort = null;
let publicAddress = null;
const lifecycleState = global.__webPanelServerLifecycle || (global.__webPanelServerLifecycle = {
    startPromise: null,
    stopPromise: null,
});

// ── JWT Issuer (used by wsClient for central OAuth2) ──────────────────────────

/**
 * Issue a signed JWT for a Discord user authenticated by the central server.
 * Called by wsClient when the central hub relays an `issue_jwt` message.
 *
 * @param {string} discordId
 * @param {string} username
 * @param {string|null} avatar
 * @returns {{ ok: boolean, jwt?: string, error?: string, statusCode?: number }}
 */
function issueJwtForDiscordUser(discordId, username, avatar) {
    const adminData = adminQueries.getAdmin(discordId);
    const isOwner = !!(adminData?.is_owner);
    const userData = adminData ? null : userQueries.getUser(discordId);
    const inUsersTable = !!(adminData || userData);

    if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
        return { ok: false, error: 'Access denied by panel settings', statusCode: 403 };
    }

    if (!adminData && !userData && getPanelAccessLevel() !== PANEL_ACCESS.EVERYONE) {
        return { ok: false, error: 'Your Discord account is not registered with this bot', statusCode: 403 };
    }

    const token = jwt.sign(
        { userId: discordId, username, avatar },
        JWT_SECRET,
        { expiresIn: JWT_EXPIRY }
    );

    return { ok: true, jwt: token };
}

/**
 * Detect the machine's public IP via external service.
 * Falls back to LAN IP from os.networkInterfaces(), then 'localhost'.
 */
async function detectPublicIP() {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        const response = await fetch('https://api.ipify.org?format=json', { signal: controller.signal });
        clearTimeout(timeout);
        if (response.ok) {
            const { ip } = await response.json();
            if (ip) return ip;
        }
    } catch {
        // External service unreachable -- fall back to LAN IP
    }

    try {
        const os = require('os');
        const interfaces = os.networkInterfaces();
        for (const name of Object.keys(interfaces)) {
            for (const iface of interfaces[name]) {
                if (iface.family === 'IPv4' && !iface.internal) return iface.address;
            }
        }
    } catch {
        // os module issue -- fall back
    }

    return 'localhost';
}

// ─────────────────────────────────────────────────────────────────────────────
// Auth middleware
// ─────────────────────────────────────────────────────────────────────────────

/** Feature access bit flag for "everyone" (mirrors FEATURE_ACCESS.EVERYONE) */
const FEATURE_ACCESS_EVERYONE = 1;
/** Feature access bit flag for "no one" (mirrors FEATURE_ACCESS.NO_ONE) */
const FEATURE_ACCESS_NO_ONE = 8;

/**
 * Read the bot's feature_access settings and return which features are publicly
 * accessible (access === EVERYONE). Defaults to true if a feature is not configured.
 * @returns {{ calculators: boolean, privateNotifications: boolean }}
 */
function getPublicFeatures() {
    try {
        const row = settingsQueries.getFeatureAccess.get();
        const parsed = JSON.parse(row?.feature_access || '{}');
        return {
            calculators: isFeaturePublic('calculators', parsed),
            privateNotifications: isFeaturePublic('privateNotifications', parsed),
        };
    } catch {
        return { calculators: false, privateNotifications: false };
    }
}

/**
 * @param {string} featureName
 * @param {object} parsed - Parsed feature_access JSON object
 * @returns {boolean}
 */
function isFeaturePublic(featureName, parsed) {
    const featureCfg = parsed[featureName];
    if (!featureCfg || typeof featureCfg !== 'object') return true; // not configured → everyone
    const access = Number(featureCfg.access) || FEATURE_ACCESS_EVERYONE;
    if (access & FEATURE_ACCESS_NO_ONE) return false;
    return !!(access & FEATURE_ACCESS_EVERYONE);
}

function attachAuthContext(req, payload) {
    const adminData = adminQueries.getAdmin(payload.userId);
    const isOwner = !!(adminData?.is_owner);
    const userData = adminData ? null : userQueries.getUser(payload.userId);
    const inUsersTable = !!(adminData || userData);

    if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
        return { ok: false, status: 403, error: 'Access restricted' };
    }

    req.userId = payload.userId;
    req.discordUsername = payload.username || null;
    req.discordAvatar = payload.avatar || null;
    req.publicFeatures = getPublicFeatures();

    if (adminData) {
        req.adminData = adminData;
        req.isAdmin = true;
        return { ok: true };
    }

    req.adminData = null;
    req.isAdmin = false;
    return { ok: true };
}

function maybeAttachAuthFromCookie(req, res) {
    const token = req.cookies?.panel_token;
    if (!token) {
        return { ok: true, authenticated: false };
    }

    try {
        const payload = jwt.verify(token, JWT_SECRET);
        const result = attachAuthContext(req, payload);
        if (!result.ok) {
            res.clearCookie('panel_token');
            return { ...result, authenticated: false };
        }
        return { ok: true, authenticated: true };
    } catch {
        res.clearCookie('panel_token');
        return { ok: false, authenticated: false, status: 401, error: 'Session expired' };
    }
}

function requireAuth(req, res, next) {
    const token = req.cookies?.panel_token;
    if (!token) return res.status(401).json({ error: 'Not authenticated' });

    try {
        const payload = jwt.verify(token, JWT_SECRET);
        const adminData = adminQueries.getAdmin(payload.userId);
        const isOwner = !!(adminData?.is_owner);
        const userData = adminData ? null : userQueries.getUser(payload.userId);
        const inUsersTable = !!(adminData || userData);

        if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
            res.clearCookie('panel_token');
            return res.status(403).json({ error: 'Access restricted' });
        }

        if (adminData) {
            req.userId = payload.userId;
            req.adminData = adminData;
            req.isAdmin = true;
        } else {
            if (!userData) {
                // Access level is everyone — allow unauthenticated Discord users
                // (they were issued a JWT via OAuth2 but have no bot record)
                req.userId = payload.userId;
                req.adminData = null;
                req.isAdmin = false;
                req.publicFeatures = getPublicFeatures();
            } else {
                req.userId = payload.userId;
                req.adminData = null;
                req.isAdmin = false;
                req.publicFeatures = getPublicFeatures();
            }
        }

        req.discordUsername = payload.username || null;
        req.discordAvatar = payload.avatar || null;
        next();
    } catch {
        res.clearCookie('panel_token');
        return res.status(401).json({ error: 'Session expired' });
    }
}

/**
 * Permission check middleware factory.
 * Owner always passes. Non-admins always fail. Otherwise checks if user has any of the listed permissions.
 * @param  {...number} perms - Permission bit flags required (any match passes)
 */
function requirePermission(...perms) {
    return (req, res, next) => {
        if (!req.isAdmin) return res.status(403).json({ error: 'Insufficient permissions' });
        if (req.adminData.is_owner) return next();
        const hasAccess = perms.some(p => req.adminData.permissions & p);
        if (!hasAccess) return res.status(403).json({ error: 'Insufficient permissions' });
        next();
    };
}

function hasAdminPermission(req, ...perms) {
    if (!req?.isAdmin) return false;
    if (req.adminData?.is_owner) return true;
    return perms.some((perm) => req.adminData.permissions & perm);
}

function canManageNotification(req, notification = null, requestedType = null) {
    if (hasAdminPermission(req, PERMISSIONS.NOTIFICATIONS_MANAGEMENT, PERMISSIONS.FULL_ACCESS)) {
        return true;
    }

    if (!req.publicFeatures?.privateNotifications) return false;
    if (!notification) return requestedType === 'private';

    return !notification.guild_id && notification.created_by === req.userId;
}

function requireOwner(req, res, next) {
    if (!req.isAdmin || !req.adminData?.is_owner) {
        return res.status(403).json({ error: 'Owner access required' });
    }
    next();
}

function canManageAllReservations(req) {
    return hasAdminPermission(req, PERMISSIONS.FULL_ACCESS);
}

function canAccessReservationsPanel(req) {
    return hasAdminPermission(req, PERMISSIONS.FULL_ACCESS, WEB_PANEL_PERMISSIONS.RESERVATIONS_MANAGEMENT);
}

function canManageAllGuides(req) {
    return hasAdminPermission(req, PERMISSIONS.FULL_ACCESS);
}

function canAccessGuidesPanel(req) {
    return hasAdminPermission(req, PERMISSIONS.FULL_ACCESS, WEB_PANEL_PERMISSIONS.GUIDE_MANAGEMENT);
}

function requireReservationAccess(req, res, next) {
    if (!canAccessReservationsPanel(req)) {
        return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
}

function requireReservationListAccess(req, res, next) {
    if (!canAccessReservationsPanel(req)) {
        return res.status(403).json({ error: 'Insufficient permissions' });
    }

    if (canManageAllReservations(req)) {
        return next();
    }

    if (positionReservations.canUserAccessList(req.params.listId, req.userId, false, req.panelGameType)) {
        return next();
    }

    return res.status(404).json({ error: 'Reservation list not found' });
}

function requireGuideAccess(req, res, next) {
    if (!canAccessGuidesPanel(req)) {
        return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
}

function requireGuideDetailAccess(req, res, next) {
    if (!canAccessGuidesPanel(req)) {
        return res.status(403).json({ error: 'Insufficient permissions' });
    }

    if (canManageAllGuides(req)) {
        return next();
    }

    if (guides.canUserAccessGuide(req.params.guideId, req.userId, false, req.panelGameType)) {
        return next();
    }

    return res.status(404).json({ error: 'Guide not found' });
}

function requireAttendanceAccess(req, res, next) {
    if (!canAccessAttendancePanel(req)) {
        return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
}

function getAccessibleAttendanceRecord(req, recordId) {
    const detail = attendance.getRecordDetail(recordId, req.panelGameType);
    if (!detail) return null;

    const accessibleIds = new Set(
        getAttendanceAccessibleAlliances(req.adminData, req.panelGameType).map(alliance => alliance.id)
    );
    return accessibleIds.has(detail.allianceId) ? detail : null;
}

function getAccessibleAttendanceAlliance(req, allianceId) {
    const normalizedAllianceId = Number.parseInt(allianceId, 10);
    if (!Number.isInteger(normalizedAllianceId)) return null;

    return getAttendanceAccessibleAlliances(req.adminData, req.panelGameType)
        .find(alliance => alliance.id === normalizedAllianceId) || null;
}

function enrichAttendanceRecord(record, allianceMap) {
    if (!record) return null;
    const alliance = allianceMap.get(record.allianceId);
    const enriched = {
        ...record,
        allianceName: alliance?.name || 'Unknown Alliance',
        alliancePriority: alliance?.priority ?? null,
    };
    if (Array.isArray(enriched.players) && enriched.players.length > 0) {
        enriched.players = attachPlayerNicknames(enriched.players, record.gameType);
    }
    return enriched;
}

// Attach nickname (primary display name) to player rows, looking them up in one batch.
function attachPlayerNicknames(players, gameType) {
    const fids = players.map(player => player.fid).filter(fid => fid != null);
    if (fids.length === 0) return players;

    const nicknameByFid = new Map();
    for (const player of playerQueries.getPlayersByFids(fids, gameType)) {
        nicknameByFid.set(String(player.fid), player.nickname || '');
    }
    return players.map(player => ({
        ...player,
        nickname: nicknameByFid.get(String(player.fid)) || ''
    }));
}

function logAttendanceAction(userId, code, details = {}) {
    adminLogQueries.addLog(userId, code, JSON.stringify(details));
}

const ALL_PERMISSION_FLAGS = [...Object.values(PERMISSIONS), ...Object.values(WEB_PANEL_PERMISSIONS)].reduce((sum, flag) => sum | flag, 0);

function normalizeAdminUserId(value) {
    const userId = String(value || '').trim();
    if (!/^\d{16,22}$/.test(userId)) {
        throw new Error('Enter a valid Discord user ID');
    }
    return userId;
}

function normalizePermissionMask(value) {
    const parsed = Number(value);
    if (!Number.isInteger(parsed) || parsed < 0) {
        throw new Error('Invalid permissions value');
    }
    if ((parsed | ALL_PERMISSION_FLAGS) !== ALL_PERMISSION_FLAGS) {
        throw new Error('Permissions include unsupported flags');
    }
    return parsed;
}

function normalizeSearchText(value) {
    return String(value || '')
        .toLowerCase()
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]/g, '');
}

function isSubsequenceMatch(query, target) {
    if (!query || !target) return false;
    let queryIndex = 0;
    for (let i = 0; i < target.length && queryIndex < query.length; i++) {
        if (target[i] === query[queryIndex]) {
            queryIndex += 1;
        }
    }
    return queryIndex === query.length;
}

function levenshteinDistance(a, b) {
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;

    const previous = Array.from({ length: b.length + 1 }, (_, index) => index);
    const current = new Array(b.length + 1);

    for (let i = 1; i <= a.length; i++) {
        current[0] = i;
        for (let j = 1; j <= b.length; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            current[j] = Math.min(
                current[j - 1] + 1,
                previous[j] + 1,
                previous[j - 1] + cost
            );
        }
        for (let j = 0; j <= b.length; j++) previous[j] = current[j];
    }

    return previous[b.length];
}

function scoreMemberSearch(query, candidate) {
    const normalizedQuery = normalizeSearchText(query);
    const values = [
        candidate.displayName,
        candidate.globalName,
        candidate.username,
        candidate.nickname,
    ]
        .map(normalizeSearchText)
        .filter(Boolean);

    let bestScore = Number.POSITIVE_INFINITY;

    for (const value of values) {
        if (value === normalizedQuery) return 0;
        if (value.startsWith(normalizedQuery)) bestScore = Math.min(bestScore, 1);
        if (value.includes(normalizedQuery)) bestScore = Math.min(bestScore, 2);
        if (isSubsequenceMatch(normalizedQuery, value)) {
            bestScore = Math.min(bestScore, 3 + Math.max(0, value.length - normalizedQuery.length) * 0.05);
        }

        const compareWindow = value.length > normalizedQuery.length + 2
            ? value.slice(0, Math.min(value.length, normalizedQuery.length + 2))
            : value;
        const distance = levenshteinDistance(normalizedQuery, compareWindow);
        const maxDistance = normalizedQuery.length <= 4 ? 1 : 2;
        if (distance <= maxDistance) {
            bestScore = Math.min(bestScore, 4 + distance);
        }
    }

    return Number.isFinite(bestScore) ? bestScore : null;
}

/**
 * Renders a branded full-page error screen (used for auth-time rejections
 * where the SPA hasn't loaded yet, e.g. "not an admin").
 * @param {string} title - Page title and heading
 * @param {string} message - HTML body text
 * @param {Object} opts
 * @param {string} [opts.basePath] - URL prefix (from x-forwarded-prefix or BASE_PATH)
 * @param {string} [opts.iconSrc] - Path to icon image (relative to basePath)
 * @param {string} [opts.actionLabel] - Button text
 * @param {string} [opts.actionHref] - Button URL
 */
function renderErrorPage(title, message, { basePath = BASE_PATH, iconSrc = '/icons/access-denied.png', actionLabel, actionHref } = {}) {
    const safeBasePath = escapeHtml(basePath);
    const safeTitle = escapeHtml(title);
    const safeIconSrc = escapeHtml(iconSrc);
    const actionHTML = actionLabel && actionHref
        ? `<a class="error-action" href="${escapeHtml(actionHref)}">${escapeHtml(actionLabel)}</a>`
        : '';
    const iconHTML = `<img src="${safeBasePath}${safeIconSrc}" alt="" width="48" height="48">`;

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#090916">
    <meta name="color-scheme" content="dark">
    <title>${safeTitle}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            background: #090916; color: #e8eaf0;
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
            position: relative; overflow: hidden;
        }
        body::before {
            content: ''; position: absolute; inset: 0;
            background:
                radial-gradient(ellipse 800px 400px at 50% 40%, rgba(248,113,113,0.08) 0%, transparent 70%),
                radial-gradient(ellipse 400px 300px at 30% 60%, rgba(167,139,250,0.06) 0%, transparent 70%);
            pointer-events: none;
        }
        .error-card {
            position: relative; z-index: 1;
            background: rgba(22, 22, 55, 0.65);
            backdrop-filter: blur(30px); -webkit-backdrop-filter: blur(30px);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 20px; padding: 48px 40px;
            text-align: center; max-width: 580px; width: 90%;
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
            animation: fadeIn 0.5s ease-out;
        }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: none; } }
        .error-icon {
            width: 72px; height: 72px;
            background: rgba(248,113,113,0.12); border: 1px solid rgba(248,113,113,0.25);
            border-radius: 16px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 20px;
        }
        .error-icon img { width: 48px; height: 48px; object-fit: contain; }
        h1 { font-size: 22px; font-weight: 700; margin-bottom: 10px; letter-spacing: -0.3px; }
        .error-message { color: #8b8da8; font-size: 14px; line-height: 1.7; margin-bottom: 24px; }
        .error-action {
            display: inline-block; padding: 10px 28px;
            background: rgba(99,139,255,0.12); border: 1px solid rgba(99,139,255,0.25);
            border-radius: 10px; color: #638bff; text-decoration: none;
            font-size: 14px; font-weight: 500; transition: background 0.2s, border-color 0.2s;
        }
        .error-action:hover { background: rgba(99,139,255,0.2); border-color: rgba(99,139,255,0.4); }
    </style>
</head>
<body>
    <div class="error-card">
        <div class="error-icon">${iconHTML}</div>
        <h1>${safeTitle}</h1>
        <p class="error-message">${message}</p>
        ${actionHTML}
    </div>
</body>
</html>`;
}

function createOAuthSupportCode() {
    return `OAUTH-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function logOAuthDiagnostic(code, phase, details = {}) {
    console.error(`[Web Panel OAuth2][${code}] ${phase}`, JSON.stringify(details));
}

function withDevSupportNote(message, supportCode) {
    return `${message}<br><br><strong>Share this with the dev:</strong> ${escapeHtml(supportCode)}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Server factory
// ─────────────────────────────────────────────────────────────────────────────
function createServer(client) {
    const app = express();
    // Trust the immediately upstream proxy (central-proxy or any reverse proxy).
    // Required so req.ip returns the real client IP rather than the proxy address,
    // which makes the auth rate limiter work correctly per-user.
    app.set('trust proxy', 1);
    const router = express.Router();
    const guideImageUpload = multer({
        storage: multer.memoryStorage(),
        limits: {
            fileSize: GUIDE_IMAGE_UPLOAD_LIMIT_BYTES,
            files: 1,
        },
        fileFilter(_req, file, callback) {
            const mimeType = String(file?.mimetype || '').trim().toLowerCase();
            if (!guides.GUIDE_IMAGE_MIME_TYPES.includes(mimeType)) {
                callback(new Error('Uploaded file must be a PNG, JPEG, WebP, or GIF image'));
                return;
            }
            callback(null, true);
        },
    });

    router.use(express.json({ limit: '1mb' }));
    router.use(cookieParser());
    router.use([
        '/api/dashboard',
        '/api/players',
        '/api/alliances',
        '/api/attendance',
        '/api/processes',
        '/api/giftcodes',
        '/api/guides',
        '/api/admin/position-reservations',
        '/api/logs',
        '/api/calculators',
    ], ensurePanelGameContext);

    // ── CSRF protection for state-changing requests ──────────────────────
    router.use((req, res, next) => {
        if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

        const origin = req.headers['origin'];
        const referer = req.headers['referer'];

        // Allow requests with no origin (same-origin, cURL, non-browser)
        if (!origin && !referer) return next();

        // Validate origin matches our host or the forwarded host (reverse proxy)
        const host = req.headers['x-forwarded-host'] || req.headers['host'];
        if (origin) {
            try {
                const originHost = new URL(origin).host;
                if (originHost !== host) {
                    return res.status(403).json({ error: 'Cross-origin request blocked' });
                }
            } catch {
                return res.status(403).json({ error: 'Invalid origin' });
            }
        }

        next();
    });
    router.use('/images/calculators', express.static(path.join(__dirname, 'public', 'images', 'calculators'), {
        index: false,
        maxAge: '1h',
        etag: true,
        lastModified: true,
        setHeaders(res) {
            res.setHeader('Cache-Control', 'public, max-age=3600');
        },
    }));
    router.use(express.static(path.join(__dirname, 'public'), { index: false }));

    // HTML template — re-read on every request so rebuilds take effect without restart
    const indexPath = path.join(__dirname, 'public', 'index.html');
    let cachedHtml = null;
    let cachedHtmlMtime = 0;

    function getIndexHtml() {
        const mtime = fs.statSync(indexPath).mtimeMs;
        if (!cachedHtml || mtime !== cachedHtmlMtime) {
            cachedHtml = fs.readFileSync(indexPath, 'utf8');
            cachedHtmlMtime = mtime;
        }
        return cachedHtml;
    }

    const publicDir = path.join(__dirname, 'public');

    // ── Rate limiter for auth endpoints ──────────────────────────────────
    const authRateMap = new Map();
    const AUTH_RATE_WINDOW_MS = 60 * 1000;
    const AUTH_RATE_MAX = 10;
    const guideOAuthStateMap = new Map();
    const GUIDE_OAUTH_STATE_EXPIRY_MS = 5 * 60 * 1000;

    /**
     * Simple per-IP rate limiter middleware for auth routes.
     */
    function authRateLimit(req, res, next) {
        const ip = req.ip || req.connection.remoteAddress;
        const now = Date.now();
        let entry = authRateMap.get(ip);
        if (!entry || now > entry.resetAt) {
            entry = { count: 0, resetAt: now + AUTH_RATE_WINDOW_MS };
            authRateMap.set(ip, entry);
        }
        entry.count++;
        if (entry.count > AUTH_RATE_MAX) {
            return res.status(429).json({ error: 'Too many requests. Please try again later.' });
        }
        next();
    }

    // Clean up stale rate-limit entries every 5 minutes
    setInterval(() => {
        const now = Date.now();
        for (const [ip, entry] of authRateMap) {
            if (now > entry.resetAt) authRateMap.delete(ip);
        }
    }, 5 * 60 * 1000).unref();

    setInterval(() => {
        const now = Date.now();
        for (const [state, entry] of guideOAuthStateMap) {
            if (now > entry.expiresAt) guideOAuthStateMap.delete(state);
        }
    }, 10 * 60 * 1000).unref();

    function generateGuideOAuthState(slug) {
        const state = crypto.randomBytes(32).toString('hex');
        guideOAuthStateMap.set(state, {
            slug,
            expiresAt: Date.now() + GUIDE_OAUTH_STATE_EXPIRY_MS,
        });
        return state;
    }

    function consumeGuideOAuthState(state) {
        const entry = guideOAuthStateMap.get(state);
        if (!entry) return null;
        guideOAuthStateMap.delete(state);
        if (Date.now() > entry.expiresAt) return null;
        return entry;
    }

    function buildSessionCookieOptions(req) {
        return {
            httpOnly: true,
            sameSite: 'lax',
            secure: req.secure || req.headers['x-forwarded-proto'] === 'https',
            maxAge: 30 * 24 * 60 * 60 * 1000,
        };
    }

    function setGuideViewerCookie(req, res, payload) {
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
        res.cookie(GUIDE_VIEWER_COOKIE_NAME, token, buildSessionCookieOptions(req));
    }

    function buildGuidePasswordCookieName(guideId) {
        return `${GUIDE_PASSWORD_COOKIE_PREFIX}${String(guideId || '').replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    }

    function setGuidePasswordAccessCookie(req, res, guideId, passwordHash) {
        const token = jwt.sign({ guideId, access: 'password', fingerprint: passwordHash }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
        res.cookie(buildGuidePasswordCookieName(guideId), token, buildSessionCookieOptions(req));
    }

    function hasGuidePasswordAccess(req, res, guideId, passwordHash) {
        const cookieName = buildGuidePasswordCookieName(guideId);
        const token = req.cookies?.[cookieName];
        if (!token) return false;

        try {
            const payload = jwt.verify(token, JWT_SECRET);
            return payload?.guideId === guideId && payload?.access === 'password' && payload?.fingerprint === passwordHash;
        } catch {
            res.clearCookie(cookieName);
            return false;
        }
    }

    function getGuideViewerIdentity(req, res) {
        const viewerToken = req.cookies?.[GUIDE_VIEWER_COOKIE_NAME];
        if (viewerToken) {
            try {
                const payload = jwt.verify(viewerToken, JWT_SECRET);
                if (payload?.userId) {
                    return {
                        userId: payload.userId,
                        username: payload.username || 'User',
                        avatar: payload.avatar || null,
                        source: 'guide',
                    };
                }
            } catch {
                res.clearCookie(GUIDE_VIEWER_COOKIE_NAME);
            }
        }

        const panelToken = req.cookies?.panel_token;
        if (panelToken) {
            try {
                const payload = jwt.verify(panelToken, JWT_SECRET);
                if (payload?.userId) {
                    return {
                        userId: payload.userId,
                        username: payload.username || 'User',
                        avatar: payload.avatar || null,
                        source: 'panel',
                    };
                }
            } catch {
                // Ignore invalid panel cookies here. The panel auth flow manages its own cleanup.
            }
        }

        return null;
    }

    // ── Auth routes ──────────────────────────────────────────────────────

    // OAuth2 login — redirect to Discord
    router.get('/auth/login', authRateLimit, (req, res) => {
        const prefix = req.headers['x-forwarded-prefix'] || BASE_PATH;

        // Legacy token-based login (still supported as fallback)
        const { token } = req.query;
        if (token) {
            const userId = validateLoginToken(token);
            if (!userId) return res.status(401).send(renderErrorPage('Link Expired', 'This login link is invalid or has expired.<br>Use the <strong>/webpanel</strong> command in Discord to get a new one.', {
                    basePath: prefix,
                    actionLabel: 'Back to Discord',
                    actionHref: 'https://discord.com/channels/@me'
                }));

            const adminData = adminQueries.getAdmin(userId);
            const isOwner = !!(adminData?.is_owner);
            const userData = adminData ? null : userQueries.getUser(userId);
            const inUsersTable = !!(adminData || userData);

            if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
                return res.status(403).send(renderErrorPage('Access Denied', 'The bot owner has restricted access to this panel.<br>Contact the bot owner for access.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }
            if (!adminData && !userData) {
                return res.status(403).send(renderErrorPage('Access Denied', 'Your Discord account is not registered for this bot.<br>Ask the bot owner to add you as an admin, or use the bot in Discord first.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }

            const jwtToken = jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
            res.cookie('panel_token', jwtToken, buildSessionCookieOptions(req));

            return res.redirect(BASE_PATH + '/?oauth=complete');
        }

        // OAuth2 login
        if (!isOAuth2Configured() || !client.application?.id) {
            const legacyRegistrationWithoutOAuth = centralProxy.hasStoredLegacyConfig() && !isOAuth2Configured();
            const message = legacyRegistrationWithoutOAuth
                ? 'This panel is still registered in legacy mode, but its old local Discord login secret is missing.<br>The bot owner needs to run <strong>/webpanel</strong> in Discord and upgrade it to WS Hub mode.'
                : 'The bot owner hasn\u2019t set up Discord login yet.<br>Use the <strong>/webpanel</strong> command in Discord to start setup.';
            return res.status(503).send(renderErrorPage('OAuth2 Not Configured', message, {
                basePath: prefix,
                actionLabel: 'Back to Discord',
                actionHref: 'https://discord.com/channels/@me'
            }));
        }

        const redirectUri = getOAuthRedirectUri(req, BASE_PATH, centralProxy.getPublicUrl());

        const oauthUrl = buildOAuth2Url(client.application.id, redirectUri, generateOAuth2State());
        res.redirect(oauthUrl);
    });

    router.get('/auth/guide-login', authRateLimit, (req, res) => {
        const prefix = req.headers['x-forwarded-prefix'] || BASE_PATH;
        const slug = String(req.query.slug || '').trim();
        const guide = guides.getPublicGuideBySlug(slug);

        if (!guide) {
            return res.status(404).send(renderErrorPage('Guide Not Found', 'This guide is unavailable or no longer published.', {
                basePath: prefix,
                iconSrc: '/icons/access-denied.png',
            }));
        }

        if (!['discord_bot_user', 'discord_mutual_guild'].includes(guide.accessMode)) {
            return res.status(400).send(renderErrorPage('Guide Login Not Required', 'This guide does not use Discord login access.', {
                basePath: prefix,
                actionLabel: 'Open Guide',
                actionHref: `${prefix}/g/${encodeURIComponent(guide.publicSlug)}`,
            }));
        }

        if (!isOAuth2Configured() || !client.application?.id) {
            const legacyRegistrationWithoutOAuth = centralProxy.hasStoredLegacyConfig() && !isOAuth2Configured();
            const message = legacyRegistrationWithoutOAuth
                ? 'This guide uses Discord login, but the panel is still on legacy mode without its old local Discord login secret.<br>The bot owner needs to run <strong>/webpanel</strong> in Discord and upgrade it to WS Hub mode.'
                : 'The bot owner hasn’t set up Discord login yet.';
            return res.status(503).send(renderErrorPage('OAuth2 Not Configured', message, {
                basePath: prefix,
                actionLabel: 'Back',
                actionHref: `${prefix}/g/${encodeURIComponent(guide.publicSlug)}`,
            }));
        }

        const redirectUri = getOAuthRedirectUri(req, BASE_PATH, centralProxy.getPublicUrl());

        const oauthUrl = buildOAuth2Url(client.application.id, redirectUri, generateGuideOAuthState(guide.publicSlug));
        res.redirect(oauthUrl);
    });

    // OAuth2 callback — exchange code for user identity
    router.get('/auth/callback', authRateLimit, async (req, res) => {
        const prefix = req.headers['x-forwarded-prefix'] || BASE_PATH;

        const { code, state, error } = req.query;

        if (typeof error === 'string') {
            const supportCode = createOAuthSupportCode();
            logOAuthDiagnostic(supportCode, 'discord_callback_error', {
                error,
                hasCode: !!code,
                hasState: typeof state === 'string'
            });
            return res.status(401).send(renderErrorPage('Authentication Cancelled', withDevSupportNote('Discord did not complete the login flow.<br>Please try again and approve access when prompted.', supportCode), {
                basePath: prefix,
                actionLabel: 'Try Again',
                actionHref: prefix + '/auth/login'
            }));
        }

        if (!code) return res.status(400).send(renderErrorPage('Invalid Request', 'The authorization code is missing.<br>Please try logging in again from Discord.', {
            basePath: prefix,
            actionLabel: 'Try Again',
            actionHref: prefix + '/auth/login'
        }));

        const guideOAuthEntry = typeof state === 'string' ? consumeGuideOAuthState(state) : null;
        if (!guideOAuthEntry && (!state || !validateOAuth2State(state))) {
            return res.status(403).send(renderErrorPage('Invalid Request', 'The login session has expired or was tampered with.<br>Please try logging in again.', {
                basePath: prefix,
                actionLabel: 'Try Again',
                actionHref: prefix + '/auth/login'
            }));
        }

        const clientSecret = getClientSecret();
        if (!clientSecret || !client.application?.id) {
            return res.status(503).send(renderErrorPage('OAuth2 Not Configured', 'The bot owner hasn\u2019t finished setting up Discord login.<br>Use the <strong>/webpanel</strong> command in Discord to complete setup.', {
                basePath: prefix,
                actionLabel: 'Back to Discord',
                actionHref: 'https://discord.com/channels/@me'
            }));
        }

        const redirectUri = getOAuthRedirectUri(req, BASE_PATH, centralProxy.getPublicUrl());

        try {
            const tokenData = await exchangeCode(code, client.application.id, clientSecret, redirectUri);
            if (!tokenData?.access_token) {
                const supportCode = createOAuthSupportCode();
                logOAuthDiagnostic(supportCode, 'token_exchange_no_access_token', {
                    redirectUriHost: (() => {
                        try { return new URL(redirectUri).host; } catch { return null; }
                    })(),
                    hasTokenData: !!tokenData
                });
                return res.status(401).send(renderErrorPage('Authentication Failed', withDevSupportNote('Discord didn\u2019t return a valid session.<br>This can happen if the login expired or was cancelled. Please try again.', supportCode), {
                    basePath: prefix,
                    actionLabel: 'Try Again',
                    actionHref: prefix + '/auth/login'
                }));
            }

            const discordUser = await fetchDiscordUser(tokenData.access_token);
            if (!discordUser?.id) {
                const supportCode = createOAuthSupportCode();
                logOAuthDiagnostic(supportCode, 'discord_profile_missing', {
                    redirectUriHost: (() => {
                        try { return new URL(redirectUri).host; } catch { return null; }
                    })()
                });
                return res.status(401).send(renderErrorPage('Profile Error', withDevSupportNote('Couldn\u2019t retrieve your Discord profile.<br>This is usually temporary. Please try logging in again.', supportCode), {
                    basePath: prefix,
                    actionLabel: 'Try Again',
                    actionHref: prefix + '/auth/login'
                }));
            }

            const viewerPayload = {
                userId: discordUser.id,
                username: discordUser.global_name || discordUser.username,
                avatar: discordUser.avatar,
            };

            if (guideOAuthEntry?.slug) {
                setGuideViewerCookie(req, res, viewerPayload);
                return res.redirect(`${BASE_PATH}/g/${encodeURIComponent(guideOAuthEntry.slug)}?oauth=complete`);
            }

            const adminData = adminQueries.getAdmin(discordUser.id);
            const isOwner = !!(adminData?.is_owner);
            const userData = adminData ? null : userQueries.getUser(discordUser.id);
            const inUsersTable = !!(adminData || userData);
            if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
                return res.status(403).send(renderErrorPage('Access Denied', 'The bot owner has restricted access to this panel.<br>Contact the bot owner for access.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }
            if (!adminData && !userData && getPanelAccessLevel() !== PANEL_ACCESS.EVERYONE) {
                return res.status(403).send(renderErrorPage('Access Denied', 'Your Discord account is not registered for this bot.<br>Ask the bot owner to add you, or use the bot in Discord first.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }

            const jwtToken = jwt.sign(viewerPayload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
            res.cookie('panel_token', jwtToken, buildSessionCookieOptions(req));

            res.redirect(BASE_PATH + '/?oauth=complete');
        } catch (error) {
            const supportCode = createOAuthSupportCode();
            logOAuthDiagnostic(supportCode, 'oauth_callback_exception', {
                error: error.message,
                redirectUriHost: (() => {
                    try { return new URL(redirectUri).host; } catch { return null; }
                })()
            });
            res.status(500).send(renderErrorPage('Something Went Wrong', withDevSupportNote('Authentication failed due to an unexpected error.<br>Please try again. If the problem persists, contact the bot owner.', supportCode), {
                basePath: prefix,
                actionLabel: 'Try Again',
                actionHref: prefix + '/auth/login'
            }));
        }
    });

    router.post('/auth/logout', (req, res) => {
        res.clearCookie('panel_token');
        res.clearCookie(GUIDE_VIEWER_COOKIE_NAME);
        res.json({ ok: true });
    });

    router.get('/auth/me', requireAuth, (req, res) => {
        const userData = userQueries.getUser(req.userId);
        const avatarHash = req.discordAvatar;
        const panelGameConfig = buildPanelGameConfig();
        const avatarUrl = avatarHash
            ? `https://cdn.discordapp.com/avatars/${req.userId}/${avatarHash}.${avatarHash.startsWith('a_') ? 'gif' : 'webp'}?size=64`
            : `https://cdn.discordapp.com/embed/avatars/${(BigInt(req.userId) >> 22n) % 6n}.png`;

        if (!req.isAdmin) {
            const publicFeatures = getPublicFeatures();
            return res.json({
                userId: req.userId,
                username: req.discordUsername || 'User',
                avatar: avatarUrl,
                permissions: 0,
                isOwner: false,
                isAdmin: false,
                publicFeatures,
                language: userData?.language || 'en',
                ...panelGameConfig
            });
        }

        res.json({
            userId: req.userId,
            username: req.discordUsername || 'Admin',
            avatar: avatarUrl,
            permissions: req.adminData.permissions,
            canAccessAttendance: canAccessAttendanceForAnyGame(req.adminData),
            isOwner: !!req.adminData.is_owner,
            isAdmin: true,
            language: userData?.language || 'en',
            ...panelGameConfig
        });
    });

    // ── Bot info (public, no auth) ───────────────────────────────────────
    router.get('/api/botinfo', (_req, res) => {
        const botUser = client.user;
        res.json({
            name: botUser?.username || 'Bot',
            avatar: botUser?.displayAvatarURL({ size: 64 }) || null,
            // Don't gate on client.application?.id — it may not be set yet on fresh restart.
            // The /auth/login route already handles the "not ready" case with a friendly error.
            hasOAuth2: isOAuth2Configured()
        });
    });

    router.get('/api/public-config', (_req, res) => {
        const publicFeatures = getPublicFeatures();
        res.json({
            guestPublicToolsEnabled: isGuestPublicToolsEnabled(),
            calculatorsPublic: !!publicFeatures.calculators,
            theme: getPanelTheme(),
            ...buildPanelGameConfig(),
        });
    });

    // ── Dashboard ────────────────────────────────────────────────────────
    router.get('/api/public/position-reservations/:publicSlug', (req, res) => {
        const data = positionReservations.getPublicList(req.params.publicSlug);
        if (!data) {
            return res.status(404).json({ error: 'Reservation list not found or unavailable' });
        }
        res.json(data);
    });

    router.post('/api/public/position-reservations/:publicSlug/reserve', async (req, res) => {
        try {
            const list = positionReservations.getPublicList(req.params.publicSlug);
            if (!list) {
                return res.status(404).json({ error: 'Reservation list not found or unavailable' });
            }

            const { category, slotId, slotIds, playerId, allianceTag } = req.body || {};
            const reservation = await positionReservations.reservePublicSlot({
                publicSlug: req.params.publicSlug,
                category,
                slotId,
                slotIds,
                playerId,
                allianceTag,
            });

            res.status(201).json({
                ok: true,
                reservation,
                list: positionReservations.getPublicList(req.params.publicSlug),
            });
        } catch (error) {
            const status = /not found|unavailable/i.test(error.message)
                ? 404
                : /already reserved|category mismatch|not published|limit|does not belong|not available/i.test(error.message)
                    ? 409
                    : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.get('/api/dashboard', requireAuth, (req, res) => {
        try {
            const gameType = req.panelGameType;
            const isOwner = req.adminData.is_owner;
            const perms = req.adminData.permissions;
            const canPlayers = isOwner || (perms & PERMISSIONS.PLAYER_MANAGEMENT) || (perms & PERMISSIONS.ALLIANCE_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canAlliances = isOwner || (perms & PERMISSIONS.ALLIANCE_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canNotifications = isOwner || (perms & PERMISSIONS.NOTIFICATIONS_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canGiftCodes = isOwner || (perms & PERMISSIONS.GIFT_CODE_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canLogs = isOwner || (perms & PERMISSIONS.FULL_ACCESS);

            const counts = {};
            if (canPlayers) counts.players = playerQueries.countPlayers(gameType);
            if (canAlliances) counts.alliances = allianceQueries.countAlliances(gameType);
            if (canNotifications) counts.activeNotifications = notificationQueries.countActiveNotifications();
            if (canGiftCodes) counts.giftCodes = giftCodeQueries.countGiftCodes(gameType);

            const activeProcesses = processQueries.getActiveProcesses()
                .map(enrichProcessForPanel)
                .filter(process => process.game_type === gameType);
            counts.activeProcesses = activeProcesses.length;

            const memUsage = process.memoryUsage();
            const recentLogs = canLogs
                ? systemLogQueries.getRecentLogs(20)
                    .map(enrichSystemLogForPanel)
                    .filter(log => matchesPanelGameOrGlobal(log.game_type, gameType))
                    .slice(0, 10)
                : [];

            res.json({
                counts,
                memory: {
                    heapUsedMB: Math.round(memUsage.heapUsed / 1048576),
                    heapTotalMB: Math.round(memUsage.heapTotal / 1048576),
                    rssMB: Math.round(memUsage.rss / 1048576)
                },
                processStats: buildProcessStatsForPanel(gameType),
                recentLogs,
                uptime: Math.floor(process.uptime())
            });
        } catch (error) {
            console.error('[Web Panel] Dashboard error:', error.message);
            res.status(500).json({ error: 'Failed to load dashboard data' });
        }
    });

    // ── Players ──────────────────────────────────────────────────────────
    router.get('/api/players/:fid', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid ID' });

        const player = playerQueries.getPlayer(fid, req.panelGameType);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        res.json({
            fid: player.fid,
            nickname: player.nickname,
            state: player.state,
            state_override: player.state_override,
            alliance_id: player.alliance_id,
            game_type: player.game_type,
        });
    });

    router.patch('/api/players/:fid', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid ID' });

        const player = playerQueries.getPlayer(fid, req.panelGameType);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        const accessibleAllianceIds = new Set(
            getAccessibleAlliances(req.adminData, req.panelGameType).map(alliance => alliance.id)
        );
        if (!accessibleAllianceIds.has(player.alliance_id)) {
            return res.status(403).json({ error: 'Access denied to this player' });
        }

        const { nickname, state } = req.body;

        if (nickname !== undefined) {
            const trimmedNickname = String(nickname).trim();
            if (trimmedNickname.length > MAX_NICKNAME_LENGTH) {
                return res.status(400).json({ error: `Nickname must be ${MAX_NICKNAME_LENGTH} characters or fewer` });
            }
            playerQueries.updatePlayerNickname(fid, trimmedNickname, req.panelGameType);
        }

        if (state !== undefined) {
            if (state === null || state === '') {
                playerQueries.updatePlayerStateOverride(fid, null, req.panelGameType);
            } else {
                const parsedState = Number(state);
                if (!Number.isSafeInteger(parsedState) || parsedState <= 0) {
                    return res.status(400).json({ error: 'State must be a positive number (or empty to clear the override)' });
                }
                playerQueries.updatePlayerStateOverride(fid, parsedState, req.panelGameType);
            }
        }

        systemLogQueries.addLog(
            'player_settings_update',
            `Player ${fid} settings updated from web panel`,
            JSON.stringify({
                fid,
                game_type: req.panelGameType,
                nickname: nickname !== undefined ? String(nickname).trim() : undefined,
                state_override: state !== undefined ? (state === null || state === '' ? null : Number(state)) : undefined,
                updated_by: req.userId
            })
        );

        res.json({ ok: true });
    });

    router.delete('/api/players/:fid', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid ID' });

        const player = playerQueries.getPlayer(fid, req.panelGameType);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        playerQueries.deletePlayer(fid, req.panelGameType);
        res.json({ ok: true });
    });

    router.post('/api/players/:fid/move', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid ID' });

        const { allianceId } = req.body;
        const targetAllianceId = parseInt(allianceId, 10);
        if (isNaN(targetAllianceId)) return res.status(400).json({ error: 'Invalid target alliance ID' });

        const player = playerQueries.getPlayer(fid, req.panelGameType);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        const targetAlliance = allianceQueries.getAllianceById(targetAllianceId, req.panelGameType);
        if (!targetAlliance) return res.status(404).json({ error: 'Target alliance not found' });
        if (!Number.isSafeInteger(targetAlliance.state) || targetAlliance.state <= 0) {
            return res.status(400).json({ error: 'Set a valid state on the target alliance first' });
        }

        playerQueries.updatePlayerAlliance(fid, targetAllianceId, targetAlliance.state, req.panelGameType);
        res.json({ ok: true });
    });

    router.post('/api/alliances/:id/players', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.FULL_ACCESS), async (req, res) => {
        const allianceId = parseInt(req.params.id, 10);
        if (isNaN(allianceId)) return res.status(400).json({ error: 'Invalid alliance ID' });

        const alliance = allianceQueries.getAllianceById(allianceId, req.panelGameType);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const isOwner = req.adminData.is_owner;
        const hasFullAccess = isOwner || (req.adminData.permissions & PERMISSIONS.FULL_ACCESS);
        if (!hasFullAccess) {
            const assignedIds = parseJsonSafe(req.adminData.alliances, []);
            if (!assignedIds.includes(allianceId)) {
                return res.status(403).json({ error: 'Access denied to this alliance' });
            }
        }

        const rawPlayerIds = String(req.body?.playerIds ?? req.body?.playerId ?? '').trim();
        if (!rawPlayerIds) return res.status(400).json({ error: 'playerIds is required' });

        try {
            const processResult = await createAddPlayerProcess(String(req.userId), allianceId, rawPlayerIds);
            if (!processResult) {
                return res.status(400).json({ error: 'Invalid player ID list' });
            }

            await queueManager.manageQueue(processResult);
            const playerCount = processResult.player_ids ? processResult.player_ids.split(',').length : 0;
            res.status(201).json({ ok: true, processId: processResult.process_id, playerCount });
        } catch (error) {
            console.error('[Web Panel] Add player process creation failed:', error.message);
            res.status(500).json({ error: 'Failed to create add player process' });
        }
    });

    // ── Alliance Create Flow (Step 1 + Step 2) ──────────────────────────
    router.post('/api/alliances', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { name, state } = req.body || {};

        if (!name || typeof name !== 'string' || !name.trim()) {
            return res.status(400).json({ error: 'Alliance name is required' });
        }

        const trimmedName = name.trim();
        if (trimmedName.length < 1 || trimmedName.length > 50) {
            return res.status(400).json({ error: 'Alliance name must be 1-50 characters' });
        }

        const allianceState = Number(state);
        if (!Number.isSafeInteger(allianceState) || allianceState <= 0) {
            return res.status(400).json({ error: 'State must be a positive whole number' });
        }

        const existingAlliances = allianceQueries.getAllAlliances(req.panelGameType);
        const nextPriority = existingAlliances.length + 1;

        const result = allianceQueries.addAlliance(
            nextPriority,
            trimmedName,
            null,
            null,
            0,
            1,
            req.adminData.id,
            req.panelGameType,
            allianceState
        );

        const createdAllianceId = Number(result.lastInsertRowid);
        const createdAlliance = allianceQueries.getAllianceById(createdAllianceId, req.panelGameType);

        res.status(201).json({
            ok: true,
            alliance: createdAlliance
        });
    });

    router.post('/api/alliances/:id/finalize', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), async (req, res) => {
        const allianceId = parseInt(req.params.id, 10);
        if (isNaN(allianceId)) return res.status(400).json({ error: 'Invalid alliance ID' });

        const { guildId, channelId } = req.body || {};
        if (!guildId || !channelId) {
            return res.status(400).json({ error: 'guildId and channelId are required' });
        }

        const alliance = allianceQueries.getAllianceById(allianceId, req.panelGameType);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const isOwner = req.adminData.is_owner;
        const hasFullAccess = isOwner || (req.adminData.permissions & PERMISSIONS.FULL_ACCESS);
        if (!hasFullAccess) {
            const assignedIds = parseJsonSafe(req.adminData.alliances, []);
            if (!assignedIds.includes(allianceId)) {
                return res.status(403).json({ error: 'Access denied to this alliance' });
            }
        }

        const userGuildIds = await getUserGuildIds(req.userId);
        if (!userGuildIds.has(String(guildId))) {
            return res.status(403).json({ error: 'Access denied to this guild' });
        }

        const guild = client.guilds.cache.get(String(guildId));
        if (!guild) return res.status(404).json({ error: 'Guild not found' });

        const selectedChannel = guild.channels.cache.get(String(channelId));
        if (!selectedChannel || selectedChannel.type !== ChannelType.GuildText) {
            return res.status(400).json({ error: 'Invalid channel selection' });
        }

        allianceQueries.updateAlliance(
            alliance.priority,
            alliance.name,
            guild.id,
            selectedChannel.id,
            alliance.interval,
            alliance.auto_redeem,
            allianceId,
            req.panelGameType
        );

        const creatorAlliances = parseJsonSafe(req.adminData.alliances, []);
        if (Array.isArray(creatorAlliances) && !creatorAlliances.includes(allianceId)) {
            creatorAlliances.push(allianceId);
            adminQueries.updateAdminAlliances(JSON.stringify(creatorAlliances), req.userId);
        }

        const finalizedAlliance = allianceQueries.getAllianceById(allianceId, req.panelGameType);
        res.json({ ok: true, alliance: finalizedAlliance });
    });

    // ── Alliances ────────────────────────────────────────────────────────
    router.get('/api/alliances', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const alliances = getAccessibleAlliances(req.adminData, req.panelGameType);

        const allianceIds = alliances.map(a => a.id);
        const playerCounts = allianceIds.length > 0
            ? playerQueries.getPlayerCountsByAllianceIds(allianceIds, req.panelGameType)
            : [];

        const countMap = new Map(playerCounts.map(c => [c.alliance_id, c.player_count]));
        const enriched = alliances.map(a => ({
            ...a,
            playerCount: countMap.get(a.id) || 0
        }));

        res.json(enriched);
    });

    router.get('/api/alliances/player-search', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const rawQuery = String(req.query.q ?? '').trim();
        if (!rawQuery) return res.status(400).json({ error: 'Search query is required' });

        const accessibleAlliances = getAccessibleAlliances(req.adminData, req.panelGameType);
        const allianceMap = new Map(accessibleAlliances.map(alliance => [alliance.id, alliance]));
        const accessibleAllianceIds = new Set(allianceMap.keys());
        const normalizedQuery = rawQuery.toLowerCase();

        const rankedMatches = playerQueries.getAllPlayers(req.panelGameType)
            .filter(player => accessibleAllianceIds.has(player.alliance_id))
            .map(player => {
                const fid = String(player.fid || '');
                const nickname = String(player.nickname || '').toLowerCase();
                let rank = null;

                if (fid === rawQuery) rank = 0;
                else if (nickname && nickname === normalizedQuery) rank = 0;
                else if (fid.includes(rawQuery)) rank = 1;
                else if (nickname && nickname.startsWith(normalizedQuery)) rank = 2;
                else if (nickname && nickname.includes(normalizedQuery)) rank = 3;

                if (rank === null) return null;

                const alliance = allianceMap.get(player.alliance_id);
                return {
                    fid: player.fid,
                    nickname: player.nickname,
                    state: player.state,
                    state_override: player.state_override,
                    allianceId: player.alliance_id,
                    allianceName: alliance?.name || 'Unknown Alliance',
                    alliancePriority: alliance?.priority ?? null,
                    matchRank: rank
                };
            })
            .filter(Boolean)
            .sort((a, b) => {
                if (a.matchRank !== b.matchRank) return a.matchRank - b.matchRank;
                return String(a.fid).localeCompare(String(b.fid));
            });

        const matches = rankedMatches
            .slice(0, 20)
            .map(({ matchRank, ...player }) => player);

        res.json({
            query: rawQuery,
            totalMatches: rankedMatches.length,
            matches
        });
    });

    router.get('/api/alliances/:id', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const accessibleAllianceIds = new Set(getAccessibleAlliances(req.adminData, req.panelGameType).map(alliance => alliance.id));
        if (!accessibleAllianceIds.has(id)) {
            return res.status(403).json({ error: 'Access denied to this alliance' });
        }

        const alliance = allianceQueries.getAllianceById(id, req.panelGameType);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const players = playerQueries.getPlayersByAlliance(id, req.panelGameType).map(player => ({
            fid: player.fid,
            nickname: player.nickname,
            state: player.state,
            state_override: player.state_override,
            alliance_id: player.alliance_id,
            game_type: player.game_type,
        }));
        res.json({ ...alliance, players });
    });

    // ── Attendance ─────────────────────────────────────────────────────────
    router.get('/api/attendance/alliances', requireAuth, requireAttendanceAccess, (req, res) => {
        const alliances = getAttendanceAccessibleAlliances(req.adminData, req.panelGameType);
        const allianceIds = alliances.map(a => a.id);
        const playerCounts = allianceIds.length > 0
            ? playerQueries.getPlayerCountsByAllianceIds(allianceIds, req.panelGameType)
            : [];
        const countMap = new Map(playerCounts.map(c => [c.alliance_id, c.player_count]));

        res.json(alliances.map(alliance => ({
            ...alliance,
            playerCount: countMap.get(alliance.id) || 0,
        })));
    });

    router.get('/api/attendance/records', requireAuth, requireAttendanceAccess, (req, res) => {
        const alliances = getAttendanceAccessibleAlliances(req.adminData, req.panelGameType);
        const allianceMap = new Map(alliances.map(alliance => [alliance.id, alliance]));
        const records = attendance.getRecords({
            gameType: req.panelGameType,
            allianceIds: alliances.map(alliance => alliance.id),
            allianceId: req.query.allianceId,
        });

        res.json(records.map(record => enrichAttendanceRecord(record, allianceMap)));
    });

    router.get('/api/attendance/analysis', requireAuth, requireAttendanceAccess, (req, res) => {
        const requestedAllianceId = Number.parseInt(req.query.allianceId, 10);
        if (!Number.isInteger(requestedAllianceId)) {
            return res.status(400).json({ error: 'Alliance is required' });
        }

        const alliance = getAccessibleAttendanceAlliance(req, req.query.allianceId);
        if (!alliance) {
            return res.status(403).json({ error: 'Access denied to this alliance' });
        }

        try {
            const analysis = attendance.getAnalysis({
                gameType: req.panelGameType,
                allianceId: alliance.id,
                startDate: req.query.startDate,
                endDate: req.query.endDate,
            });

            res.json({
                ...analysis,
                players: Array.isArray(analysis.players)
                    ? attachPlayerNicknames(analysis.players, req.panelGameType)
                    : analysis.players,
                alliance: {
                    ...analysis.alliance,
                    id: alliance.id,
                    name: alliance.name || 'Unknown Alliance',
                    gameType: req.panelGameType,
                },
            });
        } catch (error) {
            res.status(400).json({ error: error.message || 'Unable to analyze attendance' });
        }
    });

    router.get('/api/attendance/analysis/export', requireAuth, requireAttendanceAccess, (req, res) => {
        const requestedAllianceId = Number.parseInt(req.query.allianceId, 10);
        if (!Number.isInteger(requestedAllianceId)) {
            return res.status(400).json({ error: 'Alliance is required' });
        }

        const alliance = getAccessibleAttendanceAlliance(req, req.query.allianceId);
        if (!alliance) {
            return res.status(403).json({ error: 'Access denied to this alliance' });
        }

        try {
            const analysis = attendance.getAnalysis({
                gameType: req.panelGameType,
                allianceId: alliance.id,
                startDate: req.query.startDate,
                endDate: req.query.endDate,
            });
            const enriched = {
                ...analysis,
                alliance: {
                    ...analysis.alliance,
                    id: alliance.id,
                    name: alliance.name || 'Unknown Alliance',
                    gameType: req.panelGameType,
                },
            };
            const csv = attendance.buildAnalysisCsv(enriched);
            const filenameBase = `${alliance.name || 'alliance'}-${req.panelGameType}-attendance-analysis`
                .replace(/[^a-z0-9-_]+/gi, '-')
                .replace(/-+/g, '-')
                .replace(/^-|-$/g, '')
                .toLowerCase();

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="${filenameBase || 'attendance-analysis'}.csv"`);
            res.send(csv);
        } catch (error) {
            res.status(400).json({ error: error.message || 'Unable to export attendance analysis' });
        }
    });

    router.post('/api/attendance/records', requireAuth, requireAttendanceAccess, (req, res) => {
        try {
            const allianceId = Number.parseInt(req.body?.allianceId, 10);
            if (!Number.isInteger(allianceId)) {
                return res.status(400).json({ error: 'Alliance is required' });
            }

            const alliances = getAttendanceAccessibleAlliances(req.adminData, req.panelGameType);
            const allianceMap = new Map(alliances.map(alliance => [alliance.id, alliance]));
            const alliance = allianceMap.get(allianceId);
            if (!alliance) {
                return res.status(403).json({ error: 'Access denied to this alliance' });
            }

            const players = playerQueries.getPlayersByAlliance(allianceId, req.panelGameType);
            const detail = attendance.createRecord({
                title: req.body?.title,
                eventDate: req.body?.eventDate,
                allianceId,
                players,
                userId: req.userId,
                gameType: req.panelGameType,
            });
            const enriched = enrichAttendanceRecord(detail, allianceMap);

            logAttendanceAction(req.userId, LOG_CODES.ATTENDANCE.CREATED, {
                recordId: detail.id,
                recordTitle: detail.title,
                eventDate: detail.eventDate,
                allianceId,
                allianceName: alliance.name || 'Unknown Alliance',
                game_type: req.panelGameType,
                playerCount: detail.playerCount,
            });

            res.status(201).json(enriched);
        } catch (error) {
            res.status(400).json({ error: error.message || 'Unable to create attendance record' });
        }
    });

    router.get('/api/attendance/records/:recordId', requireAuth, requireAttendanceAccess, (req, res) => {
        const detail = getAccessibleAttendanceRecord(req, req.params.recordId);
        if (!detail) return res.status(404).json({ error: 'Attendance record not found' });

        const alliances = getAttendanceAccessibleAlliances(req.adminData, req.panelGameType);
        res.json(enrichAttendanceRecord(detail, new Map(alliances.map(alliance => [alliance.id, alliance]))));
    });

    router.patch('/api/attendance/records/:recordId', requireAuth, requireAttendanceAccess, (req, res) => {
        const existing = getAccessibleAttendanceRecord(req, req.params.recordId);
        if (!existing) return res.status(404).json({ error: 'Attendance record not found' });

        try {
            const detail = attendance.updateRecord(req.params.recordId, req.body || {}, req.userId, req.panelGameType);
            const alliances = getAttendanceAccessibleAlliances(req.adminData, req.panelGameType);
            const allianceMap = new Map(alliances.map(alliance => [alliance.id, alliance]));
            const enriched = enrichAttendanceRecord(detail, allianceMap);
            const alliance = allianceMap.get(detail.allianceId);

            logAttendanceAction(req.userId, LOG_CODES.ATTENDANCE.UPDATED, {
                recordId: detail.id,
                recordTitle: detail.title,
                eventDate: detail.eventDate,
                allianceId: detail.allianceId,
                allianceName: alliance?.name || 'Unknown Alliance',
                game_type: req.panelGameType,
                action: 'metadata',
            });

            res.json(enriched);
        } catch (error) {
            res.status(400).json({ error: error.message || 'Unable to update attendance record' });
        }
    });

    router.put('/api/attendance/records/:recordId/players/:fid/status', requireAuth, requireAttendanceAccess, (req, res) => {
        const existing = getAccessibleAttendanceRecord(req, req.params.recordId);
        if (!existing) return res.status(404).json({ error: 'Attendance record not found' });

        try {
            const result = attendance.updatePlayerStatus(req.params.recordId, req.params.fid, req.body?.status, req.panelGameType);
            const alliances = getAttendanceAccessibleAlliances(req.adminData, req.panelGameType);
            const allianceMap = new Map(alliances.map(alliance => [alliance.id, alliance]));
            const detail = enrichAttendanceRecord(result.detail, allianceMap);
            const alliance = allianceMap.get(result.detail.allianceId);

            if (result.previousStatus !== result.player.status) {
                logAttendanceAction(req.userId, LOG_CODES.ATTENDANCE.UPDATED, {
                    recordId: detail.id,
                    recordTitle: detail.title,
                    eventDate: detail.eventDate,
                    allianceId: detail.allianceId,
                    allianceName: alliance?.name || 'Unknown Alliance',
                    game_type: req.panelGameType,
                    action: 'player_status',
                    playerId: result.player.fid,
                    playerName: `ID ${result.player.fid}`,
                    oldStatus: result.previousStatus,
                    newStatus: result.player.status,
                });
            }

            res.json(detail);
        } catch (error) {
            res.status(400).json({ error: error.message || 'Unable to update player attendance' });
        }
    });

    router.delete('/api/attendance/records/:recordId', requireAuth, requireAttendanceAccess, (req, res) => {
        const existing = getAccessibleAttendanceRecord(req, req.params.recordId);
        if (!existing) return res.status(404).json({ error: 'Attendance record not found' });

        try {
            const alliances = getAttendanceAccessibleAlliances(req.adminData, req.panelGameType);
            const allianceMap = new Map(alliances.map(alliance => [alliance.id, alliance]));
            const alliance = allianceMap.get(existing.allianceId);
            attendance.deleteRecord(req.params.recordId, req.panelGameType);

            logAttendanceAction(req.userId, LOG_CODES.ATTENDANCE.DELETED, {
                recordId: existing.id,
                recordTitle: existing.title,
                eventDate: existing.eventDate,
                allianceId: existing.allianceId,
                allianceName: alliance?.name || 'Unknown Alliance',
                game_type: req.panelGameType,
                playerCount: existing.playerCount,
            });

            res.json({ ok: true });
        } catch (error) {
            res.status(400).json({ error: error.message || 'Unable to delete attendance record' });
        }
    });

    /**
     * Get guild IDs where the user is a member.
     * Uses guild.members.fetch() to ensure accuracy even if the member isn't cached.
     */
    async function getUserGuildIds(userId) {
        const guilds = [...client.guilds.cache.values()];
        const results = await Promise.allSettled(guilds.map(guild => guild.members.fetch(userId)));
        return new Set(
            guilds
                .filter((_, i) => results[i].status === 'fulfilled')
                .map(guild => guild.id)
        );
    }

    function serializePublicGuideDetail(detail) {
        if (!detail) return null;
        const {
            _accessPasswordHash,
            _accessPasswordSalt,
            ...safeDetail
        } = detail;
        return safeDetail;
    }

    function buildPublicGuideAccessPayload(guide, overrides = {}) {
        return {
            accessMode: guide.accessMode,
            accessGuildId: guide.accessGuildId || '',
            viewerUsername: '',
            guideMeta: {
                title: guide.title,
                summary: guide.summary,
                publishedAt: guide.publishedAt,
                publicSlug: guide.publicSlug,
            },
            ...overrides,
        };
    }

    async function evaluatePublicGuideAccess(req, res, guide) {
        if (!guide) {
            return { ok: false, status: 404, body: { error: 'Guide not found' } };
        }

        if (guide.accessMode === 'public') {
            return { ok: true };
        }

        if (guide.accessMode === 'password') {
            if (hasGuidePasswordAccess(req, res, guide.id, guide._accessPasswordHash)) {
                return { ok: true };
            }
            return {
                ok: false,
                status: 401,
                body: buildPublicGuideAccessPayload(guide, {
                    error: 'Password required',
                    requiresPassword: true,
                    authenticated: false,
                }),
            };
        }

        const viewer = getGuideViewerIdentity(req, res);
        if (!viewer?.userId) {
            return {
                ok: false,
                status: 401,
                body: buildPublicGuideAccessPayload(guide, {
                    error: 'Discord login required',
                    requiresAuth: true,
                    authenticated: false,
                }),
            };
        }

        if (guide.accessMode === 'discord_bot_user') {
            const adminData = adminQueries.getAdmin(viewer.userId);
            const userData = adminData ? null : userQueries.getUser(viewer.userId);
            if (adminData || userData) {
                return { ok: true, viewer };
            }
            return {
                ok: false,
                status: 403,
                body: buildPublicGuideAccessPayload(guide, {
                    error: 'You must be a registered bot user to view this guide',
                    requiresAuth: true,
                    authenticated: true,
                    viewerUsername: viewer.username || '',
                }),
            };
        }

        if (guide.accessMode === 'discord_mutual_guild') {
            if (!guide.accessGuildId) {
                return {
                    ok: false,
                    status: 403,
                    body: buildPublicGuideAccessPayload(guide, {
                        error: 'This guide does not have a Discord server selected yet',
                        authenticated: !!viewer?.userId,
                        viewerUsername: viewer?.username || '',
                    }),
                };
            }
            const guildIds = await getUserGuildIds(viewer.userId);
            if (guildIds.has(guide.accessGuildId)) {
                return { ok: true, viewer };
            }
            return {
                ok: false,
                status: 403,
                body: buildPublicGuideAccessPayload(guide, {
                    error: 'You must be in the required Discord server to view this guide',
                    requiresAuth: true,
                    authenticated: true,
                    viewerUsername: viewer.username || '',
                }),
            };
        }

        return {
            ok: false,
            status: 403,
            body: buildPublicGuideAccessPayload(guide, {
                error: 'Guide access is restricted',
                authenticated: !!viewer?.userId,
                viewerUsername: viewer?.username || '',
            }),
        };
    }

    // ── Guilds (Discord servers) ─────────────────────────────────────────
    router.get('/api/guilds', requireAuth, async (_req, res) => {
        try {
            const isOwner = !!_req.adminData?.is_owner;
            const userGuildIds = isOwner ? null : await getUserGuildIds(_req.userId);
            const results = client.guilds.cache
                .filter(g => isOwner || userGuildIds.has(g.id))
                .map(guild => ({
                    id: guild.id,
                    name: guild.name,
                    icon: guild.iconURL({ size: 64 }) || null,
                    memberCount: guild.memberCount
                }));
            results.sort((a, b) => a.name.localeCompare(b.name));
            res.json(results);
        } catch (error) {
            res.status(500).json({ error: 'Failed to fetch guilds' });
        }
    });

    router.get('/api/guilds/:id/channels', requireAuth, (req, res) => {
        const guild = client.guilds.cache.get(req.params.id);
        if (!guild) return res.status(404).json({ error: 'Guild not found' });

        const botMember = guild.members.me;
        const canSend = (ch) => ch.type === ChannelType.GuildText && ch.permissionsFor(botMember)?.has('SendMessages');

        const categories = guild.channels.cache
            .filter(ch => ch.type === ChannelType.GuildCategory)
            .sort((a, b) => a.position - b.position);

        const textChannels = guild.channels.cache.filter(canSend);
        const ordered = [];

        // Uncategorized channels first (no parent)
        textChannels
            .filter(ch => !ch.parentId)
            .sort((a, b) => a.position - b.position)
            .forEach(ch => ordered.push({ id: ch.id, name: ch.name }));

        // Channels grouped by category, in category order
        for (const category of categories.values()) {
            textChannels
                .filter(ch => ch.parentId === category.id)
                .sort((a, b) => a.position - b.position)
                .forEach(ch => ordered.push({ id: ch.id, name: ch.name }));
        }

        res.json(ordered);
    });

    router.get('/api/guilds/:id/roles', requireAuth, (req, res) => {
        const guild = client.guilds.cache.get(req.params.id);
        if (!guild) return res.status(404).json({ error: 'Guild not found' });

        const roles = guild.roles.cache
            .filter(r => !r.managed && r.name !== '@everyone')
            .sort((a, b) => b.position - a.position)
            .map(r => ({
                id: r.id,
                name: r.name,
                color: r.color === 0 ? null : '#' + r.color.toString(16).padStart(6, '0')
            }));

        res.json(roles);
    });

    router.get('/api/guilds/:id/members/search', requireAuth, async (req, res) => {
        const guild = client.guilds.cache.get(req.params.id);
        if (!guild) return res.status(404).json({ error: 'Guild not found' });

        const query = (req.query.q || '').trim();
        if (query.length < 2) return res.json([]);

        const limit = Math.min(parseInt(req.query.limit, 10) || 10, 25);

        try {
            const remoteMembers = await guild.members.fetch({ query, limit });
            const remoteResults = [...remoteMembers.values()].map(m => ({
                id: m.id,
                username: m.user.username,
                displayName: m.displayName || m.user.globalName || m.user.username,
                globalName: m.user.globalName || '',
                nickname: m.nickname || '',
                avatar: m.user.displayAvatarURL({ size: 32, extension: 'webp' }),
            }));

            const scoredCachedMembers = [...guild.members.cache.values()]
                .map((member) => ({
                    id: member.id,
                    username: member.user.username,
                    displayName: member.displayName || member.user.globalName || member.user.username,
                    globalName: member.user.globalName || '',
                    nickname: member.nickname || '',
                    avatar: member.user.displayAvatarURL({ size: 32, extension: 'webp' }),
                }))
                .map((member) => ({
                    ...member,
                    score: scoreMemberSearch(query, member),
                }))
                .filter((member) => member.score !== null)
                .sort((a, b) => a.score - b.score || a.displayName.localeCompare(b.displayName))
                .slice(0, limit * 3);

            const merged = new Map();
            for (const member of [...remoteResults, ...scoredCachedMembers]) {
                if (!merged.has(member.id)) {
                    merged.set(member.id, {
                        id: member.id,
                        username: member.username,
                        displayName: member.displayName,
                        avatar: member.avatar,
                    });
                }
            }

            res.json([...merged.values()].slice(0, limit));
        } catch (error) {
            console.error('[Web Panel] Members search error:', error);
            res.json([]);
        }
    });

    router.get('/api/users/batch', requireAuth, async (req, res) => {
        const ids = (req.query.ids || '').split(',').filter(id => /^\d{10,20}$/.test(id)).slice(0, 50);
        if (ids.length === 0) return res.json([]);

        const settled = await Promise.allSettled(ids.map(async id => {
            const user = await client.users.fetch(id);
            return {
                id: user.id,
                username: user.username,
                displayName: user.globalName || user.displayName || user.username,
                avatar: user.displayAvatarURL({ size: 32, extension: 'webp' }),
            };
        }));

        res.json(
            settled.filter(r => r.status === 'fulfilled').map(r => r.value)
        );
    });

    // ── Notifications ────────────────────────────────────────────────────
    router.get('/api/notifications', requireAuth, async (req, res) => {
        const isAdminWithPerms = req.isAdmin && (
            req.adminData.is_owner ||
            (req.adminData.permissions & (PERMISSIONS.NOTIFICATIONS_MANAGEMENT | PERMISSIONS.FULL_ACCESS))
        );

        // Non-admins can only see private notifications if the feature is public
        if (!isAdminWithPerms) {
            if (!req.publicFeatures?.privateNotifications) {
                return res.status(403).json({ error: 'Insufficient permissions' });
            }
            // Return only private notifications for this user
            const privateNotifications = notificationQueries.getPrivateNotifications();
            const userOwned = privateNotifications.filter(n => n.created_by === req.userId);
            return res.json(userOwned);
        }

        try {
            const notifications = notificationQueries.getAllNotifications();
            const userGuildIds = await getUserGuildIds(req.userId);
            const filtered = notifications.filter(n => !n.guild_id || userGuildIds.has(n.guild_id));
            res.json(filtered);
        } catch (error) {
            res.status(500).json({ error: 'Failed to fetch notifications' });
        }
    });

    // ── Processes ────────────────────────────────────────────────────────
    // Any admin with at least one management permission can view processes,
    // since all management operations (refresh, redeem, add player) create them.
    router.get('/api/processes', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { status } = req.query;
        let processes;
        if (status) {
            processes = processQueries.getProcessesByStatus(status);
        } else {
            processes = processQueries.getAllProcesses();
        }

        const enriched = processes
            .map(enrichProcessForPanel)
            .filter(process => process.game_type === req.panelGameType);

        res.json(enriched);
    });

    // ── Gift Codes ───────────────────────────────────────────────────────
    router.get('/api/giftcodes', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const codes = giftCodeQueries.getAllGiftCodes(req.panelGameType);
        res.json(codes);
    });

    // ── Admins ───────────────────────────────────────────────────────────
    const serializeAdminRecord = (admin) => {
        const cachedUser = client.users?.cache?.get(admin.user_id) || null;
        return {
            userId: admin.user_id,
            permissions: admin.permissions,
            isOwner: !!admin.is_owner,
            addedAt: admin.added_at,
            username: cachedUser?.username || null,
            avatar: cachedUser?.displayAvatarURL({ size: 64, extension: 'webp' }) || null,
        };
    };

    router.get('/api/admins', requireAuth, requireOwner, (_req, res) => {
        const admins = adminQueries.getAllAdmins();
        res.json(admins.map(serializeAdminRecord));
    });

    router.get('/api/admins/assignable', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (_req, res) => {
        const admins = adminQueries.getAllAdmins();
        res.json(admins.map(serializeAdminRecord));
    });

    router.post('/api/admins', requireAuth, requireOwner, (req, res) => {
        try {
            const userId = normalizeAdminUserId(req.body?.userId);
            const permissions = normalizePermissionMask(req.body?.permissions ?? 0);

            const existing = adminQueries.getAdmin(userId);
            if (existing) {
                return res.status(409).json({ error: 'That Discord user is already an admin' });
            }

            adminQueries.addAdmin(userId, req.userId, permissions, '[]', 0);
            const created = adminQueries.getAdmin(userId);
            return res.status(201).json(serializeAdminRecord(created));
        } catch (error) {
            return res.status(400).json({ error: error.message || 'Unable to add admin' });
        }
    });

    router.patch('/api/admins/:userId', requireAuth, requireOwner, (req, res) => {
        try {
            const userId = normalizeAdminUserId(req.params.userId);
            const permissions = normalizePermissionMask(req.body?.permissions ?? 0);

            const existing = adminQueries.getAdmin(userId);
            if (!existing) {
                return res.status(404).json({ error: 'Admin not found' });
            }
            if (existing.is_owner) {
                return res.status(400).json({ error: 'Owner permissions cannot be changed here' });
            }

            adminQueries.updateAdminPermissions(permissions, userId);
            const updated = adminQueries.getAdmin(userId);
            return res.json(serializeAdminRecord(updated));
        } catch (error) {
            return res.status(400).json({ error: error.message || 'Unable to update admin' });
        }
    });

    router.delete('/api/admins/:userId', requireAuth, requireOwner, (req, res) => {
        try {
            const userId = normalizeAdminUserId(req.params.userId);
            const existing = adminQueries.getAdmin(userId);

            if (!existing) {
                return res.status(404).json({ error: 'Admin not found' });
            }
            if (existing.is_owner) {
                return res.status(400).json({ error: 'Owner cannot be removed from the web panel' });
            }

            adminQueries.deleteAdmin(userId);
            return res.json({ ok: true });
        } catch (error) {
            return res.status(400).json({ error: error.message || 'Unable to remove admin' });
        }
    });

    const enrichGuideSummary = (guide, req) => {
        const canManageAll = canManageAllGuides(req);
        const isCreator = guide.createdByUserId === req.userId;
        return {
            ...guide,
            isCreator,
            isAssigned: !canManageAll && !isCreator,
            canEdit: true,
            canManageAssignments: canManageAll,
        };
    };

    function enrichGuideDetail(detail, req) {
        if (!detail) return null;
        const assigneeSet = new Set((detail.assignees || []).map((assignee) => assignee.userId));
        const canManageAll = canManageAllGuides(req);
        const canEdit = canManageAll || detail.createdByUserId === req.userId || assigneeSet.has(req.userId);

        return {
            ...detail,
            isCreator: detail.createdByUserId === req.userId,
            isAssigned: assigneeSet.has(req.userId),
            canEdit,
            canManageAssignments: canManageAll,
            canRequestDelete: canEdit && !canManageAll,
            canResolveDeleteRequests: canManageAll,
        };
    }

    function getAccessibleGuideIdForBlock(req, blockId) {
        const block = guides.getBlockDetail(blockId, req.panelGameType);
        if (!block) return null;
        if (canManageAllGuides(req)) return block.guideId;
        return guides.canUserAccessGuide(block.guideId, req.userId, false, req.panelGameType) ? block.guideId : null;
    }

    function getAccessibleGuideIdForDeleteRequest(req, requestId) {
        const deleteRequest = guides.getDeleteRequestDetail(requestId, req.panelGameType);
        if (!deleteRequest) return null;
        if (canManageAllGuides(req)) return deleteRequest.guideId;
        return guides.canUserAccessGuide(deleteRequest.guideId, req.userId, false, req.panelGameType) ? deleteRequest.guideId : null;
    }

    // —— Guides ——————————————————————————————————————————————————————————————
    router.get('/api/public/guides/:slug', async (req, res) => {
        const detail = guides.getPublicGuideBySlug(req.params.slug);
        if (!detail) return res.status(404).json({ error: 'Guide not found' });
        const access = await evaluatePublicGuideAccess(req, res, detail);
        if (!access.ok) {
            return res.status(access.status).json(access.body);
        }
        res.json(serializePublicGuideDetail(detail));
    });

    router.post('/api/public/guides/:slug/unlock', (req, res) => {
        const detail = guides.getPublicGuideBySlug(req.params.slug);
        if (!detail) return res.status(404).json({ error: 'Guide not found' });
        if (detail.accessMode !== 'password') {
            return res.status(400).json({ error: 'This guide does not use password protection' });
        }

        const password = String(req.body?.password || '');
        if (!guides.verifyGuidePassword(password, detail._accessPasswordHash, detail._accessPasswordSalt)) {
            return res.status(403).json(buildPublicGuideAccessPayload(detail, {
                error: 'Incorrect password',
                requiresPassword: true,
                authenticated: false,
            }));
        }

        setGuidePasswordAccessCookie(req, res, detail.id, detail._accessPasswordHash);
        res.json({ ok: true });
    });

    router.get('/api/public/guide-media/:assetId', async (req, res) => {
        const asset = guides.getGuideMediaAsset(req.params.assetId);
        if (!asset) return res.status(404).json({ error: 'Guide image not found' });

        const referencingGuides = guides.getPublishedGuideAccessDetailsByMediaAssetId(req.params.assetId);
        if (!referencingGuides.length) {
            return res.status(404).json({ error: 'Guide image not found' });
        }

        let accessGranted = false;
        let deniedAccess = null;
        for (const guide of referencingGuides) {
            const access = await evaluatePublicGuideAccess(req, res, guide);
            if (access.ok) {
                accessGranted = true;
                break;
            }
            if (!deniedAccess || access.status < deniedAccess.status) {
                deniedAccess = access;
            }
        }

        if (!accessGranted) {
            return res.status(deniedAccess?.status || 403).json(deniedAccess?.body || { error: 'Guide access is restricted' });
        }

        const filePath = guides.getGuideMediaAssetFilePath(req.params.assetId);
        if (!filePath || !fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'Guide image file not found' });
        }

        res.type(asset.mimeType);
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.setHeader('Content-Length', String(asset.sizeBytes));
        res.sendFile(filePath);
    });

    router.get('/api/guides', requireAuth, requireGuideAccess, (req, res) => {
        const list = guides.getGuides({
            userId: req.userId,
            hasFullAccess: canManageAllGuides(req),
            gameType: req.panelGameType,
        });
        res.json(list.map((guide) => enrichGuideSummary(guide, req)));
    });

    router.post('/api/guides', requireAuth, requireGuideAccess, (req, res) => {
        try {
            const detail = guides.createGuide({
                title: req.body?.title || 'Untitled Guide',
                summary: req.body?.summary || '',
                accessMode: req.body?.accessMode,
                accessPassword: req.body?.accessPassword,
                accessGuildId: req.body?.accessGuildId,
                createdByUserId: req.userId,
                gameType: req.panelGameType,
            });
            res.status(201).json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(400).json({ error: error.message || 'Unable to create guide' });
        }
    });

    router.get('/api/guides/:guideId', requireAuth, requireGuideDetailAccess, (req, res) => {
        const detail = guides.getGuideDetail(req.params.guideId, req.panelGameType);
        if (!detail) return res.status(404).json({ error: 'Guide not found' });
        res.json(enrichGuideDetail(detail, req));
    });

    router.patch('/api/guides/:guideId', requireAuth, requireGuideDetailAccess, (req, res) => {
        try {
            const detail = guides.updateGuideMeta(req.params.guideId, req.body || {}, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/:guideId/blocks', requireAuth, requireGuideDetailAccess, (req, res) => {
        try {
            const detail = guides.addBlock(req.params.guideId, req.body?.blockType, req.body?.payload, req.userId, req.panelGameType);
            res.status(201).json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/:guideId/image-assets', requireAuth, requireGuideDetailAccess, (req, res) => {
        guideImageUpload.single('image')(req, res, (error) => {
            if (error) {
                const message = error?.code === 'LIMIT_FILE_SIZE'
                    ? `Uploaded image must be ${Math.floor(GUIDE_IMAGE_UPLOAD_LIMIT_BYTES / (1024 * 1024))} MB or smaller`
                    : (error.message || 'Unable to upload image');
                return res.status(400).json({ error: message });
            }

            try {
                if (!req.file) {
                    return res.status(400).json({ error: 'Image file is required' });
                }

                const asset = guides.createGuideMediaAsset({
                    buffer: req.file.buffer,
                    originalName: req.file.originalname,
                    mimeType: req.file.mimetype,
                    createdByUserId: req.userId,
                });

                return res.status(201).json({
                    ...asset,
                    publicUrl: `${BASE_PATH}/api/public/guide-media/${encodeURIComponent(asset.id)}`,
                });
            } catch (uploadError) {
                return res.status(400).json({ error: uploadError.message || 'Unable to upload image' });
            }
        });
    });

    router.patch('/api/guides/blocks/:blockId', requireAuth, requireGuideAccess, (req, res) => {
        const guideId = getAccessibleGuideIdForBlock(req, req.params.blockId);
        if (!guideId) return res.status(404).json({ error: 'Guide not found' });
        try {
            const detail = guides.updateBlock(req.params.blockId, req.body?.payload, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/blocks/:blockId/move', requireAuth, requireGuideAccess, (req, res) => {
        const guideId = getAccessibleGuideIdForBlock(req, req.params.blockId);
        if (!guideId) return res.status(404).json({ error: 'Guide not found' });
        try {
            const detail = guides.moveBlock(req.params.blockId, req.body?.direction, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/blocks/:blockId/duplicate', requireAuth, requireGuideAccess, (req, res) => {
        const guideId = getAccessibleGuideIdForBlock(req, req.params.blockId);
        if (!guideId) return res.status(404).json({ error: 'Guide not found' });
        try {
            const detail = guides.duplicateBlock(req.params.blockId, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.delete('/api/guides/blocks/:blockId', requireAuth, requireGuideAccess, (req, res) => {
        const guideId = getAccessibleGuideIdForBlock(req, req.params.blockId);
        if (!guideId) return res.status(404).json({ error: 'Guide not found' });
        try {
            const detail = guides.removeBlock(req.params.blockId, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/:guideId/publish', requireAuth, requireGuideDetailAccess, (req, res) => {
        try {
            const detail = guides.publishGuide(req.params.guideId, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/:guideId/unpublish', requireAuth, requireGuideDetailAccess, (req, res) => {
        try {
            const detail = guides.unpublishGuide(req.params.guideId, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/:guideId/archive', requireAuth, requireGuideDetailAccess, (req, res) => {
        try {
            const detail = guides.archiveGuide(req.params.guideId, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.put('/api/guides/:guideId/assignees', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        try {
            const detail = guides.getGuideDetail(req.params.guideId, req.panelGameType);
            if (!detail) return res.status(404).json({ error: 'Guide not found' });

            const userIds = Array.isArray(req.body?.userIds) ? req.body.userIds : [];
            const knownAdminIds = new Set(adminQueries.getAllAdmins().map((admin) => admin.user_id));
            const invalidUserId = userIds.find((userId) => !knownAdminIds.has(String(userId || '').trim()));
            if (invalidUserId) {
                return res.status(400).json({ error: 'Assignments can only be made to existing admins' });
            }

            res.json(enrichGuideDetail(guides.setGuideAssignments(req.params.guideId, userIds, req.userId, req.panelGameType), req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/:guideId/delete-requests', requireAuth, requireGuideDetailAccess, (req, res) => {
        if (canManageAllGuides(req)) {
            return res.status(400).json({ error: 'Full-access admins do not need to submit delete requests' });
        }
        try {
            const detail = guides.createDeleteRequest(req.params.guideId, req.userId, req.body?.note || '', req.panelGameType);
            res.status(201).json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/delete-requests/:requestId/cancel', requireAuth, requireGuideAccess, (req, res) => {
        const guideId = getAccessibleGuideIdForDeleteRequest(req, req.params.requestId);
        if (!guideId) return res.status(404).json({ error: 'Guide not found' });
        try {
            const detail = guides.cancelDeleteRequest(req.params.requestId, req.userId, req.panelGameType);
            res.json(enrichGuideDetail(detail, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    router.post('/api/guides/delete-requests/:requestId/resolve', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        try {
            const result = guides.resolveDeleteRequest(req.params.requestId, req.body?.action, req.userId, req.panelGameType);
            res.json(result.deletedGuideId ? { ok: true, ...result } : enrichGuideDetail(result, req));
        } catch (error) {
            res.status(/not found/i.test(error.message) ? 404 : 400).json({ error: error.message });
        }
    });

    // ── Settings ─────────────────────────────────────────────────────────
    router.get('/api/settings', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (_req, res) => {
        const settings = settingsQueries.getSettings.get();
        res.json(settings);
    });

    // Panel access level — readable by any authenticated user, writable by owner/full-access
    router.get('/api/settings/panel-access', requireAuth, (_req, res) => {
        res.json({ accessLevel: getPanelAccessLevel() });
    });

    router.post('/api/settings/panel-access', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { accessLevel } = req.body;
        const allowedLevels = Object.values(PANEL_ACCESS);
        if (!allowedLevels.includes(accessLevel)) {
            return res.status(400).json({ error: `Invalid access level. Must be one of: ${allowedLevels.join(', ')}` });
        }
        pluginDb.set(PANEL_ACCESS_KEY, accessLevel);
        res.json({ accessLevel });
    });

    router.get('/api/settings/guest-public-tools', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (_req, res) => {
        res.json({ enabled: isGuestPublicToolsEnabled() });
    });

    router.post('/api/settings/guest-public-tools', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { enabled } = req.body;
        if (typeof enabled !== 'boolean') {
            return res.status(400).json({ error: 'enabled must be a boolean' });
        }

        pluginDb.set(GUEST_PUBLIC_TOOLS_KEY, enabled ? 'true' : 'false');
        res.json({ enabled });
    });

    router.get('/api/settings/theme', requireAuth, (_req, res) => {
        res.json({ theme: getPanelTheme(), themes: Object.values(PANEL_THEME) });
    });

    router.post('/api/settings/theme', requireAuth, requireOwner, (req, res) => {
        const { theme } = req.body;
        const allowedThemes = Object.values(PANEL_THEME);
        if (!allowedThemes.includes(theme)) {
            return res.status(400).json({ error: `Invalid theme. Must be one of: ${allowedThemes.join(', ')}` });
        }
        pluginDb.set(PANEL_THEME_KEY, theme);
        res.json({ theme });
    });

    router.post('/api/settings/restart', requireAuth, requireOwner, (_req, res) => {
        if (typeof global.restartBot !== 'function') {
            return res.status(503).json({ error: 'Restart is unavailable in this runtime' });
        }

        res.json({ ok: true, restarting: true });

        setTimeout(() => {
            try {
                global.restartBot();
            } catch (error) {
                console.error('[Web Panel] Restart failed:', error.message);
            }
        }, 150);
    });

    // ── System Logs ──────────────────────────────────────────────────────
    router.get('/api/logs', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const page = Math.max(0, parseInt(req.query.page, 10) || 0);
        const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 25));
        const offset = page * limit;
        const typeFilter = req.query.type || null;

        const { logs: pagedLogs, total } = getPanelLogsPageData(req.panelGameType, typeFilter, page, limit);

        res.json({ logs: pagedLogs, total, page, limit });
    });

    // ══════════════════════════════════════════════════════════════════════
    //  WRITE ROUTES
    // ══════════════════════════════════════════════════════════════════════

    // ── Gift Code Management ─────────────────────────────────────────────
    router.post('/api/giftcodes', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), async (req, res) => {
        const { code } = req.body;
        if (!code || typeof code !== 'string') return res.status(400).json({ error: 'Gift code is required' });

        const trimmed = code.trim();
        if (trimmed.length === 0 || trimmed.length > 50) return res.status(400).json({ error: 'Gift code must be 1-50 characters' });

        const existing = giftCodeQueries.getGiftCode(trimmed, req.panelGameType);
        if (existing) return res.status(409).json({ error: 'Gift code already exists' });

        try {
            const validationOutcome = await createRedeemProcess([
                {
                    id: null,
                    giftCode: trimmed,
                    status: 'validation'
                }
            ], {
                adminId: req.userId,
                gameType: req.panelGameType
            });

            if (!validationOutcome?.success) {
                const failureKind = getValidationFailureKind(validationOutcome?.results?.[0]);
                const detail = validationOutcome?.message
                    || validationOutcome?.results?.[0]?.message
                    || '';
                const shortDetail = detail.length > 200 ? `${detail.slice(0, 197)}...` : detail;
                let validationMessage;
                if (failureKind === 'invalid') {
                    validationMessage = 'Invalid gift code. Try a different one.';
                } else if (failureKind === 'network') {
                    validationMessage = `Gift code validation could not be completed (${shortDetail}). Check the network/proxy settings and try again.`;
                } else if (failureKind === 'rateLimit') {
                    validationMessage = 'Gift code validation is rate-limited. Wait a moment and try again.';
                } else {
                    validationMessage = 'Gift code validation could not be completed. Set a valid test ID with the correct state, then try again.';
                }
                return res.status(400).json({ error: validationMessage });
            }

            const isVipCode = !!validationOutcome?.results?.[0]?.is_vip;

            giftCodeQueries.addGiftCode(trimmed, 'active', req.userId, 'manual', false, isVipCode, req.panelGameType);
            giftCodeQueries.updateLastValidated(trimmed, req.panelGameType);

            res.status(201).json({ ok: true, code: trimmed, isVip: isVipCode });

            setImmediate(() => {
                startGiftCodeAutoRedeem(trimmed, req.userId, req.panelGameType).catch((error) => {
                    console.error(`[Web Panel Gift Codes] Auto-redeem bootstrap failed for code "${trimmed}":`, error);
                });
            });
        } catch (error) {
            console.error('[Web Panel Gift Codes] Failed to add gift code:', error);
            return res.status(500).json({ error: error.message || 'Failed to add gift code' });
        }
    });

    router.delete('/api/giftcodes/:code', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const existing = giftCodeQueries.getGiftCode(code, req.panelGameType);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        giftCodeQueries.removeGiftCode(code, req.panelGameType);
        res.json({ ok: true });
    });

    router.patch('/api/giftcodes/:code/status', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const { status } = req.body;
        const validStatuses = ['active', 'invalid', 'expired'];
        if (!validStatuses.includes(status)) return res.status(400).json({ error: `Status must be one of: ${validStatuses.join(', ')}` });

        const existing = giftCodeQueries.getGiftCode(code, req.panelGameType);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        giftCodeQueries.updateGiftCodeStatus(status, code, req.panelGameType);
        res.json({ ok: true });
    });

    router.patch('/api/giftcodes/:code/vip', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const { isVip } = req.body;
        if (typeof isVip !== 'boolean') return res.status(400).json({ error: 'isVip must be a boolean' });

        const existing = giftCodeQueries.getGiftCode(code, req.panelGameType);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        giftCodeQueries.updateGiftCodeVipStatus(isVip ? 1 : 0, code, req.panelGameType);
        res.json({ ok: true });
    });

    router.get('/api/giftcodes/:code/usage', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const existing = giftCodeQueries.getGiftCode(code, req.panelGameType);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        const usageCount = giftCodeUsageQueries.getUsageCount(code, req.panelGameType);
        res.json({ code, usageCount, game_type: req.panelGameType, game_label: getGameProfile(req.panelGameType).shortLabel });
    });

    router.post('/api/giftcodes/:code/redeem', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), async (req, res) => {
        const { code } = req.params;
        const { allianceId } = req.body;
        if (!allianceId) return res.status(400).json({ error: 'allianceId is required' });

        const existing = giftCodeQueries.getGiftCode(code, req.panelGameType);
        if (!existing || existing.status !== 'active') return res.status(400).json({ error: 'Gift code is not active' });

        const alliance = allianceQueries.getAllianceById(parseInt(allianceId, 10), req.panelGameType);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const players = playerQueries.getPlayersByAlliance(alliance.id, req.panelGameType);
        if (players.length === 0) return res.status(400).json({ error: 'Alliance has no players' });

        const redeemData = players.map(p => ({
            id: String(p.fid),
            giftCode: code,
            status: 'redeem'
        }));

        try {
            const result = await createRedeemProcess(redeemData, {
                adminId: req.userId,
                allianceContext: {
                    id: alliance.id,
                    name: alliance.name || null,
                    channelId: null,
                    guildId: null,
                    gameType: req.panelGameType
                }
            });

            if (!result.success && result.processId === null) {
                return res.status(409).json({ error: result.message || 'Duplicate process skipped' });
            }

            res.status(201).json({ ok: true, processId: result.processId });
        } catch (error) {
            console.error('[Web Panel] Redeem process creation failed:', error.message);
            res.status(500).json({ error: 'Failed to create redeem process' });
        }
    });

    // ── Notification CRUD ────────────────────────────────────────────────
    router.post('/api/notifications', requireAuth, async (req, res) => {
        const {
            name,
            type,
            hour,
            minute,
            pattern,
            guildId,
            channelId,
            nextTrigger,
            repeatStatus,
            repeatFrequency,
            messageContent,
            title,
            description,
            color,
            imageUrl,
            thumbnailUrl,
            footer,
            author,
            fields,
            mention,
            embedToggle
        } = req.body;

        if (!name || typeof name !== 'string') return res.status(400).json({ error: 'name is required' });
        if (!['server', 'private'].includes(type)) return res.status(400).json({ error: 'type must be server or private' });
        if (!canManageNotification(req, null, type)) return res.status(403).json({ error: 'Insufficient permissions' });

        const parsedHour = parseInt(hour, 10);
        const parsedMinute = parseInt(minute, 10);
        if (isNaN(parsedHour) || parsedHour < 0 || parsedHour > 23) return res.status(400).json({ error: 'hour must be 0-23' });
        if (isNaN(parsedMinute) || parsedMinute < 0 || parsedMinute > 59) return res.status(400).json({ error: 'minute must be 0-59' });

        const resolvedGuildId = type === 'server' ? (guildId || null) : null;
        const resolvedChannelId = type === 'server' ? (channelId || null) : null;
        if (type === 'server' && (!resolvedGuildId || !resolvedChannelId)) {
            return res.status(400).json({ error: 'server notifications require guildId and channelId' });
        }

        const resolvedNextTrigger = Number.isInteger(nextTrigger) ? nextTrigger : null;
        if (!resolvedNextTrigger || resolvedNextTrigger <= Math.floor(Date.now() / 1000)) {
            return res.status(400).json({ error: 'nextTrigger must be a future Unix timestamp' });
        }
        const resolvedRepeatStatus = repeatStatus ? 1 : 0;
        const resolvedRepeatFrequency = resolvedRepeatStatus ? repeatFrequency : null;
        const resolvedPattern = normalizeOptionalText(pattern) || 'time';
        if (!isValidNotificationPattern(resolvedPattern)) {
            return res.status(400).json({ error: 'pattern must contain unique positive minutes and/or time' });
        }
        if (!isValidNotificationRepeat(resolvedRepeatStatus, resolvedRepeatFrequency)) {
            return res.status(400).json({ error: 'repeat frequency is invalid' });
        }
        const resolvedFields = normalizeNotificationFields(fields);
        const resolvedMention = normalizeNotificationMention(mention);
        const resolvedEmbedToggle = !!embedToggle;
        const payloadError = getNotificationPayloadError({
            messageContent,
            title,
            description,
            footer,
            author,
            imageUrl,
            thumbnailUrl,
            fields: resolvedFields,
            embedToggle: resolvedEmbedToggle
        });
        if (payloadError) return res.status(400).json({ error: payloadError });
        const completed = hasCompletedNotificationContent({
            messageContent,
            title,
            description,
            footer,
            author,
            imageUrl,
            thumbnailUrl,
            fields: resolvedFields,
            embedToggle: resolvedEmbedToggle
        });

        if (!completed) {
            return res.status(400).json({ error: 'Notification content is required before saving' });
        }

        const result = notificationQueries.addNotification(
            name.trim(), type, true, resolvedGuildId, resolvedChannelId,
            parsedHour, parsedMinute,
            normalizeOptionalText(messageContent),
            normalizeOptionalText(title),
            normalizeOptionalText(description),
            normalizeOptionalText(color),
            normalizeOptionalText(imageUrl),
            normalizeOptionalText(thumbnailUrl),
            normalizeOptionalText(footer),
            normalizeOptionalText(author),
            resolvedFields,
            resolvedPattern,
            resolvedMention,
            resolvedRepeatStatus,
            resolvedRepeatFrequency,
            resolvedEmbedToggle,
            true,
            null,
            resolvedNextTrigger,
            req.userId
        );

        await notificationScheduler.addNotification(result.lastInsertRowid);

        res.status(201).json({ ok: true, id: result.lastInsertRowid });
    });

    router.put('/api/notifications/:id', requireAuth, async (req, res) => {
        try {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = notificationQueries.getNotificationById(id);
        if (!existing) return res.status(404).json({ error: 'Notification not found' });
        if (!canManageNotification(req, existing)) return res.status(403).json({ error: 'Insufficient permissions' });

        const body = req.body;
        const pick = (key, fallback) => key in body ? body[key] : fallback;
        const nextType = pick('type', existing.guild_id ? 'server' : 'private');
        if (!['server', 'private'].includes(nextType)) {
            return res.status(400).json({ error: 'type must be server or private' });
        }
        if (!canManageNotification(req, null, nextType)) {
            return res.status(403).json({ error: 'Insufficient permissions' });
        }

        const nextName = normalizeOptionalText(pick('name', existing.name));
        if (!nextName) return res.status(400).json({ error: 'name is required' });

        const nextHour = parseInt(pick('hour', existing.hour), 10);
        const nextMinute = parseInt(pick('minute', existing.minute), 10);
        if (isNaN(nextHour) || nextHour < 0 || nextHour > 23) {
            return res.status(400).json({ error: 'hour must be 0-23' });
        }
        if (isNaN(nextMinute) || nextMinute < 0 || nextMinute > 59) {
            return res.status(400).json({ error: 'minute must be 0-59' });
        }

        const nextGuildId = nextType === 'server' ? pick('guildId', existing.guild_id) : null;
        const nextChannelId = nextType === 'server' ? pick('channelId', existing.channel_id) : null;
        if (nextType === 'server' && (!nextGuildId || !nextChannelId)) {
            return res.status(400).json({ error: 'server notifications require guildId and channelId' });
        }

        const nextTrigger = pick('nextTrigger', existing.next_trigger);
        if (!Number.isInteger(nextTrigger) || nextTrigger <= Math.floor(Date.now() / 1000)) {
            return res.status(400).json({ error: 'nextTrigger must be a future Unix timestamp' });
        }

        const nextMessageContent = normalizeOptionalText(pick('messageContent', existing.message_content));
        const nextTitle = normalizeOptionalText(pick('title', existing.title));
        const nextDescription = normalizeOptionalText(pick('description', existing.description));
        const nextFooter = normalizeOptionalText(pick('footer', existing.footer));
        const nextAuthor = normalizeOptionalText(pick('author', existing.author));
        const nextImageUrl = normalizeOptionalText(pick('imageUrl', existing.image_url));
        const nextThumbnailUrl = normalizeOptionalText(pick('thumbnailUrl', existing.thumbnail_url));
        const nextFields = body.fields !== undefined ? normalizeNotificationFields(body.fields) : existing.fields;
        const nextEmbedToggle = !!pick('embedToggle', existing.embed_toggle);
        const nextPattern = normalizeOptionalText(pick('pattern', existing.pattern)) || 'time';
        const nextRepeatStatus = pick('repeatStatus', existing.repeat_status) ? 1 : 0;
        const nextRepeatFrequency = nextRepeatStatus ? pick('repeatFrequency', existing.repeat_frequency) : null;
        if (!isValidNotificationPattern(nextPattern)) {
            return res.status(400).json({ error: 'pattern must contain unique positive minutes and/or time' });
        }
        if (!isValidNotificationRepeat(nextRepeatStatus, nextRepeatFrequency)) {
            return res.status(400).json({ error: 'repeat frequency is invalid' });
        }

        const payloadError = getNotificationPayloadError({
            messageContent: nextMessageContent,
            title: nextTitle,
            description: nextDescription,
            footer: nextFooter,
            author: nextAuthor,
            imageUrl: nextImageUrl,
            thumbnailUrl: nextThumbnailUrl,
            fields: nextFields,
            embedToggle: nextEmbedToggle
        });
        if (payloadError) return res.status(400).json({ error: payloadError });

        const completed = hasCompletedNotificationContent({
            messageContent: nextMessageContent,
            title: nextTitle,
            description: nextDescription,
            footer: nextFooter,
            author: nextAuthor,
            imageUrl: nextImageUrl,
            thumbnailUrl: nextThumbnailUrl,
            fields: nextFields,
            embedToggle: nextEmbedToggle
        });
        if (!completed) {
            return res.status(400).json({ error: 'Notification content is required before saving' });
        }

        notificationQueries.updateNotification(
            id,
            nextName,
            nextGuildId,
            nextChannelId,
            nextHour,
            nextMinute,
            nextMessageContent,
            nextTitle,
            nextDescription,
            normalizeOptionalText(pick('color', existing.color)),
            nextImageUrl,
            nextThumbnailUrl,
            nextFooter,
            nextAuthor,
            nextFields,
            nextPattern,
            body.mention !== undefined ? normalizeNotificationMention(body.mention) : existing.mention,
            nextRepeatStatus,
            nextRepeatFrequency,
            nextEmbedToggle,
            1,
            existing.last_trigger,
            nextTrigger
        );

        const updated = notificationQueries.getNotificationById(id);
        if (updated && updated.completed !== (completed ? 1 : 0)) {
            notificationQueries.updateNotificationCompletedStatus(id, completed);
        }
        notificationScheduler.removeNotification(id);
        if (updated?.is_active && completed) {
            await notificationScheduler.addNotification(id);
        } else {
            if (updated?.is_active && !completed) {
                notificationQueries.updateNotificationActiveStatus(id, false);
            }
            await refreshNotificationBoardsForGuilds(client, [existing.guild_id, updated?.guild_id]);
        }

        res.json({ ok: true });
        } catch (err) {
            console.error('[Web Panel] PUT /api/notifications/:id error:', err);
            res.status(500).json({ error: 'Failed to update notification' });
        }
    });

    router.delete('/api/notifications/:id', requireAuth, async (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = notificationQueries.getNotificationById(id);
        if (!existing) return res.status(404).json({ error: 'Notification not found' });
        if (!canManageNotification(req, existing)) return res.status(403).json({ error: 'Insufficient permissions' });

        notificationScheduler.removeNotification(id);
        notificationQueries.deleteNotification(id);
        await refreshNotificationBoardsForGuilds(client, [existing.guild_id]);
        res.json({ ok: true });
    });

    router.patch('/api/notifications/:id/active', requireAuth, async (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = notificationQueries.getNotificationById(id);
        if (!existing) return res.status(404).json({ error: 'Notification not found' });
        if (!canManageNotification(req, existing)) return res.status(403).json({ error: 'Insufficient permissions' });

        const { isActive } = req.body;
        if (typeof isActive !== 'boolean') return res.status(400).json({ error: 'isActive must be a boolean' });

        if (isActive) {
            if (!Number.isInteger(existing.next_trigger) || existing.next_trigger <= Math.floor(Date.now() / 1000)) {
                return res.status(400).json({ error: 'Set a future trigger time before activating.' });
            }
            if (!isValidNotificationPattern(existing.pattern)) {
                return res.status(400).json({ error: 'Fix the send pattern before activating.' });
            }
            if (!isValidNotificationRepeat(existing.repeat_status, existing.repeat_frequency)) {
                return res.status(400).json({ error: 'Fix the repeat schedule before activating.' });
            }
            const payloadError = getNotificationPayloadError({
                messageContent: existing.message_content,
                title: existing.title,
                description: existing.description,
                footer: existing.footer,
                author: existing.author,
                imageUrl: existing.image_url,
                thumbnailUrl: existing.thumbnail_url,
                fields: existing.fields,
                embedToggle: !!existing.embed_toggle
            });
            if (payloadError) return res.status(400).json({ error: payloadError });
            const completed = isNotificationRecordComplete(existing);
            if (!completed) {
                return res.status(400).json({ error: 'Notification content is incomplete. Edit and save it before activating.' });
            }
            if (existing.completed !== 1) {
                notificationQueries.updateNotificationCompletedStatus(id, true);
            }
        }

        notificationQueries.updateNotificationActiveStatus(id, isActive ? 1 : 0);

        notificationScheduler.removeNotification(id);
        if (isActive) {
            await notificationScheduler.addNotification(id);
        } else {
            await refreshNotificationBoardsForGuilds(client, [existing.guild_id]);
        }

        res.json({ ok: true });
    });

    // ── Trigger Actions ──────────────────────────────────────────────────
    router.get('/api/alliances/:id/export', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const allianceId = parseInt(req.params.id, 10);
        if (isNaN(allianceId)) return res.status(400).json({ error: 'Invalid alliance ID' });

        const alliance = allianceQueries.getAllianceById(allianceId, req.panelGameType);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const players = playerQueries.getPlayersByAlliance(allianceId, req.panelGameType);
        if (players.length === 0) return res.status(400).json({ error: 'No players to export' });

        const escapeCsvCell = (value) => {
            const str = String(value ?? '');
            return (str.includes(',') || str.includes('"') || str.includes('\n'))
                ? `"${str.replace(/"/g, '""')}"`
                : str;
        };

        const headers = ['Player ID', 'Assigned State'];
        const sortedPlayers = [...players].sort((a, b) => Number(a.fid) - Number(b.fid));
        const rows = sortedPlayers.map(p => [
            p.fid,
            p.state ?? ''
        ].map(escapeCsvCell).join(','));

        const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
        const safeName = (alliance.name || 'alliance').replace(/[^a-zA-Z0-9_-]/g, '_');

        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="${safeName}_${req.panelGameType}_players.csv"`);
        res.send(csvContent);
    });

    router.delete('/api/processes/:id', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = processQueries.getProcessById(id);
        if (!existing) return res.status(404).json({ error: 'Process not found' });
        if (resolveProcessGameType(existing) !== req.panelGameType) {
            return res.status(404).json({ error: 'Process not found' });
        }

        if (existing.status === 'active') return res.status(400).json({ error: 'Cannot delete an active process' });

        processQueries.deleteProcess(id);
        res.json({ ok: true });
    });

    // ── Settings Write Routes ────────────────────────────────────────────
    router.put('/api/settings/feature-access', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { featureAccess } = req.body;
        if (!featureAccess || typeof featureAccess !== 'object') return res.status(400).json({ error: 'featureAccess object is required' });

        settingsQueries.setFeatureAccess.run(JSON.stringify(featureAccess));
        res.json({ ok: true });
    });

    router.patch('/api/settings', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { autoDelete, autoUpdate, notifAutoClean, notifAutoCleanFreq } = req.body;

        if (autoDelete !== undefined) settingsQueries.updateAutoDelete.run(autoDelete ? 1 : 0);
        if (autoUpdate !== undefined) settingsQueries.updateAutoUpdate.run(autoUpdate ? 1 : 0);
        if (notifAutoClean !== undefined) settingsQueries.updateNotifAutoClean.run(notifAutoClean ? 1 : 0);
        if (notifAutoCleanFreq !== undefined) {
            const freq = parseInt(notifAutoCleanFreq, 10);
            if (isNaN(freq) || freq < 60) return res.status(400).json({ error: 'Frequency must be at least 60 seconds' });
            settingsQueries.updateNotifAutoCleanFreq.run(freq);
        }

        res.json({ ok: true });
    });

    // ── Calculators (data bundled inside plugin) ──────────────────────────
    const CALC_BUILDINGS_DIR = path.join(__dirname, '../../src/functions/Calculators/Buildings');
    const CALC_WAR_ACADEMY_DIR = path.join(__dirname, '../../src/functions/Calculators/WarAcademy');
    const CALC_RESEARCH_DIR = path.join(__dirname, 'data/research');
    const CALC_FLAMETECH_DIR = path.join(__dirname, 'data/flameTech');
const CALC_CHIEF_GEAR_CHARMS_CANDIDATES = [
    path.join(__dirname, 'data/chief_Gear_Charm.json')
];

    const BUILDING_TYPE_FILES = {
        wos: { basic: 'basic', fire_crystal: 'fire_crystal' },
        ks: { basic: 'kingshot_basic', true_gold: 'kingshot_true_gold' }
    };
    const WAR_ACADEMY_FILES = {
        wos: { Infantry: 'Infantry', Marksman: 'Marksman', Lancer: 'Lancer' },
        ks: { Infantry: 'kingshot_infantry', Archer: 'kingshot_archer', Cavalry: 'kingshot_cavalry' }
    };
    const ALLOWED_RESEARCH_CATS = new Set(['battle', 'economy', 'growth']);

    /**
     * Middleware for calculator routes — allows non-admin users when the
     * calculators feature is set to "everyone" in the bot's feature access.
     */
    function requireCalcAccess(req, res, next) {
        if (req.isAdmin) return next();
        if (req.publicFeatures?.calculators) return next();
        return res.status(403).json({ error: 'Calculators are not publicly accessible' });
    }

    router.get('/api/calculators/buildings/:type', requireGuestOrAuthenticatedCalculators, requireCalcAccess, (req, res) => {
        const { type } = req.params;
        const fileStem = BUILDING_TYPE_FILES[req.panelGameType]?.[type];
        if (!fileStem) {
            return res.status(400).json({ error: 'Invalid building type' });
        }
        try {
            const filePath = path.join(CALC_BUILDINGS_DIR, `${fileStem}.json`);
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error(`[Web Panel] Failed to load buildings data (${type}):`, error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    router.get('/api/calculators/war-academy/:category', requireGuestOrAuthenticatedCalculators, requireCalcAccess, (req, res) => {
        const { category } = req.params;
        const fileStem = WAR_ACADEMY_FILES[req.panelGameType]?.[category];
        if (!fileStem) {
            return res.status(400).json({ error: 'Invalid War Academy category' });
        }
        try {
            const filePath = path.join(CALC_WAR_ACADEMY_DIR, `${fileStem}.json`);
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error(`[Web Panel] Failed to load War Academy data (${category}):`, error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    router.get('/api/calculators/research/:category', requireGuestOrAuthenticatedCalculators, requireCalcAccess, (req, res) => {
        const { category } = req.params;
        if (!ALLOWED_RESEARCH_CATS.has(category)) {
            return res.status(400).json({ error: 'Invalid research category' });
        }
        try {
            const filePath = path.join(CALC_RESEARCH_DIR, `${category}.json`);
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error(`[Web Panel] Failed to load research data (${category}):`, error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    router.get('/api/calculators/flametech/t12', requireGuestOrAuthenticatedCalculators, requireCalcAccess, (req, res) => {
        try {
            const filePath = path.join(CALC_FLAMETECH_DIR, 't12.json');
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error('[Web Panel] Failed to load Flame Tech T12 data:', error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    router.get('/api/calculators/chief-gear-charms', requireGuestOrAuthenticatedCalculators, requireCalcAccess, (req, res) => {
        if (req.panelGameType === 'ks') {
            return res.status(400).json({ error: 'Chief Gear and Chief Charms are only available for Whiteout Survival' });
        }

        try {
            const filePath = CALC_CHIEF_GEAR_CHARMS_CANDIDATES.find(candidate => fs.existsSync(candidate));
            if (!filePath) {
                throw new Error('Chief Gear and Charm calculator data file not found');
            }
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error('[Web Panel] Failed to load Chief Gear and Charm data:', error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    // ── SPA fallback ─────────────────────────────────────────────────────
    function enrichReservationAssignee(assignment) {
        const cachedUser = client.users?.cache?.get(assignment.userId) || null;
        return {
            ...assignment,
            username: cachedUser?.username || null,
        };
    }

    function enrichReservationDetail(detail, req) {
        if (!detail) return null;
        const enriched = {
            ...detail,
            canManageAssignments: canManageAllReservations(req),
            canDelete: canManageAllReservations(req) || detail.createdByUserId === req.userId,
            assignees: (detail.assignees || []).map(enrichReservationAssignee),
        };
        if (Array.isArray(enriched.categories)) {
            for (const category of enriched.categories) {
                if (!Array.isArray(category.slots)) continue;
                const fids = category.slots
                    .map(slot => slot.reservation?.playerId)
                    .filter(playerId => playerId != null && /^\d+$/.test(String(playerId)));
                if (fids.length === 0) continue;

                const nicknameByFid = new Map();
                for (const player of playerQueries.getPlayersByFids(fids, detail.gameType)) {
                    nicknameByFid.set(String(player.fid), player.nickname || '');
                }
                for (const slot of category.slots) {
                    if (slot.reservation?.playerId && nicknameByFid.has(String(slot.reservation.playerId))) {
                        slot.reservation.nickname = nicknameByFid.get(String(slot.reservation.playerId)) || '';
                    }
                }
            }
        }
        return enriched;
    }

    router.post('/api/admin/position-reservations', requireAuth, requireReservationAccess, (req, res) => {
        try {
            const { stateNumber } = req.body || {};
            const detail = positionReservations.createList({
                stateNumber,
                createdByUserId: req.userId,
                gameType: req.panelGameType,
            });
            res.status(201).json(enrichReservationDetail(detail, req));
        } catch (error) {
            res.status(400).json({ error: error.message });
        }
    });

    router.get('/api/admin/position-reservations', requireAuth, requireReservationAccess, (req, res) => {
        res.json(positionReservations.getLists({
            userId: req.userId,
            hasFullAccess: canManageAllReservations(req),
            gameType: req.panelGameType,
        }));
    });

    router.get('/api/admin/position-reservations/:listId', requireAuth, requireReservationListAccess, (req, res) => {
        const detail = positionReservations.getListDetail(req.params.listId, req.panelGameType);
        if (!detail) return res.status(404).json({ error: 'Reservation list not found' });
        res.json(enrichReservationDetail(detail, req));
    });

    router.patch('/api/admin/position-reservations/:listId', requireAuth, requireReservationListAccess, (req, res) => {
        try {
            const detail = positionReservations.updateListMeta(req.params.listId, req.body || {}, req.panelGameType);
            res.json(enrichReservationDetail(detail, req));
        } catch (error) {
            const status = /not found/i.test(error.message) ? 404 : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.post('/api/admin/position-reservations/:listId/config', requireAuth, requireReservationListAccess, (req, res) => {
        try {
            const configs = Array.isArray(req.body?.configs) ? req.body.configs : [];
            const detail = positionReservations.upsertCategoryConfigs(req.params.listId, configs, req.panelGameType);
            res.json(enrichReservationDetail(detail, req));
        } catch (error) {
            const status = /not found/i.test(error.message) ? 404 : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.post('/api/admin/position-reservations/:listId/generate-slots', requireAuth, requireReservationListAccess, (req, res) => {
        try {
            const result = positionReservations.regenerateSlots(req.params.listId, {
                force: !!req.body?.force,
                categories: Array.isArray(req.body?.categories) ? req.body.categories : null,
            }, req.panelGameType);
            if (result.requiresForce) {
                return res.status(409).json({
                    error: 'Reservations already exist. Confirm destructive regeneration to continue.',
                    requiresForce: true,
                    reservationCount: result.reservationCount,
                });
            }
            res.json(enrichReservationDetail(result.detail, req));
        } catch (error) {
            const status = /not found/i.test(error.message) ? 404 : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.post('/api/admin/position-reservations/:listId/publish', requireAuth, requireReservationListAccess, (req, res) => {
        try {
            res.json(enrichReservationDetail(positionReservations.publishList(req.params.listId, req.panelGameType), req));
        } catch (error) {
            const status = /not found/i.test(error.message) ? 404 : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.post('/api/admin/position-reservations/:listId/unpublish', requireAuth, requireReservationListAccess, (req, res) => {
        try {
            res.json(enrichReservationDetail(positionReservations.unpublishList(req.params.listId, req.panelGameType), req));
        } catch (error) {
            const status = /not found/i.test(error.message) ? 404 : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.put('/api/admin/position-reservations/:listId/assignees', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        try {
            const listId = req.params.listId;
            const detail = positionReservations.getListDetail(listId, req.panelGameType);
            if (!detail) return res.status(404).json({ error: 'Reservation list not found' });

            const userIds = Array.isArray(req.body?.userIds) ? req.body.userIds : [];
            const knownAdminIds = new Set(adminQueries.getAllAdmins().map((admin) => admin.user_id));
            const invalidUserId = userIds.find((userId) => !knownAdminIds.has(String(userId || '').trim()));
            if (invalidUserId) {
                return res.status(400).json({ error: 'Assignments can only be made to existing admins' });
            }
            res.json(enrichReservationDetail(positionReservations.setListAssignments(listId, userIds, req.userId, req.panelGameType), req));
        } catch (error) {
            const status = /not found/i.test(error.message) ? 404 : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.delete('/api/admin/position-reservations/:listId', requireAuth, requireReservationListAccess, (req, res) => {
        try {
            const detail = positionReservations.getListDetail(req.params.listId, req.panelGameType);
            if (!detail) return res.status(404).json({ error: 'Reservation list not found' });
            if (!canManageAllReservations(req) && detail.createdByUserId !== req.userId) {
                return res.status(403).json({ error: 'Only the creator, owner, or full-access admins can delete this list' });
            }
            res.json({
                ok: true,
                deleted: positionReservations.deleteList(req.params.listId, req.panelGameType),
            });
        } catch (error) {
            const status = /not found/i.test(error.message) ? 404 : 400;
            res.status(status).json({ error: error.message });
        }
    });

    router.patch('/api/admin/position-reservations/slots/:slotId', requireAuth, requireReservationAccess, async (req, res) => {
        try {
            const slot = positionReservations.getSlot(req.params.slotId, req.panelGameType);
            if (!slot) return res.status(404).json({ error: 'Slot not found' });
            if (!canManageAllReservations(req) && !positionReservations.canUserAccessList(slot.listId, req.userId, false, req.panelGameType)) {
                return res.status(404).json({ error: 'Reservation list not found' });
            }
            const { status, playerId, allianceTag } = req.body || {};
            const detail = await positionReservations.setSlotState({
                slotId: req.params.slotId,
                status,
                reservation: { playerId, allianceTag },
                createdByType: 'admin',
            }, req.panelGameType);
            res.json(enrichReservationDetail(detail, req));
        } catch (error) {
            const code = /not found/i.test(error.message) ? 404 : 400;
            res.status(code).json({ error: error.message });
        }
    });

    router.delete('/api/admin/position-reservations/reservations/:reservationId', requireAuth, requireReservationAccess, (req, res) => {
        try {
            const reservation = positionReservations.getReservation(req.params.reservationId, req.panelGameType);
            if (!reservation) return res.status(404).json({ error: 'Reservation not found' });
            if (!canManageAllReservations(req) && !positionReservations.canUserAccessList(reservation.listId, req.userId, false, req.panelGameType)) {
                return res.status(404).json({ error: 'Reservation list not found' });
            }
            const detail = positionReservations.deleteReservation(req.params.reservationId, req.panelGameType);
            res.json(enrichReservationDetail(detail, req));
        } catch (error) {
            const code = /not found/i.test(error.message) ? 404 : 400;
            res.status(code).json({ error: error.message });
        }
    });

    router.get('*', (req, res) => {
        // Use forwarded prefix from central proxy, or the env-configured BASE_PATH
        const prefix = req.headers['x-forwarded-prefix'] || BASE_PATH;
        const safePrefix = escapeHtml(prefix);
        let html = getIndexHtml().replace(
            '<meta name="base-path" content="">',
            `<meta name="base-path" content="${safePrefix}">`
        );

        // Inject <base> tag so relative asset paths resolve correctly through the proxy
        if (prefix) {
            html = html.replace('<head>', `<head>\n    <base href="${safePrefix}/">`);
        }

        res.type('html').set('Cache-Control', 'no-cache').send(html);
    });

    app.use(BASE_PATH || '/', router);

    return app;
}

// ─────────────────────────────────────────────────────────────────────────────
// Start / Stop
// ─────────────────────────────────────────────────────────────────────────────
const tunnel = require('./tunnel');
const WS_FALLBACK_DELAY_MS = 20_000;
let wsFallbackTimer = null;
let wsTunnelFallbackActive = false;
let wsStateUnsubscribe = null;

function clearWsFallbackTimer() {
    if (wsFallbackTimer) {
        clearTimeout(wsFallbackTimer);
        wsFallbackTimer = null;
    }
}

function requireGuestOrAuthenticatedCalculators(req, res, next) {
    const authResult = maybeAttachAuthFromCookie(req, res);
    if (authResult.ok && authResult.authenticated) {
        return next();
    }

    const publicFeatures = getPublicFeatures();
    if (isGuestPublicToolsEnabled() && publicFeatures.calculators) {
        req.userId = null;
        req.adminData = null;
        req.isAdmin = false;
        req.isGuest = true;
        req.publicFeatures = publicFeatures;
        req.discordUsername = 'Guest';
        req.discordAvatar = null;
        return next();
    }

    const status = authResult.status || 401;
    const error = authResult.error || 'Not authenticated';
    return res.status(status).json({ error });
}

function configureTunnelReregister(tunnelType) {
    if (tunnelType === 'localtunnel' && centralProxy.isConfigured()) {
        tunnel.setReconnectHandler((newUrl) => {
            centralProxy.reRegister(newUrl).catch(err => {
                console.warn('[Web Panel] Could not re-register after tunnel reconnect:', err.message);
            });
        });
    } else {
        tunnel.setReconnectHandler(null);
    }
}

async function activateWsTunnelFallback(port) {
    if (!centralProxy.isLegacyModeEnabled()) return;
    if (wsTunnelFallbackActive || tunnel.getTunnelUrl()) return;

    const tunnelResult = await tunnel.openTunnel(port);
    if (!tunnelResult) {
        console.log(`[Web Panel] No tunnel available — direct IP access only (http://${publicAddress}:${port})`);
        return;
    }

    wsTunnelFallbackActive = true;
    configureTunnelReregister(tunnelResult.type);

    if (centralProxy.isConfigured()) {
        centralProxy.reRegister(tunnelResult.url).catch(err => {
            console.warn('[Web Panel] Could not re-register tunnel fallback with central proxy:', err.message);
        });
    }

    console.log(`[Web Panel] Tunnel fallback active via ${tunnelResult.type}: ${tunnelResult.url}`);
}

function deactivateWsTunnelFallback() {
    clearWsFallbackTimer();
    configureTunnelReregister(null);

    if (tunnel.getTunnelUrl()) {
        tunnel.closeTunnel();
        console.log('[Web Panel] Tunnel fallback closed after WebSocket recovery.');
    }

    wsTunnelFallbackActive = false;
}

function scheduleWsTunnelFallback(port) {
    if (!centralProxy.isLegacyModeEnabled()) return;
    if (!centralProxy.isWsConfigured()) return;
    if (wsFallbackTimer || wsTunnelFallbackActive) return;

    wsFallbackTimer = setTimeout(async () => {
        wsFallbackTimer = null;
        if (!wsClient.isConnected() && serverInstance) {
            await activateWsTunnelFallback(port);
        }
    }, WS_FALLBACK_DELAY_MS);
}

async function determineStartupConnectivityMode(selfHosted) {
    if (selfHosted) {
        return 'self-hosted';
    }

    if (centralProxy.isWsConfigured()) {
        return 'ws';
    }

    if (centralProxy.isLegacyModeEnabled() && centralProxy.isLegacyConfigured()) {
        return 'tunnel';
    }

    return 'setup';
}

async function startServer(client, port = DEFAULT_PORT) {
    if (serverInstance) return serverInstance;
    if (lifecycleState.startPromise) return lifecycleState.startPromise;

    lifecycleState.startPromise = (async () => {
        if (lifecycleState.stopPromise) {
            await lifecycleState.stopPromise;
        }

        if (serverInstance) return serverInstance;

        const selfHosted = isOAuth2Configured() && getSelfHostedPublicUrl();
        const app = createServer(client);

        return new Promise((resolve, reject) => {
        let currentPort = port;
        let attempts = 0;

        function tryListen() {
            const server = app.listen(currentPort, '0.0.0.0', async () => {
                serverInstance = server;
                runningPort = currentPort;
                publicAddress = await detectPublicIP();

                const preferredMode = selfHosted ? null : await centralProxy.ensurePreferredConnectionMode();
                if (preferredMode?.action === 'migrated') {
                    console.log('[Web Panel] Automatically migrated stored legacy registration to WebSocket hub mode.');
                } else if (preferredMode?.action === 'migration_failed') {
                    console.warn(`[Web Panel] Automatic legacy migration failed: ${preferredMode.error}`);
                }

                const startupMode = await determineStartupConnectivityMode(selfHosted);

                // Connect to the central hub via WebSocket (no tunnel needed for this path).
                // When WS credentials are available, keep startup on the WS path and do not
                // immediately re-register a Cloudflare/localtunnel URL over the central record.
                if (startupMode === 'self-hosted') {
                    console.log(`[Web Panel] Self-hosted Discord login enabled at ${selfHosted}.`);
                } else if (startupMode === 'ws') {
                    wsTunnelFallbackActive = false;
                    clearWsFallbackTimer();
                    if (wsStateUnsubscribe) {
                        wsStateUnsubscribe();
                        wsStateUnsubscribe = null;
                    }
                    wsStateUnsubscribe = wsClient.onStateChange((state) => {
                        if (state === 'authenticated') {
                            deactivateWsTunnelFallback();
                            return;
                        }

                        if (state === 'disconnected') {
                            scheduleWsTunnelFallback(currentPort);
                        }
                    });
                    wsClient.connect(currentPort, issueJwtForDiscordUser);
                    console.log('[Web Panel] WebSocket hub mode enabled — skipping startup tunnel registration.');
                } else if (startupMode === 'setup') {
                    console.log('[Web Panel] Legacy tunnel mode is disabled - waiting for WebSocket hub setup.');
                } else {
                    const tunnelResult = await tunnel.openTunnel(currentPort);

                    if (tunnelResult) {
                        configureTunnelReregister(tunnelResult.type);
                        // Re-register current tunnel URL with the central proxy so OAuth2
                        // callbacks and other proxy-forwarded requests reach the new URL.
                        // This is critical on localtunnel, which issues a new URL on every restart.
                        if (centralProxy.isConfigured()) {
                            centralProxy.reRegister(tunnelResult.url).catch(err => {
                                console.warn('[Web Panel] Could not re-register with central proxy:', err.message);
                            });
                        }
                    } else {
                        console.log(`[Web Panel] No tunnel available — direct IP access only (http://${publicAddress}:${currentPort})`);
                    }
                }

                resolve(server);
            });

            server.on('error', (error) => {
                if (error.code === 'EADDRINUSE' && attempts < MAX_PORT_RETRIES) {
                    attempts++;
                    currentPort++;
                    console.log(`[Web Panel] Port ${currentPort - 1} in use, trying ${currentPort}...`);
                    tryListen();
                } else {
                    serverInstance = null;
                    runningPort = null;
                    reject(error);
                }
            });
        }

            tryListen();
        });
    })();

    try {
        return await lifecycleState.startPromise;
    } finally {
        lifecycleState.startPromise = null;
    }
}

function stopServer() {
    if (lifecycleState.stopPromise) return lifecycleState.stopPromise;

    clearWsFallbackTimer();
    wsTunnelFallbackActive = false;
    if (wsStateUnsubscribe) {
        wsStateUnsubscribe();
        wsStateUnsubscribe = null;
    }
    configureTunnelReregister(null);
    tunnel.closeTunnel();
    wsClient.disconnect();
    lifecycleState.stopPromise = new Promise((resolve) => {
        if (!serverInstance) return resolve();
        const instance = serverInstance;
        // Clear state immediately so startServer can proceed if called before close completes
        serverInstance = null;
        runningPort = null;
        instance.close(() => {
            console.log('[Web Panel] Server stopped');
            resolve();
        });
    });

    return lifecycleState.stopPromise.finally(() => {
        lifecycleState.stopPromise = null;
    });
}

function getRunningPort() {
    return runningPort;
}

function getPublicAddress() {
    return publicAddress;
}

function getTunnelUrl() {
    return tunnel.getTunnelUrl();
}

function getBasePath() {
    return BASE_PATH;
}

/** Returns true when the bot is actively connected to the central WS hub. */
function isWsConnected() {
    return wsClient.isConnected();
}

module.exports = { startServer, stopServer, getRunningPort, getPublicAddress, getTunnelUrl, getBasePath, isWsConnected, issueJwtForDiscordUser, DEFAULT_PORT };
