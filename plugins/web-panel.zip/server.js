const express = require('express');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const {
    validateLoginToken, JWT_SECRET, JWT_EXPIRY,
    isOAuth2Configured, getClientSecret, buildOAuth2Url,
    exchangeCode, fetchDiscordUser,
    generateOAuth2State, validateOAuth2State
} = require('./auth');
const centralProxy = require('./centralProxy');
const pluginDb = require('./pluginDb');

const {
    adminQueries,
    playerQueries,
    allianceQueries,
    notificationQueries,
    processQueries,
    giftCodeQueries,
    giftCodeUsageQueries,
    settingsQueries,
    systemLogQueries,
    userQueries,
    adminLogQueries
} = require('../../src/functions/utility/database');

const { PERMISSIONS } = require('../../src/functions/Settings/admin/permissions');
const { createProcess, PROCESS_PRIORITIES } = require('../../src/functions/Processes/createProcesses');
const { queueManager } = require('../../src/functions/Processes/queueManager');
const { createRedeemProcess } = require('../../src/functions/GiftCode/redeemFunction');
const { notificationScheduler } = require('../../src/functions/Notification/notificationScheduler');

const { ChannelType } = require('discord.js');

// ── Panel Access Level ────────────────────────────────────────────────────────
/** Who is allowed to log in to the web panel. Persisted in pluginDb. */
const PANEL_ACCESS = {
    EVERYONE:    'everyone',    // Anyone with the URL can log in via Discord OAuth2
    BOT_USERS:   'bot_users',  // Only users registered in the bot's users table
    ADMINS_ONLY: 'admins_only',// Only admins
    OWNER_ONLY:  'owner_only', // Only the bot owner
};
const PANEL_ACCESS_KEY = 'panel_access_level';
const PANEL_ACCESS_DEFAULT = PANEL_ACCESS.EVERYONE;

/** Returns the configured panel access level. */
function getPanelAccessLevel() {
    return pluginDb.get(PANEL_ACCESS_KEY) || PANEL_ACCESS_DEFAULT;
}

/**
 * Returns true if the given user is allowed to access the panel based on
 * the current panel access level.
 * @param {{ adminData: object|null, isOwner: boolean, inUsersTable: boolean }} ctx
 */
function isAllowedByAccessLevel(ctx) {
    const level = getPanelAccessLevel();
    if (level === PANEL_ACCESS.EVERYONE) return true;
    if (level === PANEL_ACCESS.BOT_USERS) return ctx.inUsersTable || !!ctx.adminData;
    if (level === PANEL_ACCESS.ADMINS_ONLY) return !!ctx.adminData;
    if (level === PANEL_ACCESS.OWNER_ONLY) return ctx.isOwner;
    return false;
}

const DEFAULT_PORT = parseInt(process.env.PORT, 10) || 3010;
const MAX_PORT_RETRIES = 10;
const BASE_PATH = (process.env.WEB_PANEL_BASE_PATH || '').replace(/\/+$/, '');

// Furnace level display mapping — used in CSV export
const FURNACE_LEVEL_DISPLAY = {
    31:'30-1',32:'30-2',33:'30-3',34:'30-4',35:'FC 1',
    36:'FC 1-1',37:'FC 1-2',38:'FC 1-3',39:'FC 1-4',40:'FC 2',
    41:'FC 2-1',42:'FC 2-2',43:'FC 2-3',44:'FC 2-4',45:'FC 3',
    46:'FC 3-1',47:'FC 3-2',48:'FC 3-3',49:'FC 3-4',50:'FC 4',
    51:'FC 4-1',52:'FC 4-2',53:'FC 4-3',54:'FC 4-4',55:'FC 5',
    56:'FC 5-1',57:'FC 5-2',58:'FC 5-3',59:'FC 5-4',60:'FC 6',
    61:'FC 6-1',62:'FC 6-2',63:'FC 6-3',64:'FC 6-4',65:'FC 7',
    66:'FC 7-1',67:'FC 7-2',68:'FC 7-3',69:'FC 7-4',70:'FC 8',
    71:'FC 8-1',72:'FC 8-2',73:'FC 8-3',74:'FC 8-4',75:'FC 9',
    76:'FC 9-1',77:'FC 9-2',78:'FC 9-3',79:'FC 9-4',80:'FC 10',
    81:'FC 10-1',82:'FC 10-2',83:'FC 10-3',84:'FC 10-4'
};

/**
 * Safely parse a JSON string, returning a fallback value on parse failure.
 * @param {string} jsonString
 * @param {*} fallback
 */
function parseJsonSafe(jsonString, fallback) {
    try {
        return JSON.parse(jsonString);
    } catch {
        return fallback;
    }
}

/**
 * Escape a string for safe insertion into HTML attributes/content.
 * Prevents XSS from user-controlled values like x-forwarded-prefix.
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

let serverInstance = null;
let runningPort = null;
let publicAddress = null;

/**
 * Detect the machine's public IP via external service.
 * Falls back to LAN IP from os.networkInterfaces(), then 'localhost'.
 */
async function detectPublicIP() {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        const response = await fetch('https://api.ipify.org?format=json', { signal: controller.signal });
        clearTimeout(timeout);
        if (response.ok) {
            const { ip } = await response.json();
            if (ip) return ip;
        }
    } catch {
        // External service unreachable -- fall back to LAN IP
    }

    try {
        const os = require('os');
        const interfaces = os.networkInterfaces();
        for (const name of Object.keys(interfaces)) {
            for (const iface of interfaces[name]) {
                if (iface.family === 'IPv4' && !iface.internal) return iface.address;
            }
        }
    } catch {
        // os module issue -- fall back
    }

    return 'localhost';
}

// ─────────────────────────────────────────────────────────────────────────────
// Auth middleware
// ─────────────────────────────────────────────────────────────────────────────

/** Feature access bit flag for "everyone" (mirrors FEATURE_ACCESS.EVERYONE) */
const FEATURE_ACCESS_EVERYONE = 1;
/** Feature access bit flag for "no one" (mirrors FEATURE_ACCESS.NO_ONE) */
const FEATURE_ACCESS_NO_ONE = 8;

/**
 * Read the bot's feature_access settings and return which features are publicly
 * accessible (access === EVERYONE). Defaults to true if a feature is not configured.
 * @returns {{ calculators: boolean, privateNotifications: boolean }}
 */
function getPublicFeatures() {
    try {
        const row = settingsQueries.getFeatureAccess.get();
        const parsed = JSON.parse(row?.feature_access || '{}');
        return {
            calculators: isFeaturePublic('calculators', parsed),
            privateNotifications: isFeaturePublic('privateNotifications', parsed),
        };
    } catch {
        return { calculators: false, privateNotifications: false };
    }
}

/**
 * @param {string} featureName
 * @param {object} parsed - Parsed feature_access JSON object
 * @returns {boolean}
 */
function isFeaturePublic(featureName, parsed) {
    const featureCfg = parsed[featureName];
    if (!featureCfg || typeof featureCfg !== 'object') return true; // not configured → everyone
    const access = Number(featureCfg.access) || FEATURE_ACCESS_EVERYONE;
    if (access & FEATURE_ACCESS_NO_ONE) return false;
    return !!(access & FEATURE_ACCESS_EVERYONE);
}

function requireAuth(req, res, next) {
    const token = req.cookies?.panel_token;
    if (!token) return res.status(401).json({ error: 'Not authenticated' });

    try {
        const payload = jwt.verify(token, JWT_SECRET);
        const adminData = adminQueries.getAdmin(payload.userId);
        const isOwner = !!(adminData?.is_owner);
        const userData = adminData ? null : userQueries.getUser(payload.userId);
        const inUsersTable = !!(adminData || userData);

        if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
            res.clearCookie('panel_token');
            return res.status(403).json({ error: 'Access restricted' });
        }

        if (adminData) {
            req.userId = payload.userId;
            req.adminData = adminData;
            req.isAdmin = true;
        } else {
            if (!userData) {
                // Access level is everyone — allow unauthenticated Discord users
                // (they were issued a JWT via OAuth2 but have no bot record)
                req.userId = payload.userId;
                req.adminData = null;
                req.isAdmin = false;
                req.publicFeatures = getPublicFeatures();
            } else {
                req.userId = payload.userId;
                req.adminData = null;
                req.isAdmin = false;
                req.publicFeatures = getPublicFeatures();
            }
        }

        req.discordUsername = payload.username || null;
        req.discordAvatar = payload.avatar || null;
        next();
    } catch {
        res.clearCookie('panel_token');
        return res.status(401).json({ error: 'Session expired' });
    }
}

/**
 * Permission check middleware factory.
 * Owner always passes. Non-admins always fail. Otherwise checks if user has any of the listed permissions.
 * @param  {...number} perms - Permission bit flags required (any match passes)
 */
function requirePermission(...perms) {
    return (req, res, next) => {
        if (!req.isAdmin) return res.status(403).json({ error: 'Insufficient permissions' });
        if (req.adminData.is_owner) return next();
        const hasAccess = perms.some(p => req.adminData.permissions & p);
        if (!hasAccess) return res.status(403).json({ error: 'Insufficient permissions' });
        next();
    };
}

/**
 * Renders a branded full-page error screen (used for auth-time rejections
 * where the SPA hasn't loaded yet, e.g. "not an admin").
 * @param {string} title - Page title and heading
 * @param {string} message - HTML body text
 * @param {Object} opts
 * @param {string} [opts.basePath] - URL prefix (from x-forwarded-prefix or BASE_PATH)
 * @param {string} [opts.iconSrc] - Path to icon image (relative to basePath)
 * @param {string} [opts.actionLabel] - Button text
 * @param {string} [opts.actionHref] - Button URL
 */
function renderErrorPage(title, message, { basePath = BASE_PATH, iconSrc = '/icons/access-denied.png', actionLabel, actionHref } = {}) {
    const safeBasePath = escapeHtml(basePath);
    const safeTitle = escapeHtml(title);
    const safeIconSrc = escapeHtml(iconSrc);
    const actionHTML = actionLabel && actionHref
        ? `<a class="error-action" href="${escapeHtml(actionHref)}">${escapeHtml(actionLabel)}</a>`
        : '';
    const iconHTML = `<img src="${safeBasePath}${safeIconSrc}" alt="" width="48" height="48">`;

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#090916">
    <meta name="color-scheme" content="dark">
    <title>${safeTitle}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            background: #090916; color: #e8eaf0;
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
            position: relative; overflow: hidden;
        }
        body::before {
            content: ''; position: absolute; inset: 0;
            background:
                radial-gradient(ellipse 800px 400px at 50% 40%, rgba(248,113,113,0.08) 0%, transparent 70%),
                radial-gradient(ellipse 400px 300px at 30% 60%, rgba(167,139,250,0.06) 0%, transparent 70%);
            pointer-events: none;
        }
        .error-card {
            position: relative; z-index: 1;
            background: rgba(22, 22, 55, 0.65);
            backdrop-filter: blur(30px); -webkit-backdrop-filter: blur(30px);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 20px; padding: 48px 40px;
            text-align: center; max-width: 580px; width: 90%;
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
            animation: fadeIn 0.5s ease-out;
        }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: none; } }
        .error-icon {
            width: 72px; height: 72px;
            background: rgba(248,113,113,0.12); border: 1px solid rgba(248,113,113,0.25);
            border-radius: 16px; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 20px;
        }
        .error-icon img { width: 48px; height: 48px; object-fit: contain; }
        h1 { font-size: 22px; font-weight: 700; margin-bottom: 10px; letter-spacing: -0.3px; }
        .error-message { color: #8b8da8; font-size: 14px; line-height: 1.7; margin-bottom: 24px; }
        .error-action {
            display: inline-block; padding: 10px 28px;
            background: rgba(99,139,255,0.12); border: 1px solid rgba(99,139,255,0.25);
            border-radius: 10px; color: #638bff; text-decoration: none;
            font-size: 14px; font-weight: 500; transition: background 0.2s, border-color 0.2s;
        }
        .error-action:hover { background: rgba(99,139,255,0.2); border-color: rgba(99,139,255,0.4); }
    </style>
</head>
<body>
    <div class="error-card">
        <div class="error-icon">${iconHTML}</div>
        <h1>${safeTitle}</h1>
        <p class="error-message">${message}</p>
        ${actionHTML}
    </div>
</body>
</html>`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Server factory
// ─────────────────────────────────────────────────────────────────────────────
function createServer(client) {
    const app = express();
    // Trust the immediately upstream proxy (central-proxy or any reverse proxy).
    // Required so req.ip returns the real client IP rather than the proxy address,
    // which makes the auth rate limiter work correctly per-user.
    app.set('trust proxy', 1);
    const router = express.Router();

    router.use(express.json({ limit: '1mb' }));
    router.use(cookieParser());

    // ── CSRF protection for state-changing requests ──────────────────────
    router.use((req, res, next) => {
        if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

        const origin = req.headers['origin'];
        const referer = req.headers['referer'];

        // Allow requests with no origin (same-origin, cURL, non-browser)
        if (!origin && !referer) return next();

        // Validate origin matches our host or the forwarded host (reverse proxy)
        const host = req.headers['x-forwarded-host'] || req.headers['host'];
        if (origin) {
            try {
                const originHost = new URL(origin).host;
                if (originHost !== host) {
                    return res.status(403).json({ error: 'Cross-origin request blocked' });
                }
            } catch {
                return res.status(403).json({ error: 'Invalid origin' });
            }
        }

        next();
    });
    router.use(express.static(path.join(__dirname, 'public'), { index: false }));

    // HTML template — re-read on every request so rebuilds take effect without restart
    const indexPath = path.join(__dirname, 'public', 'index.html');
    let cachedHtml = null;
    let cachedHtmlMtime = 0;

    function getIndexHtml() {
        const mtime = fs.statSync(indexPath).mtimeMs;
        if (!cachedHtml || mtime !== cachedHtmlMtime) {
            cachedHtml = fs.readFileSync(indexPath, 'utf8');
            cachedHtmlMtime = mtime;
        }
        return cachedHtml;
    }

    const publicDir = path.join(__dirname, 'public');

    // ── Rate limiter for auth endpoints ──────────────────────────────────
    const authRateMap = new Map();
    const AUTH_RATE_WINDOW_MS = 60 * 1000;
    const AUTH_RATE_MAX = 10;

    /**
     * Simple per-IP rate limiter middleware for auth routes.
     */
    function authRateLimit(req, res, next) {
        const ip = req.ip || req.connection.remoteAddress;
        const now = Date.now();
        let entry = authRateMap.get(ip);
        if (!entry || now > entry.resetAt) {
            entry = { count: 0, resetAt: now + AUTH_RATE_WINDOW_MS };
            authRateMap.set(ip, entry);
        }
        entry.count++;
        if (entry.count > AUTH_RATE_MAX) {
            return res.status(429).json({ error: 'Too many requests. Please try again later.' });
        }
        next();
    }

    // Clean up stale rate-limit entries every 5 minutes
    setInterval(() => {
        const now = Date.now();
        for (const [ip, entry] of authRateMap) {
            if (now > entry.resetAt) authRateMap.delete(ip);
        }
    }, 5 * 60 * 1000).unref();

    // ── Auth routes ──────────────────────────────────────────────────────

    // OAuth2 login — redirect to Discord
    router.get('/auth/login', authRateLimit, (req, res) => {
        const prefix = req.headers['x-forwarded-prefix'] || BASE_PATH;

        // Legacy token-based login (still supported as fallback)
        const { token } = req.query;
        if (token) {
            const userId = validateLoginToken(token);
            if (!userId) return res.status(401).send(renderErrorPage('Link Expired', 'This login link is invalid or has expired.<br>Use the <strong>/webpanel</strong> command in Discord to get a new one.', {
                    basePath: prefix,
                    actionLabel: 'Back to Discord',
                    actionHref: 'https://discord.com/channels/@me'
                }));

            const adminData = adminQueries.getAdmin(userId);
            const isOwner = !!(adminData?.is_owner);
            const userData = adminData ? null : userQueries.getUser(userId);
            const inUsersTable = !!(adminData || userData);

            if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
                return res.status(403).send(renderErrorPage('Access Denied', 'The bot owner has restricted access to this panel.<br>Contact the bot owner for access.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }
            if (!adminData && !userData) {
                return res.status(403).send(renderErrorPage('Access Denied', 'Your Discord account is not registered for this bot.<br>Ask the bot owner to add you as an admin, or use the bot in Discord first.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }

            const jwtToken = jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
            res.cookie('panel_token', jwtToken, {
                httpOnly: true,
                sameSite: 'lax',
                secure: req.secure || req.headers['x-forwarded-proto'] === 'https',
                maxAge: 30 * 24 * 60 * 60 * 1000
            });

            return res.redirect(BASE_PATH + '/');
        }

        // OAuth2 login
        if (!isOAuth2Configured() || !client.application?.id) {
            return res.status(503).send(renderErrorPage('OAuth2 Not Configured', 'The bot owner hasn\u2019t set up Discord login yet.<br>Use the <strong>/webpanel</strong> command in Discord to start setup.', {
                basePath: prefix,
                actionLabel: 'Back to Discord',
                actionHref: 'https://discord.com/channels/@me'
            }));
        }

        const publicUrl = centralProxy.getPublicUrl();
        const redirectUri = publicUrl
            ? `${publicUrl}/auth/callback`
            : `http://${req.headers.host}${BASE_PATH}/auth/callback`;

        const oauthUrl = buildOAuth2Url(client.application.id, redirectUri, generateOAuth2State());
        res.redirect(oauthUrl);
    });

    // OAuth2 callback — exchange code for user identity
    router.get('/auth/callback', authRateLimit, async (req, res) => {
        const prefix = req.headers['x-forwarded-prefix'] || BASE_PATH;

        const { code, state } = req.query;
        if (!code) return res.status(400).send(renderErrorPage('Invalid Request', 'The authorization code is missing.<br>Please try logging in again from Discord.', {
            basePath: prefix,
            actionLabel: 'Try Again',
            actionHref: prefix + '/auth/login'
        }));

        if (!state || !validateOAuth2State(state)) {
            return res.status(403).send(renderErrorPage('Invalid Request', 'The login session has expired or was tampered with.<br>Please try logging in again.', {
                basePath: prefix,
                actionLabel: 'Try Again',
                actionHref: prefix + '/auth/login'
            }));
        }

        const clientSecret = getClientSecret();
        if (!clientSecret || !client.application?.id) {
            return res.status(503).send(renderErrorPage('OAuth2 Not Configured', 'The bot owner hasn\u2019t finished setting up Discord login.<br>Use the <strong>/webpanel</strong> command in Discord to complete setup.', {
                basePath: prefix,
                actionLabel: 'Back to Discord',
                actionHref: 'https://discord.com/channels/@me'
            }));
        }

        const publicUrl = centralProxy.getPublicUrl();
        const redirectUri = publicUrl
            ? `${publicUrl}/auth/callback`
            : `http://${req.headers.host}${BASE_PATH}/auth/callback`;

        try {
            const tokenData = await exchangeCode(code, client.application.id, clientSecret, redirectUri);
            if (!tokenData?.access_token) {
                return res.status(401).send(renderErrorPage('Authentication Failed', 'Discord didn\u2019t return a valid session.<br>This can happen if the login expired or was cancelled. Please try again.', {
                    basePath: prefix,
                    actionLabel: 'Try Again',
                    actionHref: prefix + '/auth/login'
                }));
            }

            const discordUser = await fetchDiscordUser(tokenData.access_token);
            if (!discordUser?.id) {
                return res.status(401).send(renderErrorPage('Profile Error', 'Couldn\u2019t retrieve your Discord profile.<br>This is usually temporary. Please try logging in again.', {
                    basePath: prefix,
                    actionLabel: 'Try Again',
                    actionHref: prefix + '/auth/login'
                }));
            }

            const adminData = adminQueries.getAdmin(discordUser.id);
            const isOwner = !!(adminData?.is_owner);
            const userData = adminData ? null : userQueries.getUser(discordUser.id);
            const inUsersTable = !!(adminData || userData);

            if (!isAllowedByAccessLevel({ adminData, isOwner, inUsersTable })) {
                return res.status(403).send(renderErrorPage('Access Denied', 'The bot owner has restricted access to this panel.<br>Contact the bot owner for access.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }
            if (!adminData && !userData && getPanelAccessLevel() !== PANEL_ACCESS.EVERYONE) {
                return res.status(403).send(renderErrorPage('Access Denied', 'Your Discord account is not registered for this bot.<br>Ask the bot owner to add you, or use the bot in Discord first.', {
                    basePath: prefix,
                    iconSrc: '/icons/access-denied.png'
                }));
            }

            const jwtToken = jwt.sign({
                userId: discordUser.id,
                username: discordUser.global_name || discordUser.username,
                avatar: discordUser.avatar
            }, JWT_SECRET, { expiresIn: JWT_EXPIRY });
            res.cookie('panel_token', jwtToken, {
                httpOnly: true,
                sameSite: 'lax',
                secure: req.secure || req.headers['x-forwarded-proto'] === 'https',
                maxAge: 30 * 24 * 60 * 60 * 1000
            });

            res.redirect(BASE_PATH + '/');
        } catch (error) {
            console.error('[Web Panel] OAuth2 callback error:', error.message);
            res.status(500).send(renderErrorPage('Something Went Wrong', 'Authentication failed due to an unexpected error.<br>Please try again. If the problem persists, contact the bot owner.', {
                basePath: prefix,
                actionLabel: 'Try Again',
                actionHref: prefix + '/auth/login'
            }));
        }
    });

    router.post('/auth/logout', (req, res) => {
        res.clearCookie('panel_token');
        res.json({ ok: true });
    });

    router.get('/auth/me', requireAuth, (req, res) => {
        const userData = userQueries.getUser(req.userId);
        const avatarHash = req.discordAvatar;
        const avatarUrl = avatarHash
            ? `https://cdn.discordapp.com/avatars/${req.userId}/${avatarHash}.${avatarHash.startsWith('a_') ? 'gif' : 'webp'}?size=64`
            : `https://cdn.discordapp.com/embed/avatars/${(BigInt(req.userId) >> 22n) % 6n}.png`;

        if (!req.isAdmin) {
            const publicFeatures = getPublicFeatures();
            return res.json({
                userId: req.userId,
                username: req.discordUsername || 'User',
                avatar: avatarUrl,
                permissions: 0,
                isOwner: false,
                isAdmin: false,
                publicFeatures,
                language: userData?.language || 'en'
            });
        }

        res.json({
            userId: req.userId,
            username: req.discordUsername || 'Admin',
            avatar: avatarUrl,
            permissions: req.adminData.permissions,
            isOwner: !!req.adminData.is_owner,
            isAdmin: true,
            language: userData?.language || 'en'
        });
    });

    // ── Bot info (public, no auth) ───────────────────────────────────────
    router.get('/api/botinfo', (_req, res) => {
        const botUser = client.user;
        res.json({
            name: botUser?.username || 'Bot',
            avatar: botUser?.displayAvatarURL({ size: 64 }) || null,
            // Don't gate on client.application?.id — it may not be set yet on fresh restart.
            // The /auth/login route already handles the "not ready" case with a friendly error.
            hasOAuth2: isOAuth2Configured()
        });
    });

    // ── Dashboard ────────────────────────────────────────────────────────
    router.get('/api/dashboard', requireAuth, (req, res) => {
        try {
            const isOwner = req.adminData.is_owner;
            const perms = req.adminData.permissions;
            const canPlayers = isOwner || (perms & PERMISSIONS.PLAYER_MANAGEMENT) || (perms & PERMISSIONS.ALLIANCE_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canAlliances = isOwner || (perms & PERMISSIONS.ALLIANCE_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canNotifications = isOwner || (perms & PERMISSIONS.NOTIFICATIONS_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canGiftCodes = isOwner || (perms & PERMISSIONS.GIFT_CODE_MANAGEMENT) || (perms & PERMISSIONS.FULL_ACCESS);
            const canLogs = isOwner || (perms & PERMISSIONS.FULL_ACCESS);

            const counts = {};
            if (canPlayers) counts.players = playerQueries.countPlayers();
            if (canAlliances) counts.alliances = allianceQueries.countAlliances();
            if (canNotifications) counts.activeNotifications = notificationQueries.countActiveNotifications();
            if (canGiftCodes) counts.giftCodes = giftCodeQueries.countGiftCodes();

            counts.activeProcesses = processQueries.countActiveProcesses();

            const memUsage = process.memoryUsage();
            const recentLogs = canLogs ? systemLogQueries.getRecentLogs(10) : [];

            res.json({
                counts,
                memory: {
                    heapUsedMB: Math.round(memUsage.heapUsed / 1048576),
                    heapTotalMB: Math.round(memUsage.heapTotal / 1048576),
                    rssMB: Math.round(memUsage.rss / 1048576)
                },
                processStats: processQueries.getProcessStats(),
                recentLogs,
                uptime: Math.floor(process.uptime())
            });
        } catch (error) {
            console.error('[Web Panel] Dashboard error:', error.message);
            res.status(500).json({ error: 'Failed to load dashboard data' });
        }
    });

    // ── Players ──────────────────────────────────────────────────────────
    router.get('/api/players/:fid', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid FID' });

        const player = playerQueries.getPlayer(fid);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        res.json(player);
    });

    router.delete('/api/players/:fid', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid FID' });

        const player = playerQueries.getPlayer(fid);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        playerQueries.deletePlayer(fid);
        res.json({ ok: true });
    });

    router.post('/api/players/:fid/refresh', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), async (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid FID' });

        const player = playerQueries.getPlayer(fid);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        try {
            const processResult = await createProcess({
                admin_id: req.userId,
                alliance_id: player.alliance_id,
                player_ids: String(fid),
                action: 'refresh'
            });
            await queueManager.manageQueue(processResult);
            res.status(201).json({ ok: true, processId: processResult.process_id });
        } catch (error) {
            console.error('[Web Panel] Player refresh failed:', error.message);
            res.status(500).json({ error: 'Failed to create refresh process' });
        }
    });

    router.post('/api/players/:fid/move', requireAuth, requirePermission(PERMISSIONS.PLAYER_MANAGEMENT, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const fid = parseInt(req.params.fid, 10);
        if (isNaN(fid)) return res.status(400).json({ error: 'Invalid FID' });

        const { allianceId } = req.body;
        const targetAllianceId = parseInt(allianceId, 10);
        if (isNaN(targetAllianceId)) return res.status(400).json({ error: 'Invalid target alliance ID' });

        const player = playerQueries.getPlayer(fid);
        if (!player) return res.status(404).json({ error: 'Player not found' });

        const targetAlliance = allianceQueries.getAllianceById(targetAllianceId);
        if (!targetAlliance) return res.status(404).json({ error: 'Target alliance not found' });

        playerQueries.updatePlayerAlliance(fid, targetAllianceId);
        res.json({ ok: true });
    });

    // ── Alliances ────────────────────────────────────────────────────────
    router.get('/api/alliances', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const isOwner = req.adminData.is_owner;
        const hasFullAccess = isOwner || (req.adminData.permissions & PERMISSIONS.FULL_ACCESS);

        let alliances;
        if (hasFullAccess) {
            alliances = allianceQueries.getAllAlliances();
        } else {
            const assignedIds = parseJsonSafe(req.adminData.alliances, []);
            alliances = allianceQueries.getAllAlliances().filter(a => assignedIds.includes(a.id));
        }

        const allianceIds = alliances.map(a => a.id);
        const playerCounts = allianceIds.length > 0
            ? playerQueries.getPlayerCountsByAllianceIds(allianceIds)
            : [];

        const countMap = new Map(playerCounts.map(c => [c.alliance_id, c.player_count]));
        const enriched = alliances.map(a => ({
            ...a,
            playerCount: countMap.get(a.id) || 0
        }));

        res.json(enriched);
    });

    router.get('/api/alliances/:id', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const isOwner = req.adminData.is_owner;
        const hasFullAccess = isOwner || (req.adminData.permissions & PERMISSIONS.FULL_ACCESS);
        if (!hasFullAccess) {
            const assignedIds = parseJsonSafe(req.adminData.alliances, []);
            if (!assignedIds.includes(id)) {
                return res.status(403).json({ error: 'Access denied to this alliance' });
            }
        }

        const alliance = allianceQueries.getAllianceById(id);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const players = playerQueries.getPlayersByAlliance(id);
        res.json({ ...alliance, players });
    });

    /**
     * Get guild IDs where the user is a member.
     * Uses guild.members.fetch() to ensure accuracy even if the member isn't cached.
     */
    async function getUserGuildIds(userId) {
        const guilds = [...client.guilds.cache.values()];
        const results = await Promise.allSettled(guilds.map(guild => guild.members.fetch(userId)));
        return new Set(
            guilds
                .filter((_, i) => results[i].status === 'fulfilled')
                .map(guild => guild.id)
        );
    }

    // ── Guilds (Discord servers) ─────────────────────────────────────────
    router.get('/api/guilds', requireAuth, async (_req, res) => {
        try {
            const userGuildIds = await getUserGuildIds(_req.userId);
            const results = client.guilds.cache
                .filter(g => userGuildIds.has(g.id))
                .map(guild => ({
                    id: guild.id,
                    name: guild.name,
                    icon: guild.iconURL({ size: 64 }) || null,
                    memberCount: guild.memberCount
                }));
            results.sort((a, b) => a.name.localeCompare(b.name));
            res.json(results);
        } catch (error) {
            res.status(500).json({ error: 'Failed to fetch guilds' });
        }
    });

    router.get('/api/guilds/:id/channels', requireAuth, (req, res) => {
        const guild = client.guilds.cache.get(req.params.id);
        if (!guild) return res.status(404).json({ error: 'Guild not found' });

        const botMember = guild.members.me;
        const canSend = (ch) => ch.type === ChannelType.GuildText && ch.permissionsFor(botMember)?.has('SendMessages');

        const categories = guild.channels.cache
            .filter(ch => ch.type === ChannelType.GuildCategory)
            .sort((a, b) => a.position - b.position);

        const textChannels = guild.channels.cache.filter(canSend);
        const ordered = [];

        // Uncategorized channels first (no parent)
        textChannels
            .filter(ch => !ch.parentId)
            .sort((a, b) => a.position - b.position)
            .forEach(ch => ordered.push({ id: ch.id, name: ch.name }));

        // Channels grouped by category, in category order
        for (const category of categories.values()) {
            textChannels
                .filter(ch => ch.parentId === category.id)
                .sort((a, b) => a.position - b.position)
                .forEach(ch => ordered.push({ id: ch.id, name: ch.name }));
        }

        res.json(ordered);
    });

    router.get('/api/guilds/:id/roles', requireAuth, (req, res) => {
        const guild = client.guilds.cache.get(req.params.id);
        if (!guild) return res.status(404).json({ error: 'Guild not found' });

        const roles = guild.roles.cache
            .filter(r => !r.managed && r.name !== '@everyone')
            .sort((a, b) => b.position - a.position)
            .map(r => ({
                id: r.id,
                name: r.name,
                color: r.color === 0 ? null : '#' + r.color.toString(16).padStart(6, '0')
            }));

        res.json(roles);
    });

    router.get('/api/guilds/:id/members/search', requireAuth, async (req, res) => {
        const guild = client.guilds.cache.get(req.params.id);
        if (!guild) return res.status(404).json({ error: 'Guild not found' });

        const query = (req.query.q || '').trim();
        if (query.length < 2) return res.json([]);

        const limit = Math.min(parseInt(req.query.limit, 10) || 10, 25);

        try {
            const members = await guild.members.fetch({ query, limit });
            const results = [...members.values()].map(m => ({
                id: m.id,
                username: m.user.username,
                displayName: m.displayName || m.user.globalName || m.user.username,
                avatar: m.user.displayAvatarURL({ size: 32, extension: 'webp' }),
            }));
            res.json(results);
        } catch (error) {
            console.error('[Web Panel] Members search error:', error);
            res.json([]);
        }
    });

    router.get('/api/users/batch', requireAuth, async (req, res) => {
        const ids = (req.query.ids || '').split(',').filter(id => /^\d{10,20}$/.test(id)).slice(0, 50);
        if (ids.length === 0) return res.json([]);

        const settled = await Promise.allSettled(ids.map(async id => {
            const user = await client.users.fetch(id);
            return {
                id: user.id,
                username: user.username,
                displayName: user.globalName || user.displayName || user.username,
                avatar: user.displayAvatarURL({ size: 32, extension: 'webp' }),
            };
        }));

        res.json(
            settled.filter(r => r.status === 'fulfilled').map(r => r.value)
        );
    });

    // ── Notifications ────────────────────────────────────────────────────
    router.get('/api/notifications', requireAuth, async (req, res) => {
        const isAdminWithPerms = req.isAdmin && (
            req.adminData.is_owner ||
            (req.adminData.permissions & (PERMISSIONS.NOTIFICATIONS_MANAGEMENT | PERMISSIONS.FULL_ACCESS))
        );

        // Non-admins can only see private notifications if the feature is public
        if (!isAdminWithPerms) {
            if (!req.publicFeatures?.privateNotifications) {
                return res.status(403).json({ error: 'Insufficient permissions' });
            }
            // Return only private notifications for this user
            const privateNotifications = notificationQueries.getPrivateNotifications();
            const userOwned = privateNotifications.filter(n => n.created_by === req.userId);
            return res.json(userOwned);
        }

        try {
            const notifications = notificationQueries.getAllNotifications();
            const userGuildIds = await getUserGuildIds(req.userId);
            const filtered = notifications.filter(n => !n.guild_id || userGuildIds.has(n.guild_id));
            res.json(filtered);
        } catch (error) {
            res.status(500).json({ error: 'Failed to fetch notifications' });
        }
    });

    // ── Processes ────────────────────────────────────────────────────────
    // Any admin with at least one management permission can view processes,
    // since all management operations (refresh, redeem, add player) create them.
    router.get('/api/processes', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { status } = req.query;
        let processes;
        if (status) {
            processes = processQueries.getProcessesByStatus(status);
        } else {
            processes = processQueries.getAllProcesses();
        }

        const enriched = processes.map(p => {
            let progressPercent = 0;
            try {
                const progress = JSON.parse(p.progress || '{}');
                const pendingCount = progress.pending?.length || 0;
                const doneCount = progress.done?.length || 0;
                const failedCount = progress.failed?.length || 0;
                const existingCount = progress.existing?.length || 0;
                const changedCount = progress.changed?.length || 0;
                const unchangedCount = progress.unchanged?.length || 0;
                const processedCount = doneCount + failedCount + existingCount + changedCount + unchangedCount;
                const total = pendingCount + processedCount;
                progressPercent = total > 0 ? Math.round((processedCount / total) * 100) : 0;
            } catch {
                // Invalid JSON, keep 0%
            }
            return { ...p, progressPercent };
        });

        res.json(enriched);
    });

    // ── Gift Codes ───────────────────────────────────────────────────────
    router.get('/api/giftcodes', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (_req, res) => {
        const codes = giftCodeQueries.getAllGiftCodes();
        res.json(codes);
    });

    // ── Admins ───────────────────────────────────────────────────────────
    router.get('/api/admins', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (_req, res) => {
        const admins = adminQueries.getAllAdmins();
        const sanitized = admins.map(({ user_id, permissions, is_owner, added_at }) => ({
            user_id,
            permissions,
            is_owner,
            added_at
        }));
        res.json(sanitized);
    });

    // ── Settings ─────────────────────────────────────────────────────────
    router.get('/api/settings', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (_req, res) => {
        const settings = settingsQueries.getSettings.get();
        res.json(settings);
    });

    // Panel access level — readable by any authenticated user, writable by owner/full-access
    router.get('/api/settings/panel-access', requireAuth, (_req, res) => {
        res.json({ accessLevel: getPanelAccessLevel() });
    });

    router.post('/api/settings/panel-access', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { accessLevel } = req.body;
        const allowedLevels = Object.values(PANEL_ACCESS);
        if (!allowedLevels.includes(accessLevel)) {
            return res.status(400).json({ error: `Invalid access level. Must be one of: ${allowedLevels.join(', ')}` });
        }
        pluginDb.set(PANEL_ACCESS_KEY, accessLevel);
        res.json({ accessLevel });
    });

    // ── System Logs ──────────────────────────────────────────────────────
    router.get('/api/logs', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const page = Math.max(0, parseInt(req.query.page, 10) || 0);
        const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 25));
        const offset = page * limit;
        const typeFilter = req.query.type || null;

        const total = typeFilter
            ? systemLogQueries.countLogsByType(typeFilter)
            : systemLogQueries.countAllLogs();
        const logs = typeFilter
            ? systemLogQueries.getLogsByTypePage(typeFilter, limit, offset)
            : systemLogQueries.getLogsPage(limit, offset);

        res.json({ logs, total, page, limit });
    });

    // ══════════════════════════════════════════════════════════════════════
    //  WRITE ROUTES
    // ══════════════════════════════════════════════════════════════════════

    // ── Gift Code Management ─────────────────────────────────────────────
    router.post('/api/giftcodes', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code, isVip } = req.body;
        if (!code || typeof code !== 'string') return res.status(400).json({ error: 'Gift code is required' });

        const trimmed = code.trim();
        if (trimmed.length === 0 || trimmed.length > 50) return res.status(400).json({ error: 'Gift code must be 1-50 characters' });

        const existing = giftCodeQueries.getGiftCode(trimmed);
        if (existing) return res.status(409).json({ error: 'Gift code already exists' });

        giftCodeQueries.addGiftCode(trimmed, 'active', req.userId, 'web-panel', 0, isVip ? 1 : 0);
        res.status(201).json({ ok: true, code: trimmed });
    });

    router.delete('/api/giftcodes/:code', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const existing = giftCodeQueries.getGiftCode(code);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        giftCodeQueries.removeGiftCode(code);
        res.json({ ok: true });
    });

    router.patch('/api/giftcodes/:code/status', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const { status } = req.body;
        const validStatuses = ['active', 'invalid', 'expired'];
        if (!validStatuses.includes(status)) return res.status(400).json({ error: `Status must be one of: ${validStatuses.join(', ')}` });

        const existing = giftCodeQueries.getGiftCode(code);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        giftCodeQueries.updateGiftCodeStatus(status, code);
        res.json({ ok: true });
    });

    router.patch('/api/giftcodes/:code/vip', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const { isVip } = req.body;
        if (typeof isVip !== 'boolean') return res.status(400).json({ error: 'isVip must be a boolean' });

        const existing = giftCodeQueries.getGiftCode(code);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        giftCodeQueries.updateGiftCodeVipStatus(isVip ? 1 : 0, code);
        res.json({ ok: true });
    });

    router.get('/api/giftcodes/:code/usage', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { code } = req.params;
        const existing = giftCodeQueries.getGiftCode(code);
        if (!existing) return res.status(404).json({ error: 'Gift code not found' });

        const usageCount = giftCodeUsageQueries.getUsageCount(code);
        res.json({ code, usageCount });
    });

    router.post('/api/giftcodes/:code/redeem', requireAuth, requirePermission(PERMISSIONS.GIFT_CODE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), async (req, res) => {
        const { code } = req.params;
        const { allianceId } = req.body;
        if (!allianceId) return res.status(400).json({ error: 'allianceId is required' });

        const existing = giftCodeQueries.getGiftCode(code);
        if (!existing || existing.status !== 'active') return res.status(400).json({ error: 'Gift code is not active' });

        const alliance = allianceQueries.getAllianceById(parseInt(allianceId, 10));
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const players = playerQueries.getPlayersByAlliance(alliance.id);
        if (players.length === 0) return res.status(400).json({ error: 'Alliance has no players' });

        const redeemData = players.map(p => ({
            id: String(p.fid),
            giftCode: code,
            status: 'redeem'
        }));

        try {
            const result = await createRedeemProcess(redeemData, {
                adminId: req.userId,
                allianceContext: {
                    id: alliance.id,
                    name: alliance.name || null,
                    channelId: null,
                    guildId: null
                }
            });

            if (!result.success && result.processId === null) {
                return res.status(409).json({ error: result.message || 'Duplicate process skipped' });
            }

            res.status(201).json({ ok: true, processId: result.processId });
        } catch (error) {
            console.error('[Web Panel] Redeem process creation failed:', error.message);
            res.status(500).json({ error: 'Failed to create redeem process' });
        }
    });

    // ── Notification CRUD ────────────────────────────────────────────────
    router.post('/api/notifications', requireAuth, requirePermission(PERMISSIONS.NOTIFICATIONS_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { name, type, hour, minute, pattern, guildId, channelId, nextTrigger, repeatStatus, repeatFrequency } = req.body;

        if (!name || typeof name !== 'string') return res.status(400).json({ error: 'name is required' });
        if (!['server', 'private'].includes(type)) return res.status(400).json({ error: 'type must be server or private' });

        const parsedHour = parseInt(hour, 10);
        const parsedMinute = parseInt(minute, 10);
        if (isNaN(parsedHour) || parsedHour < 0 || parsedHour > 23) return res.status(400).json({ error: 'hour must be 0-23' });
        if (isNaN(parsedMinute) || parsedMinute < 0 || parsedMinute > 59) return res.status(400).json({ error: 'minute must be 0-59' });

        const resolvedGuildId = type === 'server' ? (guildId || null) : null;
        const resolvedNextTrigger = (nextTrigger && typeof nextTrigger === 'number') ? nextTrigger : null;
        const resolvedRepeatStatus = repeatStatus ? 1 : 0;
        const resolvedRepeatFrequency = repeatFrequency ?? 0;

        const result = notificationQueries.addNotification(
            name.trim(), type, 0, resolvedGuildId, channelId || null,
            parsedHour, parsedMinute,
            null, null, null, null, null, null, null, null, null,
            pattern || null, null, resolvedRepeatStatus, resolvedRepeatFrequency, false,
            true, null, resolvedNextTrigger, req.userId
        );

        const notification = notificationQueries.getNotificationById(result.lastInsertRowid);
        if (notification) notificationScheduler.scheduleNotification(notification);

        res.status(201).json({ ok: true, id: result.lastInsertRowid });
    });

    router.put('/api/notifications/:id', requireAuth, requirePermission(PERMISSIONS.NOTIFICATIONS_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        try {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = notificationQueries.getNotificationById(id);
        if (!existing) return res.status(404).json({ error: 'Notification not found' });

        const body = req.body;
        const pick = (key, fallback) => key in body ? body[key] : fallback;

        notificationQueries.updateNotification(
            id,
            pick('name', existing.name),
            pick('guildId', existing.guild_id),
            pick('channelId', existing.channel_id),
            pick('hour', existing.hour),
            pick('minute', existing.minute),
            pick('messageContent', existing.message_content),
            pick('title', existing.title),
            pick('description', existing.description),
            pick('color', existing.color),
            pick('imageUrl', existing.image_url),
            pick('thumbnailUrl', existing.thumbnail_url),
            pick('footer', existing.footer),
            pick('author', existing.author),
            body.fields !== undefined ? (typeof body.fields === 'string' ? body.fields : JSON.stringify(body.fields)) : existing.fields,
            pick('pattern', existing.pattern),
            body.mention !== undefined ? (typeof body.mention === 'string' ? body.mention : JSON.stringify(body.mention)) : existing.mention,
            pick('repeatStatus', existing.repeat_status),
            pick('repeatFrequency', existing.repeat_frequency),
            pick('embedToggle', existing.embed_toggle),
            pick('isActive', existing.is_active),
            existing.last_trigger,
            body.nextTrigger !== undefined ? body.nextTrigger : existing.next_trigger
        );

        const updated = notificationQueries.getNotificationById(id);
        notificationScheduler.removeNotification(id);
        if (updated?.is_active) notificationScheduler.scheduleNotification(updated);

        res.json({ ok: true });
        } catch (err) {
            console.error('[Web Panel] PUT /api/notifications/:id error:', err);
            res.status(500).json({ error: 'Failed to update notification' });
        }
    });

    router.delete('/api/notifications/:id', requireAuth, requirePermission(PERMISSIONS.NOTIFICATIONS_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = notificationQueries.getNotificationById(id);
        if (!existing) return res.status(404).json({ error: 'Notification not found' });

        notificationScheduler.removeNotification(id);
        notificationQueries.deleteNotification(id);
        res.json({ ok: true });
    });

    router.patch('/api/notifications/:id/active', requireAuth, requirePermission(PERMISSIONS.NOTIFICATIONS_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = notificationQueries.getNotificationById(id);
        if (!existing) return res.status(404).json({ error: 'Notification not found' });

        const { isActive } = req.body;
        if (typeof isActive !== 'boolean') return res.status(400).json({ error: 'isActive must be a boolean' });

        notificationQueries.updateNotificationActiveStatus(id, isActive ? 1 : 0);

        notificationScheduler.removeNotification(id);
        if (isActive) {
            const updated = notificationQueries.getNotificationById(id);
            if (updated) notificationScheduler.scheduleNotification(updated);
        }

        res.json({ ok: true });
    });

    // ── Trigger Actions ──────────────────────────────────────────────────
    router.post('/api/alliances/:id/refresh', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), async (req, res) => {
        const allianceId = parseInt(req.params.id, 10);
        if (isNaN(allianceId)) return res.status(400).json({ error: 'Invalid alliance ID' });

        const alliance = allianceQueries.getAllianceById(allianceId);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const players = playerQueries.getPlayersByAlliance(allianceId);
        if (players.length === 0) return res.status(400).json({ error: 'Alliance has no players' });

        const playerIds = players.map(p => p.fid).join(',');

        try {
            const processResult = await createProcess({
                admin_id: req.userId,
                alliance_id: allianceId,
                player_ids: playerIds,
                action: 'refresh'
            });
            await queueManager.manageQueue(processResult);
            res.status(201).json({ ok: true, processId: processResult.process_id });
        } catch (error) {
            console.error('[Web Panel] Refresh process creation failed:', error.message);
            res.status(500).json({ error: 'Failed to create refresh process' });
        }
    });

    router.get('/api/alliances/:id/export', requireAuth, requirePermission(PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS), (req, res) => {
        const allianceId = parseInt(req.params.id, 10);
        if (isNaN(allianceId)) return res.status(400).json({ error: 'Invalid alliance ID' });

        const alliance = allianceQueries.getAllianceById(allianceId);
        if (!alliance) return res.status(404).json({ error: 'Alliance not found' });

        const players = playerQueries.getPlayersByAlliance(allianceId);
        if (players.length === 0) return res.status(400).json({ error: 'No players to export' });

        const escapeCsvCell = (value) => {
            const str = String(value ?? '');
            return (str.includes(',') || str.includes('"') || str.includes('\n'))
                ? `"${str.replace(/"/g, '""')}"`
                : str;
        };

        const headers = ['Player ID', 'Player Name', 'Furnace Level', 'State'];
        const sortedPlayers = [...players].sort((a, b) => (b.furnace_level || 0) - (a.furnace_level || 0));
        const rows = sortedPlayers.map(p => [
            p.fid,
            p.nickname || '',
            FURNACE_LEVEL_DISPLAY[p.furnace_level] || String(p.furnace_level || 0),
            p.state ?? ''
        ].map(escapeCsvCell).join(','));

        const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
        const safeName = (alliance.name || 'alliance').replace(/[^a-zA-Z0-9_-]/g, '_');

        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="${safeName}_players.csv"`);
        res.send(csvContent);
    });

    router.delete('/api/processes/:id', requireAuth, (req, res) => {
        const id = parseInt(req.params.id, 10);
        if (isNaN(id)) return res.status(400).json({ error: 'Invalid ID' });

        const existing = processQueries.getProcessById(id);
        if (!existing) return res.status(404).json({ error: 'Process not found' });

        if (existing.status === 'active') return res.status(400).json({ error: 'Cannot delete an active process' });

        processQueries.deleteProcess(id);
        res.json({ ok: true });
    });

    // ── Settings Write Routes ────────────────────────────────────────────
    router.put('/api/settings/feature-access', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { featureAccess } = req.body;
        if (!featureAccess || typeof featureAccess !== 'object') return res.status(400).json({ error: 'featureAccess object is required' });

        settingsQueries.setFeatureAccess.run(JSON.stringify(featureAccess));
        res.json({ ok: true });
    });

    router.patch('/api/settings', requireAuth, requirePermission(PERMISSIONS.FULL_ACCESS), (req, res) => {
        const { autoDelete, autoUpdate, notifAutoClean, notifAutoCleanFreq } = req.body;

        if (autoDelete !== undefined) settingsQueries.updateAutoDelete.run(autoDelete ? 1 : 0);
        if (autoUpdate !== undefined) settingsQueries.updateAutoUpdate.run(autoUpdate ? 1 : 0);
        if (notifAutoClean !== undefined) settingsQueries.updateNotifAutoClean.run(notifAutoClean ? 1 : 0);
        if (notifAutoCleanFreq !== undefined) {
            const freq = parseInt(notifAutoCleanFreq, 10);
            if (isNaN(freq) || freq < 60) return res.status(400).json({ error: 'Frequency must be at least 60 seconds' });
            settingsQueries.updateNotifAutoCleanFreq.run(freq);
        }

        res.json({ ok: true });
    });

    // ── Calculators (data bundled inside plugin) ──────────────────────────
    const CALC_BUILDINGS_DIR = path.join(__dirname, '../../src/functions/Calculators/Buildings');
    const CALC_WAR_ACADEMY_DIR = path.join(__dirname, '../../src/functions/Calculators/WarAcademy');
    const CALC_RESEARCH_DIR = path.join(__dirname, 'data/research');

    const ALLOWED_BUILDING_TYPES = new Set(['basic', 'fire_crystal']);
    const ALLOWED_WAR_ACADEMY_CATS = new Set(['Infantry', 'Marksman', 'Lancer']);
    const ALLOWED_RESEARCH_CATS = new Set(['battle', 'economy', 'growth']);

    /**
     * Middleware for calculator routes — allows non-admin users when the
     * calculators feature is set to "everyone" in the bot's feature access.
     */
    function requireCalcAccess(req, res, next) {
        if (req.isAdmin) return next();
        if (req.publicFeatures?.calculators) return next();
        return res.status(403).json({ error: 'Calculators are not publicly accessible' });
    }

    router.get('/api/calculators/buildings/:type', requireAuth, requireCalcAccess, (req, res) => {
        const { type } = req.params;
        if (!ALLOWED_BUILDING_TYPES.has(type)) {
            return res.status(400).json({ error: 'Invalid building type' });
        }
        try {
            const filePath = path.join(CALC_BUILDINGS_DIR, `${type}.json`);
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error(`[Web Panel] Failed to load buildings data (${type}):`, error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    router.get('/api/calculators/war-academy/:category', requireAuth, requireCalcAccess, (req, res) => {
        const { category } = req.params;
        if (!ALLOWED_WAR_ACADEMY_CATS.has(category)) {
            return res.status(400).json({ error: 'Invalid War Academy category' });
        }
        try {
            const filePath = path.join(CALC_WAR_ACADEMY_DIR, `${category}.json`);
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error(`[Web Panel] Failed to load War Academy data (${category}):`, error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    router.get('/api/calculators/research/:category', requireAuth, requireCalcAccess, (req, res) => {
        const { category } = req.params;
        if (!ALLOWED_RESEARCH_CATS.has(category)) {
            return res.status(400).json({ error: 'Invalid research category' });
        }
        try {
            const filePath = path.join(CALC_RESEARCH_DIR, `${category}.json`);
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            res.json(data);
        } catch (error) {
            console.error(`[Web Panel] Failed to load research data (${category}):`, error.message);
            res.status(500).json({ error: 'Failed to load calculator data' });
        }
    });

    // ── SPA fallback ─────────────────────────────────────────────────────
    router.get('*', (req, res) => {
        // Use forwarded prefix from central proxy, or the env-configured BASE_PATH
        const prefix = req.headers['x-forwarded-prefix'] || BASE_PATH;
        const safePrefix = escapeHtml(prefix);
        let html = getIndexHtml().replace(
            '<meta name="base-path" content="">',
            `<meta name="base-path" content="${safePrefix}">`
        );

        // Inject <base> tag so relative asset paths resolve correctly through the proxy
        if (prefix) {
            html = html.replace('<head>', `<head>\n    <base href="${safePrefix}/">`);
        }

        res.type('html').set('Cache-Control', 'no-cache').send(html);
    });

    app.use(BASE_PATH || '/', router);

    return app;
}

// ─────────────────────────────────────────────────────────────────────────────
// Start / Stop
// ─────────────────────────────────────────────────────────────────────────────
const tunnel = require('./tunnel');

function startServer(client, port = DEFAULT_PORT) {
    if (serverInstance) return Promise.resolve(serverInstance);

    const app = createServer(client);

    return new Promise((resolve, reject) => {
        let currentPort = port;
        let attempts = 0;

        function tryListen() {
            const server = app.listen(currentPort, '0.0.0.0', async () => {
                serverInstance = server;
                runningPort = currentPort;
                publicAddress = await detectPublicIP();

                // Always open a tunnel so the central proxy can reach us
                const tunnelResult = await tunnel.openTunnel(currentPort);

                if (tunnelResult) {
                    // Re-register current tunnel URL with the central proxy so OAuth2
                    // callbacks and other proxy-forwarded requests reach the new URL.
                    // This is critical on localtunnel, which issues a new URL on every restart.
                    if (centralProxy.isConfigured()) {
                        centralProxy.reRegister(tunnelResult.url).catch(err => {
                            console.warn('[Web Panel] Could not re-register with central proxy:', err.message);
                        });
                    }
                } else {
                    console.log(`[Web Panel] No tunnel available — direct IP access only (http://${publicAddress}:${currentPort})`);
                }

                resolve(server);
            });

            server.on('error', (error) => {
                if (error.code === 'EADDRINUSE' && attempts < MAX_PORT_RETRIES) {
                    attempts++;
                    currentPort++;
                    console.log(`[Web Panel] Port ${currentPort - 1} in use, trying ${currentPort}...`);
                    tryListen();
                } else {
                    serverInstance = null;
                    runningPort = null;
                    reject(error);
                }
            });
        }

        tryListen();
    });
}

function stopServer() {
    tunnel.closeTunnel();
    return new Promise((resolve) => {
        if (!serverInstance) return resolve();
        const instance = serverInstance;
        // Clear state immediately so startServer can proceed if called before close completes
        serverInstance = null;
        runningPort = null;
        instance.close(() => {
            console.log('[Web Panel] Server stopped');
            resolve();
        });
    });
}

function getRunningPort() {
    return runningPort;
}

function getPublicAddress() {
    return publicAddress;
}

function getTunnelUrl() {
    return tunnel.getTunnelUrl();
}

function getBasePath() {
    return BASE_PATH;
}

module.exports = { startServer, stopServer, getRunningPort, getPublicAddress, getTunnelUrl, getBasePath, DEFAULT_PORT };
