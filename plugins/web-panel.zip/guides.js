const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const { getDefaultGameType } = require('../../src/functions/utility/gameRuntime');
const { normalizeGameType } = require('../../src/functions/utility/gameProfiles');

const DB_PATH = path.join(__dirname, 'webpanel.db');
const GUIDE_MEDIA_DIR = path.join(__dirname, 'guide-media');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
fs.mkdirSync(GUIDE_MEDIA_DIR, { recursive: true });

const GUIDE_STATUSES = ['draft', 'published', 'unpublished', 'archived'];
const GUIDE_ACCESS_MODES = ['public', 'password', 'discord_bot_user', 'discord_mutual_guild'];
const GUIDE_BLOCK_TYPES = ['heading', 'text', 'image', 'button', 'divider', 'collapsible', 'table', 'table_of_contents'];
const DELETE_REQUEST_STATUSES = ['pending', 'approved', 'rejected', 'cancelled'];
const GUIDE_IMAGE_MIME_TYPES = new Set([
    'image/png',
    'image/jpeg',
    'image/webp',
    'image/gif',
]);
const GUIDE_IMAGE_EXTENSIONS = {
    'image/png': '.png',
    'image/jpeg': '.jpg',
    'image/webp': '.webp',
    'image/gif': '.gif',
};

db.exec(`
    CREATE TABLE IF NOT EXISTS guides (
        id TEXT PRIMARY KEY,
        game_type TEXT NOT NULL DEFAULT 'wos',
        title TEXT NOT NULL,
        summary TEXT NOT NULL DEFAULT '',
        public_slug TEXT NOT NULL UNIQUE,
        status TEXT NOT NULL CHECK (status IN ('draft', 'published', 'unpublished', 'archived')) DEFAULT 'draft',
        access_mode TEXT NOT NULL DEFAULT 'public',
        access_password_hash TEXT,
        access_password_salt TEXT,
        access_guild_id TEXT,
        created_by_user_id TEXT NOT NULL,
        updated_by_user_id TEXT NOT NULL,
        published_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS guide_blocks (
        id TEXT PRIMARY KEY,
        guide_id TEXT NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
        block_type TEXT NOT NULL CHECK (block_type IN ('heading', 'text', 'image', 'button', 'divider', 'collapsible', 'table', 'table_of_contents')),
        sort_order INTEGER NOT NULL,
        payload_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS guide_admins (
        guide_id TEXT NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
        user_id TEXT NOT NULL,
        assigned_by_user_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        PRIMARY KEY (guide_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS guide_delete_requests (
        id TEXT PRIMARY KEY,
        guide_id TEXT NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
        requested_by_user_id TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')) DEFAULT 'pending',
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        resolved_at TEXT,
        resolved_by_user_id TEXT
    );

    CREATE TABLE IF NOT EXISTS guide_media_assets (
        id TEXT PRIMARY KEY,
        storage_name TEXT NOT NULL UNIQUE,
        original_name TEXT NOT NULL,
        mime_type TEXT NOT NULL,
        size_bytes INTEGER NOT NULL,
        created_by_user_id TEXT NOT NULL,
        created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_guides_status ON guides(status);
    CREATE INDEX IF NOT EXISTS idx_guides_updated_at ON guides(updated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_guide_blocks_guide_sort ON guide_blocks(guide_id, sort_order);
    CREATE INDEX IF NOT EXISTS idx_guide_admins_user ON guide_admins(user_id);
    CREATE INDEX IF NOT EXISTS idx_guide_delete_requests_guide ON guide_delete_requests(guide_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_guide_media_assets_created_at ON guide_media_assets(created_at DESC);
`);

function resolveGuideGameType(gameType) {
    return normalizeGameType(gameType, getDefaultGameType());
}

function ensureGuidesAccessSchema() {
    const columns = db.prepare(`PRAGMA table_info(guides)`).all();
    const columnNames = new Set(columns.map((column) => column.name));

    if (!columnNames.has('access_mode')) {
        db.exec(`ALTER TABLE guides ADD COLUMN access_mode TEXT NOT NULL DEFAULT 'public'`);
    }
    if (!columnNames.has('access_password_hash')) {
        db.exec(`ALTER TABLE guides ADD COLUMN access_password_hash TEXT`);
    }
    if (!columnNames.has('access_password_salt')) {
        db.exec(`ALTER TABLE guides ADD COLUMN access_password_salt TEXT`);
    }
    if (!columnNames.has('access_guild_id')) {
        db.exec(`ALTER TABLE guides ADD COLUMN access_guild_id TEXT`);
    }
    if (!columnNames.has('game_type')) {
        db.exec(`ALTER TABLE guides ADD COLUMN game_type TEXT NOT NULL DEFAULT 'wos'`);
    }

    db.exec(`
        UPDATE guides
        SET game_type = 'wos'
        WHERE game_type IS NULL OR TRIM(game_type) = ''
    `);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_guides_game_type ON guides(game_type)`);
}

function ensureGuideBlocksSchema() {
    const row = db.prepare(`
        SELECT sql
        FROM sqlite_master
        WHERE type = 'table' AND name = 'guide_blocks'
    `).get();

    const currentSql = String(row?.sql || '');
    if (currentSql.includes("'table'") && currentSql.includes("'table_of_contents'")) {
        return;
    }

    db.exec(`
        BEGIN;
        ALTER TABLE guide_blocks RENAME TO guide_blocks_legacy;

        CREATE TABLE guide_blocks (
            id TEXT PRIMARY KEY,
            guide_id TEXT NOT NULL REFERENCES guides(id) ON DELETE CASCADE,
            block_type TEXT NOT NULL CHECK (block_type IN ('heading', 'text', 'image', 'button', 'divider', 'collapsible', 'table', 'table_of_contents')),
            sort_order INTEGER NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        INSERT INTO guide_blocks (id, guide_id, block_type, sort_order, payload_json, created_at, updated_at)
        SELECT id, guide_id, block_type, sort_order, payload_json, created_at, updated_at
        FROM guide_blocks_legacy;

        DROP TABLE guide_blocks_legacy;
        CREATE INDEX IF NOT EXISTS idx_guide_blocks_guide_sort ON guide_blocks(guide_id, sort_order);
        COMMIT;
    `);
}

ensureGuidesAccessSchema();
ensureGuideBlocksSchema();

const stmts = {
    createGuide: db.prepare(`
        INSERT INTO guides (
            id, game_type, title, summary, public_slug, status, access_mode, access_password_hash, access_password_salt, access_guild_id, created_by_user_id, updated_by_user_id, published_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
    `),
    getGuideById: db.prepare(`SELECT * FROM guides WHERE id = ?`),
    getGuideBySlug: db.prepare(`SELECT * FROM guides WHERE public_slug = ?`),
    listGuidesForSlugMigration: db.prepare(`SELECT id, public_slug FROM guides`),
    getGuideSummaries: db.prepare(`
        SELECT
            g.*,
            COUNT(DISTINCT b.id) AS block_count,
            COUNT(DISTINCT ga.user_id) AS assignee_count,
            COUNT(DISTINCT CASE WHEN gdr.status = 'pending' THEN gdr.id END) AS pending_delete_request_count
        FROM guides g
        LEFT JOIN guide_blocks b ON b.guide_id = g.id
        LEFT JOIN guide_admins ga ON ga.guide_id = g.id
        LEFT JOIN guide_delete_requests gdr ON gdr.guide_id = g.id
        GROUP BY g.id
        ORDER BY g.updated_at DESC, g.created_at DESC
    `),
    updateGuideMeta: db.prepare(`
        UPDATE guides
        SET title = ?, summary = ?, access_mode = ?, access_password_hash = ?, access_password_salt = ?, access_guild_id = ?, updated_by_user_id = ?, updated_at = ?
        WHERE id = ?
    `),
    updateGuideSlug: db.prepare(`
        UPDATE guides
        SET public_slug = ?
        WHERE id = ?
    `),
    updateGuideStatus: db.prepare(`
        UPDATE guides
        SET status = ?, published_at = ?, updated_by_user_id = ?, updated_at = ?
        WHERE id = ?
    `),
    updateGuideUpdatedAt: db.prepare(`
        UPDATE guides
        SET updated_by_user_id = ?, updated_at = ?
        WHERE id = ?
    `),
    deleteGuide: db.prepare(`DELETE FROM guides WHERE id = ?`),

    getBlocksByGuideId: db.prepare(`
        SELECT * FROM guide_blocks
        WHERE guide_id = ?
        ORDER BY sort_order ASC, created_at ASC
    `),
    getBlockById: db.prepare(`SELECT * FROM guide_blocks WHERE id = ?`),
    getMaxSortOrderByGuide: db.prepare(`SELECT MAX(sort_order) AS max_sort_order FROM guide_blocks WHERE guide_id = ?`),
    insertBlock: db.prepare(`
        INSERT INTO guide_blocks (
            id, guide_id, block_type, sort_order, payload_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `),
    updateBlockPayload: db.prepare(`
        UPDATE guide_blocks
        SET payload_json = ?, updated_at = ?
        WHERE id = ?
    `),
    updateBlockSortOrder: db.prepare(`
        UPDATE guide_blocks
        SET sort_order = ?, updated_at = ?
        WHERE id = ?
    `),
    deleteBlock: db.prepare(`DELETE FROM guide_blocks WHERE id = ?`),
    listAllBlocksForMediaScan: db.prepare(`
        SELECT id, guide_id, payload_json
        FROM guide_blocks
        WHERE block_type = 'image'
    `),

    getAssignmentsByGuideId: db.prepare(`
        SELECT guide_id, user_id, assigned_by_user_id, created_at
        FROM guide_admins
        WHERE guide_id = ?
        ORDER BY created_at ASC
    `),
    getAssignedGuideIdsByUser: db.prepare(`
        SELECT guide_id
        FROM guide_admins
        WHERE user_id = ?
    `),
    deleteAssignmentsByGuide: db.prepare(`DELETE FROM guide_admins WHERE guide_id = ?`),
    insertAssignment: db.prepare(`
        INSERT INTO guide_admins (guide_id, user_id, assigned_by_user_id, created_at)
        VALUES (?, ?, ?, ?)
    `),

    getDeleteRequestsByGuideId: db.prepare(`
        SELECT *
        FROM guide_delete_requests
        WHERE guide_id = ?
        ORDER BY created_at DESC
    `),
    getDeleteRequestById: db.prepare(`SELECT * FROM guide_delete_requests WHERE id = ?`),
    getPendingDeleteRequestByGuideId: db.prepare(`
        SELECT *
        FROM guide_delete_requests
        WHERE guide_id = ? AND status = 'pending'
        ORDER BY created_at DESC
        LIMIT 1
    `),
    insertDeleteRequest: db.prepare(`
        INSERT INTO guide_delete_requests (
            id, guide_id, requested_by_user_id, status, note, created_at, resolved_at, resolved_by_user_id
        ) VALUES (?, ?, ?, 'pending', ?, ?, NULL, NULL)
    `),
    resolveDeleteRequest: db.prepare(`
        UPDATE guide_delete_requests
        SET status = ?, resolved_at = ?, resolved_by_user_id = ?
        WHERE id = ?
    `),

    createGuideMediaAsset: db.prepare(`
        INSERT INTO guide_media_assets (
            id, storage_name, original_name, mime_type, size_bytes, created_by_user_id, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `),
    getGuideMediaAssetById: db.prepare(`
        SELECT *
        FROM guide_media_assets
        WHERE id = ?
    `),
    deleteGuideMediaAsset: db.prepare(`
        DELETE FROM guide_media_assets
        WHERE id = ?
    `),
};

function nowIso() {
    return new Date().toISOString();
}

function createId(prefix) {
    return `${prefix}_${crypto.randomUUID()}`;
}

function createRandomSlug() {
    return crypto.randomBytes(8).toString('hex');
}

function isRandomGuideSlug(value) {
    return /^[a-f0-9]{16}$/.test(String(value || '').trim());
}

function generateUniqueSlug() {
    let slug = createRandomSlug();
    while (stmts.getGuideBySlug.get(slug)) {
        slug = createRandomSlug();
    }
    return slug;
}

const migrateGuideSlugsTx = db.transaction(() => {
    const guides = stmts.listGuidesForSlugMigration.all();
    for (const guide of guides) {
        if (isRandomGuideSlug(guide.public_slug)) continue;
        let nextSlug = createRandomSlug();
        while (stmts.getGuideBySlug.get(nextSlug)) {
            nextSlug = createRandomSlug();
        }
        stmts.updateGuideSlug.run(nextSlug, guide.id);
    }
});

function parsePayload(payloadJson) {
    try {
        return JSON.parse(payloadJson || '{}');
    } catch {
        return {};
    }
}

function validateGuideStatus(status) {
    const normalized = String(status || '').trim().toLowerCase();
    if (!GUIDE_STATUSES.includes(normalized)) {
        throw new Error('Invalid guide status');
    }
    return normalized;
}

function validateBlockType(blockType) {
    const normalized = String(blockType || '').trim().toLowerCase();
    if (!GUIDE_BLOCK_TYPES.includes(normalized)) {
        throw new Error('Invalid guide block type');
    }
    return normalized;
}

function validateGuideTitle(title) {
    const normalized = String(title || '').trim();
    if (!normalized) throw new Error('Guide title is required');
    if (normalized.length > 120) throw new Error('Guide title must be 120 characters or fewer');
    return normalized;
}

function validateGuideSummary(summary) {
    const normalized = String(summary || '').trim();
    if (normalized.length > 400) throw new Error('Guide summary must be 400 characters or fewer');
    return normalized;
}

function validateGuideAccessMode(mode) {
    const normalized = String(mode || '').trim().toLowerCase();
    if (!GUIDE_ACCESS_MODES.includes(normalized)) {
        throw new Error('Invalid guide security mode');
    }
    return normalized;
}

function hashGuidePassword(password, salt = crypto.randomBytes(16).toString('hex')) {
    const derivedKey = crypto.scryptSync(password, salt, 64).toString('hex');
    return { hash: derivedKey, salt };
}

function normalizeGuideSecurityInput(input = {}, existingGuide = null) {
    const guideRow = existingGuide || {};
    const accessMode = validateGuideAccessMode(input.accessMode ?? guideRow.access_mode ?? 'public');
    const nextPassword = input.accessPassword === undefined || input.accessPassword === null
        ? ''
        : String(input.accessPassword);
    const nextGuildId = input.accessGuildId === undefined || input.accessGuildId === null
        ? String(guideRow.access_guild_id || '').trim()
        : String(input.accessGuildId || '').trim();

    let passwordHash = guideRow.access_password_hash || null;
    let passwordSalt = guideRow.access_password_salt || null;
    let accessGuildId = null;

    if (accessMode === 'password') {
        const trimmedPassword = nextPassword.trim();
        if (trimmedPassword) {
            if (trimmedPassword.length < 4) {
                throw new Error('Guide password must be at least 4 characters');
            }
            if (trimmedPassword.length > 120) {
                throw new Error('Guide password must be 120 characters or fewer');
            }
            const hashedPassword = hashGuidePassword(trimmedPassword);
            passwordHash = hashedPassword.hash;
            passwordSalt = hashedPassword.salt;
        } else if (!passwordHash || !passwordSalt) {
            throw new Error('A password is required for password-protected guides');
        }
    } else {
        passwordHash = null;
        passwordSalt = null;
    }

    if (accessMode === 'discord_mutual_guild') {
        if (!nextGuildId) {
            throw new Error('Select which Discord server should grant access to this guide');
        }
        accessGuildId = nextGuildId;
    }

    return {
        accessMode,
        accessPasswordHash: passwordHash,
        accessPasswordSalt: passwordSalt,
        accessGuildId,
    };
}

function verifyGuidePassword(password, hash, salt) {
    if (!password || !hash || !salt) return false;
    try {
        const normalizedPassword = String(password);
        const nextHash = crypto.scryptSync(normalizedPassword, salt, 64).toString('hex');
        const expected = Buffer.from(hash, 'hex');
        const actual = Buffer.from(nextHash, 'hex');
        return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
    } catch {
        return false;
    }
}

function validateOptionalUrl(value, fieldName) {
    const normalized = String(value || '').trim();
    if (!normalized) return '';
    try {
        const parsed = new URL(normalized);
        if (!['http:', 'https:'].includes(parsed.protocol)) {
            throw new Error();
        }
        return parsed.toString();
    } catch {
        throw new Error(`${fieldName} must be a valid http(s) URL`);
    }
}

function validateButtonStyle(style) {
    const normalized = String(style || '').trim().toLowerCase();
    return ['primary', 'secondary', 'ghost'].includes(normalized) ? normalized : 'primary';
}

function parseTableCells(value) {
    const stripped = String(value || '').trim().replace(/^\|+|\|+$/g, '');
    if (!stripped) return [];
    return stripped
        .split('|')
        .map((cell) => String(cell || '').trim())
        .filter((cell) => cell.length > 0);
}

function normalizeTableData(headersInput, rowsInput) {
    const rawHeaders = Array.isArray(headersInput)
        ? headersInput.map((value) => String(value || '').trim())
        : parseTableCells(headersInput);
    const headers = rawHeaders
        .filter(Boolean)
        .slice(0, 8)
        .map((cell) => cell.slice(0, 120));

    if (!headers.length) {
        throw new Error('Table must include at least one column header');
    }

    const rawRows = Array.isArray(rowsInput)
        ? rowsInput
        : String(rowsInput || '')
            .replace(/\r\n/g, '\n')
            .split('\n')
            .map((line) => parseTableCells(line))
            .filter((cells) => cells.length > 0);

    const rows = rawRows
        .slice(0, 40)
        .map((row) => {
            const normalizedRow = Array.isArray(row)
                ? row.map((value) => String(value || '').trim())
                : parseTableCells(row);
            return headers.map((_, index) => String(normalizedRow[index] || '').trim().slice(0, 400));
        });

    return { headers, rows };
}

function validateGuideImageMimeType(mimeType) {
    const normalized = String(mimeType || '').trim().toLowerCase();
    if (!GUIDE_IMAGE_MIME_TYPES.has(normalized)) {
        throw new Error('Uploaded file must be a PNG, JPEG, WebP, or GIF image');
    }
    return normalized;
}

function getGuideImageExtension(mimeType) {
    return GUIDE_IMAGE_EXTENSIONS[mimeType] || '.bin';
}

function getImageAssetIdFromPayload(payload) {
    if (!payload || typeof payload !== 'object') return '';
    if (String(payload.source || '').trim().toLowerCase() !== 'upload') return '';
    return String(payload.assetId || '').trim();
}

function getReferencedGuideMediaAssetIds({ guideId = null, excludeBlockId = null } = {}) {
    const rows = stmts.listAllBlocksForMediaScan.all();
    const assetIds = new Set();
    for (const row of rows) {
        if (guideId && row.guide_id !== guideId) continue;
        if (excludeBlockId && row.id === excludeBlockId) continue;
        const assetId = getImageAssetIdFromPayload(parsePayload(row.payload_json));
        if (assetId) assetIds.add(assetId);
    }
    return assetIds;
}

function deleteGuideMediaFile(storageName) {
    const resolved = path.join(GUIDE_MEDIA_DIR, storageName);
    if (!fs.existsSync(resolved)) return;
    fs.unlinkSync(resolved);
}

function cleanupOrphanedGuideMediaAssetIds(assetIds) {
    const uniqueIds = [...new Set((Array.isArray(assetIds) ? assetIds : []).filter(Boolean))];
    if (!uniqueIds.length) return;

    const referencedIds = getReferencedGuideMediaAssetIds();
    for (const assetId of uniqueIds) {
        if (referencedIds.has(assetId)) continue;
        const asset = stmts.getGuideMediaAssetById.get(assetId);
        if (!asset) continue;
        stmts.deleteGuideMediaAsset.run(assetId);
        try {
            deleteGuideMediaFile(asset.storage_name);
        } catch {
            // Best effort cleanup — missing files should not break guide deletion/update.
        }
    }
}

function normalizeBlockPayload(blockType, payload) {
    const input = payload && typeof payload === 'object' ? payload : {};
    switch (blockType) {
        case 'heading': {
            const text = String(input.text || '').trim();
            const level = Math.max(1, Math.min(4, Number.parseInt(input.level, 10) || 2));
            if (!text) throw new Error('Heading block text is required');
            return { text: text.slice(0, 200), level };
        }
        case 'text': {
            const content = String(input.content || '').trim();
            if (!content) throw new Error('Text block content is required');
            return { content: content.slice(0, 10000) };
        }
        case 'image': {
            const width = Math.max(20, Math.min(100, Number.parseInt(input.width, 10) || 100));
            const alt = String(input.alt || '').trim().slice(0, 200);
            const caption = String(input.caption || '').trim().slice(0, 500);
            const requestedSource = String(input.source || '').trim().toLowerCase();
            const source = requestedSource === 'upload' || (!requestedSource && input.assetId)
                ? 'upload'
                : 'url';

            if (source === 'upload') {
                const assetId = String(input.assetId || '').trim();
                if (!assetId) throw new Error('Uploaded image is required');
                if (!stmts.getGuideMediaAssetById.get(assetId)) {
                    throw new Error('Uploaded image could not be found');
                }
                return {
                    source: 'upload',
                    assetId,
                    alt,
                    caption,
                    width,
                };
            }

            const imageUrl = validateOptionalUrl(input.imageUrl, 'Image URL');
            if (!imageUrl) throw new Error('Image URL is required');
            return {
                source: 'url',
                imageUrl,
                alt,
                caption,
                width,
            };
        }
        case 'button': {
            const label = String(input.label || '').trim();
            if (!label) throw new Error('Button label is required');
            const url = validateOptionalUrl(input.url, 'Button URL');
            if (!url) throw new Error('Button URL is required');
            return {
                label: label.slice(0, 120),
                url,
                style: validateButtonStyle(input.style),
            };
        }
        case 'divider':
            return {};
        case 'collapsible': {
            const title = String(input.title || '').trim();
            const content = String(input.content || '').trim();
            if (!title) throw new Error('Collapsible title is required');
            if (!content) throw new Error('Collapsible content is required');
            return {
                title: title.slice(0, 200),
                content: content.slice(0, 10000),
            };
        }
        case 'table': {
            const { headers, rows } = normalizeTableData(input.headers, input.rows);
            return {
                headers,
                rows,
            };
        }
        case 'table_of_contents': {
            const title = String(input.title || '').trim().slice(0, 120);
            return {
                title,
            };
        }
        default:
            throw new Error('Unsupported guide block type');
    }
}

function shapeGuideRow(row) {
    if (!row) return null;
    return {
        id: row.id,
        gameType: resolveGuideGameType(row.game_type),
        title: row.title,
        summary: row.summary || '',
        publicSlug: row.public_slug,
        status: row.status,
        accessMode: validateGuideAccessMode(row.access_mode || 'public'),
        hasPassword: !!(row.access_password_hash && row.access_password_salt),
        accessGuildId: row.access_guild_id || '',
        createdByUserId: row.created_by_user_id,
        updatedByUserId: row.updated_by_user_id,
        publishedAt: row.published_at,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        blockCount: Number(row.block_count || 0),
        assigneeCount: Number(row.assignee_count || 0),
        pendingDeleteRequestCount: Number(row.pending_delete_request_count || 0),
    };
}

function shapeBlockRow(row) {
    if (!row) return null;
    return {
        id: row.id,
        guideId: row.guide_id,
        blockType: row.block_type,
        sortOrder: row.sort_order,
        payload: parsePayload(row.payload_json),
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}

function shapeAssignmentRow(row) {
    if (!row) return null;
    return {
        guideId: row.guide_id,
        userId: row.user_id,
        assignedByUserId: row.assigned_by_user_id,
        createdAt: row.created_at,
    };
}

function shapeDeleteRequestRow(row) {
    if (!row) return null;
    return {
        id: row.id,
        guideId: row.guide_id,
        requestedByUserId: row.requested_by_user_id,
        status: row.status,
        note: row.note || '',
        createdAt: row.created_at,
        resolvedAt: row.resolved_at,
        resolvedByUserId: row.resolved_by_user_id,
    };
}

function shapeGuideMediaAssetRow(row) {
    if (!row) return null;
    return {
        id: row.id,
        storageName: row.storage_name,
        originalName: row.original_name,
        mimeType: row.mime_type,
        sizeBytes: Number(row.size_bytes || 0),
        createdByUserId: row.created_by_user_id,
        createdAt: row.created_at,
    };
}

function getGuideDetail(guideId, gameType = null) {
    const guide = shapeGuideRow(stmts.getGuideById.get(guideId));
    if (!guide) return null;
    if (gameType && guide.gameType !== resolveGuideGameType(gameType)) return null;
    return {
        ...guide,
        blocks: stmts.getBlocksByGuideId.all(guideId).map(shapeBlockRow),
        assignees: stmts.getAssignmentsByGuideId.all(guideId).map(shapeAssignmentRow),
        deleteRequests: stmts.getDeleteRequestsByGuideId.all(guideId).map(shapeDeleteRequestRow),
    };
}

function getBlockDetail(blockId, gameType = null) {
    const block = shapeBlockRow(stmts.getBlockById.get(blockId));
    if (!block) return null;
    return getGuideDetail(block.guideId, gameType) ? block : null;
}

function getDeleteRequestDetail(requestId, gameType = null) {
    const request = shapeDeleteRequestRow(stmts.getDeleteRequestById.get(requestId));
    if (!request) return null;
    return getGuideDetail(request.guideId, gameType) ? request : null;
}

function getGuideMediaAsset(assetId) {
    return shapeGuideMediaAssetRow(stmts.getGuideMediaAssetById.get(assetId));
}

function getGuideMediaAssetFilePath(assetId) {
    const asset = stmts.getGuideMediaAssetById.get(assetId);
    if (!asset) return '';
    return path.join(GUIDE_MEDIA_DIR, asset.storage_name);
}

function canUserAccessGuide(guideId, userId, hasFullAccess = false, gameType = null) {
    if (hasFullAccess) return !!getGuideDetail(guideId, gameType);
    const detail = getGuideDetail(guideId, gameType);
    if (!detail) return false;
    if (detail.createdByUserId === userId) return true;
    return detail.assignees.some((assignee) => assignee.userId === userId);
}

function getGuides({ userId = null, hasFullAccess = false, gameType = null } = {}) {
    const resolvedGameType = resolveGuideGameType(gameType);
    const rows = stmts.getGuideSummaries.all()
        .map(shapeGuideRow)
        .filter((row) => row.gameType === resolvedGameType);
    if (hasFullAccess) return rows;

    const assignedGuideIds = new Set(
        userId
            ? stmts.getAssignedGuideIdsByUser.all(userId).map((row) => row.guide_id)
            : []
    );

    return rows.filter((row) => row.createdByUserId === userId || assignedGuideIds.has(row.id));
}

const createGuideTx = db.transaction((input) => {
    const { title, summary = '', createdByUserId } = input || {};
    const normalizedTitle = validateGuideTitle(title);
    const normalizedSummary = validateGuideSummary(summary);
    const security = normalizeGuideSecurityInput(input);
    const now = nowIso();
    const guideId = createId('guide');
    const slug = generateUniqueSlug();
    stmts.createGuide.run(
        guideId,
        resolveGuideGameType(input?.gameType),
        normalizedTitle,
        normalizedSummary,
        slug,
        'draft',
        security.accessMode,
        security.accessPasswordHash,
        security.accessPasswordSalt,
        security.accessGuildId,
        createdByUserId,
        createdByUserId,
        now,
        now
    );
    return guideId;
});

const updateGuideMetaTx = db.transaction((guideId, input, updatedByUserId) => {
    const guide = stmts.getGuideById.get(guideId);
    if (!guide) throw new Error('Guide not found');
    const title = validateGuideTitle(input.title ?? guide.title);
    const summary = validateGuideSummary(input.summary ?? guide.summary);
    const security = normalizeGuideSecurityInput(input, guide);
    stmts.updateGuideMeta.run(
        title,
        summary,
        security.accessMode,
        security.accessPasswordHash,
        security.accessPasswordSalt,
        security.accessGuildId,
        updatedByUserId,
        nowIso(),
        guideId,
    );
    return getGuideDetail(guideId);
});

const setGuideAssignmentsTx = db.transaction((guideId, userIds, assignedByUserId) => {
    const guide = stmts.getGuideById.get(guideId);
    if (!guide) throw new Error('Guide not found');

    const normalizedUserIds = [...new Set(
        (Array.isArray(userIds) ? userIds : [])
            .map((value) => String(value || '').trim())
            .filter(Boolean)
    )].filter((userId) => userId !== guide.created_by_user_id);

    stmts.deleteAssignmentsByGuide.run(guideId);
    const now = nowIso();
    for (const userId of normalizedUserIds) {
        stmts.insertAssignment.run(guideId, userId, assignedByUserId, now);
    }
    stmts.updateGuideUpdatedAt.run(assignedByUserId, now, guideId);
    return getGuideDetail(guideId);
});

const addBlockTx = db.transaction((guideId, blockType, payload, updatedByUserId) => {
    const guide = stmts.getGuideById.get(guideId);
    if (!guide) throw new Error('Guide not found');
    const normalizedType = validateBlockType(blockType);
    const normalizedPayload = normalizeBlockPayload(normalizedType, payload);
    const maxSort = Number(stmts.getMaxSortOrderByGuide.get(guideId)?.max_sort_order || 0);
    const now = nowIso();
    stmts.insertBlock.run(
        createId('block'),
        guideId,
        normalizedType,
        maxSort + 1,
        JSON.stringify(normalizedPayload),
        now,
        now
    );
    stmts.updateGuideUpdatedAt.run(updatedByUserId, now, guideId);
    return getGuideDetail(guideId);
});

const updateBlockTx = db.transaction((blockId, payload, updatedByUserId) => {
    const block = stmts.getBlockById.get(blockId);
    if (!block) throw new Error('Guide block not found');
    const previousAssetId = getImageAssetIdFromPayload(parsePayload(block.payload_json));
    const normalizedPayload = normalizeBlockPayload(block.block_type, payload);
    const now = nowIso();
    stmts.updateBlockPayload.run(JSON.stringify(normalizedPayload), now, blockId);
    stmts.updateGuideUpdatedAt.run(updatedByUserId, now, block.guide_id);
    const nextAssetId = getImageAssetIdFromPayload(normalizedPayload);
    if (previousAssetId && previousAssetId !== nextAssetId) {
        cleanupOrphanedGuideMediaAssetIds([previousAssetId]);
    }
    return getGuideDetail(block.guide_id);
});

function reorderBlocks(guideId, blockRows) {
    const now = nowIso();
    blockRows.forEach((blockRow, index) => {
        stmts.updateBlockSortOrder.run(index + 1, now, blockRow.id);
    });
}

const moveBlockTx = db.transaction((blockId, direction, updatedByUserId) => {
    const block = stmts.getBlockById.get(blockId);
    if (!block) throw new Error('Guide block not found');
    const normalizedDirection = direction === 'down' ? 'down' : 'up';
    const blocks = stmts.getBlocksByGuideId.all(block.guide_id);
    const currentIndex = blocks.findIndex((item) => item.id === blockId);
    if (currentIndex === -1) throw new Error('Guide block not found');

    const targetIndex = normalizedDirection === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (targetIndex < 0 || targetIndex >= blocks.length) {
        return getGuideDetail(block.guide_id);
    }

    const reordered = [...blocks];
    const [current] = reordered.splice(currentIndex, 1);
    reordered.splice(targetIndex, 0, current);
    reorderBlocks(block.guide_id, reordered);
    stmts.updateGuideUpdatedAt.run(updatedByUserId, nowIso(), block.guide_id);
    return getGuideDetail(block.guide_id);
});

const duplicateBlockTx = db.transaction((blockId, updatedByUserId) => {
    const block = stmts.getBlockById.get(blockId);
    if (!block) throw new Error('Guide block not found');
    const blocks = stmts.getBlocksByGuideId.all(block.guide_id);
    const sourceIndex = blocks.findIndex((item) => item.id === blockId);
    if (sourceIndex === -1) throw new Error('Guide block not found');

    const now = nowIso();
    const inserted = {
        id: createId('block'),
        guide_id: block.guide_id,
        block_type: block.block_type,
        sort_order: blocks.length + 1,
        payload_json: block.payload_json,
        created_at: now,
        updated_at: now,
    };

    stmts.insertBlock.run(
        inserted.id,
        inserted.guide_id,
        inserted.block_type,
        inserted.sort_order,
        inserted.payload_json,
        inserted.created_at,
        inserted.updated_at
    );

    const reordered = [...blocks];
    reordered.splice(sourceIndex + 1, 0, inserted);
    reorderBlocks(block.guide_id, reordered);
    stmts.updateGuideUpdatedAt.run(updatedByUserId, now, block.guide_id);
    return getGuideDetail(block.guide_id);
});

const removeBlockTx = db.transaction((blockId, updatedByUserId) => {
    const block = stmts.getBlockById.get(blockId);
    if (!block) throw new Error('Guide block not found');
    const previousAssetId = getImageAssetIdFromPayload(parsePayload(block.payload_json));
    stmts.deleteBlock.run(blockId);
    reorderBlocks(block.guide_id, stmts.getBlocksByGuideId.all(block.guide_id));
    stmts.updateGuideUpdatedAt.run(updatedByUserId, nowIso(), block.guide_id);
    if (previousAssetId) {
        cleanupOrphanedGuideMediaAssetIds([previousAssetId]);
    }
    return getGuideDetail(block.guide_id);
});

const updateGuideStatusTx = db.transaction((guideId, status, updatedByUserId) => {
    const guide = stmts.getGuideById.get(guideId);
    if (!guide) throw new Error('Guide not found');
    const normalizedStatus = validateGuideStatus(status);
    const publishedAt = normalizedStatus === 'published'
        ? (guide.published_at || nowIso())
        : null;
    stmts.updateGuideStatus.run(normalizedStatus, publishedAt, updatedByUserId, nowIso(), guideId);
    return getGuideDetail(guideId);
});

const createDeleteRequestTx = db.transaction((guideId, requestedByUserId, note = '') => {
    const guide = stmts.getGuideById.get(guideId);
    if (!guide) throw new Error('Guide not found');
    const pending = stmts.getPendingDeleteRequestByGuideId.get(guideId);
    if (pending) throw new Error('A delete request is already pending for this guide');
    const now = nowIso();
    stmts.insertDeleteRequest.run(
        createId('guide_delete'),
        guideId,
        requestedByUserId,
        String(note || '').trim().slice(0, 1000),
        now
    );
    stmts.updateGuideUpdatedAt.run(requestedByUserId, now, guideId);
    return getGuideDetail(guideId);
});

const cancelDeleteRequestTx = db.transaction((requestId, cancelledByUserId) => {
    const request = stmts.getDeleteRequestById.get(requestId);
    if (!request) throw new Error('Delete request not found');
    if (request.status !== 'pending') throw new Error('Only pending delete requests can be cancelled');
    stmts.resolveDeleteRequest.run('cancelled', nowIso(), cancelledByUserId, requestId);
    stmts.updateGuideUpdatedAt.run(cancelledByUserId, nowIso(), request.guide_id);
    return getGuideDetail(request.guide_id);
});

const resolveDeleteRequestTx = db.transaction((requestId, action, resolvedByUserId) => {
    const request = stmts.getDeleteRequestById.get(requestId);
    if (!request) throw new Error('Delete request not found');
    if (request.status !== 'pending') throw new Error('Delete request has already been resolved');
    if (!['approve', 'reject'].includes(String(action || '').trim().toLowerCase())) {
        throw new Error('Invalid delete request action');
    }

    const resolvedStatus = action === 'approve' ? 'approved' : 'rejected';
    stmts.resolveDeleteRequest.run(resolvedStatus, nowIso(), resolvedByUserId, requestId);

    if (resolvedStatus === 'approved') {
        const guideAssetIds = [...getReferencedGuideMediaAssetIds({ guideId: request.guide_id })];
        stmts.deleteGuide.run(request.guide_id);
        cleanupOrphanedGuideMediaAssetIds(guideAssetIds);
        return { deletedGuideId: request.guide_id, requestId, status: 'approved' };
    }

    stmts.updateGuideUpdatedAt.run(resolvedByUserId, nowIso(), request.guide_id);
    return getGuideDetail(request.guide_id);
});

migrateGuideSlugsTx();

function getPublicGuideBySlug(slug) {
    const row = stmts.getGuideBySlug.get(String(slug || '').trim());
    const guide = shapeGuideRow(row);
    if (!guide || guide.status !== 'published') return null;
    return {
        ...guide,
        _accessPasswordHash: row.access_password_hash || null,
        _accessPasswordSalt: row.access_password_salt || null,
        blocks: stmts.getBlocksByGuideId.all(guide.id).map(shapeBlockRow),
    };
}

function createGuideMediaAsset({ buffer, originalName, mimeType, createdByUserId }) {
    if (!buffer || !Buffer.isBuffer(buffer) || !buffer.length) {
        throw new Error('Image file is required');
    }

    const normalizedMimeType = validateGuideImageMimeType(mimeType);
    const assetId = createId('asset');
    const storageName = `${assetId}${getGuideImageExtension(normalizedMimeType)}`;
    const resolved = path.join(GUIDE_MEDIA_DIR, storageName);
    const createdAt = nowIso();
    const safeOriginalName = String(originalName || 'image').trim().slice(0, 255) || 'image';

    fs.writeFileSync(resolved, buffer);
    try {
        stmts.createGuideMediaAsset.run(
            assetId,
            storageName,
            safeOriginalName,
            normalizedMimeType,
            buffer.length,
            createdByUserId,
            createdAt,
        );
    } catch (error) {
        try {
            fs.unlinkSync(resolved);
        } catch {
            // Best effort rollback.
        }
        throw error;
    }

    return getGuideMediaAsset(assetId);
}

function ensureGuideInGame(guideId, gameType) {
    const detail = getGuideDetail(guideId, gameType);
    if (!detail) throw new Error('Guide not found');
    return detail;
}

function ensureBlockInGame(blockId, gameType) {
    const detail = getBlockDetail(blockId, gameType);
    if (!detail) throw new Error('Guide not found');
    return detail;
}

function ensureDeleteRequestInGame(requestId, gameType) {
    const detail = getDeleteRequestDetail(requestId, gameType);
    if (!detail) throw new Error('Guide not found');
    return detail;
}

module.exports = {
    GUIDE_ACCESS_MODES,
    GUIDE_BLOCK_TYPES,
    GUIDE_STATUSES,
    DELETE_REQUEST_STATUSES,
    GUIDE_IMAGE_MIME_TYPES: [...GUIDE_IMAGE_MIME_TYPES],
    getGuides,
    getGuideDetail,
    getBlockDetail,
    getDeleteRequestDetail,
    getGuideMediaAsset,
    getGuideMediaAssetFilePath,
    getPublicGuideBySlug,
    canUserAccessGuide,
    verifyGuidePassword,
    createGuideMediaAsset,
    createGuide(input) {
        const guideId = createGuideTx(input);
        return getGuideDetail(guideId);
    },
    updateGuideMeta(guideId, input, updatedByUserId, gameType = null) {
        ensureGuideInGame(guideId, gameType);
        return updateGuideMetaTx(guideId, input, updatedByUserId);
    },
    setGuideAssignments(guideId, userIds, assignedByUserId, gameType = null) {
        ensureGuideInGame(guideId, gameType);
        return setGuideAssignmentsTx(guideId, userIds, assignedByUserId);
    },
    addBlock(guideId, blockType, payload, updatedByUserId, gameType = null) {
        ensureGuideInGame(guideId, gameType);
        return addBlockTx(guideId, blockType, payload, updatedByUserId);
    },
    updateBlock(blockId, payload, updatedByUserId, gameType = null) {
        ensureBlockInGame(blockId, gameType);
        return updateBlockTx(blockId, payload, updatedByUserId);
    },
    moveBlock(blockId, direction, updatedByUserId, gameType = null) {
        ensureBlockInGame(blockId, gameType);
        return moveBlockTx(blockId, direction, updatedByUserId);
    },
    duplicateBlock(blockId, updatedByUserId, gameType = null) {
        ensureBlockInGame(blockId, gameType);
        return duplicateBlockTx(blockId, updatedByUserId);
    },
    removeBlock(blockId, updatedByUserId, gameType = null) {
        ensureBlockInGame(blockId, gameType);
        return removeBlockTx(blockId, updatedByUserId);
    },
    publishGuide(guideId, updatedByUserId, gameType = null) {
        ensureGuideInGame(guideId, gameType);
        return updateGuideStatusTx(guideId, 'published', updatedByUserId);
    },
    unpublishGuide(guideId, updatedByUserId, gameType = null) {
        ensureGuideInGame(guideId, gameType);
        return updateGuideStatusTx(guideId, 'unpublished', updatedByUserId);
    },
    archiveGuide(guideId, updatedByUserId, gameType = null) {
        ensureGuideInGame(guideId, gameType);
        return updateGuideStatusTx(guideId, 'archived', updatedByUserId);
    },
    createDeleteRequest(guideId, requestedByUserId, note, gameType = null) {
        ensureGuideInGame(guideId, gameType);
        return createDeleteRequestTx(guideId, requestedByUserId, note);
    },
    cancelDeleteRequest(requestId, cancelledByUserId, gameType = null) {
        ensureDeleteRequestInGame(requestId, gameType);
        return cancelDeleteRequestTx(requestId, cancelledByUserId);
    },
    resolveDeleteRequest(requestId, action, resolvedByUserId, gameType = null) {
        ensureDeleteRequestInGame(requestId, gameType);
        return resolveDeleteRequestTx(requestId, action, resolvedByUserId);
    },
    close() {
        if (db.open) {
            db.pragma('wal_checkpoint(TRUNCATE)');
            db.close();
        }
    },
};
