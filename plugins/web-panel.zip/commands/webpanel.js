const { SlashCommandBuilder, MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { generateLoginToken, isOAuth2Configured } = require('../auth');
const { getSelfHostedPublicUrl } = require('../oauthUrl');
const { getRunningPort, getPublicAddress, getTunnelUrl, getBasePath, isWsConnected } = require('../server');
const { adminQueries, userQueries } = require('../../../src/functions/utility/database');
const centralProxy = require('../centralProxy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('webpanel')
        .setDescription('Get a login link for the web admin panel'),

    async execute(interaction) {
        const adminData = adminQueries.getAdmin(interaction.user.id);
        if (!adminData) {
            const userData = userQueries.getUser(interaction.user.id);
            if (!userData) {
                return interaction.reply({
                    content: 'You need to register first. Please use `/panel` to get started.',
                    flags: MessageFlags.Ephemeral
                });
            }
        }

        const port = getRunningPort();
        if (!port) {
            return interaction.reply({
                content: 'The web panel server is not currently running.',
                flags: MessageFlags.Ephemeral
            });
        }

        const tunnelUrl = getTunnelUrl();
        const basePath = getBasePath();
        const baseUrl = tunnelUrl || `http://${getPublicAddress() || 'localhost'}:${port}`;
        const token = generateLoginToken(interaction.user.id);
        const tokenLink = `${baseUrl}${basePath}/auth/login?token=${token}`;

        const selfHostedUrl = isOAuth2Configured() && getSelfHostedPublicUrl();
        if (selfHostedUrl) {
            return interaction.reply({
                content: `**Web Panel**\nOpen the dashboard:\n${selfHostedUrl}\n\n-# You'll be redirected to log in with Discord if needed.`,
                flags: MessageFlags.Ephemeral
            });
        }

        if (isWsConnected()) {
            const publicUrl = centralProxy.getPublicUrl();
            return interaction.reply({
                content: `**Web Panel**\nOpen the dashboard:\n${publicUrl}\n\n-# You'll be redirected to log in with Discord if needed.`,
                flags: MessageFlags.Ephemeral
            });
        }

        if (centralProxy.isWsConfigured()) {
            const publicUrl = centralProxy.getPublicUrl();

            return interaction.reply({
                content: [
                    `**Web Panel**`,
                    `Central hub connection is still starting.`,
                    publicUrl ? `Hub URL: ${publicUrl}` : null,
                    ``,
                    `-# Try the hub URL again in a few seconds if the panel is not responding yet.`
                ].filter(Boolean).join('\n'),
                flags: MessageFlags.Ephemeral
            });
        }

        if (centralProxy.hasStoredLegacyConfig()) {
            const publicUrl = centralProxy.getPublicUrl();

            if (!adminData?.is_owner) {
                return interaction.reply({
                    content: [
                        `**Web Panel**`,
                        publicUrl ? `Existing URL: ${publicUrl}` : null,
                        ``,
                        `-# This panel still has an older legacy registration stored.`,
                        `-# Ask the bot owner to run \`/webpanel\` and migrate it to the WebSocket hub.`
                    ].filter(Boolean).join('\n'),
                    flags: MessageFlags.Ephemeral
                });
            }

            const upgradeRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`wp_upgrade_ws_${interaction.user.id}`)
                    .setLabel('Migrate to WS Hub')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('⚡')
            );

            return interaction.reply({
                content: [
                    `**Web Panel** *(Legacy Registration Found)*`,
                    publicUrl || 'An older panel URL is registered.',
                    ``,
                    `-# Legacy mode is disabled unless explicitly enabled in .env.`,
                    `-# Migrate this panel to the WebSocket hub to restore the permanent WOS Land connection.`
                ].join('\n'),
                components: [upgradeRow],
                flags: MessageFlags.Ephemeral
            });
        }

        if (!adminData || !adminData.is_owner) {
            return interaction.reply({
                content: `**Web Panel Login**\nClick the link below (expires in 5 minutes):\n${tokenLink}\n\n-# Ask the bot owner to run \`/webpanel\` to set up a permanent URL.`,
                flags: MessageFlags.Ephemeral
            });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`wp_setup_start_${interaction.user.id}`)
                .setLabel('Set Up Web Panel')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('🌐')
        );

        await interaction.reply({
            content: `# Welcome to the Web Panel!\nSet up a **permanent URL** with Discord login so you and your users can access the panel anytime. Click the button below to get started.\n-# Or use this temporary link (expires in 5 min): [link](${tokenLink})`,
            components: [row],
            flags: MessageFlags.Ephemeral
        });
    }
};
