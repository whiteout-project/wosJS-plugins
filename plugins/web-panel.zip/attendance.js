const crypto = require('crypto');
const { db } = require('./pluginDb');
const { getDefaultGameType } = require('../../src/functions/utility/gameRuntime');
const { normalizeGameType } = require('../../src/functions/utility/gameProfiles');

const ATTENDANCE_STATUSES = ['unassigned', 'attended', 'absent'];

db.exec(`
    CREATE TABLE IF NOT EXISTS attendance_records (
        id TEXT PRIMARY KEY,
        game_type TEXT NOT NULL DEFAULT 'wos',
        alliance_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        event_date TEXT NOT NULL,
        created_by_user_id TEXT NOT NULL,
        updated_by_user_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS attendance_record_players (
        record_id TEXT NOT NULL REFERENCES attendance_records(id) ON DELETE CASCADE,
        fid TEXT NOT NULL,
        state TEXT,
        status TEXT NOT NULL CHECK (status IN ('unassigned', 'attended', 'absent')) DEFAULT 'unassigned',
        updated_at TEXT NOT NULL,
        PRIMARY KEY (record_id, fid)
    );

    CREATE INDEX IF NOT EXISTS idx_attendance_records_game_alliance ON attendance_records(game_type, alliance_id);
    CREATE INDEX IF NOT EXISTS idx_attendance_records_updated_at ON attendance_records(updated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_attendance_players_record_status ON attendance_record_players(record_id, status);
`);

function resolveAttendanceGameType(gameType) {
    return normalizeGameType(gameType, getDefaultGameType());
}

function nowIso() {
    return new Date().toISOString();
}

function createId(prefix) {
    return `${prefix}_${crypto.randomUUID().replace(/-/g, '')}`;
}

function validateTitle(title) {
    const normalized = String(title || '').trim();
    if (!normalized) throw new Error('Attendance title is required');
    if (normalized.length > 120) throw new Error('Attendance title must be 120 characters or fewer');
    return normalized;
}

function validateEventDate(eventDate) {
    const normalized = String(eventDate || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
        throw new Error('Attendance date must use YYYY-MM-DD format');
    }
    const parsed = new Date(`${normalized}T00:00:00.000Z`);
    if (Number.isNaN(parsed.getTime())) {
        throw new Error('Attendance date is invalid');
    }
    return normalized;
}

function validateStatus(status) {
    const normalized = String(status || '').trim().toLowerCase();
    if (!ATTENDANCE_STATUSES.includes(normalized)) {
        throw new Error('Invalid attendance status');
    }
    return normalized;
}

function validateOptionalDateFilter(value, fieldName) {
    const normalized = String(value || '').trim();
    if (!normalized) return '';
    return validateEventDate(normalized, fieldName);
}

function buildAnalysisDateFilters(startDate, endDate) {
    const normalizedStartDate = validateOptionalDateFilter(startDate, 'Start date');
    const normalizedEndDate = validateOptionalDateFilter(endDate, 'End date');

    if (normalizedStartDate && normalizedEndDate && normalizedStartDate > normalizedEndDate) {
        throw new Error('Start date must be before or equal to end date');
    }

    return {
        startDate: normalizedStartDate,
        endDate: normalizedEndDate,
    };
}

function parseFid(value) {
    const text = String(value || '').trim();
    if (/^\d+$/.test(text)) return Number(text);
    return text;
}

function shapeRecordRow(row) {
    if (!row) return null;
    return {
        id: row.id,
        gameType: row.game_type,
        allianceId: Number(row.alliance_id),
        title: row.title,
        eventDate: row.event_date,
        createdByUserId: row.created_by_user_id,
        updatedByUserId: row.updated_by_user_id,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        playerCount: Number(row.player_count || 0),
        attendedCount: Number(row.attended_count || 0),
        absentCount: Number(row.absent_count || 0),
        unassignedCount: Number(row.unassigned_count || 0),
    };
}

function shapePlayerRow(row) {
    if (!row) return null;
    return {
        fid: parseFid(row.fid),
        state: row.state || '',
        status: row.status || 'unassigned',
        updatedAt: row.updated_at,
    };
}

const stmts = {
    createRecord: db.prepare(`
        INSERT INTO attendance_records (
            id, game_type, alliance_id, title, event_date, created_by_user_id, updated_by_user_id, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `),
    updateRecord: db.prepare(`
        UPDATE attendance_records
        SET title = ?, event_date = ?, updated_by_user_id = ?, updated_at = ?
        WHERE id = ?
    `),
    deleteRecord: db.prepare(`DELETE FROM attendance_records WHERE id = ?`),
    getRecord: db.prepare(`SELECT * FROM attendance_records WHERE id = ?`),
    getRecordSummary: db.prepare(`
        SELECT
            r.*,
            COUNT(p.fid) AS player_count,
            SUM(CASE WHEN p.status = 'attended' THEN 1 ELSE 0 END) AS attended_count,
            SUM(CASE WHEN p.status = 'absent' THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN p.status = 'unassigned' THEN 1 ELSE 0 END) AS unassigned_count
        FROM attendance_records r
        LEFT JOIN attendance_record_players p ON p.record_id = r.id
        WHERE r.id = ?
        GROUP BY r.id
    `),
    listRecordSummaries: db.prepare(`
        SELECT
            r.*,
            COUNT(p.fid) AS player_count,
            SUM(CASE WHEN p.status = 'attended' THEN 1 ELSE 0 END) AS attended_count,
            SUM(CASE WHEN p.status = 'absent' THEN 1 ELSE 0 END) AS absent_count,
            SUM(CASE WHEN p.status = 'unassigned' THEN 1 ELSE 0 END) AS unassigned_count
        FROM attendance_records r
        LEFT JOIN attendance_record_players p ON p.record_id = r.id
        WHERE r.game_type = ?
        GROUP BY r.id
        ORDER BY r.event_date DESC, r.updated_at DESC
    `),
    insertPlayer: db.prepare(`
        INSERT INTO attendance_record_players (
            record_id, fid, state, status, updated_at
        ) VALUES (?, ?, ?, 'unassigned', ?)
    `),
    getPlayersByRecord: db.prepare(`
        SELECT fid, state, status, updated_at
        FROM attendance_record_players
        WHERE record_id = ?
        ORDER BY CAST(fid AS INTEGER) ASC
    `),
    getPlayer: db.prepare(`
        SELECT *
        FROM attendance_record_players
        WHERE record_id = ? AND fid = ?
    `),
    updatePlayerStatus: db.prepare(`
        UPDATE attendance_record_players
        SET status = ?, updated_at = ?
        WHERE record_id = ? AND fid = ?
    `),
};

function buildAnalysisQueryParts({ gameType, allianceId, startDate, endDate, includePlayers = true }) {
    const where = ['r.game_type = ?', 'r.alliance_id = ?'];
    const params = [resolveAttendanceGameType(gameType), Number.parseInt(allianceId, 10)];

    if (!Number.isInteger(params[1])) {
        throw new Error('Alliance is required');
    }

    if (startDate) {
        where.push('r.event_date >= ?');
        params.push(startDate);
    }

    if (endDate) {
        where.push('r.event_date <= ?');
        params.push(endDate);
    }

    const join = includePlayers
        ? "JOIN attendance_record_players p ON p.record_id = r.id AND p.status IN ('attended', 'absent')"
        : '';

    return {
        whereSql: where.join(' AND '),
        params,
        join,
    };
}

function roundRate(value) {
    return Math.round((Number(value) || 0) * 10) / 10;
}

function comparePlayerAnalysis(a, b) {
    if (b.attendanceRate !== a.attendanceRate) return b.attendanceRate - a.attendanceRate;
    if (b.participationCount !== a.participationCount) return b.participationCount - a.participationCount;
    return String(a.fid).localeCompare(String(b.fid), undefined, { numeric: true });
}

function shapeTopParticipantGraph(players) {
    return [...players]
        .sort((a, b) => {
            if (b.participationCount !== a.participationCount) return b.participationCount - a.participationCount;
            if (b.attendanceRate !== a.attendanceRate) return b.attendanceRate - a.attendanceRate;
            return String(a.fid).localeCompare(String(b.fid), undefined, { numeric: true });
        })
        .slice(0, 10)
        .map((player) => ({
            fid: player.fid,
            attendanceRate: player.attendanceRate,
            participationCount: player.participationCount,
            attendedCount: player.attendedCount,
            absentCount: player.absentCount,
        }));
}

function getAnalysis({ gameType, allianceId, startDate = '', endDate = '' } = {}) {
    const filters = buildAnalysisDateFilters(startDate, endDate);
    const queryParts = buildAnalysisQueryParts({
        gameType,
        allianceId,
        startDate: filters.startDate,
        endDate: filters.endDate,
    });

    const rowQuery = db.prepare(`
        SELECT
            r.id AS record_id,
            r.event_date,
            r.updated_at AS record_updated_at,
            p.fid,
            p.state,
            p.status,
            p.updated_at AS player_updated_at
        FROM attendance_records r
        ${queryParts.join}
        WHERE ${queryParts.whereSql}
        ORDER BY r.event_date ASC, r.updated_at ASC, p.updated_at ASC, CAST(p.fid AS INTEGER) ASC
    `);

    const recordCountQuery = db.prepare(`
        SELECT COUNT(*) AS record_count
        FROM attendance_records r
        WHERE ${queryParts.whereSql}
    `);

    const rows = rowQuery.all(...queryParts.params);
    const recordCount = Number(recordCountQuery.get(...queryParts.params)?.record_count || 0);
    const playersByFid = new Map();
    let attendedCount = 0;
    let absentCount = 0;

    for (const row of rows) {
        const fidKey = String(row.fid);
        const existing = playersByFid.get(fidKey) || {
            fid: parseFid(row.fid),
            state: row.state || '',
            attendedCount: 0,
            absentCount: 0,
            participationCount: 0,
            attendanceRate: 0,
        };

        existing.state = row.state || existing.state || '';

        if (row.status === 'attended') {
            existing.attendedCount += 1;
            attendedCount += 1;
        } else if (row.status === 'absent') {
            existing.absentCount += 1;
            absentCount += 1;
        }

        existing.participationCount = existing.attendedCount + existing.absentCount;
        existing.attendanceRate = existing.participationCount > 0
            ? roundRate((existing.attendedCount / existing.participationCount) * 100)
            : 0;

        playersByFid.set(fidKey, existing);
    }

    const players = [...playersByFid.values()]
        .filter((player) => player.participationCount > 0)
        .sort(comparePlayerAnalysis);

    const participationCount = attendedCount + absentCount;
    const attendanceRate = participationCount > 0
        ? roundRate((attendedCount / participationCount) * 100)
        : 0;

    return {
        alliance: {
            id: Number.parseInt(allianceId, 10),
            name: '',
            gameType: resolveAttendanceGameType(gameType),
        },
        filters: {
            allianceId: String(allianceId),
            startDate: filters.startDate,
            endDate: filters.endDate,
        },
        summary: {
            recordCount,
            attendedCount,
            absentCount,
            participationCount,
            attendanceRate,
        },
        players,
        graphs: {
            topParticipants: shapeTopParticipantGraph(players),
            totals: [
                { key: 'attended', label: 'Attended', value: attendedCount },
                { key: 'absent', label: 'Absent', value: absentCount },
            ],
        },
    };
}

function escapeCsvCell(value) {
    const text = String(value ?? '');
    if (/[",\n]/.test(text)) {
        return `"${text.replace(/"/g, '""')}"`;
    }
    return text;
}

function formatCsvRate(value) {
    const numeric = Number(value) || 0;
    const rounded = roundRate(numeric);
    const text = Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
    return `${text}%`;
}

function buildAnalysisCsv(analysis) {
    const startDate = analysis?.filters?.startDate || 'All time';
    const endDate = analysis?.filters?.endDate || 'All time';
    const allianceName = analysis?.alliance?.name || 'Unknown Alliance';
    const gameType = String(analysis?.alliance?.gameType || '').toUpperCase();
    const rows = [
        [
            'Alliance',
            'Game Type',
            'Start Date',
            'End Date',
            'ID',
            'Assigned State',
            'Attended Count',
            'Absent Count',
            'Total Participations',
            'Attendance Rate',
        ],
        ...(analysis?.players || []).map((player) => ([
            allianceName,
            gameType,
            startDate,
            endDate,
            String(player.fid ?? ''),
            player.state ?? '',
            player.attendedCount ?? 0,
            player.absentCount ?? 0,
            player.participationCount ?? 0,
            formatCsvRate(player.attendanceRate),
        ])),
    ];

    return `\uFEFF${rows.map((row) => row.map(escapeCsvCell).join(',')).join('\n')}`;
}

function getRecordDetail(recordId, gameType = null) {
    const record = shapeRecordRow(stmts.getRecordSummary.get(recordId));
    if (!record) return null;
    if (gameType && record.gameType !== resolveAttendanceGameType(gameType)) return null;

    return {
        ...record,
        players: stmts.getPlayersByRecord.all(recordId).map(shapePlayerRow),
    };
}

function getRecords({ gameType, allianceIds = [], allianceId = null } = {}) {
    const resolvedGameType = resolveAttendanceGameType(gameType);
    const accessibleIds = new Set((Array.isArray(allianceIds) ? allianceIds : []).map(Number));
    const requestedAllianceId = allianceId === null || allianceId === undefined || allianceId === ''
        ? null
        : Number.parseInt(allianceId, 10);

    return stmts.listRecordSummaries.all(resolvedGameType)
        .map(shapeRecordRow)
        .filter((record) => accessibleIds.has(record.allianceId))
        .filter((record) => requestedAllianceId === null || record.allianceId === requestedAllianceId);
}

const createRecordTx = db.transaction(({ title, eventDate, allianceId, players, userId, gameType }) => {
    const recordId = createId('attendance');
    const now = nowIso();
    const normalizedTitle = validateTitle(title);
    const normalizedDate = validateEventDate(eventDate);
    const resolvedGameType = resolveAttendanceGameType(gameType);
    const normalizedAllianceId = Number.parseInt(allianceId, 10);

    if (!Number.isInteger(normalizedAllianceId)) throw new Error('Alliance is required');

    stmts.createRecord.run(
        recordId,
        resolvedGameType,
        normalizedAllianceId,
        normalizedTitle,
        normalizedDate,
        userId,
        userId,
        now,
        now
    );

    for (const player of Array.isArray(players) ? players : []) {
        stmts.insertPlayer.run(
            recordId,
            String(player.fid),
            player.state || '',
            now
        );
    }

    return recordId;
});

const updateRecordTx = db.transaction((recordId, input, updatedByUserId) => {
    const record = stmts.getRecord.get(recordId);
    if (!record) throw new Error('Attendance record not found');

    const title = validateTitle(input.title ?? record.title);
    const eventDate = validateEventDate(input.eventDate ?? record.event_date);
    stmts.updateRecord.run(title, eventDate, updatedByUserId, nowIso(), recordId);
    return getRecordDetail(recordId);
});

const updatePlayerStatusTx = db.transaction((recordId, fid, status) => {
    const normalizedStatus = validateStatus(status);
    const player = stmts.getPlayer.get(recordId, String(fid));
    if (!player) throw new Error('Player is not part of this attendance record');

    stmts.updatePlayerStatus.run(normalizedStatus, nowIso(), recordId, String(fid));
    return {
        previousStatus: player.status,
        player: shapePlayerRow({ ...player, status: normalizedStatus, updated_at: nowIso() }),
        detail: getRecordDetail(recordId),
    };
});

module.exports = {
    ATTENDANCE_STATUSES,
    getRecords,
    getRecordDetail,
    getAnalysis,
    buildAnalysisCsv,
    createRecord(input) {
        const recordId = createRecordTx(input);
        return getRecordDetail(recordId, input?.gameType);
    },
    updateRecord(recordId, input, updatedByUserId, gameType = null) {
        const detail = getRecordDetail(recordId, gameType);
        if (!detail) throw new Error('Attendance record not found');
        return updateRecordTx(recordId, input, updatedByUserId);
    },
    updatePlayerStatus(recordId, fid, status, gameType = null) {
        const detail = getRecordDetail(recordId, gameType);
        if (!detail) throw new Error('Attendance record not found');
        return updatePlayerStatusTx(recordId, fid, status);
    },
    deleteRecord(recordId, gameType = null) {
        const detail = getRecordDetail(recordId, gameType);
        if (!detail) throw new Error('Attendance record not found');
        stmts.deleteRecord.run(recordId);
        return detail;
    },
};
