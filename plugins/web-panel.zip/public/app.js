// ─────────────────────────────────────────────────────────────────────────────
// Web Panel - SPA
// ─────────────────────────────────────────────────────────────────────────────
(() => {
    const app = document.getElementById('app');
    const BASE_PATH = document.querySelector('meta[name="base-path"]')?.content || '';
    let currentUser = null;
    let botInfo = { name: 'Bot', avatar: null };
    let currentPage = 'dashboard';

    // Permission bit flags (mirrored from server)
    const PERMS = {
        ALLIANCE_MANAGEMENT: 1,
        PLAYER_MANAGEMENT: 2,
        GIFT_CODE_MANAGEMENT: 4,
        NOTIFICATIONS_MANAGEMENT: 8,
        FULL_ACCESS: 16
    };

    function hasPerm(...perms) {
        if (currentUser.isOwner) return true;
        return perms.some(p => currentUser.permissions & p);
    }

    // ── Furnace Level Display ─────────────────────────────────────────────
    const FURNACE_LEVEL_MAP = {
        31:'30-1',32:'30-2',33:'30-3',34:'30-4',35:'FC 1',
        36:'FC 1-1',37:'FC 1-2',38:'FC 1-3',39:'FC 1-4',40:'FC 2',
        41:'FC 2-1',42:'FC 2-2',43:'FC 2-3',44:'FC 2-4',45:'FC 3',
        46:'FC 3-1',47:'FC 3-2',48:'FC 3-3',49:'FC 3-4',50:'FC 4',
        51:'FC 4-1',52:'FC 4-2',53:'FC 4-3',54:'FC 4-4',55:'FC 5',
        56:'FC 5-1',57:'FC 5-2',58:'FC 5-3',59:'FC 5-4',60:'FC 6',
        61:'FC 6-1',62:'FC 6-2',63:'FC 6-3',64:'FC 6-4',65:'FC 7',
        66:'FC 7-1',67:'FC 7-2',68:'FC 7-3',69:'FC 7-4',70:'FC 8',
        71:'FC 8-1',72:'FC 8-2',73:'FC 8-3',74:'FC 8-4',75:'FC 9',
        76:'FC 9-1',77:'FC 9-2',78:'FC 9-3',79:'FC 9-4',80:'FC 10',
        81:'FC 10-1',82:'FC 10-2',83:'FC 10-3',84:'FC 10-4'
    };

    function formatFurnaceLevel(level) {
        if (!level && level !== 0) return '-';
        return FURNACE_LEVEL_MAP[level] || String(level);
    }

    // ── Toast System ─────────────────────────────────────────────────────
    function showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const icons = { success: '\u2713', error: '\u2717', info: '\u24D8' };
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${escapeHTML(message)}</span>`;
        container.appendChild(toast);

        const dismissTimeout = setTimeout(() => removeToast(toast), 4000);
        toast.addEventListener('click', () => {
            clearTimeout(dismissTimeout);
            removeToast(toast);
        });
    }

    function removeToast(toast) {
        toast.classList.add('toast-leaving');
        toast.addEventListener('animationend', () => toast.remove());
    }

    // ── API helper ───────────────────────────────────────────────────────
    async function apiFetch(urlPath, options = {}) {
        const { method = 'GET', body } = options;
        const fetchOptions = { method };

        if (body !== undefined) {
            fetchOptions.headers = { 'Content-Type': 'application/json' };
            fetchOptions.body = JSON.stringify(body);
        }

        const response = await fetch(BASE_PATH + urlPath, fetchOptions);
        if (response.status === 401) {
            currentUser = null;
            renderLogin();
            return null;
        }
        if (response.status === 403) return null;
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `HTTP ${response.status}`);
        }
        return response.json();
    }

    // ── Init ─────────────────────────────────────────────────────────────
    async function init() {
        try {
            const [userResponse, botResponse] = await Promise.all([
                fetch(BASE_PATH + '/auth/me'),
                fetch(BASE_PATH + '/api/botinfo')
            ]);

            if (botResponse.ok) {
                botInfo = await botResponse.json();
                document.title = `${botInfo.name} Panel`;
            }

            if (!userResponse.ok) {
                renderLogin();
                return;
            }

            currentUser = await userResponse.json();
            renderApp();
            navigate('dashboard');
        } catch {
            renderLogin();
        }
    }

    // ── Login screen ─────────────────────────────────────────────────────
    function renderLogin() {
        const initial = botInfo.name.charAt(0).toUpperCase();
        const loginAction = botInfo.hasOAuth2
            ? `<button class="login-discord-btn" onclick="window.location.href='${BASE_PATH}/auth/login'">Login with Discord</button>`
            : `<p>Use the <strong>/webpanel</strong> command in Discord to get a login link.</p>`;

        app.innerHTML = `
            <div class="login-screen">
                <div class="login-card">
                    <div class="login-icon">${initial}</div>
                    <h1>${escapeHTML(botInfo.name)} Panel</h1>
                    ${loginAction}
                </div>
            </div>
        `;
    }

    // ── Navigation definitions ───────────────────────────────────────────
    function getNavItems() {
        const items = [
            { page: 'dashboard', icon: 'dashboard.png', label: 'Dashboard', allowed: true },
            { page: 'alliances', icon: 'alliances.png', label: 'Alliances', allowed: hasPerm(PERMS.ALLIANCE_MANAGEMENT, PERMS.FULL_ACCESS) },
            { page: 'notifications', icon: 'notifications.png', label: 'Notifications', allowed: hasPerm(PERMS.NOTIFICATIONS_MANAGEMENT, PERMS.FULL_ACCESS) },
            { page: 'processes', icon: 'processes.png', label: 'Processes', allowed: true },
            { page: 'giftcodes', icon: 'giftcodes.png', label: 'Gift Codes', allowed: hasPerm(PERMS.GIFT_CODE_MANAGEMENT, PERMS.FULL_ACCESS) },
            { page: 'settings', icon: 'settings.png', label: 'Settings', allowed: hasPerm(PERMS.FULL_ACCESS) },
            { page: 'logs', icon: 'logs.png', label: 'Logs', allowed: hasPerm(PERMS.FULL_ACCESS) }
        ];
        return items.filter(item => item.allowed);
    }

    // ── App shell ────────────────────────────────────────────────────────
    function renderApp() {
        const navItems = getNavItems();
        const initial = botInfo.name.charAt(0).toUpperCase();
        const isCollapsed = localStorage.getItem('sidebar-collapsed') === 'true';
        const navHTML = navItems.map(item =>
            `<button class="nav-item" data-page="${item.page}"><span class="icon"><img src="${BASE_PATH}/icons/${item.icon}" alt="${item.label}"></span><span class="nav-label">${item.label}</span></button>`
        ).join('');

        app.innerHTML = `
            <div class="layout">
                <div class="mobile-header">
                    <button class="hamburger" id="menu-toggle">&#9776;</button>
                    <span class="mobile-title">${escapeHTML(botInfo.name)}</span>
                </div>
                <div class="sidebar-overlay" id="sidebar-overlay"></div>
                <nav class="sidebar ${isCollapsed ? 'collapsed' : ''}" id="sidebar">
                    <div class="sidebar-header">
                        <div class="sidebar-brand">
                            <div class="brand-icon">${initial}</div>
                            <div class="brand-text">
                                <h1>${escapeHTML(botInfo.name)}</h1>
                                <div class="subtitle">Admin Panel</div>
                            </div>
                        </div>
                        <button class="sidebar-collapse-btn" id="sidebar-collapse" title="Toggle sidebar">&#9664;</button>
                    </div>
                    <div class="nav-section">
                        ${navHTML}
                    </div>
                    <div class="sidebar-footer">
                        <div class="user-row">
                            <span class="user-id">${currentUser.userId.slice(-6)}</span>
                            <button class="logout-btn" id="logout-btn">Logout</button>
                        </div>
                    </div>
                </nav>
                <main class="main-content" id="page-content"></main>
                <button class="scroll-top-btn" id="scroll-top-btn" aria-label="Scroll to top">&#9650;</button>
            </div>
        `;

        // Scroll-to-top button
        const scrollTopBtn = document.getElementById('scroll-top-btn');
        window.addEventListener('scroll', () => {
            scrollTopBtn.classList.toggle('visible', window.scrollY > 200);
        });
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        document.querySelectorAll('.nav-item').forEach(btn => {
            btn.addEventListener('click', () => {
                navigate(btn.dataset.page);
                closeMobileMenu();
            });
        });

        document.getElementById('logout-btn').addEventListener('click', async () => {
            await fetch(BASE_PATH + '/auth/logout', { method: 'POST' });
            currentUser = null;
            window.location.href = BASE_PATH + '/auth/login';
        });

        // Mobile menu
        document.getElementById('menu-toggle')?.addEventListener('click', toggleMobileMenu);
        document.getElementById('sidebar-overlay')?.addEventListener('click', closeMobileMenu);

        // Sidebar collapse toggle
        document.getElementById('sidebar-collapse')?.addEventListener('click', () => {
            const sidebar = document.getElementById('sidebar');
            sidebar?.classList.toggle('collapsed');
            const isCollapsed = sidebar?.classList.contains('collapsed');
            localStorage.setItem('sidebar-collapsed', isCollapsed);
        });

        // Expand sidebar when clicking brand icon in collapsed state
        document.querySelector('.sidebar-brand')?.addEventListener('click', () => {
            const sidebar = document.getElementById('sidebar');
            if (sidebar?.classList.contains('collapsed')) {
                sidebar.classList.remove('collapsed');
                localStorage.setItem('sidebar-collapsed', 'false');
            }
        });
    }

    let savedScrollY = 0;

    function lockBodyScroll() {
        savedScrollY = window.scrollY;
        document.documentElement.classList.add('sidebar-open');
        document.body.classList.add('sidebar-open');
        document.body.style.top = `-${savedScrollY}px`;
    }

    function unlockBodyScroll() {
        document.documentElement.classList.remove('sidebar-open');
        document.body.classList.remove('sidebar-open');
        document.body.style.top = '';
        window.scrollTo(0, savedScrollY);
    }

    function toggleMobileMenu() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        const isOpening = !sidebar?.classList.contains('open');
        sidebar?.classList.toggle('open');
        overlay?.classList.toggle('visible');
        if (isOpening) lockBodyScroll();
        else unlockBodyScroll();
    }

    function closeMobileMenu() {
        document.getElementById('sidebar')?.classList.remove('open');
        document.getElementById('sidebar-overlay')?.classList.remove('visible');
        unlockBodyScroll();
    }

    // ── Router ────────────────────────────────────────────────────────────
    let activePollingTimer = null;

    function stopPolling() {
        if (activePollingTimer) {
            clearInterval(activePollingTimer);
            activePollingTimer = null;
        }
    }

    function navigate(page) {
        stopPolling();
        currentPage = page;

        document.querySelectorAll('.nav-item').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.page === page);
        });

        const content = document.getElementById('page-content');
        content.innerHTML = `
            <div style="animation: fadeIn 0.3s ease">
                <div class="skeleton skeleton-heading"></div>
                <div class="stats-grid stagger">
                    <div class="skeleton skeleton-card"></div>
                    <div class="skeleton skeleton-card"></div>
                    <div class="skeleton skeleton-card"></div>
                </div>
            </div>
        `;

        const pageRenderers = {
            dashboard: renderDashboard,
            alliances: renderAlliances,
            notifications: renderNotifications,
            processes: renderProcesses,
            giftcodes: renderGiftCodes,
            settings: renderSettings,
            logs: renderLogs
        };

        const renderer = pageRenderers[page];
        if (renderer) renderer(content);
    }

    // ── Dashboard ────────────────────────────────────────────────────────
    async function renderDashboard(container) {
        const data = await apiFetch('/api/dashboard');
        if (!data) return;

        const uptimeStr = formatUptime(data.uptime);
        const counts = data.counts;

        const statCards = [];
        if (counts.players !== undefined) statCards.push({ label: 'Players', value: counts.players, cls: 'accent' });
        if (counts.alliances !== undefined) statCards.push({ label: 'Alliances', value: counts.alliances, cls: 'accent' });
        if (counts.activeNotifications !== undefined) statCards.push({ label: 'Active Notifications', value: counts.activeNotifications, cls: 'green' });
        if (counts.activeProcesses !== undefined) statCards.push({ label: 'Active Processes', value: counts.activeProcesses, cls: 'yellow' });
        if (counts.giftCodes !== undefined) statCards.push({ label: 'Gift Codes', value: counts.giftCodes, cls: '' });
        statCards.push({ label: 'Uptime', value: uptimeStr, cls: '', style: 'font-size:20px' });

        const cardsHTML = statCards.map(c =>
            `<div class="stat-card"><div class="label">${c.label}</div><div class="value ${c.cls}"${c.style ? ` style="${c.style}"` : ''}>${c.value}</div></div>`
        ).join('');

        container.innerHTML = `
            <div class="page-header">
                <h2>Dashboard</h2>
                <div class="desc">System overview</div>
            </div>
            <div class="stats-grid stagger">${cardsHTML}</div>
        `;
    }

    // ── Alliances ────────────────────────────────────────────────────────
    let selectedAllianceId = null;

    async function renderAlliances(container) {
        const alliances = await apiFetch('/api/alliances');
        if (!alliances) return;

        container.innerHTML = `
            <div class="page-header">
                <h2>Alliances</h2>
                <div class="desc">${alliances.length} alliances</div>
            </div>
            <div class="alliance-layout">
                <div class="alliance-list">
                    ${alliances.map(a => `
                        <div class="alliance-item ${selectedAllianceId === a.id ? 'active' : ''}" data-id="${a.id}" data-name="${escapeHTML(a.name || '')}">
                            <div class="alliance-priority">${a.priority}</div>
                            <div class="alliance-info">
                                <div class="alliance-name">${escapeHTML(a.name || 'Unnamed')}</div>
                                <div class="alliance-meta">
                                    <span>${a.playerCount} players</span>
                                    <span class="badge ${a.interval > 0 ? 'green' : 'red'}">${a.interval > 0 ? 'Auto' : 'Off'}</span>
                                    ${a.interval > 0 ? `<span>${a.interval}m</span>` : ''}
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <div class="alliance-detail" id="alliance-detail">
                    <div class="alliance-empty">
                        <div class="empty-icon">\u{1F3F0}</div>
                        <span>Pick an alliance to view its players</span>
                    </div>
                </div>
            </div>
        `;

        container.querySelectorAll('.alliance-item').forEach(item => {
            item.addEventListener('click', () => selectAlliance(container, alliances, parseInt(item.dataset.id, 10)));
        });

        if (selectedAllianceId) {
            const preselected = alliances.find(a => a.id === selectedAllianceId);
            if (preselected) selectAlliance(container, alliances, selectedAllianceId);
        }
    }

    function updateSidebarAllianceCount(allianceId, count) {
        const sidebarItem = document.querySelector(`.alliance-item[data-id="${allianceId}"]`);
        if (!sidebarItem) return;
        const metaSpan = sidebarItem.querySelector('.alliance-meta span:first-child');
        if (metaSpan) metaSpan.textContent = `${count} players`;
    }

    async function selectAlliance(container, alliances, allianceId) {
        selectedAllianceId = allianceId;

        container.querySelectorAll('.alliance-item').forEach(item => {
            item.classList.toggle('active', parseInt(item.dataset.id, 10) === allianceId);
        });

        // Mobile: hide alliance list, show detail
        const layout = container.querySelector('.alliance-layout');
        if (layout) layout.classList.add('detail-active');

        const detailPanel = document.getElementById('alliance-detail');
        if (!detailPanel) return;

        detailPanel.innerHTML = `<div class="skeleton" style="height:200px;border-radius:var(--radius)"></div>`;

        const allianceData = await apiFetch(`/api/alliances/${allianceId}`);
        if (!allianceData) return;

        const alliance = alliances.find(a => a.id === allianceId);
        const allianceName = escapeHTML(alliance?.name || allianceData.name || 'Unnamed');
        const players = allianceData.players || [];

        detailPanel.innerHTML = `
            <div class="alliance-detail-header">
                <div>
                    <button class="btn btn-sm alliance-back-btn">&#9664; Back</button>
                    <div class="detail-title">${allianceName}</div>
                    <div class="detail-stats">
                        <span>${players.length} players</span>
                        <span>${alliance?.interval > 0 ? 'Refresh Rate: ' + alliance.interval + 'min' : 'Auto refresh disabled'}</span>
                    </div>
                </div>
                <div class="alliance-header-actions">
                    <div class="custom-select" id="sort-dropdown">
                        <button class="custom-select-trigger btn btn-sm">
                            <span class="custom-select-value">Furnace: High &#x2192; Low</span>
                            <span class="custom-select-arrow">&#9662;</span>
                        </button>
                        <div class="custom-select-options">
                            <div class="custom-select-option active" data-value="desc">Furnace: High &#x2192; Low</div>
                            <div class="custom-select-option" data-value="asc">Furnace: Low &#x2192; High</div>
                            <div class="custom-select-option" data-value="default">Default Order</div>
                        </div>
                    </div>
                    <button class="btn btn-sm export-alliance-btn" ${players.length === 0 ? 'disabled' : ''}>Export CSV</button>
                    <button class="btn btn-sm refresh-alliance-btn" ${players.length === 0 ? 'disabled' : ''}>Refresh</button>
                </div>
            </div>
            ${players.length > 0 ? `
                <div class="alliance-detail-scroll">
                    <div class="player-cards-grid">
                        ${players.map(p => buildPlayerCard(p)).join('')}
                    </div>
                </div>
            ` : `
                <div class="alliance-empty">
                    <div class="empty-icon">\u{1F465}</div>
                    <span>No players in this alliance</span>
                </div>
            `}
        `;

        // Back button — mobile master-detail toggle
        const backBtn = detailPanel.querySelector('.alliance-back-btn');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                const layout = container.querySelector('.alliance-layout');
                if (layout) layout.classList.remove('detail-active');
            });
        }

        // Sort filter — custom dropdown
        const sortDropdown = detailPanel.querySelector('#sort-dropdown');
        if (sortDropdown) {
            const trigger = sortDropdown.querySelector('.custom-select-trigger');
            const optionsPanel = sortDropdown.querySelector('.custom-select-options');
            const valueLabel = sortDropdown.querySelector('.custom-select-value');

            trigger.addEventListener('click', (e) => {
                e.stopPropagation();
                sortDropdown.classList.toggle('open');
            });

            optionsPanel.querySelectorAll('.custom-select-option').forEach(opt => {
                opt.addEventListener('click', () => {
                    const sortValue = opt.dataset.value;
                    valueLabel.textContent = opt.textContent;
                    optionsPanel.querySelectorAll('.custom-select-option').forEach(o => o.classList.remove('active'));
                    opt.classList.add('active');
                    sortDropdown.classList.remove('open');

                    const grid = detailPanel.querySelector('.player-cards-grid');
                    if (!grid) return;
                    let sorted;
                    if (sortValue === 'desc') {
                        sorted = [...players].sort((a, b) => (b.furnace_level || 0) - (a.furnace_level || 0));
                    } else if (sortValue === 'asc') {
                        sorted = [...players].sort((a, b) => (a.furnace_level || 0) - (b.furnace_level || 0));
                    } else {
                        sorted = players;
                    }
                    grid.innerHTML = sorted.map(p => buildPlayerCard(p)).join('');
                });
            });

            document.addEventListener('click', (e) => {
                if (!sortDropdown.contains(e.target)) {
                    sortDropdown.classList.remove('open');
                }
            });
        }

        // Export button
        const exportBtn = detailPanel.querySelector('.export-alliance-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                showExportModal(allianceId, allianceName, players.length);
            });
        }

        const refreshBtn = detailPanel.querySelector('.refresh-alliance-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', async () => {
                refreshBtn.disabled = true;
                refreshBtn.classList.add('loading');
                refreshBtn.textContent = '';
                try {
                    const refreshResult = await apiFetch(`/api/alliances/${allianceId}/refresh`, { method: 'POST' });
                    if (refreshResult) showToast(`Refresh started (ID: ${refreshResult.processId})`, 'success');
                } catch (error) {
                    showToast(error.message, 'error');
                }
                refreshBtn.disabled = false;
                refreshBtn.classList.remove('loading');
                refreshBtn.textContent = 'Refresh';
            });
        }

        // Player card actions (event delegation)
        detailPanel.addEventListener('click', async (e) => {
            const movePlayerBtn = e.target.closest('.move-player-btn');
            if (movePlayerBtn) {
                const fid = movePlayerBtn.dataset.fid;
                const card = movePlayerBtn.closest('.player-card');
                const playerName = card?.querySelector('.player-nickname')?.textContent || fid;
                showMovePlayerModal(fid, playerName, allianceId, alliances, detailPanel);
                return;
            }

            const removePlayerBtn = e.target.closest('.remove-player-btn');
            if (removePlayerBtn) {
                const fid = removePlayerBtn.dataset.fid;
                const card = removePlayerBtn.closest('.player-card');
                const playerName = card?.querySelector('.player-nickname')?.textContent || fid;
                if (!confirm(`Remove player ${playerName} (#${fid})?`)) return;

                removePlayerBtn.disabled = true;
                try {
                    const deleteResult = await apiFetch(`/api/players/${fid}`, { method: 'DELETE' });
                    if (deleteResult?.ok) {
                        card?.remove();
                        showToast(`Player #${fid} removed`, 'success');
                        const remaining = detailPanel.querySelectorAll('.player-card').length;
                        const countSpan = detailPanel.querySelector('.detail-stats span');
                        if (countSpan) countSpan.textContent = `${remaining} players`;
                        updateSidebarAllianceCount(allianceId, remaining);
                    }
                } catch (error) {
                    showToast(error.message, 'error');
                    removePlayerBtn.disabled = false;
                }
            }
        });
    }

    function buildPlayerCard(player) {
        const nickname = escapeHTML(player.nickname || 'Unknown');
        const initial = (player.nickname || '?')[0].toUpperCase();
        const hasAvatar = player.image_url && player.image_url.trim();

        return `
            <div class="player-card" data-fid="${player.fid}">
                <div class="player-card-actions">
                    <button class="player-action-btn move-player-btn" data-tooltip="Move" data-fid="${player.fid}">
                        <img src="${BASE_PATH}/icons/move.png" alt="Move" width="16" height="16">
                    </button>
                    <button class="player-action-btn remove-player-btn" data-tooltip="Remove" data-fid="${player.fid}">
                        <img src="${BASE_PATH}/icons/delete.png" alt="Remove" width="16" height="16">
                    </button>
                </div>
                <div class="player-header">
                    <div class="player-avatar"${hasAvatar ? '' : ` data-initial="${initial}"`}>
                        ${hasAvatar
                            ? `<img src="${player.image_url}" alt="${nickname}" onerror="this.style.display='none';this.parentElement.dataset.initial='${initial}';this.parentElement.textContent='${initial}'">`
                            : initial}
                    </div>
                    <div>
                        <div class="player-nickname">${nickname}</div>
                        <div class="player-fid">#${player.fid}</div>
                    </div>
                </div>
                <div class="player-stats">
                    <div class="player-stat">
                        <span class="stat-label">Furnace</span>
                        <span class="stat-value">${formatFurnaceLevel(player.furnace_level)}</span>
                    </div>
                    <div class="player-stat">
                        <span class="stat-label">State</span>
                        <span class="stat-value">${player.state || '-'}</span>
                    </div>
                </div>
            </div>
        `;
    }

    // ── Export Modal ─────────────────────────────────────────────────────
    function showExportModal(allianceId, allianceName, playerCount) {
        const existing = document.querySelector('.export-modal-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.className = 'export-modal-overlay';
        overlay.innerHTML = `
            <div class="export-modal">
                <div class="export-modal-header">
                    <h3>Export Players</h3>
                    <button class="export-modal-close">&times;</button>
                </div>
                <div class="export-modal-body">
                    <p>Export <strong>${playerCount}</strong> players from <strong>${allianceName}</strong> as CSV.</p>
                    <p class="export-modal-note">The file will be sorted by furnace level (highest first) and includes: Player ID, Name, Furnace Level, State.</p>
                </div>
                <div class="export-modal-footer">
                    <button class="btn btn-sm export-modal-cancel">Cancel</button>
                    <button class="btn btn-sm btn-primary export-modal-confirm">Download CSV</button>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        overlay.querySelector('.export-modal-close').addEventListener('click', () => overlay.remove());
        overlay.querySelector('.export-modal-cancel').addEventListener('click', () => overlay.remove());
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });

        const confirmBtn = overlay.querySelector('.export-modal-confirm');
        confirmBtn.addEventListener('click', async () => {
            confirmBtn.disabled = true;
            confirmBtn.textContent = 'Generating...';
            try {
                const response = await fetch(`${BASE_PATH}/api/alliances/${allianceId}/export`, {
                    credentials: 'include'
                });
                if (!response.ok) {
                    const err = await response.json().catch(() => ({ error: 'Export failed' }));
                    throw new Error(err.error || 'Export failed');
                }
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = response.headers.get('Content-Disposition')?.match(/filename="(.+)"/)?.[1] || `${allianceName}_players.csv`;
                document.body.appendChild(link);
                link.click();
                link.remove();
                URL.revokeObjectURL(url);
                showToast('Export downloaded', 'success');
                overlay.remove();
            } catch (error) {
                showToast(error.message, 'error');
                confirmBtn.disabled = false;
                confirmBtn.textContent = 'Download CSV';
            }
        });
    }

    function showMovePlayerModal(fid, playerName, currentAllianceId, alliances, detailPanel) {
        const existing = document.querySelector('.export-modal-overlay');
        if (existing) existing.remove();

        const otherAlliances = alliances.filter(a => a.id !== currentAllianceId);
        if (otherAlliances.length === 0) {
            showToast('No other alliances available', 'error');
            return;
        }

        const overlay = document.createElement('div');
        overlay.className = 'export-modal-overlay';
        overlay.innerHTML = `
            <div class="export-modal">
                <div class="export-modal-header">
                    <h3>Move Player</h3>
                    <button class="export-modal-close">&times;</button>
                </div>
                <div class="export-modal-body">
                    <p>Move <strong>${escapeHTML(playerName)}</strong> (#${fid}) to another alliance:</p>
                    <select class="move-alliance-select">
                        ${otherAlliances.map(a => `<option value="${a.id}">${escapeHTML(a.name || 'Unnamed')}</option>`).join('')}
                    </select>
                </div>
                <div class="export-modal-footer">
                    <button class="btn btn-sm export-modal-cancel">Cancel</button>
                    <button class="btn btn-sm btn-primary move-modal-confirm">Move</button>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        overlay.querySelector('.export-modal-close').addEventListener('click', () => overlay.remove());
        overlay.querySelector('.export-modal-cancel').addEventListener('click', () => overlay.remove());
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });

        const confirmBtn = overlay.querySelector('.move-modal-confirm');
        const selectEl = overlay.querySelector('.move-alliance-select');

        confirmBtn.addEventListener('click', async () => {
            const targetAllianceId = parseInt(selectEl.value, 10);
            confirmBtn.disabled = true;
            confirmBtn.textContent = 'Moving...';
            try {
                const moveResult = await apiFetch(`/api/players/${fid}/move`, {
                    method: 'POST',
                    body: { allianceId: targetAllianceId }
                });
                if (moveResult?.ok) {
                    const card = detailPanel.querySelector(`.player-card[data-fid="${fid}"]`);
                    if (card) card.remove();
                    const remaining = detailPanel.querySelectorAll('.player-card').length;
                    const countSpan = detailPanel.querySelector('.detail-stats span');
                    if (countSpan) countSpan.textContent = `${remaining} players`;
                    updateSidebarAllianceCount(currentAllianceId, remaining);
                    const sourceAlliance = alliances.find(a => a.id === currentAllianceId);
                    if (sourceAlliance) sourceAlliance.playerCount = remaining;
                    const targetAlliance = otherAlliances.find(a => a.id === targetAllianceId);
                    const targetName = targetAlliance?.name || 'unknown';
                    const newTargetCount = (targetAlliance?.playerCount || 0) + 1;
                    updateSidebarAllianceCount(targetAllianceId, newTargetCount);
                    if (targetAlliance) targetAlliance.playerCount = newTargetCount;
                    showToast(`Player moved to ${targetName}`, 'success');
                    overlay.remove();
                }
            } catch (error) {
                showToast(error.message, 'error');
                confirmBtn.disabled = false;
                confirmBtn.textContent = 'Move';
            }
        });
    }

    // ── Notifications ────────────────────────────────────────────────────
    async function renderNotifications(container) {
        const notifications = await apiFetch('/api/notifications');
        if (!notifications) return;

        container.innerHTML = `
            <div class="page-header">
                <h2>Notifications</h2>
                <div class="desc">${notifications.length} total</div>
            </div>
            <div class="action-bar">
                <button id="create-notif-btn" class="btn btn-primary">Create Notification</button>
            </div>
            <div id="notif-form-area"></div>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>Name</th><th>Type</th><th>Status</th><th>Pattern</th><th>Time (UTC)</th><th>Next Trigger</th><th>Actions</th></tr></thead>
                    <tbody>
                        ${notifications.map(n => `
                            <tr>
                                <td>${escapeHTML(n.name || 'Untitled')}</td>
                                <td>${n.guild_id ? 'Server' : 'Private'}</td>
                                <td>
                                    <button class="badge-btn ${n.is_active ? 'green' : 'red'} toggle-active" data-id="${n.id}" data-active="${n.is_active ? 1 : 0}">
                                        ${n.is_active ? 'Active' : 'Inactive'}
                                    </button>
                                </td>
                                <td style="font-family:var(--font-mono);font-size:11px">${escapeHTML(n.pattern || '-')}</td>
                                <td>${String(n.hour ?? 0).padStart(2, '0')}:${String(n.minute ?? 0).padStart(2, '0')}</td>
                                <td>${formatTime(n.next_trigger)}</td>
                                <td class="actions-cell">
                                    <button class="btn btn-sm edit-notif" data-id="${n.id}">Edit</button>
                                    <button class="btn btn-danger btn-sm delete-notif" data-id="${n.id}" data-name="${escapeHTML(n.name || '')}">Delete</button>
                                </td>
                            </tr>
                        `).join('')}
                        ${notifications.length === 0 ? '<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">No notifications</td></tr>' : ''}
                    </tbody>
                </table>
            </div>
        `;

        document.getElementById('create-notif-btn')?.addEventListener('click', () => {
            showNotificationForm(container);
        });

        container.querySelectorAll('.toggle-active').forEach(btn => {
            btn.addEventListener('click', async () => {
                const isCurrentlyActive = btn.dataset.active === '1';
                try {
                    await apiFetch(`/api/notifications/${btn.dataset.id}/active`, { method: 'PATCH', body: { isActive: !isCurrentlyActive } });
                    renderNotifications(container);
                } catch (error) {
                    showToast(error.message, 'error');
                }
            });
        });

        container.querySelectorAll('.edit-notif').forEach(btn => {
            btn.addEventListener('click', () => {
                const notif = notifications.find(n => n.id === parseInt(btn.dataset.id, 10));
                if (notif) showNotificationForm(container, notif);
            });
        });

        container.querySelectorAll('.delete-notif').forEach(btn => {
            btn.addEventListener('click', async () => {
                if (!confirm(`Delete notification "${btn.dataset.name}"?`)) return;
                try {
                    await apiFetch(`/api/notifications/${btn.dataset.id}`, { method: 'DELETE' });
                    renderNotifications(container);
                } catch (error) {
                    showToast(error.message, 'error');
                }
            });
        });
    }

    function showNotificationForm(container, existing = null) {
        const isEdit = !!existing;
        const formArea = document.getElementById('notif-form-area');

        formArea.innerHTML = `
            <div class="form-card">
                <h3>${isEdit ? 'Edit' : 'Create'} Notification</h3>
                <form id="notif-form">
                    <div class="form-row">
                        <label>Name<input type="text" id="nf-name" value="${escapeHTML(existing?.name || '')}" required maxlength="100" /></label>
                        <label>Type
                            <select id="nf-type" ${isEdit ? 'disabled' : ''}>
                                <option value="private" ${existing?.type !== 'server' ? 'selected' : ''}>Private</option>
                                <option value="server" ${existing?.type === 'server' ? 'selected' : ''}>Server</option>
                            </select>
                        </label>
                    </div>
                    <div class="form-row">
                        <label>Hour (UTC 0-23)<input type="number" id="nf-hour" min="0" max="23" value="${existing?.hour ?? 12}" required /></label>
                        <label>Minute (0-59)<input type="number" id="nf-minute" min="0" max="59" value="${existing?.minute ?? 0}" required /></label>
                    </div>
                    <div class="form-row">
                        <label>Pattern (e.g. MON,WED,FRI)<input type="text" id="nf-pattern" value="${escapeHTML(existing?.pattern || '')}" placeholder="Daily if empty" /></label>
                        <label>Channel ID<input type="text" id="nf-channel" value="${escapeHTML(existing?.channel_id || '')}" placeholder="Discord channel ID" /></label>
                    </div>
                    ${isEdit ? `
                        <div class="form-row">
                            <label>Message Content<textarea id="nf-message" rows="3" maxlength="2000">${escapeHTML(existing?.message_content || '')}</textarea></label>
                        </div>
                        <div class="form-row">
                            <label>Embed Title<input type="text" id="nf-title" value="${escapeHTML(existing?.title || '')}" /></label>
                            <label>Embed Color<input type="text" id="nf-color" value="${escapeHTML(existing?.color || '')}" placeholder="#FF0000" /></label>
                        </div>
                        <div class="form-row">
                            <label>Embed Description<textarea id="nf-desc" rows="3">${escapeHTML(existing?.description || '')}</textarea></label>
                        </div>
                        <div class="form-row">
                            <label class="checkbox-label full-width"><input type="checkbox" id="nf-embed" ${existing?.embed_toggle ? 'checked' : ''} /> Use embed</label>
                        </div>
                    ` : ''}
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">${isEdit ? 'Save' : 'Create'}</button>
                        <button type="button" class="btn" id="nf-cancel">Cancel</button>
                    </div>
                </form>
            </div>
        `;

        document.getElementById('nf-cancel')?.addEventListener('click', () => {
            formArea.innerHTML = '';
        });

        document.getElementById('notif-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();

            const payload = {
                name: document.getElementById('nf-name').value.trim(),
                type: document.getElementById('nf-type').value,
                hour: parseInt(document.getElementById('nf-hour').value, 10),
                minute: parseInt(document.getElementById('nf-minute').value, 10),
                pattern: document.getElementById('nf-pattern').value.trim() || null,
                channelId: document.getElementById('nf-channel').value.trim() || null
            };

            if (isEdit) {
                payload.messageContent = document.getElementById('nf-message').value;
                payload.title = document.getElementById('nf-title').value.trim() || null;
                payload.color = document.getElementById('nf-color').value.trim() || null;
                payload.description = document.getElementById('nf-desc').value || null;
                payload.embedToggle = document.getElementById('nf-embed').checked ? 1 : 0;
            }

            try {
                if (isEdit) {
                    await apiFetch(`/api/notifications/${existing.id}`, { method: 'PUT', body: payload });
                } else {
                    await apiFetch('/api/notifications', { method: 'POST', body: payload });
                }
                formArea.innerHTML = '';
                renderNotifications(container);
            } catch (error) {
                showToast(error.message, 'error');
            }
        });
    }

    // ── Processes ────────────────────────────────────────────────────────
    let lastProcessIds = '';

    async function renderProcesses(container) {
        const processes = await apiFetch('/api/processes');
        if (!processes) return;

        const queuedByPriority = processes
            .filter(p => p.status === 'queued')
            .sort((a, b) => a.priority - b.priority || new Date(a.created_at) - new Date(b.created_at));
        const nextInQueueId = queuedByPriority.length > 0 ? queuedByPriority[0].id : null;

        const STATUS_ORDER = { active: 0, queued: 1, paused: 2, completed: 3, failed: 4 };
        const sorted = [...processes].sort((a, b) => {
            const orderA = STATUS_ORDER[a.status] ?? 5;
            const orderB = STATUS_ORDER[b.status] ?? 5;
            if (orderA !== orderB) return orderA - orderB;
            if (a.status === 'queued') {
                if (a.id === nextInQueueId) return -1;
                if (b.id === nextInQueueId) return 1;
                return a.priority - b.priority || new Date(a.created_at) - new Date(b.created_at);
            }
            return new Date(b.created_at) - new Date(a.created_at);
        });

        const STATUS_COLORS = { active: 'yellow', queued: '', completed: 'green', failed: 'red', paused: 'purple' };
        const STATUS_LABELS = { active: 'Active', queued: 'Queued', completed: 'Completed', failed: 'Failed', paused: 'Paused' };
        const RING_COLORS = { active: 'var(--yellow)', completed: 'var(--green)', failed: 'var(--red)', queued: 'var(--accent)', paused: 'var(--purple)' };

        const statusBadge = (process) => {
            if (process.status === 'queued' && process.id === nextInQueueId) {
                return `<span class="badge blue">Next in Queue</span>`;
            }
            return `<span class="badge ${STATUS_COLORS[process.status] || ''}">${STATUS_LABELS[process.status] || process.status}</span>`;
        };

        const progressCircle = (process) => {
            const pct = process.status === 'completed' ? 100 : (process.progressPercent || 0);
            const strokeColor = RING_COLORS[process.status] || 'var(--text-muted)';
            const offset = 100 - pct;
            const isActive = process.status === 'active';
            return `
                <div class="progress-ring ${isActive ? 'progress-ring--active' : ''}">
                    <svg viewBox="0 0 36 36">
                        <circle class="progress-ring__bg" cx="18" cy="18" r="15.9" />
                        <circle class="progress-ring__fill" cx="18" cy="18" r="15.9"
                            stroke="${strokeColor}" stroke-dasharray="100" stroke-dashoffset="${offset}"
                            transform="rotate(-90 18 18)" />
                    </svg>
                    <span class="progress-ring__text">${pct}%</span>
                </div>`;
        };

        const currentSignature = sorted.map(p => `${p.id}:${p.status}`).join(',');
        const needsFullRender = lastProcessIds !== currentSignature || !container.querySelector('.data-table');
        lastProcessIds = currentSignature;

        if (needsFullRender) {
            container.innerHTML = `
                <div class="page-header">
                    <h2>Processes</h2>
                    <div class="desc">${processes.length} total</div>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead><tr><th>Progress</th><th>ID</th><th>Action</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
                        <tbody>
                            ${sorted.map(p => `
                                <tr data-process-id="${p.id}">
                                    <td>${progressCircle(p)}</td>
                                    <td>${p.id}</td>
                                    <td>${escapeHTML(p.action || '')}</td>
                                    <td class="process-status">${statusBadge(p)}</td>
                                    <td>${formatTime(p.created_at)}</td>
                                    <td class="actions-cell">
                                        ${p.status !== 'active' ? `<button class="btn btn-danger btn-sm delete-process" data-id="${p.id}">Delete</button>` : ''}
                                    </td>
                                </tr>
                            `).join('')}
                            ${processes.length === 0 ? '<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">No processes</td></tr>' : ''}
                        </tbody>
                    </table>
                </div>
            `;

            container.querySelectorAll('.delete-process').forEach(btn => {
                btn.addEventListener('click', async () => {
                    if (!confirm(`Delete process #${btn.dataset.id}?`)) return;
                    try {
                        await apiFetch(`/api/processes/${btn.dataset.id}`, { method: 'DELETE' });
                        showToast('Process deleted', 'success');
                        lastProcessIds = '';
                        await renderProcesses(container);
                    } catch (error) {
                        showToast(error.message, 'error');
                    }
                });
            });
        } else {
            for (const p of sorted) {
                const row = container.querySelector(`tr[data-process-id="${p.id}"]`);
                if (!row) continue;

                const ring = row.querySelector('.progress-ring');
                if (ring) {
                    const pct = p.status === 'completed' ? 100 : (p.progressPercent || 0);
                    const fill = ring.querySelector('.progress-ring__fill');
                    const text = ring.querySelector('.progress-ring__text');
                    if (fill) fill.setAttribute('stroke-dashoffset', String(100 - pct));
                    if (text) text.textContent = `${pct}%`;
                }
            }
        }

        const hasActiveProcesses = processes.some(p => p.status === 'active' || p.status === 'queued');
        stopPolling();
        if (hasActiveProcesses) {
            const POLL_INTERVAL_MS = 5000;
            activePollingTimer = setInterval(() => {
                if (currentPage === 'processes') renderProcesses(container);
            }, POLL_INTERVAL_MS);
        }
    }

    // ── Gift Codes ───────────────────────────────────────────────────────
    async function renderGiftCodes(container) {
        const [codes, alliances] = await Promise.all([
            apiFetch('/api/giftcodes'),
            hasPerm(PERMS.ALLIANCE_MANAGEMENT, PERMS.FULL_ACCESS) ? apiFetch('/api/alliances') : Promise.resolve([])
        ]);
        if (!codes) return;

        const allianceOptions = (alliances || []).map(a =>
            `<option value="${a.id}">${escapeHTML(a.name || 'Alliance #' + a.priority)}</option>`
        ).join('');

        container.innerHTML = `
            <div class="page-header">
                <h2>Gift Codes</h2>
                <div class="desc">${codes.length} total</div>
            </div>
            <div class="action-bar">
                <form id="add-code-form" class="inline-form">
                    <input type="text" id="new-code" placeholder="Enter gift code" maxlength="50" required />
                    <label class="checkbox-label"><input type="checkbox" id="new-code-vip" /> VIP</label>
                    <button type="submit" class="btn btn-primary">Add Code</button>
                </form>
            </div>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>Code</th><th>Status</th><th>VIP</th><th>Source</th><th>Added</th><th>Actions</th></tr></thead>
                    <tbody>
                        ${codes.map(c => `
                            <tr data-code="${escapeHTML(c.gift_code)}">
                                <td style="font-family:var(--font-mono)">${escapeHTML(c.gift_code || '')}</td>
                                <td>
                                    <select class="status-select" data-code="${escapeHTML(c.gift_code)}">
                                        <option value="active" ${c.status === 'active' ? 'selected' : ''}>Active</option>
                                        <option value="expired" ${c.status === 'expired' ? 'selected' : ''}>Expired</option>
                                        <option value="invalid" ${c.status === 'invalid' ? 'selected' : ''}>Invalid</option>
                                    </select>
                                </td>
                                <td>
                                    <label class="checkbox-label">
                                        <input type="checkbox" class="vip-toggle" data-code="${escapeHTML(c.gift_code)}" ${c.is_vip ? 'checked' : ''} />
                                    </label>
                                </td>
                                <td>${escapeHTML(c.source || '-')}</td>
                                <td>${formatTime(c.date)}</td>
                                <td class="actions-cell">
                                    ${allianceOptions ? `
                                        <select class="redeem-alliance" data-code="${escapeHTML(c.gift_code)}" ${c.status !== 'active' ? 'disabled' : ''}>
                                            <option value="">Redeem for...</option>
                                            ${allianceOptions}
                                        </select>
                                    ` : ''}
                                    <button class="btn btn-danger btn-sm delete-code" data-code="${escapeHTML(c.gift_code)}">Delete</button>
                                </td>
                            </tr>
                        `).join('')}
                        ${codes.length === 0 ? '<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">No gift codes</td></tr>' : ''}
                    </tbody>
                </table>
            </div>
        `;

        document.getElementById('add-code-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const codeInput = document.getElementById('new-code');
            const vipInput = document.getElementById('new-code-vip');
            try {
                await apiFetch('/api/giftcodes', { method: 'POST', body: { code: codeInput.value, isVip: vipInput.checked } });
                renderGiftCodes(container);
            } catch (error) {
                showToast(error.message, 'error');
            }
        });

        container.querySelectorAll('.status-select').forEach(select => {
            select.addEventListener('change', async () => {
                try {
                    await apiFetch(`/api/giftcodes/${encodeURIComponent(select.dataset.code)}/status`, { method: 'PATCH', body: { status: select.value } });
                } catch (error) {
                    showToast(error.message, 'error');
                    renderGiftCodes(container);
                }
            });
        });

        container.querySelectorAll('.vip-toggle').forEach(checkbox => {
            checkbox.addEventListener('change', async () => {
                try {
                    await apiFetch(`/api/giftcodes/${encodeURIComponent(checkbox.dataset.code)}/vip`, { method: 'PATCH', body: { isVip: checkbox.checked } });
                } catch (error) {
                    showToast(error.message, 'error');
                    renderGiftCodes(container);
                }
            });
        });

        container.querySelectorAll('.delete-code').forEach(btn => {
            btn.addEventListener('click', async () => {
                if (!confirm(`Delete gift code "${btn.dataset.code}"?`)) return;
                try {
                    await apiFetch(`/api/giftcodes/${encodeURIComponent(btn.dataset.code)}`, { method: 'DELETE' });
                    renderGiftCodes(container);
                } catch (error) {
                    showToast(error.message, 'error');
                }
            });
        });

        container.querySelectorAll('.redeem-alliance').forEach(select => {
            select.addEventListener('change', async () => {
                if (!select.value) return;
                const allianceId = select.value;
                const code = select.dataset.code;
                if (!confirm(`Redeem "${code}" for the selected alliance?`)) {
                    select.value = '';
                    return;
                }
                try {
                    const result = await apiFetch(`/api/giftcodes/${encodeURIComponent(code)}/redeem`, { method: 'POST', body: { allianceId } });
                    if (result) showToast(`Redeem process started (ID: ${result.processId})`, 'success');
                } catch (error) {
                    showToast(error.message, 'error');
                }
                select.value = '';
            });
        });
    }

    // ── Logs ─────────────────────────────────────────────────────────────
    async function renderLogs(container) {
        const logs = await apiFetch('/api/logs?limit=50');
        if (!logs) return;

        container.innerHTML = `
            <div class="page-header">
                <h2>System Logs</h2>
                <div class="desc">Most recent 50 entries</div>
            </div>
            <div class="table-container">
                <table class="data-table">
                    <thead><tr><th>Time</th><th>Type</th><th>Action</th><th>Details</th></tr></thead>
                    <tbody>
                        ${logs.map(log => `
                            <tr>
                                <td style="white-space:nowrap">${formatTime(log.timestamp)}</td>
                                <td>${escapeHTML(log.action_type || '')}</td>
                                <td>${escapeHTML(truncate(log.action || '', 60))}</td>
                                <td style="font-size:11px;color:var(--text-muted)">${escapeHTML(truncate(log.extra_details || '', 80))}</td>
                            </tr>
                        `).join('')}
                        ${logs.length === 0 ? '<tr><td colspan="4" style="text-align:center;color:var(--text-muted)">No logs</td></tr>' : ''}
                    </tbody>
                </table>
            </div>
        `;
    }

    // ── Settings ────────────────────────────────────────────────────────
    async function renderSettings(container) {
        const settings = await apiFetch('/api/settings');
        if (!settings) return;

        let featureAccess = {};
        try {
            featureAccess = typeof settings.feature_access === 'string'
                ? JSON.parse(settings.feature_access)
                : (settings.feature_access || {});
        } catch { /* empty */ }

        const featureKeys = ['privateNotifications', 'calculators', 'inspect'];
        const featureRows = featureKeys.map(key => {
            const config = featureAccess[key] || {};
            const access = config.access || 'everyone';
            return `
                <tr>
                    <td>${escapeHTML(key)}</td>
                    <td>
                        <select class="feature-access-select" data-feature="${key}">
                            <option value="everyone" ${access === 'everyone' ? 'selected' : ''}>Everyone</option>
                            <option value="whitelist" ${access === 'whitelist' ? 'selected' : ''}>Whitelist</option>
                            <option value="disabled" ${access === 'disabled' ? 'selected' : ''}>Disabled</option>
                        </select>
                    </td>
                </tr>`;
        }).join('');

        container.innerHTML = `
            <div class="page-header">
                <h2>Settings</h2>
                <div class="desc">Global bot settings</div>
            </div>
            <div class="settings-section">
                <h3>General</h3>
                <div class="settings-grid">
                    <label class="toggle-row">
                        <span>Auto Delete</span>
                        <input type="checkbox" id="set-auto-delete" ${settings.auto_delete ? 'checked' : ''} />
                    </label>
                    <label class="toggle-row">
                        <span>Auto Update</span>
                        <input type="checkbox" id="set-auto-update" ${settings.auto_update ? 'checked' : ''} />
                    </label>
                    <label class="toggle-row">
                        <span>Notification Auto Clean</span>
                        <input type="checkbox" id="set-notif-clean" ${settings.notif_auto_clean ? 'checked' : ''} />
                    </label>
                    <label class="toggle-row">
                        <span>Clean Frequency (seconds)</span>
                        <input type="number" id="set-notif-freq" min="60" value="${settings.notif_auto_clean_freq || 3600}" style="width:100px" />
                    </label>
                </div>
                <button id="save-general-settings" class="btn btn-primary" style="margin-top:12px">Save General Settings</button>
            </div>
            <div class="settings-section">
                <h3>Feature Access</h3>
                <table class="data-table">
                    <thead><tr><th>Feature</th><th>Access Level</th></tr></thead>
                    <tbody>${featureRows}</tbody>
                </table>
                <button id="save-feature-access" class="btn btn-primary" style="margin-top:12px">Save Feature Access</button>
            </div>
        `;

        document.getElementById('save-general-settings')?.addEventListener('click', async () => {
            try {
                await apiFetch('/api/settings', {
                    method: 'PATCH',
                    body: {
                        autoDelete: document.getElementById('set-auto-delete').checked,
                        autoUpdate: document.getElementById('set-auto-update').checked,
                        notifAutoClean: document.getElementById('set-notif-clean').checked,
                        notifAutoCleanFreq: parseInt(document.getElementById('set-notif-freq').value, 10) || 3600
                    }
                });
                showToast('Settings saved', 'success');
            } catch (error) {
                showToast(error.message, 'error');
            }
        });

        document.getElementById('save-feature-access')?.addEventListener('click', async () => {
            const updatedAccess = { ...featureAccess };
            container.querySelectorAll('.feature-access-select').forEach(select => {
                const feature = select.dataset.feature;
                if (!updatedAccess[feature]) updatedAccess[feature] = {};
                updatedAccess[feature].access = select.value;
            });

            try {
                await apiFetch('/api/settings/feature-access', { method: 'PUT', body: { featureAccess: updatedAccess } });
                showToast('Feature access saved', 'success');
            } catch (error) {
                showToast(error.message, 'error');
            }
        });
    }

    // ── Utilities ────────────────────────────────────────────────────────
    function escapeHTML(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function truncate(str, maxLength) {
        return str.length > maxLength ? str.slice(0, maxLength) + '...' : str;
    }

    function formatTime(isoStr) {
        if (!isoStr) return '-';
        try {
            const date = new Date(isoStr);
            if (isNaN(date.getTime())) return isoStr;
            return date.toLocaleString(undefined, {
                month: 'short', day: 'numeric',
                hour: '2-digit', minute: '2-digit'
            });
        } catch {
            return isoStr;
        }
    }

    function formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        parts.push(`${hours}h`);
        parts.push(`${minutes}m`);
        return parts.join(' ');
    }

    // ── Start ────────────────────────────────────────────────────────────
    init();
})();
