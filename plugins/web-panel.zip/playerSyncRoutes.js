const path = require('path');

function getOptionalPlayerSync() {
    const bridge = path.resolve(__dirname, '../../src/functions/Players/playerSyncIntegration');
    try {
        return require(bridge).getPlayerSyncIntegration();
    } catch (error) {
        // An older core can still serve the panel; only the optional integration is unavailable.
        if (error.code === 'MODULE_NOT_FOUND' && error.message.includes(bridge)) return null;
        return null;
    }
}

function registerPlayerSyncRoutes(
    router,
    { requireAuth, requirePermission, permissions: PERMISSIONS, getIntegration = getOptionalPlayerSync }
) {
    const permitted = requirePermission(
        PERMISSIONS.ALLIANCE_MANAGEMENT,
        PERMISSIONS.PLAYER_MANAGEMENT,
        PERMISSIONS.FULL_ACCESS
    );
    const route = (method, suffix, handler, { status = false } = {}) => {
        router[method](`/api/player-sync${suffix}`, requireAuth, permitted, async (req, res) => {
            const service = getIntegration();
            if (!service)
                return status
                    ? res.json({ installed: false })
                    : res.status(503).json({ code: 'unavailable', error: 'Player Sync is not installed or loaded.' });
            try {
                const result = await handler(service, { userId: req.userId, gameType: req.panelGameType }, req);
                res.json(result);
            } catch (error) {
                const codes = {
                    permission: 403,
                    game: 400,
                    invalid: 400,
                    mapping: 400,
                    channel: 400,
                    storage: 500,
                    auth: 400,
                    response: 502,
                    network: 502,
                    notFound: 404,
                    changed: 409,
                    duplicate: 409,
                    busy: 409,
                    expired: 410,
                    throttled: 429,
                    paused: 409,
                    unconfigured: 409,
                    unavailable: 503
                };
                const code = Object.hasOwn(codes, error?.code) ? error.code : 'response';
                // Unknown exceptions must never serialize provider responses, headers or secret values.
                const message =
                    error?.name === 'SyncError' && error.message
                        ? error.message
                        : 'Player Sync could not complete this action.';
                res.status(codes[code] || 500).json({
                    code,
                    error: message,
                    retryAt: error?.name === 'SyncError' ? error.retryAt : null
                });
            }
        });
    };
    route('get', '/status', (s, c) => s.status(c), { status: true });
    route('get', '/profile', (s, c) => ({ profile: s.exportProfile(c) }));
    route('put', '/profile', (s, c, r) => s.saveProfile(c, r.body?.profile ?? r.body));
    route('post', '/example', (s, c) => s.useExample(c));
    route('put', '/key', (s, c, r) => s.saveKey(c, r.body?.key));
    route('delete', '/key', (s, c) => s.saveKey(c, ''));
    route('put', '/settings', (s, c, r) => s.setEnabled(c, r.body?.enabled));
    route('post', '/test', (s, c, r) => s.test(c, r.body?.fid));
    route('put', '/alliances/:id/schedule', (s, c, r) => s.setSchedule(c, Number(r.params.id), r.body || {}));
    route('get', '/runs', (s, c) => ({ runs: s.status(c).runs }));
    route('post', '/runs', (s, c, r) => s.syncNow(c, r.body?.allianceIds ?? null));
    route('delete', '/runs/:id', (s, c, r) => s.cancelRun(c, r.params.id));
    route('get', '/players/:fid', (s, c, r) => s.details(c, r.params.fid));
    route('post', '/import/preview', (s, c, r) => s.previewImport(c, r.body || {}));
    route('post', '/import/confirm', (s, c, r) => s.confirmImport(c, r.body?.token));
    route('delete', '/import/:token', (s, c, r) => s.cancelImport(c, r.params.token));
}

function serializePlayer(player) {
    return {
        fid: player.fid,
        nickname: player.nickname,
        state: player.state,
        state_override: player.state_override,
        alliance_id: player.alliance_id,
        game_type: player.game_type,
        image_url: player.image_url ?? null,
        furnace_level: player.furnace_level ?? null,
        power: player.power ?? null,
        profile_synced_at: player.profile_synced_at ?? null
    };
}
module.exports = { registerPlayerSyncRoutes, getOptionalPlayerSync, serializePlayer };
