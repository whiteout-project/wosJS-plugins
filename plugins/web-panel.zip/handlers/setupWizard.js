/**
 * Web Panel Setup Wizard Handler
 *
 * Multi-step setup flow for the web panel:
 * Step 1: "Set Up" button → modal to enter bot name
 * Step 2: Name validated → register → show OAuth2 guide with "Continue" button
 * Step 3: "Continue" button → modal to enter Client Secret
 * Step 4: Client Secret saved → show final permanent URL
 */

const {
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags
} = require('discord.js');

const centralProxy = require('../centralProxy');
const { setClientSecret } = require('../auth');
const { getRunningPort, getPublicAddress, getTunnelUrl } = require('../server');

module.exports = function (client) {
    async function listener(interaction) {
        // ── Button: Start Setup ──────────────────────────────────────────
        if (interaction.isButton() && interaction.customId.startsWith('wp_setup_start_')) {
            return handleSetupStart(interaction);
        }

        // ── Modal: Bot Name Submitted ────────────────────────────────────
        if (interaction.isModalSubmit() && interaction.customId.startsWith('wp_setup_name_modal_')) {
            return handleNameSubmit(interaction, client);
        }

        // ── Button: Continue to Client Secret ────────────────────────────
        if (interaction.isButton() && interaction.customId.startsWith('wp_setup_secret_')) {
            return handleSecretButton(interaction);
        }

        // ── Modal: Client Secret Submitted ───────────────────────────────
        if (interaction.isModalSubmit() && interaction.customId.startsWith('wp_setup_secret_modal_')) {
            return handleSecretSubmit(interaction, client);
        }
    }

    client.on('interactionCreate', listener);

    return () => {
        client.off('interactionCreate', listener);
    };
};

// ── Step 1: Show name modal ──────────────────────────────────────────────────

async function handleSetupStart(interaction) {
    const expectedUserId = interaction.customId.split('_').pop();
    if (interaction.user.id !== expectedUserId) {
        return await interaction.reply({ content: 'This button is not for you.', flags: MessageFlags.Ephemeral });
    }

    const modal = new ModalBuilder()
        .setCustomId(`wp_setup_name_modal_${interaction.user.id}`)
        .setTitle('Choose Your Panel Name')
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId('bot_name')
                    .setLabel('Panel name (shown in the URL)')
                    .setPlaceholder('e.g. my-alliance, cool-bot-123')
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(3)
                    .setMaxLength(30)
                    .setRequired(true)
            )
        );

    await interaction.showModal(modal);
}

// ── Step 2: Validate name, register, show OAuth2 guide ───────────────────────

async function handleNameSubmit(interaction, client) {
    const expectedUserId = interaction.customId.split('_').pop();
    if (interaction.user.id !== expectedUserId) {
        return await interaction.reply({ content: 'This is not your setup.', flags: MessageFlags.Ephemeral });
    }

    const rawName = interaction.fields.getTextInputValue('bot_name');
    const botName = rawName.toLowerCase().trim().replace(/\s+/g, '-');

    if (!centralProxy.isValidBotName(botName)) {
        return await interaction.reply({
            content: 'Invalid name. Use 3-30 lowercase letters, numbers, and hyphens. Must start and end with a letter or number.\n\nExamples: `my-alliance`, `cool-bot-123`, `s999`',
            flags: MessageFlags.Ephemeral
        });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    // Check availability
    const availability = await centralProxy.checkAvailability(botName);
    if (!availability.available) {
        const reason = availability.error || 'This name is already taken.';
        return interaction.editReply({
            content: `**${botName}** is not available: ${reason}\n\nTry a different name by clicking "Set Up" again.`
        });
    }

    // Register with central proxy
    const tunnel = getTunnelUrl();
    const port = getRunningPort();
    const botUrl = tunnel || `http://${getPublicAddress() || 'localhost'}:${port}`;

    const result = await centralProxy.register(botName, botUrl);
    if (!result.ok) {
        return interaction.editReply({
            content: `Registration failed: ${result.error}\n\nTry again or pick a different name.`
        });
    }

    centralProxy.startHeartbeat();

    // Show OAuth2 setup guide
    const clientId = client.application?.id || client.user?.id || 'YOUR_BOT_CLIENT_ID';
    const callbackUrl = `${result.publicUrl}/auth/callback`;

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`wp_setup_secret_${interaction.user.id}`)
            .setLabel('Continue')
            .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
            .setLabel('Open Developer Portal')
            .setStyle(ButtonStyle.Link)
            .setURL(`https://discord.com/developers/applications/${clientId}/oauth2`)
    );

    await interaction.editReply({
        content: [
            `✅ **Registered as \`${botName}\`**`,
            `Your panel URL: ${result.publicUrl}`,
            '',
            '**Now set up Discord login (one-time):**',
            '',
            '1️⃣ Open your **Discord Developer Portal** (button below)',
            '2️⃣ Go to **OAuth2** → **Redirects**',
            `3️⃣ Click **Add Redirect** and paste this URL:`,
            `\`\`\`${callbackUrl}\`\`\``,
            '4️⃣ Click **Save Changes**',
            `5️⃣ Copy your **Client Secret** (under OAuth2 → General → Client Secret → "Reset Secret" if you don't have one)`,
            '',
            'Click **Continue** when you have the Client Secret ready.'
        ].join('\n'),
        components: [row]
    });
}

// ── Step 3: Show client secret modal ─────────────────────────────────────────

async function handleSecretButton(interaction) {
    const expectedUserId = interaction.customId.split('_').pop();
    if (interaction.user.id !== expectedUserId) {
        return await interaction.reply({ content: 'This button is not for you.', flags: MessageFlags.Ephemeral });
    }

    const modal = new ModalBuilder()
        .setCustomId(`wp_setup_secret_modal_${interaction.user.id}`)
        .setTitle('Enter Client Secret')
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId('client_secret')
                    .setLabel('Client Secret from Developer Portal')
                    .setPlaceholder('Paste your Client Secret here')
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(10)
                    .setMaxLength(100)
                    .setRequired(true)
            )
        );

    await interaction.showModal(modal);
}

// ── Step 4: Save secret, show final URL ──────────────────────────────────────

async function handleSecretSubmit(interaction, client) {
    const expectedUserId = interaction.customId.split('_').pop();
    if (interaction.user.id !== expectedUserId) {
        return await interaction.reply({ content: 'This is not your setup.', flags: MessageFlags.Ephemeral });
    }

    const secret = interaction.fields.getTextInputValue('client_secret').trim();
    if (!secret) {
        return await interaction.reply({ content: '❌ Client Secret cannot be empty.', flags: MessageFlags.Ephemeral });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    // Save the client secret
    setClientSecret(secret);

    const publicUrl = centralProxy.getPublicUrl();
    const loginUrl = `${publicUrl}/auth/login`;

    await interaction.editReply({
        content: [
            '✅ **Setup complete!**',
            `**Your permanent panel URL:**`,
            `[Click here to open](${loginUrl})`,
        ].join('\n')
    });
}
