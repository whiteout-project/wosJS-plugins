/**
 * Web Panel Setup Wizard Handler
 *
 * Two-step setup flow for WebSocket (WS) mode:
 * Step 1: "Set Up" button → modal to enter panel name
 * Step 2: Name validated → claim on central hub → start WS connection → show panel URL
 *
 * No OAuth2 client secret is required — the central hub handles Discord login.
 */

const {
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    MessageFlags
} = require('discord.js');

const centralProxy = require('../centralProxy');
const wsClient = require('../wsClient');
const { getRunningPort, issueJwtForDiscordUser } = require('../server');

module.exports = function (client) {
    async function listener(interaction) {
        // ── Button: Start Setup ──────────────────────────────────────────
        if (interaction.isButton() && interaction.customId.startsWith('wp_setup_start_')) {
            return handleSetupStart(interaction);
        }

        // ── Button: Upgrade to WS Hub ────────────────────────────────────
        if (interaction.isButton() && interaction.customId.startsWith('wp_upgrade_ws_')) {
            return handleUpgradeToWs(interaction);
        }

        // ── Modal: Panel Name Submitted ──────────────────────────────────
        if (interaction.isModalSubmit() && interaction.customId.startsWith('wp_setup_name_modal_')) {
            return handleNameSubmit(interaction);
        }
    }

    client.on('interactionCreate', listener);

    return () => {
        client.off('interactionCreate', listener);
    };
};

// ── Step 1: Show name modal ──────────────────────────────────────────────────

async function handleSetupStart(interaction) {
    const expectedUserId = interaction.customId.split('_').pop();
    if (interaction.user.id !== expectedUserId) {
        return await interaction.reply({ content: 'This button is not for you.', flags: MessageFlags.Ephemeral });
    }

    const modal = new ModalBuilder()
        .setCustomId(`wp_setup_name_modal_${interaction.user.id}`)
        .setTitle('Choose Your Panel Name')
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId('bot_name')
                    .setLabel('Panel name (shown in the URL)')
                    .setPlaceholder('e.g. my-alliance, cool-bot-123')
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(3)
                    .setMaxLength(30)
                    .setRequired(true)
            )
        );

    await interaction.showModal(modal);
}

// ── Step 2: Validate name, claim on hub, start WS, show panel URL ─────────────

async function handleNameSubmit(interaction) {
    const expectedUserId = interaction.customId.split('_').pop();
    if (interaction.user.id !== expectedUserId) {
        return await interaction.reply({ content: 'This is not your setup.', flags: MessageFlags.Ephemeral });
    }

    const rawName = interaction.fields.getTextInputValue('bot_name');
    const botName = rawName.toLowerCase().trim().replace(/\s+/g, '-');

    if (!centralProxy.isValidBotName(botName)) {
        return await interaction.reply({
            content: 'Invalid name. Use 3-30 lowercase letters, numbers, and hyphens. Must start and end with a letter or number.\n\nExamples: `my-alliance`, `cool-bot-123`, `s999`',
            flags: MessageFlags.Ephemeral
        });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    // Check name availability before claiming
    const availability = await centralProxy.checkAvailability(botName);
    if (!availability.available) {
        const reason = availability.error || 'This name is already taken.';
        return interaction.editReply({
            content: `**${botName}** is not available: ${reason}\n\nTry a different name by clicking "Set Up" again.`
        });
    }

    // Claim the name on the central hub (no URL needed — bot connects via WS)
    const result = await centralProxy.claimName(botName);
    if (!result.ok) {
        return interaction.editReply({
            content: `Could not claim **${botName}**: ${result.error}\n\nTry again or pick a different name.`
        });
    }

    // Start the WebSocket connection immediately
    const port = getRunningPort();
    if (port) {
        wsClient.connect(port, issueJwtForDiscordUser);
    }

    await interaction.editReply({
        content: [
            `✅ **Setup complete!**`,
            ``,
            `**Your panel URL:**`,
            result.panelUrl
        ].join('\n')
    });
}

// ── Upgrade: Migrate HTTP proxy bot to WS hub mode ───────────────────────────

async function handleUpgradeToWs(interaction) {
    const expectedUserId = interaction.customId.split('_').pop();
    if (interaction.user.id !== expectedUserId) {
        return await interaction.reply({ content: 'This button is not for you.', flags: MessageFlags.Ephemeral });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const result = await centralProxy.upgradeToWsHub();
    if (!result.ok) {
        return interaction.editReply({
            content: `❌ Upgrade failed: ${result.error}\n\nTry again or contact support.`
        });
    }

    // Start the WebSocket connection with the new botToken
    const port = getRunningPort();
    if (port) {
        wsClient.connect(port, issueJwtForDiscordUser);
    }

    await interaction.editReply({
        content: [
            `✅ **Upgraded to WS Hub mode!**`,
            ``,
            `**Your panel URL:**`,
            result.panelUrl,
            ``,
            `-# Discord login is now handled by wosland.com — your bot's client secret is no longer needed.`
        ].join('\n')
    });
}
