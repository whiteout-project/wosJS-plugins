const { startServer, stopServer, getTunnelUrl } = require('../server');
const centralProxy = require('../centralProxy');
const { isOAuth2Configured } = require('../auth');
const { getSelfHostedPublicUrl } = require('../oauthUrl');

module.exports = function (client) {
    startServer(client).then(() => {
        if (isOAuth2Configured() && getSelfHostedPublicUrl()) return;
        if (centralProxy.isConfigured()) {
            // In WS hub mode, startServer() already owns startup registration/connect flow.
            if (centralProxy.isWsConfigured()) {
                return;
            }

            if (!centralProxy.isLegacyModeEnabled() && centralProxy.hasStoredLegacyConfig()) {
                console.log('[Web Panel] Stored legacy registration detected; skipping legacy re-registration while WebSocket migration/setup takes over.');
                return;
            }

            const botUrl = getTunnelUrl();
            if (!botUrl) {
                console.log('[Web Panel] Skipping WOS Land legacy re-registration because no public tunnel URL is available.');
                return;
            }

            centralProxy.reRegister(botUrl).then((result) => {
                if (result.ok) centralProxy.startHeartbeat();
            }).catch((error) => {
                console.error('[Web Panel] Failed to register with central proxy:', error.message);
            });
        }
    }).catch((error) => {
        console.error('[Web Panel] Failed to start server:', error.message);
    });

    return () => {
        centralProxy.stopHeartbeat();
        stopServer().catch((error) => {
            console.error('[Web Panel] Error stopping server:', error.message);
        });
    };
};
