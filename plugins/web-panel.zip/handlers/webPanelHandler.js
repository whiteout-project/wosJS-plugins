const { startServer, stopServer, getTunnelUrl, getPublicAddress, getRunningPort } = require('../server');
const centralProxy = require('../centralProxy');

module.exports = function (client) {
    startServer(client).then(() => {
        if (centralProxy.isConfigured()) {
            const botUrl = getTunnelUrl() || `http://${getPublicAddress()}:${getRunningPort()}`;
            centralProxy.reRegister(botUrl).then((result) => {
                if (result.ok) centralProxy.startHeartbeat();
            }).catch((error) => {
                console.error('[Web Panel] Failed to register with central proxy:', error.message);
            });
        }
    }).catch((error) => {
        console.error('[Web Panel] Failed to start server:', error.message);
    });

    return () => {
        centralProxy.stopHeartbeat();
        stopServer().catch((error) => {
            console.error('[Web Panel] Error stopping server:', error.message);
        });
    };
};
