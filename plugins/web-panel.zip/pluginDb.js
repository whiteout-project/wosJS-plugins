/**
 * Web Panel Plugin Database
 *
 * Lightweight key-value store using SQLite for persisting plugin config.
 * Database file lives in the plugin directory alongside this module.
 */

const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, 'webpanel.db');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
    CREATE TABLE IF NOT EXISTS config (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )
`);

const getStmt = db.prepare('SELECT value FROM config WHERE key = ?');
const setStmt = db.prepare('INSERT INTO config (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
const delStmt = db.prepare('DELETE FROM config WHERE key = ?');

/**
 * Get a config value.
 * @param {string} key
 * @returns {string|null}
 */
function get(key) {
    const row = getStmt.get(key);
    return row ? row.value : null;
}

/**
 * Set a config value (upsert).
 * @param {string} key
 * @param {string} value
 */
function set(key, value) {
    setStmt.run(key, value);
}

/**
 * Delete a config key.
 * @param {string} key
 */
function remove(key) {
    delStmt.run(key);
}

/**
 * Get a config value parsed as JSON, or null.
 * @param {string} key
 * @returns {*|null}
 */
function getJSON(key) {
    const raw = get(key);
    if (raw === null) return null;
    try { return JSON.parse(raw); } catch { return null; }
}

/**
 * Set a config value as JSON.
 * @param {string} key
 * @param {*} value
 */
function setJSON(key, value) {
    set(key, JSON.stringify(value));
}

/**
 * Flush WAL to the main database file and close the connection.
 * Call this during graceful shutdown to prevent leftover .db-wal / .db-shm files.
 */
function close() {
    if (db.open) {
        db.pragma('wal_checkpoint(TRUNCATE)');
        db.close();
    }
}

module.exports = { get, set, remove, getJSON, setJSON, close };
