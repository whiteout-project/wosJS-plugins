/**
 * WebSocket Client for WOS Land Central Hub
 *
 * Connects the bot outbound to wss://wosland.com/bot-ws, eliminating the need
 * for an inbound public tunnel.  The central server relays HTTP requests from
 * browsers to the bot over this WebSocket, and the bot replies on the same channel.
 *
 * Two message types are handled:
 *   - 'request'   → relay HTTP request to the bot's local Express server
 *   - 'issue_jwt' → call the JWT issuer callback and return the signed token
 */

const WebSocket = require('ws');
const centralProxy = require('./centralProxy');

/** Reconnect delays in ms (doubles up to the last entry). */
const RECONNECT_DELAYS_MS = [5_000, 15_000, 30_000, 60_000];
const LOCAL_REQUEST_TIMEOUT_MS = 14_000;
const APP_HEARTBEAT_INTERVAL_MS = 25_000;

let _ws = null;
let _isAuthenticated = false;
let _localPort = null;
let _jwtIssuerFn = null;
let _shouldReconnect = false;
let _reconnectAttempt = 0;
let _reconnectTimer = null;
let _heartbeatTimer = null;
let _localRelayOrigin = null;
const _stateListeners = new Set();

function _isBinaryContentType(contentType) {
    if (!contentType) return false;
    const baseType = contentType.split(';')[0].trim().toLowerCase();

    if (baseType.startsWith('text/')) return false;

    return ![
        'application/json',
        'application/javascript',
        'application/xml',
        'application/xhtml+xml',
        'image/svg+xml'
    ].includes(baseType);
}

function _buildLocalRelayUrls(path, query) {
    const suffix = `${path}${query ? `?${query}` : ''}`;
    const origins = [];

    if (_localRelayOrigin) {
        origins.push(_localRelayOrigin);
    }

    for (const origin of [
        `http://127.0.0.1:${_localPort}`,
        `http://localhost:${_localPort}`
    ]) {
        if (!origins.includes(origin)) {
            origins.push(origin);
        }
    }

    return origins.map(origin => `${origin}${suffix}`);
}

async function _fetchLocalRelay(urls, fetchOptions) {
    let lastError = null;

    for (const url of urls) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), LOCAL_REQUEST_TIMEOUT_MS);

        try {
            const response = await fetch(url, {
                ...fetchOptions,
                signal: controller.signal
            });

            clearTimeout(timeoutId);
            return { response, url };
        } catch (error) {
            clearTimeout(timeoutId);
            lastError = error;
        }
    }

    throw lastError || new Error('Local relay failed');
}

async function _probeLocalRelayOrigin() {
    if (!_localPort) return;

    const probeUrls = _buildLocalRelayUrls('/api/botinfo', '');
    const fetchOptions = {
        method: 'GET',
        headers: {
            accept: 'application/json',
            host: `127.0.0.1:${_localPort}`
        }
    };

    try {
        const { response, url } = await _fetchLocalRelay(probeUrls, fetchOptions);
        if (response.ok) {
            _localRelayOrigin = new URL(url).origin;
            console.log(`[WS Client] Local relay origin ready at ${_localRelayOrigin}`);
        }
    } catch (error) {
        console.warn(`[WS Client] Local relay probe failed on port ${_localPort}:`, error.message);
    }
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Start the WebSocket connection to the central hub.
 * Should be called after the local Express server is listening.
 *
 * @param {number} port - The local Express server port
 * @param {Function} jwtIssuerFn - Called with (discordId, username, avatar) →
 *   returns { ok: boolean, jwt?: string, error?: string, statusCode?: number }
 */
function connect(port, jwtIssuerFn) {
    const hasActiveSocket =
        _ws &&
        (_ws.readyState === WebSocket.OPEN || _ws.readyState === WebSocket.CONNECTING);
    const configChanged = _localPort !== port || _jwtIssuerFn !== jwtIssuerFn;

    _clearReconnectTimer();
    _localPort = port;
    _jwtIssuerFn = jwtIssuerFn;
    _shouldReconnect = true;
    _reconnectAttempt = 0;
    _localRelayOrigin = null;
    _probeLocalRelayOrigin().catch(() => {});

    if (hasActiveSocket && !configChanged) {
        return;
    }

    if (hasActiveSocket) {
        _clearHeartbeatTimer();
        _isAuthenticated = false;
        _ws.removeAllListeners();
        try {
            _ws.close();
        } catch {
            // Best effort; a fresh socket will be opened below.
        }
        _ws = null;
    }

    _openConnection();
}

/**
 * Gracefully close the WebSocket connection and stop auto-reconnect.
 */
function disconnect() {
    _shouldReconnect = false;
    _clearReconnectTimer();
    _clearHeartbeatTimer();

    if (_ws) {
        _ws.removeAllListeners();
        _ws.close();
        _ws = null;
    }

    _isAuthenticated = false;
    _localRelayOrigin = null;
    _emitStateChange('stopped');
}

/**
 * Returns true when the WebSocket is open and authenticated.
 */
function isConnected() {
    return _isAuthenticated && _ws?.readyState === WebSocket.OPEN;
}

function onStateChange(listener) {
    if (typeof listener !== 'function') return () => {};
    _stateListeners.add(listener);
    return () => {
        _stateListeners.delete(listener);
    };
}

function _emitStateChange(state) {
    for (const listener of _stateListeners) {
        try {
            listener(state);
        } catch (error) {
            console.error('[WS Client] State listener failed:', error.message);
        }
    }
}

// ── Internal: Connection Management ──────────────────────────────────────────

function _openConnection() {
    if (!centralProxy.isConfigured()) return;
    if (_ws && (_ws.readyState === WebSocket.OPEN || _ws.readyState === WebSocket.CONNECTING)) return;

    const botName = centralProxy.getBotName();
    const apiKey = centralProxy.getApiKey();
    if (!botName || !apiKey) return;

    const wsUrl = centralProxy.CENTRAL_PROXY_URL.replace(/^http/, 'ws') + '/bot-ws';
    _clearReconnectTimer();
    _emitStateChange('connecting');

    _ws = new WebSocket(wsUrl);

    _ws.on('open', () => {
        console.log('[WS Client] Connected to central hub, authenticating...');
        _ws.send(JSON.stringify({ type: 'auth', botName, apiKey }));
    });

    _ws.on('message', async (data) => {
        let message;
        try {
            message = JSON.parse(data.toString());
        } catch {
            return;
        }
        await _handleMessage(message);
    });

    _ws.on('close', (code, reason) => {
        _isAuthenticated = false;
        _clearHeartbeatTimer();
        const reasonText = reason?.toString() || 'no reason';
        console.log(`[WS Client] Disconnected (code ${code}: ${reasonText})`);
        _emitStateChange('disconnected');
        _scheduleReconnect();
    });

    _ws.on('error', (err) => {
        // 'close' will fire after 'error' — reconnect is handled there
        console.error('[WS Client] WebSocket error:', err.message);
    });
}

function _scheduleReconnect() {
    if (!_shouldReconnect) return;

    const delay = RECONNECT_DELAYS_MS[Math.min(_reconnectAttempt, RECONNECT_DELAYS_MS.length - 1)];
    _reconnectAttempt++;

    console.log(`[WS Client] Reconnecting in ${delay / 1000}s (attempt ${_reconnectAttempt})...`);

    _reconnectTimer = setTimeout(() => {
        _reconnectTimer = null;
        if (_shouldReconnect) _openConnection();
    }, delay);
}

function _clearReconnectTimer() {
    if (_reconnectTimer) {
        clearTimeout(_reconnectTimer);
        _reconnectTimer = null;
    }
}

function _startHeartbeatTimer() {
    _clearHeartbeatTimer();
    _heartbeatTimer = setInterval(() => {
        if (!_ws || _ws.readyState !== WebSocket.OPEN || !_isAuthenticated) return;
        try {
            _ws.send(JSON.stringify({ type: 'heartbeat' }));
        } catch {
            // close handler manages reconnect
        }
    }, APP_HEARTBEAT_INTERVAL_MS);
}

function _clearHeartbeatTimer() {
    if (_heartbeatTimer) {
        clearInterval(_heartbeatTimer);
        _heartbeatTimer = null;
    }
}

// ── Internal: Message Handlers ────────────────────────────────────────────────

async function _handleMessage(message) {
    const { type } = message;

    if (type === 'auth_ok') {
        _isAuthenticated = true;
        _reconnectAttempt = 0;
        _startHeartbeatTimer();
        console.log(`[WS Client] Authenticated as "${message.botName}"`);
        _emitStateChange('authenticated');
        return;
    }

    if (type === 'request') {
        await _handleRelayRequest(message);
        return;
    }

    if (type === 'issue_jwt') {
        await _handleJwtIssue(message);
        return;
    }
}

/**
 * Relay an HTTP request from the central server to the local Express server,
 * then send the response back over the WebSocket.
 */
async function _handleRelayRequest(message) {
    const { reqId, method, path, query, headers, body } = message;

    if (!_localPort) {
        _sendResponse(reqId, 503, { 'content-type': 'application/json' }, JSON.stringify({ error: 'Local server not ready' }));
        return;
    }

    try {
        const localRelayUrls = _buildLocalRelayUrls(path, query);

        const requestHeaders = { ...headers };
        // Ensure CSRF check passes: the forwarded host header identifies the public origin
        if (!requestHeaders['x-forwarded-host']) {
            requestHeaders['x-forwarded-host'] = headers['host'] || '';
        }
        // Use the public host as 'host' so Express sees a consistent value
        requestHeaders['host'] = requestHeaders['x-forwarded-host'] || `localhost:${_localPort}`;

        const fetchOptions = { method, headers: requestHeaders };

        if (body !== null && body !== undefined && !['GET', 'HEAD'].includes(method)) {
            const bodyString = typeof body === 'string' ? body : JSON.stringify(body);
            fetchOptions.body = bodyString;
            if (!requestHeaders['content-type']) {
                requestHeaders['content-type'] = 'application/json';
            }
        }

        const { response, url } = await _fetchLocalRelay(localRelayUrls, fetchOptions);
        _localRelayOrigin = new URL(url).origin;

        const responseHeaders = {};
        for (const [key, value] of response.headers.entries()) {
            const lower = key.toLowerCase();
            if (!['transfer-encoding', 'connection', 'keep-alive'].includes(lower)) {
                responseHeaders[lower] = value;
            }
        }

        const contentType = responseHeaders['content-type'] || '';
        if (_isBinaryContentType(contentType)) {
            const responseBuffer = Buffer.from(await response.arrayBuffer());
            _sendResponse(reqId, response.status, responseHeaders, responseBuffer.toString('base64'), 'base64');
            return;
        }

        const responseBody = await response.text();
        _sendResponse(reqId, response.status, responseHeaders, responseBody, 'utf8');
    } catch (err) {
        console.error(`[WS Client] Local relay request failed (${method} ${path}) on port ${_localPort}:`, err.message);
        _sendResponse(reqId, 502, { 'content-type': 'application/json' }, JSON.stringify({ error: 'Local request failed' }));
    }
}

/**
 * Handle a JWT issuance request from the central server.
 * Calls the registered issuer function and returns the result.
 */
async function _handleJwtIssue(message) {
    const { reqId, discordId, username, avatar } = message;

    if (!_jwtIssuerFn) {
        _sendJwtResult(reqId, null, 'JWT issuer not available', 503);
        return;
    }

    try {
        const result = _jwtIssuerFn(discordId, username, avatar);
        if (result.ok && result.jwt) {
            _sendJwtResult(reqId, result.jwt, null, 200);
        } else {
            _sendJwtResult(reqId, null, result.error || 'Access denied', result.statusCode || 403);
        }
    } catch (err) {
        console.error('[WS Client] JWT issuance failed:', err.message);
        _sendJwtResult(reqId, null, 'Internal error', 500);
    }
}

// ── Internal: WS Send Helpers ─────────────────────────────────────────────────

function _sendResponse(reqId, status, headers, body, bodyEncoding = 'utf8') {
    if (!_ws || _ws.readyState !== WebSocket.OPEN) return;
    _ws.send(JSON.stringify({ type: 'response', reqId, status, headers, body, bodyEncoding }));
}

function _sendJwtResult(reqId, jwt, error, statusCode) {
    if (!_ws || _ws.readyState !== WebSocket.OPEN) return;
    _ws.send(JSON.stringify({ type: 'jwt_result', reqId, jwt, error, statusCode }));
}

module.exports = { connect, disconnect, isConnected, onStateChange };
