function getSelfHostedPublicUrl() {
    if (!process.env.WEB_PANEL_CLIENT_SECRET?.trim()) return null;
    const raw = process.env.PUBLIC_URL?.trim();
    if (!raw) return null;

    const url = new URL(raw);
    const isLocalHttp = url.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
    if ((!isLocalHttp && url.protocol !== 'https:') || url.username || url.password || url.search || url.hash) {
        throw new Error('PUBLIC_URL must be an HTTPS URL (or local HTTP URL) without credentials, a query, or a fragment');
    }
    return url.href.replace(/\/+$/, '');
}

function getOAuthRedirectUri(req, basePath, hubPublicUrl) {
    const publicUrl = getSelfHostedPublicUrl() || hubPublicUrl;
    return publicUrl
        ? `${publicUrl}/auth/callback`
        : `http://${req.headers.host}${basePath}/auth/callback`;
}

module.exports = { getSelfHostedPublicUrl, getOAuthRedirectUri };
