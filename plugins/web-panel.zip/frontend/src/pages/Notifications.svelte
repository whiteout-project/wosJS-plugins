﻿<script>
    import { onMount, onDestroy, tick as domReady } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { formatRelativeTime, showToast } from '../lib/utils.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import Select from '../components/ui/Select.svelte';

    /** Moves the node to document.body so it escapes stacking contexts */
    function portal(node) {
        document.body.appendChild(node);
        return { destroy() { node.remove(); } };
    }

    let notifications = $state([]);
    let isLoading = $state(true);
    let showForm = $state(false);
    let editingNotification = $state(null);

    // Selection
    let selectedServer = $state(null);
    let statusFilter = $state('all');
    let showMobileDetail = $state(false);

    // Delete confirmation
    let confirmDeleteOpen = $state(false);
    let deleteTarget = $state(null);
    let isSubmitting = $state(false);
    let isFormLoading = $state(false);

    // Mobile detail popup
    let mobileDetailNotif = $state(null);
    let showMobileDetailModal = $state(false);

    // Form fields
    let formName = $state('');
    let formType = $state('private');
    let formYear = $state('2025');
    let formMonth = $state('01');
    let formDay = $state('01');
    let formHour = $state('12');
    let formMinute = $state('00');
    let formChannel = $state('');
    let formGuildId = $state('');
    // Editor DOM refs for mention chip fields
    let messageDivEl = $state(null);
    let descriptionDivEl = $state(null);
    let formTitle = $state('');
    let formColor = $state('');
    let formEmbedToggle = $state(false);
    let formFooter = $state('');
    let formAuthor = $state('');
    let formImageUrl = $state('');
    let formThumbnailUrl = $state('');
    /** Which image box popup is open: 'thumbnail' | 'image' | null. */
    let urlPopupTarget = $state(null);
    /** Temporary URL value being edited in the popup. */
    let urlPopupValue = $state('');

    function openUrlPopup(target) {
        urlPopupTarget = target;
        urlPopupValue = target === 'thumbnail' ? formThumbnailUrl : formImageUrl;
    }
    function confirmUrlPopup() {
        if (urlPopupTarget === 'thumbnail') formThumbnailUrl = urlPopupValue.trim();
        else if (urlPopupTarget === 'image') formImageUrl = urlPopupValue.trim();
        urlPopupTarget = null;
    }
    function cancelUrlPopup() { urlPopupTarget = null; }
    // Embed fields: array of { _id: string, name: string, value: string, inline: boolean }
    let formFields = $state([]);
    let fieldIdCounter = 0;
    /** DOM refs for field value editors, keyed by field._id. Non-reactive. */
    const fieldEditorEls = {};

    /** Svelte action — registers a field's contenteditable element by its stable ID. */
    function fieldEditorAction(el, id) {
        fieldEditorEls[id] = el;
        return { destroy() { delete fieldEditorEls[id]; } };
    }

    /** Append a blank field (max 25, matching Discord's embed field limit). */
    function addField() {
        if (formFields.length >= 25) return;
        const id = `field_${fieldIdCounter++}`;
        formFields = [...formFields, { _id: id, name: '', value: '', inline: false }];
        formMentionMap = { ...formMentionMap, [id]: {} };
    }

    /** Remove the field at the given index. */
    function removeField(index) {
        const field = formFields[index];
        formFields = formFields.filter((_, i) => i !== index);
        const { [field._id]: _removed, ...remainingMaps } = formMentionMap;
        formMentionMap = remainingMaps;
    }

    // Pattern fields
    let formPatternPreset = $state('time');
    let formPatternCustom = $state('');

    // Repeat fields
    let formRepeatPreset = $state('none');
    let formRepeatDays = $state('0');
    let formRepeatHours = $state('0');
    let formRepeatMinutes = $state('0');
    let formRepeatSeconds = $state('0');
    let formWeeklyDays = $state([]);

    const PATTERN_PRESETS = [
        { value: 'time', label: 'On Time' },
        { value: '5', label: '5 min before' },
        { value: '5,15', label: '5 & 15 min before' },
        { value: '5,time', label: '5 min before + On Time' },
        { value: '5,15,time', label: '5 & 15 min before + On Time' },
        { value: 'custom', label: 'Custom' },
    ];

    const REPEAT_PRESETS = [
        { value: 'none', label: 'No repeat' },
        { value: 'daily', label: 'Daily (24h)' },
        { value: '2days', label: 'Every 2 days' },
        { value: '2weeks', label: 'Every 2 weeks' },
        { value: 'weekly', label: 'Weekly schedule' },
        { value: 'custom', label: 'Custom interval' },
    ];

    const WEEKDAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    // Guild/channel/role data
    let guilds = $state([]);
    let channels = $state([]);
    let isLoadingChannels = $state(false);
    let guildRoles = $state([]);

    // Mention picker
    let mentionPickerOpen = $state(false);
    let mentionActiveTab = $state('roles');   // 'roles' | 'users'
    let mentionRoleSearch = $state('');        // filter text for roles tab
    let mentionUserSearch = $state('');        // search text for users tab
    let mentionUserResults = $state([]);       // fetched user items
    let mentionUserSearching = $state(false);  // loading indicator
    let mentionStartCharOffset = $state(-1); // char offset in getEditorFlatTextBeforeCursor()
    let activeMentionField = $state(null); // 'message' | 'description'
    let activeMentionEl = $state(null);
    let mentionPickerStyle = $state('');
    let formMentionMap = $state({ message: {}, description: {} });
    /** Per-field validation errors. Keys match template `{#if}` checks. */
    let formErrors = $state({});
    let resolvedUsers = $state(new Map()); // userId → displayName
    let mentionUserSearchTimeout = null;

    // Tick counter to force relative time re-renders
    let tick = $state(0);
    let tickInterval;
    let pollInterval;
    const POLL_INTERVAL_MS = 5000;

    // Derived state
    let serverList = $derived(() => {
        const items = [];
        const privateCount = notifications.filter(n => !n.guild_id).length;
        items.push({ id: '_private', name: 'Private', iconName: 'notifications', iconUrl: null, count: privateCount });
        for (const guild of guilds) {
            const count = notifications.filter(n => n.guild_id === guild.id).length;
            items.push({ id: guild.id, name: guild.name, iconName: 'shield', iconUrl: guild.icon || null, count });
        }
        return items;
    });

    let selectedNotifications = $derived(() => {
        if (!selectedServer) return [];
        let result = selectedServer === '_private'
            ? notifications.filter(n => !n.guild_id)
            : notifications.filter(n => n.guild_id === selectedServer);
        if (statusFilter === 'active') result = result.filter(n => n.is_active);
        else if (statusFilter === 'inactive') result = result.filter(n => !n.is_active);
        return result;
    });

    let selectedServerName = $derived(() => {
        const item = serverList().find(s => s.id === selectedServer);
        return item?.name || '';
    });

    let resolvedPattern = $derived(() => {
        if (formPatternPreset === 'custom') return formPatternCustom.trim();
        return formPatternPreset;
    });

    // Format helpers
    function formatPattern(pattern) {
        if (!pattern || pattern === 'time') return 'On Time';
        const parts = pattern.split(',').map(s => s.trim()).filter(Boolean);
        if (parts.length === 0) return 'On Time';
        const minuteParts = parts.filter(p => /^\d+$/.test(p));
        const hasOnTime = parts.includes('time');
        const segments = [];
        if (minuteParts.length > 0) {
            segments.push(minuteParts.join(' & ') + ' min before');
        }
        if (hasOnTime) segments.push('On Time');
        return segments.join(' + ') || pattern;
    }

    function formatRepeat(repeatStatus, repeatFrequency) {
        if (!repeatStatus || repeatStatus === 0) return 'None';
        if (!repeatFrequency) return 'None';
        const freq = repeatFrequency;
        if (typeof freq === 'string' && freq.startsWith('weekly:')) {
            const dayNums = freq.split(':')[1].split(',').map(Number);
            return 'Weekly: ' + dayNums.map(d => WEEKDAY_NAMES[d]).join(', ');
        }
        const seconds = parseInt(freq, 10);
        if (isNaN(seconds) || seconds <= 0) return 'None';
        if (seconds === 86400) return 'Daily';
        if (seconds === 172800) return 'Every 2 days';
        if (seconds === 604800) return 'Weekly';
        if (seconds === 1209600) return 'Every 2 weeks';
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        const timeParts = [];
        if (days > 0) timeParts.push(days + 'd');
        if (hours > 0) timeParts.push(hours + 'h');
        if (mins > 0) timeParts.push(mins + 'm');
        if (secs > 0) timeParts.push(secs + 's');
        return 'Every ' + timeParts.join(' ');
    }

    function formatFullTimestamp(ts) {
        if (!ts || ts <= 0) return '-';
        const d = new Date(ts * 1000);
        return d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0') + '-' + String(d.getUTCDate()).padStart(2, '0') + ' ' + String(d.getUTCHours()).padStart(2, '0') + ':' + String(d.getUTCMinutes()).padStart(2, '0') + ' UTC';
    }

    // DateTime input handlers
    function handleYearInput(e) {
        let val = e.target.value.replace(/\D/g, '').slice(0, 4);
        formYear = val;
        e.target.value = val;
        if (val.length === 4) {
            const next = e.target.closest('.datetime-input-group')?.querySelector('.dt-month');
            if (next) next.focus();
        }
    }
    function handleMonthInput(e) {
        let val = e.target.value.replace(/\D/g, '').slice(0, 2);
        if (val.length === 2 && parseInt(val, 10) > 12) val = '12';
        if (val.length === 2 && parseInt(val, 10) < 1) val = '01';
        formMonth = val;
        e.target.value = val;
        if (val.length === 2) {
            const next = e.target.closest('.datetime-input-group')?.querySelector('.dt-day');
            if (next) next.focus();
        }
    }
    function handleDayInput(e) {
        let val = e.target.value.replace(/\D/g, '').slice(0, 2);
        if (val.length === 2 && parseInt(val, 10) > 31) val = '31';
        if (val.length === 2 && parseInt(val, 10) < 1) val = '01';
        formDay = val;
        e.target.value = val;
        if (val.length === 2) {
            const next = e.target.closest('.datetime-input-group')?.querySelector('.dt-hour');
            if (next) next.focus();
        }
    }
    function handleHourInput(e) {
        let val = e.target.value.replace(/\D/g, '').slice(0, 2);
        if (val.length === 2 && parseInt(val, 10) > 23) val = '23';
        formHour = val;
        e.target.value = val;
        if (val.length === 2) {
            const next = e.target.closest('.datetime-input-group')?.querySelector('.dt-minute');
            if (next) next.focus();
        }
    }
    function handleMinuteInput(e) {
        let val = e.target.value.replace(/\D/g, '').slice(0, 2);
        if (val.length === 2 && parseInt(val, 10) > 59) val = '59';
        formMinute = val;
        e.target.value = val;
    }

    function padOnBlur(e, setter, width = 2) {
        let val = e.target.value;
        if (val === '') val = width === 4 ? '2025' : '00';
        else val = val.padStart(width, '0');
        setter(val);
        e.target.value = val;
    }

    function setFormFromTimestamp(ts) {
        if (ts && ts > 0) {
            const d = new Date(ts * 1000);
            formYear = String(d.getUTCFullYear());
            formMonth = String(d.getUTCMonth() + 1).padStart(2, '0');
            formDay = String(d.getUTCDate()).padStart(2, '0');
        } else {
            const d = new Date();
            formYear = String(d.getUTCFullYear());
            formMonth = String(d.getUTCMonth() + 1).padStart(2, '0');
            formDay = String(d.getUTCDate()).padStart(2, '0');
        }
    }

    // Repeat helpers
    function detectRepeatPreset(repeatStatus, repeatFrequency) {
        if (!repeatStatus || repeatStatus === 0) return 'none';
        if (!repeatFrequency) return 'none';
        if (typeof repeatFrequency === 'string' && repeatFrequency.startsWith('weekly:')) return 'weekly';
        const sec = parseInt(repeatFrequency, 10);
        if (sec === 86400) return 'daily';
        if (sec === 172800) return '2days';
        if (sec === 1209600) return '2weeks';
        return 'custom';
    }

    function parseWeeklyDays(freq) {
        if (typeof freq !== 'string' || !freq.startsWith('weekly:')) return [];
        return freq.split(':')[1].split(',').map(Number);
    }

    function buildRepeatPayload() {
        if (formRepeatPreset === 'none') return { repeatStatus: 0, repeatFrequency: null };
        const repeatStatus = 1;
        let repeatFrequency;
        switch (formRepeatPreset) {
            case 'daily': repeatFrequency = 86400; break;
            case '2days': repeatFrequency = 172800; break;
            case '2weeks': repeatFrequency = 1209600; break;
            case 'weekly': {
                const sorted = [...formWeeklyDays].sort((a, b) => a - b);
                repeatFrequency = sorted.length > 0 ? 'weekly:' + sorted.join(',') : null;
                if (!repeatFrequency) return { repeatStatus: 0, repeatFrequency: null };
                break;
            }
            case 'custom': {
                const totalSeconds =
                    (parseInt(formRepeatDays, 10) || 0) * 86400 +
                    (parseInt(formRepeatHours, 10) || 0) * 3600 +
                    (parseInt(formRepeatMinutes, 10) || 0) * 60 +
                    (parseInt(formRepeatSeconds, 10) || 0);
                if (totalSeconds <= 0) return { repeatStatus: 0, repeatFrequency: null };
                repeatFrequency = totalSeconds;
                break;
            }
            default: return { repeatStatus: 0, repeatFrequency: null };
        }
        return { repeatStatus, repeatFrequency };
    }

    function detectPatternPreset(pattern) {
        if (!pattern || pattern === 'time') return 'time';
        const known = PATTERN_PRESETS.find(p => p.value === pattern);
        if (known && known.value !== 'custom') return known.value;
        return 'custom';
    }

    function toggleWeeklyDay(day) {
        if (formWeeklyDays.includes(day)) {
            formWeeklyDays = formWeeklyDays.filter(d => d !== day);
        } else {
            formWeeklyDays = [...formWeeklyDays, day];
        }
    }

    // Navigation
    function selectServer(id) {
        selectedServer = id;
        showMobileDetail = true;
    }

    function goBackToList() {
        showMobileDetail = false;
    }

    // Data loading
    onMount(() => {
        loadData();
        tickInterval = setInterval(() => { tick++; }, 1000);
        pollInterval = setInterval(refreshNotifications, POLL_INTERVAL_MS);
    });

    onDestroy(() => {
        if (tickInterval) clearInterval(tickInterval);
        if (pollInterval) clearInterval(pollInterval);
    });

    async function loadData() {
        isLoading = true;
        try {
            const [notifData, guildData] = await Promise.all([
                apiFetch('/api/notifications'),
                apiFetch('/api/guilds')
            ]);
            if (notifData) notifications = notifData;
            if (guildData) guilds = guildData;
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    async function refreshNotifications() {
        try {
            const freshData = await apiFetch('/api/notifications');
            if (freshData) mergeNotifications(freshData);
        } catch { /* silent refresh */ }
    }

    /**
     * Merge freshData into the current notifications array without replacing
     * entries that haven't changed. This prevents Svelte from re-rendering
     * countdown cells that didn't actually update (which caused flicker).
     * @param {Array} freshData
     */
    function mergeNotifications(freshData) {
        const freshById = new Map(freshData.map(n => [n.id, n]));
        const existingById = new Map(notifications.map(n => [n.id, n]));

        let hasChanges = false;
        const merged = [];

        // Preserve ordering from fresh data
        for (const fresh of freshData) {
            const existing = existingById.get(fresh.id);
            if (!existing) {
                merged.push(fresh);
                hasChanges = true;
            } else if (notificationChanged(existing, fresh)) {
                merged.push(fresh);
                hasChanges = true;
            } else {
                merged.push(existing);
            }
        }

        // Check if any existing notifications were removed
        if (!hasChanges && notifications.length !== freshData.length) {
            hasChanges = true;
        }

        if (hasChanges) {
            notifications = merged;
        }
    }

    /**
     * Returns true if any meaningful field on a notification has changed.
     * We compare all fields except those that are purely cosmetic or will
     * change every tick anyway.
     * @param {object} existing
     * @param {object} fresh
     * @returns {boolean}
     */
    function notificationChanged(existing, fresh) {
        const WATCH_KEYS = [
            'name', 'is_active', 'guild_id', 'channel_id', 'pattern',
            'repeat_status', 'repeat_frequency', 'next_trigger',
            'embed_toggle', 'message', 'title', 'color', 'description',
            'footer', 'author', 'image_url', 'thumbnail_url', 'fields',
            'mention', 'type'
        ];
        return WATCH_KEYS.some(key => existing[key] !== fresh[key]);
    }

    async function loadChannels(guildId) {
        if (!guildId) { channels = []; return; }
        isLoadingChannels = true;
        try {
            const data = await apiFetch('/api/guilds/' + guildId + '/channels');
            if (data) {
                channels = data;
                const hasMatch = data.some(ch => ch.id === formChannel);
                if (!hasMatch && data.length > 0) formChannel = data[0].id;
            }
        } catch (error) {
            console.error('Failed to load channels:', error.message);
            channels = [];
        } finally {
            isLoadingChannels = false;
        }
    }

    function handleGuildChange() {
        formChannel = '';
        loadChannels(formGuildId);
        loadRoles(formGuildId);
    }

    async function loadRoles(guildId) {
        if (!guildId) { guildRoles = []; return; }
        try {
            const data = await apiFetch('/api/guilds/' + guildId + '/roles');
            if (data) guildRoles = data;
        } catch {
            guildRoles = [];
        }
    }

    /** Filtered role/everyone/here items, derived reactively from mentionRoleSearch. */
    const filteredRoleItems = $derived(() => {
        const q = mentionRoleSearch.toLowerCase();
        const items = [];
        if (formType === 'server') {
            if (!q || 'everyone'.startsWith(q)) items.push({ label: '@everyone', value: 'everyone:', color: null });
            if (!q || 'here'.startsWith(q)) items.push({ label: '@here', value: 'here:', color: null });
        }
        if (formGuildId) {
            guildRoles
                .filter(r => !q || r.name.toLowerCase().includes(q))
                .forEach(r => items.push({ label: r.name, value: `role:${r.id}`, color: r.color }));
        }
        return items;
    });

    async function searchMembers(query) {
        if (!formGuildId || query.length < 2) return [];
        try {
            const data = await apiFetch(`/api/guilds/${formGuildId}/members/search?q=${encodeURIComponent(query)}&limit=10`);
            if (!data) return [];
            return data.map(m => ({
                label: m.displayName,
                value: `user:${m.id}`,
                color: null,
                isUser: true,
                avatar: m.avatar || null,
            }));
        } catch {
            return [];
        }
    }

    /** Returns flat text before the cursor in a contenteditable div.
     *  Chip spans count as the single character '\x01' so spaces inside chips
     *  don't fool the @-trigger regex. */
    function getEditorFlatTextBeforeCursor(el) {
        const sel = window.getSelection();
        if (!sel.rangeCount) return '';
        const range = sel.getRangeAt(0);
        const preRange = document.createRange();
        preRange.selectNodeContents(el);
        preRange.setEnd(range.startContainer, range.startOffset);
        const frag = preRange.cloneContents();
        let text = '';
        for (const child of frag.childNodes) {
            if (child.nodeType === Node.TEXT_NODE) text += child.textContent;
            else if (child.classList?.contains('mention-chip')) text += '\x01';
        }
        return text;
    }

    /** Finds the { node, offset } pair in el that corresponds to charIndex
     *  in the flat text (chips = 1 char each). */
    function getEditorNodeAtCharIndex(el, charIndex) {
        let count = 0;
        for (const child of el.childNodes) {
            if (child.nodeType === Node.TEXT_NODE) {
                if (count + child.length > charIndex) {
                    return { node: child, offset: charIndex - count };
                }
                count += child.length;
            } else if (child.classList?.contains('mention-chip')) {
                if (count === charIndex) {
                    return { node: el, offset: Array.from(el.childNodes).indexOf(child) };
                }
                count += 1;
            }
        }
        return { node: el, offset: el.childNodes.length };
    }

    /** Walk the div's child nodes and produce storage text (@tagN) + active mention map. */
    function extractEditorContent(el, currentMentionMap) {
        let text = '';
        const usedMentions = {};
        for (const child of el.childNodes) {
            if (child.nodeType === Node.TEXT_NODE) {
                text += child.textContent;
            } else if (child.classList?.contains('mention-chip')) {
                const tagName = child.dataset.tag;
                text += `@${tagName}`;
                if (currentMentionMap[tagName]) usedMentions[tagName] = currentMentionMap[tagName];
            }
        }
        return { text, usedMentions };
    }

    /** Populate a contenteditable div from storage text + mention map. */
    function loadEditorContent(el, storageText, mentionMap) {
        el.innerHTML = '';
        const tagPattern = /@(tag\d*)\b/g;
        let lastIndex = 0;
        let match;
        while ((match = tagPattern.exec(storageText)) !== null) {
            if (match.index > lastIndex) {
                el.appendChild(document.createTextNode(storageText.slice(lastIndex, match.index)));
            }
            const tagName = match[1];
            const entry = mentionMap[tagName];
            if (entry) {
                el.appendChild(createChipElement(tagName, entry.label));
            } else {
                el.appendChild(document.createTextNode(match[0]));
            }
            lastIndex = tagPattern.lastIndex;
        }
        if (lastIndex < storageText.length) {
            el.appendChild(document.createTextNode(storageText.slice(lastIndex)));
        }
    }

    /** Create a non-editable mention chip span. */
    function createChipElement(tagName, label) {
        const chip = document.createElement('span');
        chip.className = 'mention-chip';
        chip.contentEditable = 'false';
        chip.dataset.tag = tagName;
        chip.textContent = `@${label}`;
        return chip;
    }

    function handleMentionInput(event, field) {
        const el = event.currentTarget;
        const textBeforeCursor = getEditorFlatTextBeforeCursor(el);
        // \x01 is our chip placeholder — stop mention-match at it
        const match = textBeforeCursor.match(/@([^\x01\s@]*)$/);

        if (match) {
            const query = match[1];
            mentionStartCharOffset = match.index;
            activeMentionField = field;
            activeMentionEl = el;
            mentionRoleSearch = query;

            const rect = el.getBoundingClientRect();
            mentionPickerStyle = `left: ${Math.round(rect.left)}px; bottom: ${Math.round(window.innerHeight - rect.top + 4)}px; min-width: ${Math.round(rect.width)}px;`;

            if (!mentionPickerOpen) {
                mentionActiveTab = 'roles';
                mentionPickerOpen = true;
            }
            triggerUserSearch(query);
        } else {
            clearTimeout(mentionUserSearchTimeout);
            mentionPickerOpen = false;
        }
    }

    function triggerUserSearch(query) {
        mentionUserSearch = query;
        clearTimeout(mentionUserSearchTimeout);
        mentionUserResults = [];
        if (query.length < 2) {
            mentionUserSearching = false;
            return;
        }
        mentionUserSearching = true;
        mentionUserSearchTimeout = setTimeout(async () => {
            const results = await searchMembers(query);
            if (mentionUserSearch === query) {
                mentionUserResults = results;
                mentionUserSearching = false;
            }
        }, 300);
    }

    function handleUserSearch(event) {
        triggerUserSearch(event.target.value);
    }

    // Close mention picker when modal closes
    $effect(() => {
        if (!showForm) mentionPickerOpen = false;
    });

    // Close mention picker on click outside
    $effect(() => {
        if (!mentionPickerOpen) return;

        function onDocumentMousedown(e) {
            const picker = document.querySelector('.mention-picker');
            if (picker && !picker.contains(e.target)) {
                mentionPickerOpen = false;
            }
        }

        document.addEventListener('mousedown', onDocumentMousedown);
        return () => document.removeEventListener('mousedown', onDocumentMousedown);
    });

    function handleMentionKeydown(event) {
        if (!mentionPickerOpen) return;
        if (event.key === 'Escape') {
            mentionPickerOpen = false;
            event.preventDefault();
        }
    }

    /** Strip leading @ and trim — keeps spaces and special chars for display labels. */
    function normalizeMentionLabel(text) {
        return text.replace(/^@/, '').trim() || 'mention';
    }

    /** Given a storage value like 'role:123' or 'everyone:', return a full display label. */
    function resolveDisplayLabel(value) {
        const colonIdx = value.indexOf(':');
        const type = colonIdx === -1 ? value : value.slice(0, colonIdx);
        const id = colonIdx === -1 ? '' : value.slice(colonIdx + 1);
        if (type === 'everyone') return 'everyone';
        if (type === 'here') return 'here';
        if (type === 'role') {
            const role = guildRoles.find(r => r.id === id);
            return role ? role.name : `role_${id}`;
        }
        if (type === 'user') {
            const name = resolvedUsers.get(id);
            return name || `user_${id}`;
        }
        return 'mention';
    }

    /**
     * Build the server-compatible mention map:
     * strips labels (just keeps value strings) and removes stale tags
     * (tags whose @tagN placeholder is no longer present in the storage text).
     */
    function buildServerMentionMap(storageText, componentMap) {
        return Object.fromEntries(
            Object.entries(componentMap)
                .filter(([tagName]) => storageText.includes(`@${tagName}`))
                .map(([tagName, { value }]) => [tagName, value])
        );
    }

    function nextAvailableTagName() {
        const usedTags = new Set([
            ...Object.keys(formMentionMap.message),
            ...Object.keys(formMentionMap.description)
        ]);
        if (!usedTags.has('tag')) return 'tag';
        let i = 1;
        while (usedTags.has(`tag${i}`)) i++;
        return `tag${i}`;
    }

    function insertMention(event, item) {
        event.preventDefault();
        const el = activeMentionEl;

        const tagName = nextAvailableTagName();
        const label = normalizeMentionLabel(item.label);

        // Register in mention map immediately
        if (activeMentionField === 'message') {
            formMentionMap.message[tagName] = { value: item.value, label };
        } else {
            formMentionMap.description[tagName] = { value: item.value, label };
        }

        const chip = createChipElement(tagName, label);

        // Find the current cursor position
        const sel = window.getSelection();
        if (!sel.rangeCount) return;
        const cursorRange = sel.getRangeAt(0);

        // Find the DOM position of the @ that triggered the picker
        const { node: startNode, offset: startOffset } = getEditorNodeAtCharIndex(el, mentionStartCharOffset);

        // Delete from @ to cursor, then insert chip + space
        const replaceRange = document.createRange();
        replaceRange.setStart(startNode, startOffset);
        replaceRange.setEnd(cursorRange.startContainer, cursorRange.startOffset);
        replaceRange.deleteContents();

        const space = document.createTextNode('\u00A0');
        replaceRange.insertNode(space);
        replaceRange.insertNode(chip);

        // Move cursor after the space
        const newRange = document.createRange();
        newRange.setStartAfter(space);
        newRange.setEndAfter(space);
        sel.removeAllRanges();
        sel.addRange(newRange);

        mentionPickerOpen = false;
        el.focus();
    }


    // Form open/close
    function resetFormDefaults() {
        formPatternPreset = 'time';
        formPatternCustom = '';
        formRepeatPreset = 'none';
        formRepeatDays = '0';
        formRepeatHours = '0';
        formRepeatMinutes = '0';
        formRepeatSeconds = '0';
        formWeeklyDays = [];
        if (messageDivEl) messageDivEl.innerHTML = '';
        if (descriptionDivEl) descriptionDivEl.innerHTML = '';
        formTitle = '';
        formColor = '';
        formEmbedToggle = false;
        formFooter = '';
        formAuthor = '';
        formImageUrl = '';
        formThumbnailUrl = '';
        formFields = [];
        formMentionMap = { message: {}, description: {} };
        formErrors = {};
    }

    async function openCreateForm() {
        editingNotification = null;
        formName = '';
        resetFormDefaults();
        if (selectedServer && selectedServer !== '_private') {
            formType = 'server';
            formGuildId = selectedServer;
            loadChannels(selectedServer);
            loadRoles(selectedServer);
        } else {
            formType = 'private';
            formGuildId = '';
        }
        setFormFromTimestamp(null);
        formHour = '12';
        formMinute = '00';
        formChannel = '';
        if (formType !== 'server') channels = [];
        showForm = true;
        await domReady();
        if (messageDivEl) messageDivEl.innerHTML = '';
        if (descriptionDivEl) descriptionDivEl.innerHTML = '';
    }

    async function openEditForm(notification) {
        formErrors = {};
        isFormLoading = true;
        showForm = true;
        editingNotification = notification;
        formName = notification.name || '';
        formType = notification.guild_id ? 'server' : 'private';
        setFormFromTimestamp(notification.next_trigger);
        formHour = String(notification.hour ?? 12).padStart(2, '0');
        formMinute = String(notification.minute ?? 0).padStart(2, '0');
        formChannel = notification.channel_id || '';
        formGuildId = notification.guild_id || '';

        const detectedPattern = detectPatternPreset(notification.pattern);
        formPatternPreset = detectedPattern;
        formPatternCustom = detectedPattern === 'custom' ? (notification.pattern || '') : '';

        formRepeatPreset = detectRepeatPreset(notification.repeat_status, notification.repeat_frequency);
        if (formRepeatPreset === 'weekly') {
            formWeeklyDays = parseWeeklyDays(notification.repeat_frequency);
        } else if (formRepeatPreset === 'custom') {
            const sec = parseInt(notification.repeat_frequency, 10) || 0;
            formRepeatDays = String(Math.floor(sec / 86400));
            formRepeatHours = String(Math.floor((sec % 86400) / 3600));
            formRepeatMinutes = String(Math.floor((sec % 3600) / 60));
            formRepeatSeconds = String(sec % 60);
        } else {
            formRepeatDays = '0';
            formRepeatHours = '0';
            formRepeatMinutes = '0';
            formRepeatSeconds = '0';
            formWeeklyDays = [];
        }

        formTitle = notification.title || '';
        formColor = notification.color || '';

        // Load roles first so resolveDisplayLabel can look up names
        channels = [];
        if (notification.guild_id) {
            await Promise.all([loadChannels(notification.guild_id), loadRoles(notification.guild_id)]);
        }

        // Pre-resolve any user IDs present in the mention map
        try {
            const rawMention = notification.mention ? JSON.parse(notification.mention) : {};
            const userIds = new Set();
            for (const component of ['message', 'description']) {
                for (const value of Object.values(rawMention[component] ?? {})) {
                    if (typeof value === 'string' && value.startsWith('user:')) {
                        userIds.add(value.slice(5));
                    }
                }
            }
            if (userIds.size > 0) {
                const ids = [...userIds].join(',');
                const users = await apiFetch(`/api/users/batch?ids=${encodeURIComponent(ids)}`);
                if (users) {
                    const newMap = new Map(resolvedUsers);
                    for (const u of users) newMap.set(u.id, u.displayName || u.username);
                    resolvedUsers = newMap;
                }
            }
        } catch { /* ignore, labels fall back to role_ID */ }

        try {
            const parsed = notification.mention ? JSON.parse(notification.mention) : {};
            const messageTagMap = {};
            const descTagMap = {};
            for (const [tagName, value] of Object.entries(parsed.message ?? {})) {
                messageTagMap[tagName] = { value, label: resolveDisplayLabel(value) };
            }
            for (const [tagName, value] of Object.entries(parsed.description ?? {})) {
                descTagMap[tagName] = { value, label: resolveDisplayLabel(value) };
            }
            formMentionMap = { message: messageTagMap, description: descTagMap };
        } catch {
            formMentionMap = { message: {}, description: {} };
        }

        const pendingMessage = notification.message_content || '';
        const pendingDescription = notification.description || '';

        formEmbedToggle = !!notification.embed_toggle;
        formFooter = notification.footer || '';
        formAuthor = notification.author || '';
        formImageUrl = notification.image_url || '';
        formThumbnailUrl = notification.thumbnail_url || '';
        try {
            const parsedFields = notification.fields ? JSON.parse(notification.fields) : [];
            const parsedFieldsMentions = (() => {
                try { return JSON.parse(notification.mention)?.fields ?? []; } catch { return []; }
            })();
            formFields = Array.isArray(parsedFields)
                ? parsedFields.map(f => ({ ...f, _id: `field_${fieldIdCounter++}` }))
                : [];
            const fieldMaps = {};
            for (let idx = 0; idx < formFields.length; idx++) {
                const rawMap = parsedFieldsMentions[idx] ?? {};
                const resolvedMap = {};
                for (const [tagName, value] of Object.entries(rawMap)) {
                    resolvedMap[tagName] = { value, label: resolveDisplayLabel(value) };
                }
                fieldMaps[formFields[idx]._id] = resolvedMap;
            }
            formMentionMap = { ...formMentionMap, ...fieldMaps };
        } catch { formFields = []; }

        isFormLoading = false;
        showForm = true;
        await domReady();
        if (messageDivEl) loadEditorContent(messageDivEl, pendingMessage, formMentionMap.message);
        if (descriptionDivEl) loadEditorContent(descriptionDivEl, pendingDescription, formMentionMap.description);
        for (const field of formFields) {
            const el = fieldEditorEls[field._id];
            if (el) loadEditorContent(el, field.value || '', formMentionMap[field._id] ?? {});
        }
    }

    // Form submission
    /** Validates the form and returns an object of error messages keyed by field name. */
    function validateForm() {
        const errors = {};

        if (!formName.trim()) {
            errors.name = 'Name is required';
        }

        if (formType === 'server') {
            if (!formGuildId) errors.guild = 'Please select a server';
            if (!formChannel.trim()) errors.channel = 'Please select a channel';
        }

        if (editingNotification) {
            const messageText = messageDivEl?.textContent?.trim() ?? '';

            if (!formEmbedToggle && !messageText) {
                errors.messageContent = 'Message content is required when embed is disabled';
            }

            if (formEmbedToggle) {
                const descText = descriptionDivEl?.textContent?.trim() ?? '';
                const hasEmbedContent = formTitle.trim() || descText || formFields.some(f => {
                    const el = fieldEditorEls[f._id];
                    const val = (el ? el.textContent?.trim() : f.value?.trim()) ?? '';
                    return f.name.trim() && val;
                });
                if (!hasEmbedContent) {
                    errors.embedContent = 'Embed must have a title, description, or at least one field with content';
                }
            }

            formFields.forEach((field, i) => {
                const el = fieldEditorEls[field._id];
                const val = (el ? el.textContent?.trim() : field.value?.trim()) ?? '';
                const hasName = !!field.name.trim();
                const hasValue = !!val;
                if (hasName && !hasValue) errors[`field_${i}_value`] = `Field ${i + 1}: value is required`;
                if (!hasName && hasValue) errors[`field_${i}_name`] = `Field ${i + 1}: name is required`;
            });
        }

        return errors;
    }

    async function submitForm() {
        formErrors = validateForm();
        if (Object.keys(formErrors).length > 0) return;

        const isEdit = !!editingNotification;
        isSubmitting = true;
        const h = parseInt(formHour, 10) || 0;
        const m = parseInt(formMinute, 10) || 0;
        const y = parseInt(formYear, 10) || new Date().getUTCFullYear();
        const mo = parseInt(formMonth, 10) || 1;
        const dy = parseInt(formDay, 10) || 1;
        const utcDate = new Date(Date.UTC(y, mo - 1, dy, h, m, 0));
        const nextTrigger = Math.floor(utcDate.getTime() / 1000);
        const { repeatStatus, repeatFrequency } = buildRepeatPayload();
        const payload = {
            name: formName.trim(),
            type: formType,
            hour: h,
            minute: m,
            pattern: resolvedPattern() || null,
            repeatStatus,
            repeatFrequency,
            guildId: formType === 'server' ? (formGuildId || null) : null,
            channelId: formChannel.trim() || null,
            nextTrigger,
        };
        if (isEdit) {
            const { text: storageMessage, usedMentions: messageMentions } = extractEditorContent(messageDivEl ?? document.createElement('div'), formMentionMap.message);
            const { text: storageDescription, usedMentions: descriptionMentions } = extractEditorContent(descriptionDivEl ?? document.createElement('div'), formMentionMap.description);
            payload.messageContent = storageMessage;
            payload.title = formTitle.trim() || null;
            payload.color = formColor.trim() || null;
            payload.description = storageDescription || null;
            payload.embedToggle = formEmbedToggle ? 1 : 0;
            payload.footer = formFooter.trim() || null;
            payload.author = formAuthor.trim() || null;
            payload.imageUrl = formImageUrl.trim() || null;
            payload.thumbnailUrl = formThumbnailUrl.trim() || null;
            const fieldResults = formFields.map(field => {
                const el = fieldEditorEls[field._id] ?? document.createElement('div');
                const { text, usedMentions } = extractEditorContent(el, formMentionMap[field._id] ?? {});
                return { name: field.name, value: text, inline: field.inline, mentions: usedMentions };
            });
            const populatedFields = fieldResults.filter(r => r.name.trim() || r.value.trim());
            payload.fields = populatedFields.map(({ name, value, inline }) => ({ name, value, inline }));
            payload.mention = {
                message: messageMentions,
                description: descriptionMentions,
                fields: populatedFields.map(r => r.mentions),
            };
        }
        try {
            let result;
            if (isEdit) {
                result = await apiFetch('/api/notifications/' + editingNotification.id, { method: 'PUT', body: payload });
            } else {
                result = await apiFetch('/api/notifications', { method: 'POST', body: payload });
            }
            if (!result) {
                showToast('Failed to save — permission denied', 'error');
                return;
            }
            showForm = false;
            await refreshNotifications();
            showToast(isEdit ? 'Changes saved' : 'Notification created', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isSubmitting = false;
        }
    }

    // Actions
    function getGuildName(guildId) {
        if (!guildId) return 'Private';
        const guild = guilds.find(g => g.id === guildId);
        return guild ? guild.name : 'Server (' + guildId + ')';
    }

    async function toggleActive(notification) {
        try {
            const result = await apiFetch('/api/notifications/' + notification.id + '/active', {
                method: 'PATCH',
                body: { isActive: !notification.is_active },
            });
            if (!result) {
                showToast('Failed — permission denied', 'error');
                return;
            }
            await refreshNotifications();
            if (mobileDetailNotif?.id === notification.id) {
                mobileDetailNotif = notifications.find(n => n.id === notification.id) || null;
            }
            showToast(notification.is_active ? 'Notification paused' : 'Notification activated', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    async function deleteNotification(notification) {
        deleteTarget = notification;
        confirmDeleteOpen = true;
    }

    async function confirmDeleteNotification() {
        try {
            await apiFetch('/api/notifications/' + deleteTarget.id, { method: 'DELETE' });
            if (showMobileDetailModal && mobileDetailNotif?.id === deleteTarget.id) {
                showMobileDetailModal = false;
                mobileDetailNotif = null;
            }
            await refreshNotifications();
            showToast('Notification deleted', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    function openMobileDetail(notification) {
        mobileDetailNotif = notification;
        showMobileDetailModal = true;
    }
</script>
<PageHeader label="Notifications" />

{#if isLoading}
    <div class="skeleton" style="height: 400px;"></div>
{:else}
    <div class="notif-layout" class:detail-active={showMobileDetail}>
        <!-- Server List (Left) -->
        <div class="server-list">
            {#each serverList() as server (server.id)}
                <button
                    class="server-item"
                    class:active={selectedServer === server.id}
                    onclick={() => selectServer(server.id)}
                >
                    <div class="server-icon">
                        {#if server.iconUrl}
                            <img src={server.iconUrl} alt={server.name} />
                        {:else}
                            <Icon name={server.iconName} size={16} />
                        {/if}
                    </div>
                    <div class="server-info">
                        <div class="server-name">{server.name}</div>
                        <div class="server-meta">{server.count} notification{server.count !== 1 ? 's' : ''}</div>
                    </div>
                </button>
            {/each}
        </div>

        <!-- Detail Panel (Right) -->
        <div class="notif-detail">
            {#if !selectedServer}
                <div class="empty-state">
                    <div class="empty-icon">&#x1F514;</div>
                    <span>Pick a server to view its notifications</span>
                </div>
            {:else}
                <div class="detail-header">
                    <div>
                        <button class="btn btn-sm back-btn" onclick={goBackToList}>&#x25C0; Back</button>
                        <div class="detail-title">{selectedServerName()}</div>
                        <div class="detail-stats">
                            <span>{selectedNotifications().length} notification{selectedNotifications().length !== 1 ? 's' : ''}</span>
                        </div>
                    </div>
                    <div class="header-actions">
                        <Select bind:value={statusFilter} options={[
                            { value: 'all', label: 'All Status' },
                            { value: 'active', label: 'Active' },
                            { value: 'inactive', label: 'Inactive' }
                        ]} />
                        <button class="btn btn-primary btn-sm" onclick={openCreateForm}>
                            <Icon name="plus" size={14} /> Create
                        </button>
                    </div>
                </div>

                {#if selectedNotifications().length === 0}
                    <div class="empty-state">
                        <div class="empty-icon">&#x1F515;</div>
                        <span>{statusFilter !== 'all' ? 'No matching notifications' : 'No notifications yet'}</span>
                    </div>
                {:else}
                    <div class="table-scroll">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th class="mobile-hide">Pattern</th>
                                    <th class="mobile-hide">Repeat</th>
                                    <th>Next Trigger</th>
                                    <th class="mobile-hide">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {#each selectedNotifications() as notification (notification.id)}
                                    <tr class="notif-row" onclick={() => openMobileDetail(notification)}>
                                        <td>
                                            <div class="notif-name-cell">
                                                <span class="notif-name">{notification.name || 'Untitled'}</span>
                                                <span class="notif-time-hint mono">
                                                    {String(notification.hour ?? 0).padStart(2, '0')}:{String(notification.minute ?? 0).padStart(2, '0')} UTC
                                                </span>
                                            </div>
                                        </td>
                                        <td>
                                            <button
                                                class="badge-btn"
                                                class:badge-success={notification.is_active}
                                                class:badge-danger={!notification.is_active}
                                                onclick={(e) => { e.stopPropagation(); toggleActive(notification); }}
                                            >
                                                {notification.is_active ? 'Active' : 'Inactive'}
                                            </button>
                                        </td>
                                        <td class="mobile-hide">
                                            <span class="detail-value-sm">{formatPattern(notification.pattern)}</span>
                                        </td>
                                        <td class="mobile-hide">
                                            <span class="detail-value-sm">{formatRepeat(notification.repeat_status, notification.repeat_frequency)}</span>
                                        </td>
                                        <td>
                                            {#if notification.is_active && notification.next_trigger}
                                                <span class="next-trigger-cell" title={formatFullTimestamp(notification.next_trigger)}>
                                                    {tick >= 0 ? formatRelativeTime(notification.next_trigger) : ''}
                                                </span>
                                            {:else}
                                                <span class="text-muted">-</span>
                                            {/if}
                                        </td>
                                        <td class="actions-cell mobile-hide">
                                            <button class="btn btn-sm" onclick={(e) => { e.stopPropagation(); openEditForm(notification); }}>
                                                <Icon name="edit" size={14} />
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick={(e) => { e.stopPropagation(); deleteNotification(notification); }}>
                                                <Icon name="delete" size={14} />
                                            </button>
                                        </td>
                                    </tr>
                                {/each}
                            </tbody>
                        </table>
                    </div>
                {/if}
            {/if}
        </div>
    </div>
{/if}
<!-- Create / Edit Modal -->
<Modal bind:isOpen={showForm} title="{editingNotification ? 'Edit' : 'Create'} Notification" wide>
    {#if isFormLoading}
        <div class="form-loading">
            <div class="form-loading-spinner"></div>
            <span>Loading notification data…</span>
        </div>
    {:else}
    <form onsubmit={(e) => { e.preventDefault(); submitForm(); }}>
        <div class="form-row">
            <label>
                Name
                <input type="text" bind:value={formName} required maxlength="100" placeholder="e.g. Bear Trap Reminder"
                    class:is-invalid={!!formErrors.name}
                    oninput={() => { if (formErrors.name) { const {name: _, ...rest} = formErrors; formErrors = rest; } }}
                />
                {#if formErrors.name}<span class="field-error-msg">{formErrors.name}</span>{/if}
            </label>
            {#if !editingNotification}
                <div class="form-field">
                    Type
                    <Select bind:value={formType} options={[
                        { value: 'private', label: 'Private (DM)' },
                        { value: 'server', label: 'Server' }
                    ]} />
                </div>
            {/if}
        </div>

        <div class="form-row">
            <div class="datetime-field">
                <span class="form-label-text">Trigger Date & Time (UTC)</span>
                <div class="datetime-input-group">
                    <input type="text" class="dt-year" bind:value={formYear} oninput={handleYearInput} onblur={(e) => padOnBlur(e, v => formYear = v, 4)} required placeholder="YYYY" maxlength="4" inputmode="numeric" />
                    <span class="dt-sep">-</span>
                    <input type="text" class="dt-month" bind:value={formMonth} oninput={handleMonthInput} onblur={(e) => padOnBlur(e, v => formMonth = v)} required placeholder="MM" maxlength="2" inputmode="numeric" />
                    <span class="dt-sep">-</span>
                    <input type="text" class="dt-day" bind:value={formDay} oninput={handleDayInput} onblur={(e) => padOnBlur(e, v => formDay = v)} required placeholder="DD" maxlength="2" inputmode="numeric" />
                    <span class="dt-spacer"></span>
                    <input type="text" class="dt-hour" bind:value={formHour} oninput={handleHourInput} onblur={(e) => padOnBlur(e, v => formHour = v)} required placeholder="HH" maxlength="2" inputmode="numeric" />
                    <span class="dt-sep">:</span>
                    <input type="text" class="dt-minute" bind:value={formMinute} oninput={handleMinuteInput} onblur={(e) => padOnBlur(e, v => formMinute = v)} required placeholder="MM" maxlength="2" inputmode="numeric" />
                </div>
            </div>
        </div>

        <div class="form-row">
            <div class="form-field">
                Send Pattern
                <span class="form-hint">When to send relative to the trigger time</span>
                <Select bind:value={formPatternPreset} options={PATTERN_PRESETS} />
            </div>
        </div>
        {#if formPatternPreset === 'custom'}
            <div class="form-row">
                <label class="full-width">
                    Custom Pattern
                    <span class="form-hint">Comma-separated: minutes before + "time" for at trigger. Example: 5,15,time</span>
                    <input type="text" bind:value={formPatternCustom} placeholder="e.g. 5,10,time" />
                </label>
            </div>
        {/if}

        <div class="form-row">
            <div class="form-field">
                Repeat Schedule
                <Select bind:value={formRepeatPreset} options={REPEAT_PRESETS} />
            </div>
        </div>
        {#if formRepeatPreset === 'weekly'}
            <div class="form-row">
                <div class="weekly-days-picker">
                    <span class="form-label-text">Repeat on days</span>
                    <div class="weekday-buttons">
                        {#each WEEKDAY_NAMES as dayName, idx}
                            <button
                                type="button"
                                class="weekday-btn"
                                class:active={formWeeklyDays.includes(idx)}
                                onclick={() => toggleWeeklyDay(idx)}
                            >
                                {dayName}
                            </button>
                        {/each}
                    </div>
                </div>
            </div>
        {/if}
        {#if formRepeatPreset === 'custom'}
            <div class="form-row interval-row">
                <label>
                    Days
                    <input type="number" bind:value={formRepeatDays} min="0" max="365" />
                </label>
                <label>
                    Hours
                    <input type="number" bind:value={formRepeatHours} min="0" max="23" />
                </label>
                <label>
                    Minutes
                    <input type="number" bind:value={formRepeatMinutes} min="0" max="59" />
                </label>
                <label>
                    Seconds
                    <input type="number" bind:value={formRepeatSeconds} min="0" max="59" />
                </label>
            </div>
        {/if}

        {#if formType === 'server'}
            <div class="form-row">
                <div class="form-field">
                    Server
                    <Select bind:value={formGuildId} onchange={handleGuildChange} placeholder="Select a server" options={guilds.map(g => ({ value: g.id, label: g.name }))} />
                    {#if formErrors.guild}<span class="field-error-msg">{formErrors.guild}</span>{/if}
                </div>
                <div class="form-field">
                    Channel
                    <Select bind:value={formChannel} disabled={!formGuildId || isLoadingChannels} options={channels.map(c => ({ value: c.id, label: '#' + c.name }))} />
                    {#if formErrors.channel}<span class="field-error-msg">{formErrors.channel}</span>{/if}
                </div>
            </div>
        {/if}

        {#if editingNotification}
            <div class="form-section-divider">
                <span>Notification Content</span>
                <label class="checkbox-label section-toggle">
                    <input type="checkbox" bind:checked={formEmbedToggle} />
                    Enable embed
                </label>
            </div>

            <div class="form-row">
                <div class="form-field full-width">
                    Message Text
                    <span class="form-hint">Supports {'{time}'} placeholder and @tag mentions</span>
                    <div
                        class="mention-editor"
                        class:is-invalid={!!formErrors.messageContent}
                        contenteditable="true"
                        role="textbox"
                        tabindex="0"
                        aria-multiline="true"
                        bind:this={messageDivEl}
                        oninput={(e) => { handleMentionInput(e, 'message'); if (formErrors.messageContent) { const {messageContent: _, ...rest} = formErrors; formErrors = rest; } }}
                        onkeydown={handleMentionKeydown}
                    ></div>
                    {#if formErrors.messageContent}<span class="field-error-msg">{formErrors.messageContent}</span>{/if}
                </div>
            </div>

            {#if formEmbedToggle}
                <div class="form-section-divider">
                    <span>Embed Content</span>
                    <div class="color-input-row embed-color-row">
                        <input type="color" bind:value={formColor} class="color-picker" />
                        <input type="text" bind:value={formColor} placeholder="#0099ff" />
                    </div>
                </div>
                {#if formErrors.embedContent}<p class="field-error-msg embed-error-msg">{formErrors.embedContent}</p>{/if}

                <div class="embed-preview-card" style="border-left-color: {formColor || 'var(--color-accent)'}">

                    <!-- Author, Title, Description and Thumbnail grouped together -->
                    <div class="ep-top-section">
                        <div class="ep-top-main">
                            <div class="ep-row-lead">
                                <span class="ep-icon-dot"></span>
                                <input class="ep-input ep-author" type="text" bind:value={formAuthor}
                                    maxlength="256" placeholder="Embed Author..." />
                            </div>

                            <!-- Title -->
                            <input class="ep-input ep-title" type="text" bind:value={formTitle}
                                maxlength="256" placeholder="Embed Title..." />

                            <!-- Description (mention editor) -->
                            <div
                                class="mention-editor ep-description"
                                contenteditable="true"
                                role="textbox"
                                tabindex="0"
                                aria-multiline="true"
                                bind:this={descriptionDivEl}
                                oninput={(e) => handleMentionInput(e, 'description')}
                                onkeydown={handleMentionKeydown}
                                data-placeholder="Embed Description..."
                            ></div>
                        </div>

                        <!-- Thumbnail (click to open URL popup) -->
                        <div class="ep-thumbnail">
                            <div
                                class="ep-thumbnail-box"
                                class:ep-thumbnail-box--filled={!!formThumbnailUrl}
                                style:background-image={formThumbnailUrl ? `url(${formThumbnailUrl})` : 'none'}
                                role="button"
                                tabindex="0"
                                title="Click to set thumbnail URL"
                                onclick={() => openUrlPopup('thumbnail')}
                                onkeydown={(e) => e.key === 'Enter' && openUrlPopup('thumbnail')}
                            >
                                {#if !formThumbnailUrl}
                                    <span class="ep-thumbnail-icon">+</span>
                                {/if}
                            </div>
                        </div>
                    </div>

                    <!-- Fields -->
                    {#each formFields as field, i (field._id)}
                        <div class="ep-field-item">
                            <div class="ep-field-body">
                                <input
                                    class="ep-input ep-field-name"
                                    class:is-invalid={!!formErrors[`field_${i}_name`]}
                                    type="text"
                                    bind:value={field.name}
                                    maxlength="256"
                                    placeholder="Field Title..."
                                    oninput={() => { const k = `field_${i}_name`; if (formErrors[k]) { const {[k]: _, ...rest} = formErrors; formErrors = rest; } }}
                                />
                                <div
                                    class="mention-editor ep-field-value"
                                    class:is-invalid={!!formErrors[`field_${i}_value`]}
                                    contenteditable="true"
                                    role="textbox"
                                    tabindex="0"
                                    aria-multiline="true"
                                    use:fieldEditorAction={field._id}
                                    oninput={(e) => { handleMentionInput(e, field._id); const k = `field_${i}_value`; if (formErrors[k]) { const {[k]: _, ...rest} = formErrors; formErrors = rest; } }}
                                    onkeydown={handleMentionKeydown}
                                    data-placeholder="Field Value..."
                                ></div>
                                {#if formErrors[`field_${i}_name`] || formErrors[`field_${i}_value`]}
                                    <span class="field-error-msg">{formErrors[`field_${i}_name`] ?? formErrors[`field_${i}_value`]}</span>
                                {/if}
                            </div>
                            <div class="ep-field-meta">
                                <label class="embed-field-inline">
                                    <input type="checkbox" bind:checked={field.inline} />
                                    Inline
                                </label>
                                <button type="button" class="btn-icon-remove" title="Remove field"
                                    onclick={() => removeField(i)}>✕</button>
                            </div>
                        </div>
                    {/each}

                    {#if formFields.length < 25}
                        <button type="button" class="btn btn-ghost ep-add-field-btn" onclick={addField}>
                            + Add Field
                            {#if formFields.length > 0}<span class="ep-field-count">{formFields.length}/25</span>{/if}
                        </button>
                    {:else}
                        <span class="ep-field-count">25/25 fields (max reached)</span>
                    {/if}

                    <!-- Image area -->
                    <div
                        class="ep-image-area"
                        class:ep-image-area--filled={!!formImageUrl}
                        role="button"
                        tabindex="0"
                        title={formImageUrl ? 'Click to change image URL' : 'Click to set image URL'}
                        onclick={() => openUrlPopup('image')}
                        onkeydown={(e) => e.key === 'Enter' && openUrlPopup('image')}
                    >
                        {#if formImageUrl}
                            <img src={formImageUrl} alt="Embed preview" class="ep-image-preview" />
                        {:else}
                            <span class="ep-image-placeholder-icon">+</span>
                        {/if}
                    </div>

                    <!-- Footer -->
                    <div class="ep-footer-row">
                        <span class="ep-icon-dot ep-icon-sm"></span>
                        <input class="ep-input ep-footer" type="text" bind:value={formFooter}
                            maxlength="2048" placeholder="Embed Footer..." />
                    </div>

                </div>
            {/if}
        {/if}

        <div class="form-actions">
            <LoadingButton type="submit" class="btn btn-primary" loading={isSubmitting}>
                {editingNotification ? 'Save' : 'Create'}
            </LoadingButton>
            <button type="button" class="btn" onclick={() => { showForm = false; formErrors = {}; }}>Cancel</button>
        </div>
    </form>
    {/if}
</Modal>

<!-- URL popup for thumbnail / image -->
<Modal
    isOpen={urlPopupTarget !== null}
    title={urlPopupTarget === 'thumbnail' ? 'Set Thumbnail URL' : 'Set Image URL'}
    onclose={cancelUrlPopup}
>
    <!-- svelte-ignore a11y_autofocus -->
    <input
        class="url-popup-input"
        type="url"
        autofocus
        bind:value={urlPopupValue}
        placeholder="https://example.com/image.png"
        onkeydown={(e) => { if (e.key === 'Enter') confirmUrlPopup(); else if (e.key === 'Escape') cancelUrlPopup(); }}
    />
    <div class="url-popup-actions">
        <button class="btn btn-primary" onclick={confirmUrlPopup}>Apply</button>
        <button class="btn" onclick={cancelUrlPopup}>Cancel</button>
    </div>
</Modal>

{#if mentionPickerOpen}
    <div class="mention-picker" style={mentionPickerStyle} use:portal>
        <!-- Tabs -->
        <div class="mention-tabs" role="tablist">
            <button
                class="mention-tab"
                class:active={mentionActiveTab === 'roles'}
                role="tab"
                type="button"
                onmousedown={(e) => { e.preventDefault(); mentionActiveTab = 'roles'; }}
            >Roles</button>
            <button
                class="mention-tab"
                class:active={mentionActiveTab === 'users'}
                role="tab"
                type="button"
                onmousedown={(e) => {
                    e.preventDefault();
                    mentionActiveTab = 'users';
                    triggerUserSearch(mentionRoleSearch); // carry over whatever is in the roles filter
                }}
            >Users</button>
        </div>

        {#if mentionActiveTab === 'roles'}
            <div class="mention-search-row">
                <input
                    class="mention-search-input"
                    type="text"
                    placeholder="Filter roles…"
                    bind:value={mentionRoleSearch}
                    onmousedown={(e) => e.stopPropagation()}
                />
            </div>
            <div class="mention-list" role="listbox">
                {#each filteredRoleItems() as item}
                    <button class="mention-item" type="button" role="option" aria-selected="false" onmousedown={(e) => insertMention(e, item)}>
                        {#if item.color}
                            <span class="mention-role-dot" style="background: {item.color}"></span>
                        {:else}
                            <span class="mention-at-icon">@</span>
                        {/if}
                        <span>{item.label}</span>
                    </button>
                {/each}
                {#if filteredRoleItems().length === 0}
                    <div class="mention-empty">No roles found</div>
                {/if}
            </div>
        {:else}
            <div class="mention-search-row">
                <input
                    class="mention-search-input"
                    type="text"
                    placeholder="Search members…"
                    value={mentionUserSearch}
                    oninput={handleUserSearch}
                    onmousedown={(e) => e.stopPropagation()}
                />
                {#if mentionUserSearching}
                    <span class="mention-spinner"></span>
                {/if}
            </div>
            <div class="mention-list" role="listbox">
                {#each mentionUserResults as item}
                    <button class="mention-item" type="button" role="option" aria-selected="false" onmousedown={(e) => insertMention(e, item)}>
                        {#if item.avatar}
                            <img class="mention-user-avatar" src={item.avatar} alt={item.label} />
                        {:else}
                            <span class="mention-user-icon">&#x1F464;</span>
                        {/if}
                        <span>{item.label}</span>
                    </button>
                {/each}
                {#if mentionUserResults.length === 0 && !mentionUserSearching}
                    <div class="mention-empty">
                        {mentionUserSearch.length < 2 ? 'Type 2+ characters to search' : 'No members found'}
                    </div>
                {/if}
            </div>
        {/if}
    </div>
{/if}

<!-- Delete Confirm -->
<ConfirmDialog
    bind:isOpen={confirmDeleteOpen}
    title="Delete Notification"
    message={'Delete notification "' + (deleteTarget?.name || '') + '"?'}
    confirmLabel="Delete"
    variant="danger"
    onconfirm={confirmDeleteNotification}
/>

<!-- Mobile Detail Modal -->
<Modal bind:isOpen={showMobileDetailModal} title={mobileDetailNotif?.name || 'Notification'}>
    {#if mobileDetailNotif}
        <div class="mobile-detail-content">
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Status</span>
                <button
                    class="badge-btn"
                    class:badge-success={mobileDetailNotif.is_active}
                    class:badge-danger={!mobileDetailNotif.is_active}
                    onclick={() => toggleActive(mobileDetailNotif)}
                >
                    {mobileDetailNotif.is_active ? 'Active' : 'Inactive'}
                </button>
            </div>
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Type</span>
                <span class="badge" class:badge-accent={mobileDetailNotif.guild_id} class:badge-purple={!mobileDetailNotif.guild_id}>
                    {mobileDetailNotif.guild_id ? 'Server' : 'Private'}
                </span>
            </div>
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Pattern</span>
                <span>{formatPattern(mobileDetailNotif.pattern)}</span>
            </div>
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Repeat</span>
                <span>{formatRepeat(mobileDetailNotif.repeat_status, mobileDetailNotif.repeat_frequency)}</span>
            </div>
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Trigger Time</span>
                <span class="mono">{String(mobileDetailNotif.hour ?? 0).padStart(2, '0')}:{String(mobileDetailNotif.minute ?? 0).padStart(2, '0')} UTC</span>
            </div>
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Next Trigger</span>
                <span>
                    {#if mobileDetailNotif.is_active && mobileDetailNotif.next_trigger}
                        {tick >= 0 ? formatRelativeTime(mobileDetailNotif.next_trigger) : ''}
                        <span class="detail-sub">{formatFullTimestamp(mobileDetailNotif.next_trigger)}</span>
                    {:else}
                        -
                    {/if}
                </span>
            </div>
            {#if mobileDetailNotif.last_trigger}
                <div class="mobile-detail-row">
                    <span class="mobile-detail-label">Last Triggered</span>
                    <span>{formatFullTimestamp(mobileDetailNotif.last_trigger)}</span>
                </div>
            {/if}
            {#if mobileDetailNotif.message_content}
                <div class="mobile-detail-row detail-row-vertical">
                    <span class="mobile-detail-label">Message</span>
                    <span class="detail-text-block">{mobileDetailNotif.message_content}</span>
                </div>
            {/if}
            {#if mobileDetailNotif.embed_toggle}
                <div class="mobile-detail-row">
                    <span class="mobile-detail-label">Embed</span>
                    <span class="badge badge-accent">Enabled</span>
                </div>
                {#if mobileDetailNotif.title}
                    <div class="mobile-detail-row">
                        <span class="mobile-detail-label">Title</span>
                        <span>{mobileDetailNotif.title}</span>
                    </div>
                {/if}
            {/if}
        </div>
        <div class="mobile-detail-actions">
            <button class="btn btn-sm btn-primary" onclick={() => { showMobileDetailModal = false; openEditForm(mobileDetailNotif); }}>
                <Icon name="edit" size={14} /> Edit
            </button>
            <button class="btn btn-sm btn-danger" onclick={() => { showMobileDetailModal = false; deleteNotification(mobileDetailNotif); }}>
                <Icon name="delete" size={14} /> Delete
            </button>
        </div>
    {/if}
</Modal>
<style>
    .notif-layout {
        display: flex;
        gap: 20px;
        height: calc(100vh - 180px);
        overflow: hidden;
    }
    .server-list {
        width: 260px;
        flex-shrink: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
        overflow-y: auto;
        scrollbar-width: none;
    }
    .server-list::-webkit-scrollbar { display: none; }
    .server-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        cursor: pointer;
        font-family: inherit;
        text-align: left;
        width: 100%;
        color: var(--color-text-primary);
        transition: all 0.15s ease;
    }
    .server-item:hover {
        border-color: var(--color-border-accent);
        background: var(--color-card-hover);
    }
    .server-item.active {
        border-color: var(--color-accent);
        background: var(--color-accent-soft);
    }
    .server-icon {
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        background: var(--color-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        color: var(--color-accent);
        overflow: hidden;
    }
    .server-icon img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .server-info { min-width: 0; }
    .server-name {
        font-weight: 600;
        font-size: 14px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .server-meta {
        font-size: 12px;
        color: var(--color-text-muted);
        margin-top: 2px;
    }
    .notif-detail {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }
    .detail-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 16px;
        padding-bottom: 16px;
        margin-bottom: 4px;
        flex-shrink: 0;
        border-bottom: 1px solid var(--color-border);
    }
    .detail-title {
        font-size: 20px;
        font-weight: 700;
        margin: 8px 0 4px;
    }
    .detail-stats {
        display: flex;
        gap: 16px;
        font-size: 13px;
        color: var(--color-text-muted);
    }
    .header-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
    }
    .back-btn { display: none; }
    .table-scroll {
        flex: 1;
        overflow-y: auto;
        margin-top: 12px;
        border-radius: var(--radius-lg);
        scrollbar-width: none;
    }
    .table-scroll::-webkit-scrollbar { width: 0; }
    .notif-name-cell {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }
    .notif-name { font-weight: 500; }
    .notif-time-hint {
        font-size: 11px;
        color: var(--color-text-muted);
    }
    .detail-value-sm {
        font-size: 12px;
        color: var(--color-text-secondary);
    }
    .next-trigger-cell { cursor: help; }
    .text-muted { color: var(--color-text-muted); }
    .badge-btn {
        display: inline-flex;
        align-items: center;
        padding: 3px 12px;
        border-radius: 99px;
        font-size: 11px;
        font-weight: 600;
        border: none;
        cursor: pointer;
        font-family: inherit;
        transition: all 0.15s ease;
    }
    .badge-btn:hover { filter: brightness(1.2); }
    .badge-success { background: var(--color-success-soft); color: var(--color-success); }
    .badge-danger { background: var(--color-danger-soft); color: var(--color-danger); }
    .badge-accent { background: var(--color-accent-soft); color: var(--color-accent); }
    .badge-purple { background: rgba(168, 85, 247, 0.15); color: #a855f7; }
    .form-hint {
        font-size: 11px;
        color: var(--color-text-muted);
        font-weight: 400;
        display: block;
        margin-bottom: 2px;
    }
    .form-section-divider {
        display: flex;
        align-items: center;
        gap: 12px;
        margin: 20px 0 14px;
        font-size: 12px;
        font-weight: 600;
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .form-section-divider::after {
        content: '';
        flex: 1;
        height: 1px;
        background: var(--color-border);
        order: 1;
    }
    .section-toggle {
        order: 2;
        font-size: 12px;
        font-weight: 500;
        text-transform: none;
        letter-spacing: normal;
        white-space: nowrap;
    }
    .color-input-row {
        display: flex;
        gap: 8px;
        align-items: center;
    }
    .color-picker {
        width: 40px;
        height: 36px;
        padding: 2px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        background: var(--color-secondary);
        cursor: pointer;
        flex-shrink: 0;
    }
    .color-input-row input[type="text"] { flex: 1; }
    .datetime-input-group {
        display: flex;
        align-items: center;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        padding: 6px 10px;
        width: 100%;
        transition: border-color 0.2s;
    }
    .datetime-input-group:focus-within {
        border-color: var(--color-accent);
    }
    .datetime-input-group input {
        text-align: center;
        background: transparent;
        border: none;
        color: var(--color-text);
        font-size: 0.95rem;
        font-family: monospace;
        padding: 4px 0;
        outline: none;
        caret-color: var(--color-accent);
    }
    .datetime-input-group input:focus {
        background: rgba(99, 139, 255, 0.12);
        border-radius: 3px;
    }
    .datetime-input-group input::placeholder {
        color: var(--color-text-muted);
    }
    .dt-year { width: 44px; }
    .dt-month, .dt-day, .dt-hour, .dt-minute { width: 28px; }
    .dt-sep {
        color: var(--color-text-muted);
        font-size: 0.95rem;
        font-weight: 600;
        font-family: monospace;
        user-select: none;
        padding: 0 3px;
    }
    .dt-spacer { width: 16px; }
    .form-label-text {
        font-size: 13px;
        font-weight: 500;
        color: var(--color-text-secondary);
    }
    .datetime-field {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    .weekly-days-picker {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    .weekday-buttons {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
    }
    .weekday-btn {
        padding: 6px 14px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-secondary);
        font-size: 13px;
        font-weight: 500;
        font-family: inherit;
        cursor: pointer;
        transition: all 0.15s ease;
    }
    .weekday-btn:hover {
        border-color: var(--color-border-accent);
        color: var(--color-text-primary);
    }
    .weekday-btn.active {
        background: var(--color-accent);
        border-color: var(--color-accent);
        color: white;
    }
    .interval-row { gap: 10px; }
    .interval-row label { flex: 1; min-width: 70px; }
    .mobile-detail-content {
        display: flex;
        flex-direction: column;
        gap: 0;
    }
    .mobile-detail-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 0;
        border-bottom: 1px solid var(--color-border);
        gap: 12px;
    }
    .mobile-detail-row:last-child { border-bottom: none; }
    .detail-row-vertical {
        flex-direction: column;
        align-items: flex-start;
        gap: 4px;
    }
    .mobile-detail-label {
        font-size: 13px;
        color: var(--color-text-muted);
        font-weight: 500;
        flex-shrink: 0;
    }
    .detail-sub {
        display: block;
        font-size: 11px;
        color: var(--color-text-muted);
        margin-top: 2px;
    }
    .detail-text-block {
        font-size: 13px;
        color: var(--color-text-secondary);
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 120px;
        overflow-y: auto;
    }
    .mobile-detail-actions {
        display: flex;
        gap: 8px;
        margin-top: 16px;
        justify-content: flex-end;
    }
    @media (max-width: 768px) {
        .notif-layout {
            flex-direction: column;
            height: auto;
        }
        .server-list {
            width: 100%;
            max-height: none;
            overflow-y: visible;
        }
        .notif-detail {
            display: none;
            overflow: visible;
        }
        .notif-layout.detail-active .server-list { display: none; }
        .notif-layout.detail-active .notif-detail { display: flex; }
        .table-scroll { overflow-y: visible; }
        .back-btn { display: inline-flex; }
        .mobile-hide { display: none; }
        .notif-row { cursor: pointer; }
        .notif-row:active { background: var(--color-accent-soft); }
    }
    .mention-picker {
        position: fixed;
        z-index: 9999;
        background: var(--color-surface, #1e2130);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md, 8px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
        display: flex;
        flex-direction: column;
        width: 260px;
        max-width: 95vw;
        overflow: hidden;
    }
    .mention-tabs {
        display: flex;
        border-bottom: 1px solid var(--color-border);
        flex-shrink: 0;
    }
    .mention-tab {
        flex: 1;
        padding: 7px 10px;
        background: transparent;
        border: none;
        color: var(--color-text-muted, #8b8fa8);
        cursor: pointer;
        font-size: 0.8rem;
        font-weight: 500;
        font-family: inherit;
        transition: color 0.1s ease, background 0.1s ease;
    }
    .mention-tab.active {
        color: var(--color-accent, #638bff);
        box-shadow: inset 0 -2px 0 var(--color-accent, #638bff);
    }
    .mention-tab:hover:not(.active) {
        background: var(--color-accent-soft, rgba(99, 139, 255, 0.08));
    }
    .mention-search-row {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 8px;
        border-bottom: 1px solid var(--color-border);
        flex-shrink: 0;
    }
    .mention-search-input {
        flex: 1;
        background: var(--color-surface-2, #252a3a);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm, 4px);
        color: var(--color-text);
        font-size: 0.8rem;
        font-family: inherit;
        padding: 4px 8px;
        outline: none;
        min-width: 0;
    }
    .mention-search-input:focus {
        border-color: var(--color-accent, #638bff);
    }
    .mention-list {
        max-height: 180px;
        overflow-y: auto;
        padding: 4px;
        display: flex;
        flex-direction: column;
        gap: 1px;
    }
    .mention-empty {
        padding: 10px;
        font-size: 0.8rem;
        color: var(--color-text-muted, #8b8fa8);
        text-align: center;
    }
    .mention-spinner {
        width: 14px;
        height: 14px;
        border: 2px solid var(--color-border);
        border-top-color: var(--color-accent, #638bff);
        border-radius: 50%;
        animation: spin 0.6s linear infinite;
        flex-shrink: 0;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .mention-item {
        display: flex;
        align-items: center;
        gap: 8px;
        width: 100%;
        padding: 7px 10px;
        background: transparent;
        border: none;
        color: var(--color-text);
        cursor: pointer;
        text-align: left;
        border-radius: var(--radius-sm, 4px);
        font-size: 0.875rem;
        font-family: inherit;
        transition: background 0.1s ease;
    }
    .mention-item:hover {
        background: var(--color-accent-soft, rgba(99, 139, 255, 0.15));
    }
    .mention-role-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
        flex-shrink: 0;
    }
    .mention-user-avatar {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        flex-shrink: 0;
        object-fit: cover;
    }
    .mention-user-icon {
        width: 14px;
        font-size: 12px;
        flex-shrink: 0;
        text-align: center;
        opacity: 0.8;
    }
    .mention-at-icon {
        width: 10px;
        font-size: 11px;
        font-weight: 700;
        color: var(--color-accent);
        flex-shrink: 0;
        text-align: center;
    }
    /* Contenteditable mention editor — matches app.css textarea/input styles */
    .mention-editor {
        display: block;
        width: 100%;
        min-height: 72px; /* ~3 rows */
        padding: 8px 12px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 14px;
        font-family: inherit;
        line-height: 1.5;
        outline: none;
        resize: vertical;
        overflow: auto;
        white-space: pre-wrap;
        word-break: break-word;
        overflow-wrap: break-word;
        cursor: text;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .mention-editor:focus {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }
    .mention-editor:empty::before {
        content: attr(data-placeholder);
        color: var(--color-text-muted);
        pointer-events: none;
    }
    /* Discord-style mention chip inside the editor */
    :global(.mention-chip) {
        display: inline;
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-radius: 3px;
        padding: 0 3px;
        font-weight: 500;
        cursor: default;
        user-select: all;
        white-space: nowrap;
    }

    /* ── Validation errors ────────────────────────────────────────────── */
    .is-invalid {
        border-color: var(--color-danger) !important;
        box-shadow: 0 0 0 3px var(--color-danger-soft) !important;
    }
    .field-error-msg {
        display: block;
        color: var(--color-danger);
        font-size: 12px;
        margin-top: 4px;
    }
    .embed-error-msg {
        margin: 0 0 8px;
    }

    /* ── Embed preview card (Discord-style layout) ──────────────────── */
    .embed-color-row {
        order: 2;
        text-transform: none;
        letter-spacing: normal;
        width: 160px;
        flex-shrink: 0;
    }
    .embed-preview-card {
        border-left: 4px solid var(--color-accent);
        border-top: 1px solid var(--color-border);
        border-right: 1px solid var(--color-border);
        border-bottom: 1px solid var(--color-border);
        border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
        background: var(--color-card);
        padding: 12px 16px;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    /* Base style for all ep-* inputs */
    .ep-input {
        width: 100%;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
        font-family: inherit;
        padding: 5px 8px;
        outline: none;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }
    .ep-input:focus {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }
    .ep-title { font-size: 15px; font-weight: 600; }
    .ep-author, .ep-footer { font-size: 12px; }
    /* Author row */
    .ep-top-section {
        display: flex;
        gap: 10px;
        align-items: flex-start;
    }
    .ep-top-main {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 8px;
        min-width: 0;
    }
    .ep-row-lead {
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 1;
        min-width: 0;
    }
    .ep-icon-dot {
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        flex-shrink: 0;
    }
    .ep-icon-sm { width: 14px; height: 14px; }
    /* Thumbnail */
    .ep-thumbnail {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
        align-self: flex-start;
    }
    .ep-thumbnail-box {
        width: 80px;
        height: 80px;
        border-radius: var(--radius-sm);
        background-color: var(--color-secondary);
        border: 1px solid var(--color-border);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: border-color 0.15s ease, opacity 0.15s ease;
        position: relative;
    }
    .ep-thumbnail-box:hover {
        border-color: var(--color-accent);
        opacity: 0.9;
    }
    .ep-thumbnail-icon {
        font-size: 28px;
        font-weight: 300;
        color: var(--color-text-muted);
        pointer-events: none;
        user-select: none;
        line-height: 1;
    }
    /* Description inherits .mention-editor, just override height */
    .ep-description { min-height: 64px; }
    /* Fields */
    .ep-field-item {
        display: flex;
        gap: 8px;
        align-items: flex-start;
    }
    .ep-field-body {
        display: flex;
        flex-direction: column;
        gap: 4px;
        flex: 1;
        min-width: 0;
    }
    .ep-field-value {
        min-height: 40px;
        resize: vertical;
    }
    .ep-field-meta {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        flex-shrink: 0;
        padding-top: 2px;
    }
    .ep-add-field-btn { align-self: flex-start; }
    .ep-field-count {
        font-size: 11px;
        color: var(--color-text-muted);
        margin-left: 6px;
    }
    /* Image area */
    .ep-image-area {
        min-height: 100px;
        background-color: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 6px;
        cursor: pointer;
        overflow: hidden;
        transition: border-color 0.15s ease, opacity 0.15s ease;
    }
    .ep-image-area:hover {
        border-color: var(--color-accent);
        opacity: 0.9;
    }
    .ep-image-area--filled {
        min-height: unset;
        padding: 0;
        background-color: transparent;
    }
    .ep-image-preview {
        display: block;
        width: 100%;
        border-radius: var(--radius-sm);
        max-height: 300px;
        object-fit: cover;
    }
    .ep-image-placeholder-icon {
        font-size: 36px;
        font-weight: 300;
        color: var(--color-text-muted);
        pointer-events: none;
        user-select: none;
        line-height: 1;
    }
    /* Footer row */
    .ep-footer-row {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    /* URL popup modal content */
    .url-popup-input {
        width: 100%;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
        font-family: inherit;
        padding: 7px 10px;
        outline: none;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
        margin-bottom: 12px;
    }
    .url-popup-input:focus {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }
    .url-popup-actions {
        display: flex;
        gap: 8px;
        justify-content: flex-end;
    }
    /* Placeholder for contenteditable mention editors */
    .mention-editor[data-placeholder]:empty::before {
        content: attr(data-placeholder);
        color: var(--color-text-muted);
        pointer-events: none;
        font-style: italic;
    }
    /* Inline checkbox + remove button */
    .embed-field-inline {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 12px;
        color: var(--color-text-secondary);
        cursor: pointer;
        white-space: nowrap;
    }
    .btn-icon-remove {
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        padding: 4px 6px;
        border-radius: var(--radius-sm);
        font-size: 13px;
        line-height: 1;
        transition: color 0.15s ease, background 0.15s ease;
    }
    .btn-icon-remove:hover {
        color: var(--color-danger);
        background: var(--color-danger-soft);
    }

    .form-loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 14px;
        padding: 60px 24px;
        color: var(--color-text-muted, #8b8fa8);
        font-size: 0.9rem;
    }
    .form-loading-spinner {
        width: 36px;
        height: 36px;
        border: 3px solid var(--color-border);
        border-top-color: var(--color-accent, #638bff);
        border-radius: 50%;
        animation: spin 0.7s linear infinite;
    }
</style>