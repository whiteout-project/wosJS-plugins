<script>
    import { onMount } from 'svelte';
    import { getBasePath } from '../lib/api.js';
    import { showToast } from '../lib/utils.js';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import Select from '../components/ui/Select.svelte';

    let { slug = '' } = $props();

    const basePath = getBasePath();
    let isLoading = $state(true);
    let list = $state(null);
    let selectedCategory = $state('');
    let playerId = $state('');
    let allianceTag = $state('');
    let selectedSlotIds = $state([]);
    let pendingSlotId = $state('');
    let isSubmitting = $state(false);
    let errorMessage = $state('');
    let successMessage = $state('');

    onMount(async () => {
        await loadList();
    });

    async function loadList() {
        isLoading = true;
        errorMessage = '';
        try {
            const response = await fetch(`${basePath}/api/public/position-reservations/${encodeURIComponent(slug)}`);
            const data = await response.json().catch(() => null);
            if (!response.ok || !data) {
                throw new Error(data?.error || 'Reservation list is unavailable');
            }
            list = data;
            if (!selectedCategory && data.categories[0]?.category) {
                selectedCategory = data.categories[0].category;
            }
            const availableIds = new Set(getSelectedSlots().map((slot) => slot.id));
            selectedSlotIds = selectedSlotIds.filter((id) => availableIds.has(id));
            if (!availableIds.has(pendingSlotId)) {
                pendingSlotId = '';
            }
        } catch (error) {
            errorMessage = error.message;
        } finally {
            isLoading = false;
        }
    }

    function getSelectedCategory() {
        return list?.categories?.find((category) => category.category === selectedCategory) || null;
    }

    function getSelectedSlots() {
        return (getSelectedCategory()?.slots || []).filter((slot) => slot.status === 'available');
    }

    function getSlotOptions() {
        return getSelectedSlots()
            .filter((slot) => !selectedSlotIds.includes(slot.id))
            .map((slot) => ({
                value: slot.id,
                label: formatSlot(slot),
            }));
    }

    function getSelectedSlotObjects() {
        const selectedIds = new Set(selectedSlotIds);
        return getSelectedSlots().filter((slot) => selectedIds.has(slot.id));
    }

    function getSelectedSlotLimit() {
        return Math.max(1, Number(getSelectedCategory()?.allowedSlotCount || 1));
    }

    function isSlotSelected(slotId) {
        return selectedSlotIds.includes(slotId);
    }

    function toggleSlotSelection(slotId) {
        const limit = getSelectedSlotLimit();

        if (isSlotSelected(slotId)) {
            selectedSlotIds = selectedSlotIds.filter((id) => id !== slotId);
            return;
        }

        if (selectedSlotIds.length >= limit) {
            if (limit === 1) {
                errorMessage = '';
                selectedSlotIds = [slotId];
                return;
            }

            const message = `You can select up to ${limit} slot${limit === 1 ? '' : 's'} for this category.`;
            errorMessage = message;
            showToast(message, 'error');
            return;
        }

        errorMessage = '';
        selectedSlotIds = [...selectedSlotIds, slotId];
        pendingSlotId = '';
    }

    function handleSlotSelect(slotId) {
        if (!slotId) return;
        const limit = getSelectedSlotLimit();
        if (limit === 1) {
            errorMessage = '';
            selectedSlotIds = [slotId];
            pendingSlotId = slotId;
            return;
        }

        pendingSlotId = slotId;
    }

    function addPendingSlot() {
        if (!pendingSlotId) return;
        toggleSlotSelection(pendingSlotId);
    }

    function removeSelectedSlot(slotId) {
        selectedSlotIds = selectedSlotIds.filter((id) => id !== slotId);
        if (pendingSlotId === slotId) {
            pendingSlotId = '';
        }
    }

    function formatUtcShort(isoString) {
        if (!isoString) return '--:--';
        return new Date(isoString).toISOString().slice(11, 16);
    }

    function formatSlot(slot) {
        return `${formatUtcShort(slot.startsAtUtc)} - ${formatUtcShort(slot.endsAtUtc)} UTC`;
    }

    async function submitReservation() {
        if (!selectedCategory || !selectedSlotIds.length) return;
        isSubmitting = true;
        successMessage = '';
        errorMessage = '';

        try {
            const response = await fetch(`${basePath}/api/public/position-reservations/${encodeURIComponent(slug)}/reserve`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    category: selectedCategory,
                    slotIds: selectedSlotIds,
                    playerId,
                    allianceTag,
                }),
            });

            const data = await response.json().catch(() => null);
            if (!response.ok || !data) {
                throw new Error(data?.error || 'Failed to reserve slot');
            }

            const reservedSlots = getSelectedSlots().filter((slot) => selectedSlotIds.includes(slot.id));
            const selectionCount = reservedSlots.length || selectedSlotIds.length;
            const reservedLabel = selectionCount === 1
                ? (reservedSlots[0] ? formatSlot(reservedSlots[0]) : 'the selected slot')
                : `${selectionCount} selected slots`;
            successMessage = `Reserved ${getSelectedCategory()?.label || selectedCategory} for ${playerId.trim()} (${allianceTag.trim().toUpperCase()}) at ${reservedLabel}.`;
            list = data.list;
            selectedSlotIds = [];
            playerId = '';
            allianceTag = '';
            showToast(selectionCount === 1 ? 'Slot reserved successfully' : 'Slots reserved successfully', 'success');
        } catch (error) {
            errorMessage = error.message;
            showToast(error.message, 'error');
            await loadList();
        } finally {
            isSubmitting = false;
        }
    }
</script>

<div class="public-shell">
    <div class="hero-card">
        <div>
            <h1>State {list?.stateNumber || '--'}</h1>
        </div>
    </div>

    {#if isLoading}
        <div class="panel"><div class="skeleton" style="height: 240px;"></div></div>
    {:else if errorMessage && !list}
        <div class="panel error-panel">
            <h2>Unavailable</h2>
            <p>{errorMessage}</p>
        </div>
    {:else}
        <div class="panel">
            <div class="category-grid">
                {#each list.categories as category (category.category)}
                    <button
                        class="category-card"
                        class:active={selectedCategory === category.category}
                        onclick={() => {
                            selectedCategory = category.category;
                            selectedSlotIds = [];
                            pendingSlotId = '';
                            successMessage = '';
                            errorMessage = '';
                        }}
                    >
                        <div class="category-label">{category.label}</div>
                        <strong>{category.positionName}</strong>
                        <p>Up to {category.allowedSlotCount || 1} slot{(category.allowedSlotCount || 1) === 1 ? '' : 's'} per player</p>
                        <span>{category.slots.length} open slots</span>
                    </button>
            {/each}
        </div>

            {#if getSelectedCategory()}
                <div class="reservation-panel">
                    {#if successMessage}
                        <div class="notice success">{successMessage}</div>
                    {/if}
                    {#if errorMessage}
                        <div class="notice error">{errorMessage}</div>
                    {/if}

                    <div class="form-grid">
                        <label>
                            <span>Player ID</span>
                            <input type="text" bind:value={playerId} maxlength="32" placeholder="Enter player ID" />
                        </label>
                        <label>
                            <span>Alliance Tag</span>
                            <input type="text" bind:value={allianceTag} maxlength="12" placeholder="Enter alliance tag" />
                        </label>
                    </div>

                    {#if getSelectedSlots().length > 0}
                        <div class="slot-select-panel">
                            <label>
                                <span>Available Slots</span>
                                <Select
                                    value={getSelectedSlotLimit() === 1 ? (selectedSlotIds[0] || '') : pendingSlotId}
                                    options={getSlotOptions()}
                                    placeholder="Choose a slot"
                                    onchange={handleSlotSelect}
                                    class="slot-select"
                                />
                            </label>

                            {#if getSelectedSlotLimit() > 1}
                                <button
                                    class="btn add-slot-button"
                                    type="button"
                                    disabled={!pendingSlotId || selectedSlotIds.length >= getSelectedSlotLimit()}
                                    onclick={addPendingSlot}
                                >
                                    <Icon name="plus" size={14} /> Add Slot
                                </button>
                            {/if}
                        </div>
                    {:else}
                        <div class="empty-slots">No available slots remain for this category.</div>
                    {/if}

                    {#if selectedSlotIds.length > 0}
                        <div class="selected-slots">
                            {#each getSelectedSlotObjects() as slot (slot.id)}
                                <div class="selected-slot-row">
                                    <span>{formatSlot(slot)}</span>
                                    <button
                                        class="selected-slot-remove"
                                        type="button"
                                        aria-label="Remove selected slot"
                                        onclick={() => removeSelectedSlot(slot.id)}
                                    >
                                        <Icon name="close" size={14} />
                                    </button>
                                </div>
                            {/each}
                        </div>
                    {/if}

                    <LoadingButton
                        class="btn btn-primary"
                        loading={isSubmitting}
                        disabled={!selectedSlotIds.length || !playerId.trim() || !allianceTag.trim()}
                        onclick={submitReservation}
                    >
                        <Icon name="check" size={14} /> Reserve Selected Slot{selectedSlotIds.length === 1 ? '' : 's'}
                    </LoadingButton>
                </div>
            {/if}
        </div>
    {/if}
</div>

<style>
    .public-shell {
        min-height: 100dvh;
        background:
            radial-gradient(circle at top left, rgba(148, 163, 184, 0.08), transparent 28%),
            radial-gradient(circle at top right, rgba(96, 165, 250, 0.05), transparent 20%),
            linear-gradient(180deg, var(--color-canvas-2), var(--color-canvas));
        color: var(--color-text-primary);
        padding: 24px;
    }

    .hero-card,
    .panel,
    .category-card {
        border: 1px solid rgba(255, 244, 232, 0.08);
        background:
            linear-gradient(180deg, rgba(255, 244, 232, 0.035), transparent 22%),
            color-mix(in oklab, var(--color-panel) 95%, black);
        backdrop-filter: blur(14px);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-panel), var(--shadow-inset);
    }

    .hero-card {
        max-width: 1080px;
        margin: 0 auto 20px;
        padding: 24px;
        display: flex;
        justify-content: space-between;
        gap: 16px;
        align-items: start;
    }

    .category-card p,
    .category-card span,
    label span,
    .empty-slots {
        color: var(--color-text-muted);
    }

    h1,
    h2,
    p {
        margin: 0;
    }

    .hero-card h1 {
        font-size: clamp(28px, 4vw, 42px);
        margin: 6px 0;
        letter-spacing: -0.04em;
    }

    .panel {
        max-width: 1080px;
        margin: 0 auto;
        padding: 24px;
    }

    .category-grid,
    .form-grid {
        display: grid;
        gap: 14px;
    }

    .category-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .category-card {
        text-align: left;
        padding: 18px;
        transition:
            transform 0.18s var(--ease-out),
            border-color 0.18s var(--ease-out),
            background-color 0.18s var(--ease-out),
            box-shadow 0.18s var(--ease-out);
    }

    .category-card.active,
    .category-card:hover {
        border-color: rgba(207, 215, 230, 0.18);
        transform: translateY(-1px);
        box-shadow: var(--shadow-glow);
    }

    .category-label {
        font-size: 12px;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--color-accent-strong);
        margin-bottom: 8px;
    }

    .reservation-panel {
        margin-top: 22px;
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .form-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    label {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    input {
        width: 100%;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        padding: 11px 12px;
    }

    .slot-select-panel {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
        gap: 12px;
    }

    .selected-slots {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .selected-slot-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: rgba(255, 244, 232, 0.03);
        color: var(--color-text-primary);
    }

    .selected-slot-remove {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 30px;
        height: 30px;
        border: 1px solid var(--color-border);
        border-radius: 999px;
        background: transparent;
        color: var(--color-text-secondary);
        cursor: pointer;
    }

    .selected-slot-remove:hover {
        color: var(--color-text-primary);
        border-color: var(--color-border-accent);
    }

    .add-slot-button {
        justify-content: center;
    }

    :global(.slot-select) {
        width: 100%;
    }

    :global(.slot-select .custom-select) {
        width: 100%;
    }

    :global(.slot-select .select-trigger) {
        width: 100%;
    }

    .notice {
        border-radius: var(--radius-md);
        padding: 12px 14px;
        font-size: 14px;
    }

    .notice.success {
        background: var(--color-success-soft);
        color: var(--color-success);
    }

    .notice.error,
    .error-panel {
        background: var(--color-danger-soft);
        color: var(--color-danger);
    }

    @media (max-width: 768px) {
        .public-shell {
            padding: 16px;
        }

        .hero-card,
        .form-grid,
        .category-grid {
            grid-template-columns: 1fr;
            display: grid;
        }

        .hero-card {
            display: grid;
        }

        :global(.btn.btn-primary) {
            width: 100%;
        }
    }
</style>
