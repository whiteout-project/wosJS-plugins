<script>
    import PageHeader from '../components/ui/PageHeader.svelte';
    import BuildingsCalc from './calculators/BuildingsCalc.svelte';
    import WarAcademyCalc from './calculators/WarAcademyCalc.svelte';
    import ResearchCalc from './calculators/ResearchCalc.svelte';

    const TABS = [
        { id: 'buildings', label: 'Buildings' },
        { id: 'war-academy', label: 'War Academy' },
        { id: 'research', label: 'Research' },
    ];

    let activeTab = $state('buildings');
</script>

<div class="calculators-page">
    <PageHeader title="Calculators" subtitle="Calculate resource costs and upgrade times" />

    <div class="calc-tabs">
        {#each TABS as tab (tab.id)}
            <button
                class="calc-tab"
                class:active={activeTab === tab.id}
                onclick={() => { activeTab = tab.id; }}
            >
                {tab.label}
            </button>
        {/each}
    </div>

    <div class="calc-content">
        {#if activeTab === 'buildings'}
            <BuildingsCalc />
        {:else if activeTab === 'war-academy'}
            <WarAcademyCalc />
        {:else if activeTab === 'research'}
            <ResearchCalc />
        {/if}
    </div>
</div>

<style>
    .calculators-page {
        display: flex;
        flex-direction: column;
        gap: 0;
    }

    .calc-tabs {
        display: flex;
        gap: 4px;
        padding: 0 0 20px;
        border-bottom: 1px solid var(--color-border);
        margin-bottom: 24px;
        flex-wrap: wrap;
    }

    .calc-tab {
        padding: 8px 20px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
    }

    .calc-tab:hover {
        background: var(--color-card-hover);
        color: var(--color-text-primary);
        border-color: var(--color-border-accent);
    }

    .calc-tab.active {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }
</style>
