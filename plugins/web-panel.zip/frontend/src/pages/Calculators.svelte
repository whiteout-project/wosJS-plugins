<script>
    import { selectedGameType } from '../lib/stores.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import BuildingsCalc from './calculators/BuildingsCalc.svelte';
    import FlameTech from './calculators/FlameTech.svelte';
    import WarAcademyCalc from './calculators/WarAcademyCalc.svelte';
    import ResearchCalc from './calculators/ResearchCalc.svelte';

    const TABS = [
        { id: 'buildings', label: 'Buildings' },
        { id: 'war-academy', label: 'War Academy' },
        { id: 'research', label: 'Research' },
        { id: 'flametech', label: 'Flame Tech' },
    ];

    let activeTab = $state('buildings');
    let visibleTabs = $derived(
        $selectedGameType === 'ks'
            ? TABS.filter(tab => tab.id === 'buildings' || tab.id === 'war-academy')
            : TABS
    );

    $effect(() => {
        if (!visibleTabs.some(tab => tab.id === activeTab)) {
            activeTab = visibleTabs[0]?.id || 'buildings';
        }
    });
</script>

<div class="calculators-page">
    <PageHeader title="Calculators" subtitle="Calculate resource costs and upgrade times" />

    <div class="calc-tabs">
        {#each visibleTabs as tab (tab.id)}
            <button
                class="calc-tab"
                class:active={activeTab === tab.id}
                onclick={() => { activeTab = tab.id; }}
            >
                {tab.label}
            </button>
        {/each}
    </div>

    <div class="calc-content">
        {#if activeTab === 'buildings'}
            {#key `buildings:${$selectedGameType}`}
                <BuildingsCalc />
            {/key}
        {:else if activeTab === 'war-academy'}
            {#key `war-academy:${$selectedGameType}`}
                <WarAcademyCalc />
            {/key}
        {:else if activeTab === 'research'}
            <ResearchCalc />
        {:else if activeTab === 'flametech'}
            <FlameTech />
        {/if}
    </div>
</div>

<style>
    .calculators-page {
        display: flex;
        flex-direction: column;
        gap: 0;
    }

    .calc-tabs {
        display: flex;
        gap: 4px;
        padding: 0 0 20px;
        border-bottom: 1px solid var(--color-border);
        margin-bottom: 24px;
        flex-wrap: wrap;
    }

    .calc-tab {
        padding: 8px 20px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
    }

    .calc-tab:hover {
        background: var(--color-card-hover);
        color: var(--color-text-primary);
        border-color: var(--color-border-accent);
    }

    .calc-tab.active {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }
</style>
