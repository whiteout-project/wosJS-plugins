<script>
    import { onMount } from 'svelte';
    import { getBasePath } from '../lib/api.js';
    import Icon from '../components/ui/Icon.svelte';

    let { slug = '' } = $props();

    const basePath = getBasePath();
    let isLoading = $state(true);
    let isUnlocking = $state(false);
    let guide = $state(null);
    let errorMessage = $state('');
    let accessChallenge = $state(null);
    let guidePassword = $state('');
    let activeImageViewer = $state(null);
    let headingEntries = $derived(getGuideHeadingEntries(guide?.blocks || []));

    onMount(() => {
        void loadGuide();
    });

    async function loadGuide() {
        isLoading = true;
        errorMessage = '';
        accessChallenge = null;
        try {
            const response = await fetch(`${basePath}/api/public/guides/${encodeURIComponent(slug)}`, {
                credentials: 'same-origin',
            });
            const data = await response.json().catch(() => null);
            if (!response.ok || !data) {
                if ((response.status === 401 || response.status === 403) && data?.accessMode) {
                    accessChallenge = data;
                    guide = null;
                    clearOAuthQuery();
                    return;
                }
                throw new Error(data?.error || 'Guide is unavailable');
            }
            guide = data;
            guidePassword = '';
            clearOAuthQuery();
        } catch (error) {
            errorMessage = error.message;
        } finally {
            isLoading = false;
        }
    }

    function clearOAuthQuery() {
        if (typeof window === 'undefined') return;
        if (!window.location.search.includes('oauth=complete')) return;
        const nextUrl = window.location.pathname + window.location.hash;
        window.history.replaceState({}, '', nextUrl || '/');
    }

    async function unlockGuideWithPassword() {
        if (!guidePassword.trim()) {
            errorMessage = 'Enter the guide password first';
            return;
        }

        isUnlocking = true;
        errorMessage = '';
        try {
            const response = await fetch(`${basePath}/api/public/guides/${encodeURIComponent(slug)}/unlock`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ password: guidePassword }),
            });
            const data = await response.json().catch(() => null);
            if (!response.ok) {
                if (data?.accessMode) accessChallenge = data;
                throw new Error(data?.error || 'Unable to unlock guide');
            }
            await loadGuide();
        } catch (error) {
            errorMessage = error.message;
        } finally {
            isUnlocking = false;
        }
    }

    function startGuideLogin() {
        if (typeof window === 'undefined') return;
        window.location.href = `${basePath}/auth/guide-login?slug=${encodeURIComponent(slug)}`;
    }

    function getChallengeTitle() {
        if (accessChallenge?.accessMode === 'password') return 'Password Required';
        if (accessChallenge?.accessMode === 'discord_bot_user') return 'Discord Login Required';
        if (accessChallenge?.accessMode === 'discord_mutual_guild') return 'Shared Server Required';
        return 'Guide Unavailable';
    }

    function getChallengeMessage() {
        if (accessChallenge?.accessMode === 'password') {
            return 'Enter the guide password to continue.';
        }
        if (accessChallenge?.accessMode === 'discord_bot_user') {
            return accessChallenge?.authenticated
                ? (accessChallenge?.error || 'You must already be a bot user to view this guide.')
                : 'Log in with Discord to confirm that you are already a bot user.';
        }
        if (accessChallenge?.accessMode === 'discord_mutual_guild') {
            return accessChallenge?.authenticated
                ? (accessChallenge?.error || 'You must share a server with this bot to view this guide.')
                : 'Log in with Discord to confirm that you share a server with this bot.';
        }
        return accessChallenge?.error || 'This guide is not currently available.';
    }

    function shouldShowDiscordLoginButton() {
        if (!accessChallenge) return false;
        if (!['discord_bot_user', 'discord_mutual_guild'].includes(accessChallenge.accessMode)) return false;
        return !accessChallenge.authenticated;
    }

    async function logoutGuideViewer() {
        if (typeof window === 'undefined') return;
        errorMessage = '';
        try {
            await fetch(`${basePath}/auth/logout`, {
                method: 'POST',
                credentials: 'same-origin',
            });
        } catch {
            // Best effort; a reload still gives the browser a chance to clear state if logout succeeded.
        }
        window.location.href = `${basePath}/g/${encodeURIComponent(slug)}`;
    }

    function formatPublishedAt(value) {
        if (!value) return '';
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return '';
        return date.toLocaleDateString(undefined, {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    }

    function escapeHtml(value) {
        return String(value || '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#39;');
    }

    function escapeHtmlAttr(value) {
        return escapeHtml(value);
    }

    function formatInlineRichText(value) {
        const linkTokens = [];
        let output = String(value || '');

        output = output.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_match, label, url) => {
            const safeUrl = escapeHtmlAttr(url);
            const safeLabel = escapeHtml(label);
            const token = `@@LINK_${linkTokens.length}@@`;
            linkTokens.push(`<a href="${safeUrl}" target="_blank" rel="noreferrer">${safeLabel}</a>`);
            return token;
        });

        output = escapeHtml(output);
        output = output.replace(/(https?:\/\/[^\s<]+)/g, (match) => {
            const safeUrl = escapeHtmlAttr(match);
            return `<a href="${safeUrl}" target="_blank" rel="noreferrer">${safeUrl}</a>`;
        });
        output = output.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

        linkTokens.forEach((html, index) => {
            output = output.replace(`@@LINK_${index}@@`, html);
        });

        return output;
    }

    function renderRichText(content) {
        const lines = String(content || '').replace(/\r\n/g, '\n').split('\n');
        let html = '';
        let paragraphLines = [];

        function flushParagraph() {
            if (!paragraphLines.length) return;
            html += `<p>${paragraphLines.map((line) => formatInlineRichText(line)).join('<br>')}</p>`;
            paragraphLines = [];
        }

        for (const rawLine of lines) {
            const line = rawLine ?? '';
            const listMatch = line.match(/^(\s*)(?:-|•)\s+(.*)$/);

            if (listMatch) {
                flushParagraph();
                const indent = listMatch[1] || '';
                const indentSize = indent.replace(/\t/g, '  ').length;
                const depth = Math.min(3, Math.floor(indentSize / 2) + 1);
                html += `<div class="rich-list depth-${depth}"><span class="rich-bullet">•</span><span class="rich-list-content">${formatInlineRichText(listMatch[2] || '')}</span></div>`;
                continue;
            }

            if (!line.trim()) {
                flushParagraph();
                if (html) {
                    html += '<div class="rich-spacer" aria-hidden="true"></div>';
                }
                continue;
            }

            paragraphLines.push(line);
        }

        flushParagraph();
        return html || '<p></p>';
    }

    function getGuideMediaUrl(assetId) {
        const normalized = String(assetId || '').trim();
        if (!normalized) return '';
        return `${basePath}/api/public/guide-media/${encodeURIComponent(normalized)}`;
    }

    function getBlockImageUrl(payload) {
        if (!payload || typeof payload !== 'object') return '';
        const source = String(payload.source || '').trim().toLowerCase();
        if (source === 'upload' && payload.assetId) {
            return getGuideMediaUrl(payload.assetId);
        }
        return payload.imageUrl || '';
    }

    function slugifyHeading(text) {
        const base = String(text || '')
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
        return base || 'section';
    }

    function getGuideHeadingEntries(blocks) {
        const seen = new Map();
        const entries = [];
        for (const block of blocks || []) {
            if (block.blockType !== 'heading') continue;
            const label = String(block.payload?.text || '').trim();
            if (!label) continue;
            const base = slugifyHeading(label);
            const nextCount = (seen.get(base) || 0) + 1;
            seen.set(base, nextCount);
            entries.push({
                blockId: block.id,
                label,
                level: Math.max(1, Math.min(4, Number(block.payload?.level) || 2)),
                anchorId: nextCount === 1 ? `guide-heading-${base}` : `guide-heading-${base}-${nextCount}`,
            });
        }
        return entries;
    }

    function getHeadingAnchorId(block, blocks) {
        return getGuideHeadingEntries(blocks).find((entry) => entry.blockId === block.id)?.anchorId || '';
    }

    function scrollToGuideHeading(anchorId, event) {
        event?.preventDefault?.();
        const target = typeof document !== 'undefined' ? document.getElementById(anchorId) : null;
        if (!target) return;
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function openImageViewer(block) {
        const imageUrl = getBlockImageUrl(block?.payload);
        if (!imageUrl) return;
        activeImageViewer = {
            src: imageUrl,
            alt: block?.payload?.alt || '',
            caption: block?.payload?.caption || '',
        };
    }

    function closeImageViewer() {
        activeImageViewer = null;
    }

    function handleViewerKeydown(event) {
        if (event.key === 'Escape' && activeImageViewer) {
            closeImageViewer();
        }
    }

</script>

<svelte:window onkeydown={handleViewerKeydown} />

<div class="guide-public-shell">
    {#if isLoading}
        <div class="guide-public-card muted-state">Loading guide...</div>
    {:else if accessChallenge}
        <div class="guide-public-card muted-state locked-state">
            <div class="locked-icon">
                <Icon name={accessChallenge.accessMode === 'password' ? 'lock' : 'shield'} size={22} />
            </div>
            <h1>{accessChallenge.guideMeta?.title || getChallengeTitle()}</h1>
            {#if accessChallenge.guideMeta?.summary}
                <p class="guide-summary">{accessChallenge.guideMeta.summary}</p>
            {/if}
            <p>{getChallengeMessage()}</p>
            {#if errorMessage}
                <p class="guide-meta">{errorMessage}</p>
            {/if}
            {#if accessChallenge.authenticated && accessChallenge.viewerUsername}
                <div class="guide-account-row">
                    <span class="guide-account-label">Logged in as <strong>{accessChallenge.viewerUsername}</strong></span>
                    <button class="guide-logout-button" type="button" onclick={logoutGuideViewer}>Log out</button>
                </div>
            {/if}

            {#if accessChallenge.accessMode === 'password'}
                <div class="locked-actions">
                    <input
                        type="password"
                        bind:value={guidePassword}
                        maxlength="120"
                        placeholder="Enter guide password"
                        onkeydown={(event) => event.key === 'Enter' && !isUnlocking && unlockGuideWithPassword()}
                    />
                    <button class="guide-auth-button" type="button" disabled={isUnlocking} onclick={unlockGuideWithPassword}>
                        {isUnlocking ? 'Checking...' : 'Unlock Guide'}
                    </button>
                </div>
            {:else if shouldShowDiscordLoginButton()}
                <div class="locked-actions">
                    <button class="guide-auth-button" type="button" onclick={startGuideLogin}>
                        Continue with Discord
                    </button>
                </div>
            {/if}
        </div>
    {:else if errorMessage || !guide}
        <div class="guide-public-card muted-state">
            <h1>Guide Unavailable</h1>
            <p>{errorMessage || 'This guide is not currently available.'}</p>
        </div>
    {:else}
        <article class="guide-public-card guide-article">
            <header class="guide-hero">
                <h1>{guide.title}</h1>
                {#if guide.summary}
                    <p class="guide-summary">{guide.summary}</p>
                {/if}
                {#if formatPublishedAt(guide.publishedAt)}
                    <div class="guide-meta">Published {formatPublishedAt(guide.publishedAt)}</div>
                {/if}
            </header>

            <div class="guide-blocks">
                {#each guide.blocks || [] as block (block.id)}
                    {#if block.blockType === 'heading'}
                        {@const HeadingTag = `h${Math.max(1, Math.min(4, Number(block.payload?.level) || 2))}`}
                        <svelte:element this={HeadingTag} id={getHeadingAnchorId(block, guide?.blocks || [])} class={`guide-heading heading-${block.payload?.level || 2}`}>
                            {block.payload?.text}
                        </svelte:element>
                    {:else if block.blockType === 'text'}
                        <div class="guide-text rendered-rich-text">{@html renderRichText(block.payload?.content)}</div>
                    {:else if block.blockType === 'image'}
                        <figure class="guide-image-block" style={`--guide-image-width: ${Math.max(20, Math.min(100, Number(block.payload?.width || 100)))}%;`}>
                            <button
                                class="guide-image-trigger"
                                type="button"
                                onclick={() => openImageViewer(block)}
                                aria-label={block.payload?.caption ? `Open image: ${block.payload.caption}` : 'Open image'}
                            >
                                <img src={getBlockImageUrl(block.payload)} alt={block.payload?.alt || ''} loading="lazy" />
                            </button>
                            {#if block.payload?.caption}
                                <figcaption>{block.payload.caption}</figcaption>
                            {/if}
                        </figure>
                    {:else if block.blockType === 'button'}
                        <div class="guide-button-row">
                            <a
                                class={`guide-link-button style-${block.payload?.style || 'primary'}`}
                                href={block.payload?.url}
                                target="_blank"
                                rel="noreferrer"
                            >
                                {block.payload?.label}
                            </a>
                        </div>
                    {:else if block.blockType === 'divider'}
                        <hr class="guide-divider" />
                    {:else if block.blockType === 'collapsible'}
                        <details class="guide-collapsible">
                            <summary>{block.payload?.title}</summary>
                            <div class="guide-text">{block.payload?.content}</div>
                        </details>
                    {:else if block.blockType === 'table'}
                        <div class="guide-table-wrap">
                            <table class="guide-table">
                                <thead>
                                    <tr>
                                        {#each block.payload?.headers || [] as header}
                                            <th>{header}</th>
                                        {/each}
                                    </tr>
                                </thead>
                                <tbody>
                                     {#each block.payload?.rows || [] as row}
                                         <tr>
                                             {#each row as cell}
                                                 <td><span class:table-empty-cell={!cell}>{cell || 'Empty'}</span></td>
                                             {/each}
                                         </tr>
                                     {/each}
                                 </tbody>
                             </table>
                        </div>
                    {:else if block.blockType === 'table_of_contents'}
                        <nav class="guide-toc" aria-label="Table of contents">
                            <div class="guide-toc-title">{block.payload?.title || 'Table of contents'}</div>
                            {#if headingEntries.length}
                                <div class="guide-toc-list">
                                    {#each headingEntries as entry}
                                        <button class={`guide-toc-link level-${entry.level}`} type="button" onclick={(event) => scrollToGuideHeading(entry.anchorId, event)}>
                                            {entry.label}
                                        </button>
                                    {/each}
                                </div>
                            {:else}
                                <p class="guide-toc-empty">Add heading sections to generate a table of contents.</p>
                            {/if}
                        </nav>
                    {/if}
                {/each}
            </div>
        </article>
    {/if}
</div>

{#if activeImageViewer}
    <div class="guide-image-viewer" role="dialog" aria-modal="true" aria-label="Image preview" tabindex="-1">
        <button class="guide-image-viewer-backdrop" type="button" onclick={closeImageViewer} aria-label="Close image preview"></button>
        <button class="guide-image-viewer-close" type="button" onclick={closeImageViewer} aria-label="Close image preview">
            <Icon name="x" size={18} />
        </button>
        <div class="guide-image-viewer-stage">
            <img src={activeImageViewer.src} alt={activeImageViewer.alt} />
            {#if activeImageViewer.caption}
                <p class="guide-image-viewer-caption">{activeImageViewer.caption}</p>
            {/if}
        </div>
    </div>
{/if}

<style>
    .guide-public-shell {
        min-height: 100dvh;
        padding: 32px 18px 60px;
        background:
            radial-gradient(circle at top, rgba(148, 163, 184, 0.08), transparent 32%),
            linear-gradient(180deg, var(--color-canvas-2), var(--color-canvas));
    }

    .guide-public-card {
        width: min(920px, 100%);
        margin: 0 auto;
        background:
            linear-gradient(180deg, rgba(255, 244, 232, 0.04), transparent 18%),
            color-mix(in oklab, var(--color-panel) 95%, black);
        border: 1px solid rgba(255, 244, 232, 0.08);
        border-radius: 28px;
        padding: 28px;
        box-shadow: var(--shadow-lg), var(--shadow-inset);
    }

    .guide-hero {
        display: grid;
        gap: 12px;
        padding-bottom: 24px;
        border-bottom: 1px solid var(--color-border-subtle);
    }

    h1 {
        margin: 0;
        font-size: clamp(30px, 5vw, 54px);
        line-height: 1.05;
        color: var(--color-text-primary);
        letter-spacing: -0.05em;
    }

    .guide-summary,
    figcaption,
    .guide-meta {
        color: var(--color-text-secondary);
        line-height: 1.7;
    }

    .guide-summary {
        max-width: 60ch;
        font-size: 18px;
    }

    .guide-meta {
        font-size: 14px;
    }

    .guide-account-row {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        flex-wrap: wrap;
        margin-top: 6px;
        color: var(--color-text-secondary);
        font-size: 14px;
    }

    .guide-account-label strong {
        color: var(--color-text-primary);
        font-weight: 600;
    }

    .guide-logout-button {
        border: 1px solid var(--color-border-subtle);
        background: color-mix(in oklab, var(--color-panel-elevated) 88%, black);
        color: var(--color-text-primary);
        border-radius: 999px;
        padding: 8px 14px;
        font: inherit;
        cursor: pointer;
        transition:
            border-color 160ms ease,
            background-color 160ms ease,
            transform 160ms ease;
    }

    .guide-logout-button:hover {
        border-color: var(--color-border-strong);
        transform: translateY(-1px);
    }

    .guide-blocks {
        display: grid;
        gap: 22px;
        padding-top: 26px;
    }

    .guide-heading {
        margin: 0;
        color: var(--color-text-primary);
        line-height: 1.15;
        letter-spacing: -0.04em;
    }

    .heading-1 { font-size: 40px; }
    .heading-2 { font-size: 32px; }
    .heading-3 { font-size: 24px; }
    .heading-4 { font-size: 20px; }

    .guide-text {
        font-size: 16px;
    }

    .rendered-rich-text :global(p) {
        margin: 0;
        line-height: 1.85;
    }

    .rendered-rich-text :global(p + p) {
        margin-top: 6px;
    }

    .rendered-rich-text :global(.rich-list) {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        margin: 1px 0;
    }

    .rendered-rich-text :global(.rich-list.depth-2) {
        padding-left: 24px;
    }

    .rendered-rich-text :global(.rich-list.depth-3) {
        padding-left: 48px;
    }

    .rendered-rich-text :global(.rich-bullet) {
        flex: 0 0 auto;
        width: 12px;
        text-align: center;
        line-height: 1.85;
        font-size: 15px;
        color: var(--color-accent-strong);
    }

    .rendered-rich-text :global(.rich-list-content) {
        min-width: 0;
        line-height: 1.85;
    }

    .rendered-rich-text :global(.rich-spacer) {
        height: 1.1em;
    }

    .rendered-rich-text :global(strong) {
        font-weight: 700;
        color: var(--color-text-primary);
    }

    .rendered-rich-text :global(a) {
        color: var(--color-accent-strong);
        text-decoration: underline;
        text-underline-offset: 2px;
        word-break: break-word;
    }

    .rendered-rich-text :global(a:hover) {
        color: var(--color-accent-hover);
    }

    .guide-image-block {
        margin: 0;
        display: grid;
        gap: 8px;
    }

    .guide-image-trigger {
        width: var(--guide-image-width, 100%);
        max-width: 100%;
        display: block;
        padding: 0;
        margin: 0;
        border: 0;
        background: transparent;
        cursor: zoom-in;
    }

    .guide-image-block img {
        width: 100%;
        max-width: 100%;
        max-height: 420px;
        display: block;
        border-radius: 12px;
        object-fit: contain;
        border: 1px solid rgba(255, 255, 255, 0.06);
        transition:
            transform 0.18s var(--ease-out),
            border-color 0.18s var(--ease-out),
            box-shadow 0.18s var(--ease-out);
    }

    .guide-image-trigger:hover img {
        transform: translateY(-2px);
        border-color: color-mix(in srgb, var(--color-accent) 26%, rgba(255, 255, 255, 0.08));
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
    }

    .guide-image-viewer {
        position: fixed;
        inset: 0;
        z-index: 1200;
        display: grid;
        place-items: center;
        padding: 24px;
    }

    .guide-image-viewer-backdrop {
        position: absolute;
        inset: 0;
        border: 0;
        background:
            radial-gradient(circle at top, rgba(96, 165, 250, 0.12), transparent 30%),
            rgba(4, 7, 12, 0.88);
        backdrop-filter: blur(12px);
        cursor: zoom-out;
    }

    .guide-image-viewer-stage {
        position: relative;
        z-index: 1;
        display: grid;
        justify-items: center;
        gap: 14px;
        width: 100%;
        max-width: min(92vw, 1500px);
        max-height: calc(100dvh - 48px);
        pointer-events: none;
    }

    .guide-image-viewer-close {
        position: absolute;
        top: 20px;
        right: 20px;
        z-index: 2;
        width: 40px;
        height: 40px;
        display: grid;
        place-items: center;
        border-radius: 999px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        background: rgba(8, 11, 18, 0.82);
        color: var(--color-text-primary);
        cursor: pointer;
        transition:
            transform 0.16s var(--ease-out),
            border-color 0.16s var(--ease-out),
            background-color 0.16s var(--ease-out);
    }

    .guide-image-viewer-close:hover {
        transform: translateY(-1px);
        border-color: color-mix(in srgb, var(--color-accent) 24%, rgba(255, 255, 255, 0.12));
    }

    .guide-image-viewer-stage img {
        max-width: 100%;
        max-height: calc(100dvh - 120px);
        width: auto;
        height: auto;
        display: block;
        object-fit: contain;
        border-radius: 14px;
        box-shadow: 0 36px 120px rgba(0, 0, 0, 0.42);
        pointer-events: auto;
    }

    .guide-image-viewer-caption {
        margin: 0;
        color: var(--color-text-primary);
        font-size: 14px;
        line-height: 1.6;
        text-align: center;
        max-width: min(72ch, 92vw);
        pointer-events: auto;
    }

    figcaption {
        font-size: 14px;
        line-height: 1.6;
    }

    .guide-button-row {
        display: flex;
        justify-content: flex-start;
    }

    .guide-link-button {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 48px;
        padding: 0 20px;
        border-radius: var(--radius-pill);
        text-decoration: none;
        font-weight: 700;
        transition:
            transform 0.16s var(--ease-out),
            opacity 0.16s var(--ease-out),
            border-color 0.16s var(--ease-out),
            background-color 0.16s var(--ease-out);
    }

    .guide-link-button:hover {
        transform: translateY(-1px);
        opacity: 0.96;
    }

    .style-primary {
        background: linear-gradient(135deg, var(--color-accent), var(--color-accent-strong));
        color: var(--color-accent-ink);
        border: 1px solid rgba(255, 255, 255, 0.12);
    }

    .style-secondary {
        background: rgba(255, 244, 232, 0.05);
        color: var(--color-text-primary);
        border: 1px solid rgba(255, 244, 232, 0.09);
    }

    .style-ghost {
        background: transparent;
        color: var(--color-accent-strong);
        border: 1px solid rgba(207, 215, 230, 0.24);
    }

    .guide-divider {
        width: 100%;
        border: 0;
        border-top: 1px solid var(--color-border-subtle);
    }

    .guide-collapsible {
        padding: 16px 18px;
        border-radius: 18px;
        border: 1px solid rgba(255, 244, 232, 0.08);
        background: rgba(255, 244, 232, 0.02);
    }

    .guide-collapsible summary {
        cursor: pointer;
        font-weight: 700;
        color: var(--color-text-primary);
    }

    .guide-collapsible .guide-text {
        margin-top: 12px;
    }

    .guide-table-wrap {
        overflow-x: auto;
        border: 1px solid rgba(255, 244, 232, 0.08);
        border-radius: 18px;
        background: rgba(255, 244, 232, 0.02);
    }

    .guide-table {
        width: 100%;
        min-width: 480px;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .guide-table th,
    .guide-table td {
        padding: 14px 16px;
        text-align: left;
        vertical-align: top;
        border-bottom: 1px solid var(--color-border-subtle);
        overflow-wrap: anywhere;
        word-break: break-word;
        hyphens: auto;
    }

    .guide-table th {
        color: var(--color-text-primary);
        font-size: 13px;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        background: rgba(255, 244, 232, 0.04);
    }

    .guide-table td {
        color: var(--color-text-secondary);
        line-height: 1.7;
    }

    .table-empty-cell {
        display: block;
        color: var(--color-text-muted);
        overflow-wrap: anywhere;
        word-break: break-word;
    }

    .guide-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .guide-toc {
        display: grid;
        gap: 12px;
        padding: 18px 20px;
        border: 1px solid rgba(255, 244, 232, 0.08);
        border-radius: 18px;
        background: rgba(255, 244, 232, 0.02);
        justify-items: start;
    }

    .guide-toc-title {
        color: var(--color-text-primary);
        font-size: 15px;
        font-weight: 700;
    }

    .guide-toc-list {
        display: grid;
        gap: 8px;
        width: 100%;
        justify-items: start;
    }

    .guide-toc-link {
        width: 100%;
        display: block;
        padding: 0;
        border: 0;
        appearance: none;
        background: transparent;
        color: var(--color-text-secondary);
        font: inherit;
        text-align: left;
        text-decoration: none;
        line-height: 1.55;
        cursor: pointer;
        justify-self: start;
    }

    .guide-toc-link:hover {
        color: var(--color-accent-strong);
    }

    .guide-toc-link.level-3 {
        padding-left: 18px;
    }

    .guide-toc-link.level-4 {
        padding-left: 36px;
    }

    .guide-toc-empty {
        margin: 0;
        color: var(--color-text-muted);
    }

    .muted-state {
        min-height: 220px;
        display: grid;
        place-content: center;
        text-align: center;
        gap: 10px;
    }

    .locked-state {
        justify-items: center;
        text-align: center;
    }

    .locked-icon {
        width: 54px;
        height: 54px;
        display: grid;
        place-items: center;
        border-radius: 18px;
        color: var(--color-text-primary);
        background: color-mix(in srgb, var(--color-secondary) 85%, transparent);
        border: 1px solid var(--color-border-subtle);
    }

    .locked-actions {
        width: min(420px, 100%);
        display: grid;
        gap: 12px;
        margin-top: 10px;
    }

    .locked-actions input {
        width: 100%;
    }

    .guide-auth-button {
        min-height: 48px;
        padding: 0 18px;
        border: 1px solid color-mix(in srgb, var(--color-accent) 55%, transparent);
        border-radius: var(--radius-pill);
        background: linear-gradient(135deg, var(--color-accent), var(--color-accent-strong));
        color: var(--color-accent-ink);
        font: inherit;
        font-weight: 700;
        cursor: pointer;
        transition:
            transform 0.16s var(--ease-out),
            opacity 0.16s var(--ease-out),
            border-color 0.16s var(--ease-out);
    }

    .guide-auth-button:hover:not(:disabled) {
        transform: translateY(-1px);
        opacity: 0.96;
    }

    .guide-auth-button:disabled {
        opacity: 0.6;
        cursor: wait;
    }

    .muted-state h1,
    .muted-state p {
        margin: 0;
    }

    @media (max-width: 720px) {
        .guide-public-shell {
            padding: 18px 12px 40px;
        }

        .guide-public-card {
            padding: 20px 16px;
            border-radius: 22px;
        }

        .guide-summary {
            font-size: 16px;
        }

        .guide-link-button {
            width: 100%;
        }

        .guide-image-viewer {
            padding: 12px;
        }

        .guide-image-viewer-stage {
            max-width: 100%;
            max-height: calc(100dvh - 24px);
        }

        .guide-image-viewer-close {
            top: 12px;
            right: 12px;
        }

    }
</style>
