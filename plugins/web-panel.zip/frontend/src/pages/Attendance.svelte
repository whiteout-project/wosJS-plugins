<script>
    import { onMount } from 'svelte';
    import { apiFetch, downloadFile } from '../lib/api.js';
    import { immersivePage } from '../lib/stores.js';
    import { showToast } from '../lib/utils.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import Select from '../components/ui/Select.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';
    import Icon from '../components/ui/Icon.svelte';

    const STATUS_LABELS = {
        unassigned: 'Alliance Members',
        attended: 'Attended',
        absent: 'Absent',
    };

    let alliances = $state([]);
    let records = $state([]);
    let detail = $state(null);
    let analysis = $state(null);
    let selectedAllianceId = $state('');
    let workspaceRecordId = $state('');
    let analysisAllianceId = $state('');
    let memberSearch = $state('');
    let draggedFid = $state(null);
    let savingPlayerIds = $state({});
    let isLoading = $state(true);
    let isLoadingAnalysis = $state(false);
    let isCreating = $state(false);
    let isSavingMeta = $state(false);
    let isDeleting = $state(false);
    let isExportingAnalysis = $state(false);
    let showCreateModal = $state(false);
    let showEditModal = $state(false);
    let showDeleteDialog = $state(false);
    let createForm = $state(getEmptyForm());
    let editForm = $state(getEmptyForm());
    let analysisFilters = $state({
        startDate: '',
        endDate: '',
    });
    let immersiveRecordId = $derived(getImmersiveRecordId($immersivePage));
    let immersiveAnalysisAllianceId = $derived(getImmersiveAnalysisAllianceId($immersivePage));
    let activeWorkspaceRecordId = $derived(workspaceRecordId || immersiveRecordId);
    let activeAnalysisAllianceId = $derived(analysisAllianceId || immersiveAnalysisAllianceId);
    let isRecordWorkspaceMode = $derived(!!activeWorkspaceRecordId);
    let isAnalysisMode = $derived(!activeWorkspaceRecordId && !!activeAnalysisAllianceId);
    let isImmersiveMode = $derived(isRecordWorkspaceMode || isAnalysisMode);
    let analysisLoadedForActiveAlliance = $derived(
        !!analysis
        && String(analysis?.alliance?.id || '') === String(activeAnalysisAllianceId || '')
    );

    let allianceOptions = $derived(alliances.map(alliance => ({
        value: String(alliance.id),
        label: alliance.name || 'Unnamed',
    })));
    let recordAllianceIds = $derived(new Set(records.map(record => String(record.allianceId))));
    let recordAllianceOptions = $derived([
        { value: '', label: 'All record alliances' },
        ...alliances
            .filter(alliance => recordAllianceIds.has(String(alliance.id)))
            .map(alliance => ({
                value: String(alliance.id),
                label: alliance.name || 'Unnamed',
            })),
    ]);
    let showRecordAllianceFilter = $derived(recordAllianceOptions.length > 1);
    let selectedAlliance = $derived(alliances.find(alliance => String(alliance.id) === String(selectedAllianceId)));
    let canAnalyzeSelectedAlliance = $derived(!!selectedAllianceId);
    let visibleRecords = $derived(
        selectedAllianceId
            ? records.filter(record => String(record.allianceId) === String(selectedAllianceId))
            : records
    );
    let normalizedMemberSearch = $derived(memberSearch.trim().toLowerCase());
    let unassignedPlayers = $derived(
        (detail?.players?.filter(player => player.status === 'unassigned') || [])
            .filter(player => {
                if (!normalizedMemberSearch) return true;
                return String(player.fid || '').toLowerCase().includes(normalizedMemberSearch) ||
                    String(player.nickname || '').toLowerCase().includes(normalizedMemberSearch);
            })
    );
    let attendedPlayers = $derived(detail?.players?.filter(player => player.status === 'attended') || []);
    let absentPlayers = $derived(detail?.players?.filter(player => player.status === 'absent') || []);

    onMount(async () => {
        if (immersiveRecordId) {
            workspaceRecordId = immersiveRecordId;
            await Promise.all([
                loadAttendance(),
                loadRecordDetail(immersiveRecordId),
            ]);
            return;
        }
        if (immersiveAnalysisAllianceId) {
            analysisAllianceId = immersiveAnalysisAllianceId;
            selectedAllianceId = String(immersiveAnalysisAllianceId);
            await Promise.all([
                loadAttendance(),
                loadAnalysis(immersiveAnalysisAllianceId),
            ]);
            return;
        }
        await loadAttendance();
    });

    function todayDate() {
        return new Date().toISOString().slice(0, 10);
    }

    function getEmptyForm() {
        return {
            title: '',
            eventDate: todayDate(),
            allianceId: '',
        };
    }

    function getImmersiveRecordId(value) {
        if (typeof value !== 'string') return '';
        const match = value.match(/^attendance-record:(.+)$/);
        return match ? match[1] : '';
    }

    function getImmersiveAnalysisAllianceId(value) {
        if (typeof value !== 'string') return '';
        const match = value.match(/^attendance-analysis:(.+)$/);
        return match ? match[1] : '';
    }

    async function loadAttendance() {
        isLoading = true;
        try {
            const data = await apiFetch('/api/attendance/alliances');
            alliances = Array.isArray(data) ? data : [];
            await loadRecords();
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    async function loadRecords() {
        const data = await apiFetch('/api/attendance/records');
        records = Array.isArray(data) ? data : [];
        if (selectedAllianceId && !records.some(record => String(record.allianceId) === String(selectedAllianceId))) {
            selectedAllianceId = '';
        }
    }

    function selectAlliance(value) {
        selectedAllianceId = String(value || '');
    }

    function openCreateModal() {
        createForm = {
            ...getEmptyForm(),
            allianceId: selectedAllianceId || String(alliances[0]?.id || ''),
        };
        showCreateModal = true;
    }

    async function createRecord() {
        isCreating = true;
        try {
            const data = await apiFetch('/api/attendance/records', {
                method: 'POST',
                body: {
                    title: createForm.title || 'Untitled Event',
                    eventDate: createForm.eventDate || todayDate(),
                    allianceId: createForm.allianceId,
                },
            });
            if (data) {
                applyDetail(data);
                await loadRecords();
                showCreateModal = false;
                openWorkspace(data.id);
                showToast('Attendance record created', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isCreating = false;
        }
    }

    async function openWorkspace(recordId) {
        analysisAllianceId = '';
        analysis = null;
        workspaceRecordId = recordId;
        immersivePage.set(`attendance-record:${recordId}`);
        await loadRecordDetail(recordId);
    }

    function closeWorkspace() {
        workspaceRecordId = '';
        analysisAllianceId = '';
        detail = null;
        analysis = null;
        memberSearch = '';
        draggedFid = null;
        immersivePage.set('');
    }

    async function loadRecordDetail(recordId) {
        try {
            const data = await apiFetch(`/api/attendance/records/${recordId}`);
            if (data) applyDetail(data);
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    function applyDetail(data) {
        detail = normalizeDetail(data);
        workspaceRecordId = detail.id;
        upsertRecordSummary(detail);
    }

    function buildAnalysisQuery(allianceId, filters = analysisFilters) {
        const params = new URLSearchParams({
            allianceId: String(allianceId || ''),
        });

        if (filters.startDate) params.set('startDate', filters.startDate);
        if (filters.endDate) params.set('endDate', filters.endDate);

        return params.toString();
    }

    async function openAnalysisWorkspace(allianceId) {
        if (!allianceId) return;

        workspaceRecordId = '';
        detail = null;
        analysis = null;
        analysisFilters = { startDate: '', endDate: '' };
        analysisAllianceId = String(allianceId);
        selectedAllianceId = String(allianceId);
        immersivePage.set(`attendance-analysis:${allianceId}`);
        await loadAnalysis(allianceId, { startDate: '', endDate: '' });
    }

    async function loadAnalysis(allianceId = activeAnalysisAllianceId, filters = analysisFilters) {
        if (!allianceId) return;

        isLoadingAnalysis = true;
        try {
            const data = await apiFetch(`/api/attendance/analysis?${buildAnalysisQuery(allianceId, filters)}`);
            if (!data) {
                closeWorkspace();
                return;
            }

            analysis = data;
            analysisAllianceId = String(data.alliance?.id || allianceId);
            analysisFilters = {
                startDate: data.filters?.startDate || '',
                endDate: data.filters?.endDate || '',
            };
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoadingAnalysis = false;
        }
    }

    async function applyAnalysisFilters() {
        if (!activeAnalysisAllianceId) return;
        await loadAnalysis(activeAnalysisAllianceId, analysisFilters);
    }

    async function clearAnalysisFilters() {
        analysisFilters = { startDate: '', endDate: '' };
        if (!activeAnalysisAllianceId) return;
        await loadAnalysis(activeAnalysisAllianceId, { startDate: '', endDate: '' });
    }

    async function exportAnalysisCsv() {
        if (!activeAnalysisAllianceId) return;

        isExportingAnalysis = true;
        try {
            const allianceName = selectedAlliance?.name || analysis?.alliance?.name || 'attendance';
            await downloadFile(
                `/api/attendance/analysis/export?${buildAnalysisQuery(activeAnalysisAllianceId, analysisFilters)}`,
                `${allianceName.replace(/[^a-z0-9-_]+/gi, '-').toLowerCase()}-attendance-analysis.csv`
            );
            showToast('Attendance analysis exported', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isExportingAnalysis = false;
        }
    }

    function normalizeDetail(data) {
        const players = Array.isArray(data?.players) ? data.players : [];
        const counts = countPlayers(players);
        return {
            ...data,
            players,
            playerCount: counts.playerCount,
            attendedCount: counts.attendedCount,
            absentCount: counts.absentCount,
            unassignedCount: counts.unassignedCount,
        };
    }

    function countPlayers(players) {
        return {
            playerCount: players.length,
            attendedCount: players.filter(player => player.status === 'attended').length,
            absentCount: players.filter(player => player.status === 'absent').length,
            unassignedCount: players.filter(player => player.status === 'unassigned').length,
        };
    }

    function upsertRecordSummary(record) {
        const summary = {
            id: record.id,
            gameType: record.gameType,
            allianceId: record.allianceId,
            allianceName: record.allianceName,
            alliancePriority: record.alliancePriority,
            title: record.title,
            eventDate: record.eventDate,
            updatedAt: record.updatedAt,
            playerCount: record.playerCount,
            attendedCount: record.attendedCount,
            absentCount: record.absentCount,
            unassignedCount: record.unassignedCount,
        };
        const existingIndex = records.findIndex(item => item.id === record.id);
        records = existingIndex >= 0
            ? records.map(item => item.id === record.id ? summary : item)
            : [summary, ...records];
    }

    function openEditModal() {
        if (!detail) return;
        editForm = {
            title: detail.title,
            eventDate: detail.eventDate,
            allianceId: String(detail.allianceId),
        };
        showEditModal = true;
    }

    async function saveMetadata() {
        if (!detail) return;
        isSavingMeta = true;
        try {
            const data = await apiFetch(`/api/attendance/records/${detail.id}`, {
                method: 'PATCH',
                body: {
                    title: editForm.title,
                    eventDate: editForm.eventDate,
                },
            });
            if (data) {
                applyDetail(data);
                showEditModal = false;
                showToast('Attendance record updated', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isSavingMeta = false;
        }
    }

    async function deleteRecord() {
        if (!detail) return;
        isDeleting = true;
        try {
            const recordId = detail.id;
            const data = await apiFetch(`/api/attendance/records/${recordId}`, { method: 'DELETE' });
            if (data) {
                records = records.filter(record => record.id !== recordId);
                closeWorkspace();
                showToast('Attendance record deleted', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isDeleting = false;
        }
    }

    function updatePlayerLocally(fid, status) {
        if (!detail) return detail;
        const players = detail.players.map(player =>
            String(player.fid) === String(fid) ? { ...player, status } : player
        );
        const nextDetail = normalizeDetail({ ...detail, players });
        detail = nextDetail;
        upsertRecordSummary(nextDetail);
        return nextDetail;
    }

    async function movePlayer(player, targetStatus) {
        if (!detail || !player) return;
        const nextStatus = player.status === targetStatus ? 'unassigned' : targetStatus;
        if (player.status === nextStatus) return;

        const previousDetail = JSON.parse(JSON.stringify(detail));
        savingPlayerIds = { ...savingPlayerIds, [player.fid]: true };
        updatePlayerLocally(player.fid, nextStatus);

        try {
            const data = await apiFetch(`/api/attendance/records/${detail.id}/players/${encodeURIComponent(player.fid)}/status`, {
                method: 'PUT',
                body: { status: nextStatus },
            });
            if (data) applyDetail(data);
        } catch (error) {
            detail = previousDetail;
            upsertRecordSummary(previousDetail);
            showToast(error.message, 'error');
        } finally {
            const { [player.fid]: _removed, ...rest } = savingPlayerIds;
            savingPlayerIds = rest;
        }
    }

    function handleDragStart(event, player) {
        draggedFid = player.fid;
        event.dataTransfer?.setData('text/plain', String(player.fid));
        if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
    }

    function handleDragOver(event) {
        event.preventDefault();
        if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    }

    function handleDrop(event, status) {
        event.preventDefault();
        const fid = draggedFid || event.dataTransfer?.getData('text/plain');
        const player = detail?.players?.find(item => String(item.fid) === String(fid));
        draggedFid = null;
        if (player) void movePlayer(player, status);
    }

    function formatState(value) {
        if (value === null || value === undefined || value === '') return '-';
        const parsed = Number(value);
        return Number.isFinite(parsed) ? String(Math.trunc(parsed)) : String(value);
    }

    function formatRecordDate(value) {
        if (!value) return '';
        const date = new Date(`${value}T00:00:00`);
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    }

    function formatPercent(value) {
        const numeric = Math.round((Number(value) || 0) * 10) / 10;
        return `${Number.isInteger(numeric) ? numeric.toFixed(0) : numeric.toFixed(1)}%`;
    }

    function formatGameContext(value) {
        return String(value || 'wos').toUpperCase();
    }

    function getTotalsDonut() {
        const attended = Number(analysis?.summary?.attendedCount || 0);
        const absent = Number(analysis?.summary?.absentCount || 0);
        const total = attended + absent;
        const attendedShare = total > 0 ? attended / total : 0;
        return {
            attended,
            absent,
            total,
            attendedDash: `${(attendedShare * 100).toFixed(3)} 100`,
            absentDash: `${((1 - attendedShare) * 100).toFixed(3)} 100`,
            absentOffset: `${(-attendedShare * 100).toFixed(3)}`,
        };
    }
</script>

{#if !isImmersiveMode}
    <PageHeader label="Attendance">
        Record event attendance by alliance and keep each event roster as a historical snapshot.
    </PageHeader>
{/if}

{#if detail?.id === activeWorkspaceRecordId}
    <div class="attendance-workspace">
        <div class="workspace-topbar">
            <div class="workspace-topbar-left">
                <button class="workspace-back" type="button" onclick={closeWorkspace} aria-label="Back to attendance" title="Back to attendance">
                    <Icon name="chevron-left" size={16} />
                </button>
                <div class="workspace-title-group">
                    <strong>{detail.title}</strong>
                    <p>{detail.allianceName} · {formatRecordDate(detail.eventDate)}</p>
                </div>
            </div>
            <div class="workspace-actions">
                <span class="count-pill">{detail.attendedCount} attended</span>
                <span class="count-pill muted">{detail.absentCount} absent</span>
                <button class="btn" type="button" onclick={openEditModal}>Edit</button>
                <LoadingButton class="btn btn-danger" loading={isDeleting} onclick={() => showDeleteDialog = true}>Delete</LoadingButton>
            </div>
        </div>

        <div class="attendance-board">
            <section class="attendance-column source-column" role="list" ondragover={handleDragOver} ondrop={(event) => handleDrop(event, 'unassigned')}>
                <div class="column-header">
                    <h2>{STATUS_LABELS.unassigned}</h2>
                    <span>{detail.unassignedCount}</span>
                </div>
                <label class="member-search" aria-label="Search alliance members">
                    <Icon name="search" size={14} />
                    <input type="search" bind:value={memberSearch} placeholder="Search by ID or name" />
                </label>
                <div class="player-stack">
                    {#each unassignedPlayers as player (player.fid)}
                        <article class="attendance-player-card" draggable="true" ondragstart={(event) => handleDragStart(event, player)}>
                            <div class="player-card-top">
                                <div class="player-main">
                                    <div class="player-avatar">
                                        #
                                    </div>
                                    <div class="player-copy">
                                        <strong>{player.nickname || `ID ${player.fid}`}</strong>
                                        <span>{player.nickname ? `Player ID ${player.fid}` : 'Player ID'}</span>
                                    </div>
                                </div>
                                <div class="attendance-actions">
                                    <button class="status-btn attended" disabled={savingPlayerIds[player.fid]} onclick={() => movePlayer(player, 'attended')}>
                                        <Icon name="check" size={13} /> <span class="status-label">Attended</span>
                                    </button>
                                    <button class="status-btn absent" disabled={savingPlayerIds[player.fid]} onclick={() => movePlayer(player, 'absent')}>
                                        <Icon name="x" size={13} /> <span class="status-label">Absent</span>
                                    </button>
                                </div>
                            </div>
                            <div class="player-meta">
                                <span>Assigned state {formatState(player.state)}</span>
                            </div>
                        </article>
                    {:else}
                        <div class="drop-empty">{memberSearch.trim() ? 'No matching members.' : 'All players are classified.'}</div>
                    {/each}
                </div>
            </section>

            <div class="result-columns">
                <section class="attendance-column" role="list" ondragover={handleDragOver} ondrop={(event) => handleDrop(event, 'attended')}>
                    <div class="column-header">
                        <h2>{STATUS_LABELS.attended}</h2>
                        <span>{detail.attendedCount}</span>
                    </div>
                    <div class="player-stack">
                        {#each attendedPlayers as player (player.fid)}
                            <article class="attendance-player-card is-attended" draggable="true" ondragstart={(event) => handleDragStart(event, player)}>
                                <div class="player-card-top">
                                    <div class="player-main">
                                        <div class="player-avatar">
                                            #
                                        </div>
                                        <div class="player-copy">
                                        <strong>{player.nickname || `ID ${player.fid}`}</strong>
                                        <span>{player.nickname ? `Player ID ${player.fid}` : 'Player ID'}</span>
                                        </div>
                                    </div>
                                    <div class="attendance-actions">
                                        <button class="status-btn attended active" disabled={savingPlayerIds[player.fid]} onclick={() => movePlayer(player, 'attended')}>
                                            <Icon name="check" size={13} /> <span class="status-label">Attended</span>
                                        </button>
                                        <button class="status-btn absent" disabled={savingPlayerIds[player.fid]} onclick={() => movePlayer(player, 'absent')}>
                                            <Icon name="x" size={13} /> <span class="status-label">Absent</span>
                                        </button>
                                    </div>
                                </div>
                                <div class="player-meta">
                                    <span>Assigned state {formatState(player.state)}</span>
                                </div>
                            </article>
                        {:else}
                            <div class="drop-empty">Drop anywhere in this column to mark attended.</div>
                        {/each}
                    </div>
                </section>

                <section class="attendance-column" role="list" ondragover={handleDragOver} ondrop={(event) => handleDrop(event, 'absent')}>
                    <div class="column-header">
                        <h2>{STATUS_LABELS.absent}</h2>
                        <span>{detail.absentCount}</span>
                    </div>
                    <div class="player-stack">
                        {#each absentPlayers as player (player.fid)}
                            <article class="attendance-player-card is-absent" draggable="true" ondragstart={(event) => handleDragStart(event, player)}>
                                <div class="player-card-top">
                                    <div class="player-main">
                                        <div class="player-avatar">
                                            #
                                        </div>
                                        <div class="player-copy">
                                        <strong>{player.nickname || `ID ${player.fid}`}</strong>
                                        <span>{player.nickname ? `Player ID ${player.fid}` : 'Player ID'}</span>
                                        </div>
                                    </div>
                                    <div class="attendance-actions">
                                        <button class="status-btn attended" disabled={savingPlayerIds[player.fid]} onclick={() => movePlayer(player, 'attended')}>
                                            <Icon name="check" size={13} /> <span class="status-label">Attended</span>
                                        </button>
                                        <button class="status-btn absent active" disabled={savingPlayerIds[player.fid]} onclick={() => movePlayer(player, 'absent')}>
                                            <Icon name="x" size={13} /> <span class="status-label">Absent</span>
                                        </button>
                                    </div>
                                </div>
                                <div class="player-meta">
                                    <span>Assigned state {formatState(player.state)}</span>
                                </div>
                            </article>
                        {:else}
                            <div class="drop-empty">Drop anywhere in this column to mark absent.</div>
                        {/each}
                    </div>
                </section>
            </div>
        </div>
    </div>
{:else if isRecordWorkspaceMode}
    <div class="attendance-workspace">
        <div class="workspace-topbar">
            <div class="workspace-topbar-left">
                <button class="workspace-back" type="button" onclick={closeWorkspace} aria-label="Back to attendance" title="Back to attendance">
                    <Icon name="chevron-left" size={16} />
                </button>
                <div class="workspace-title-group">
                    <strong>Loading attendance record</strong>
                    <p>Preparing roster snapshot...</p>
                </div>
            </div>
        </div>
        <div class="attendance-board" aria-busy="true">
            <section class="attendance-column source-column">
                <div class="skeleton" style="height: 34px;"></div>
                <div class="skeleton" style="height: 34px;"></div>
                <div class="player-stack">
                    <div class="skeleton" style="height: 78px;"></div>
                    <div class="skeleton" style="height: 78px;"></div>
                    <div class="skeleton" style="height: 78px;"></div>
                </div>
            </section>
            <div class="result-columns">
                <section class="attendance-column"><div class="skeleton" style="height: 126px;"></div></section>
                <section class="attendance-column"><div class="skeleton" style="height: 126px;"></div></section>
            </div>
        </div>
    </div>
{:else if analysisLoadedForActiveAlliance}
    <div class="attendance-workspace">
        <div class="workspace-topbar analysis-topbar">
            <div class="workspace-topbar-left">
                <button class="workspace-back" type="button" onclick={closeWorkspace} aria-label="Back to attendance analysis list" title="Back to attendance analysis list">
                    <Icon name="chevron-left" size={16} />
                </button>
                <div class="workspace-title-group">
                    <strong>{analysis.alliance?.name || 'Attendance Analysis'}</strong>
                    <p>{formatGameContext(analysis.alliance?.gameType)} attendance analysis {(analysis.filters?.startDate || analysis.filters?.endDate) ? `- ${analysis.filters.startDate || 'Start'} to ${analysis.filters.endDate || 'Now'}` : '- All time'}</p>
                </div>
            </div>
            <div class="workspace-actions analysis-toolbar">
                <label class="analysis-filter">
                    <span>Start date</span>
                    <input type="date" bind:value={analysisFilters.startDate} />
                </label>
                <label class="analysis-filter">
                    <span>End date</span>
                    <input type="date" bind:value={analysisFilters.endDate} />
                </label>
                <div class="analysis-action-row">
                    <button class="btn" type="button" onclick={applyAnalysisFilters}>Apply</button>
                    <button class="btn" type="button" onclick={clearAnalysisFilters}>Clear</button>
                    <LoadingButton class="btn btn-primary" loading={isExportingAnalysis} onclick={exportAnalysisCsv}>
                        <Icon name="download" size={14} /> Export CSV
                    </LoadingButton>
                </div>
            </div>
        </div>

        <div class="analysis-layout">
            <div class="analysis-summary-grid">
                <article class="analysis-card summary-card">
                    <span>Total Records</span>
                    <strong>{analysis.summary?.recordCount || 0}</strong>
                    <p>Attendance records included in this report.</p>
                </article>
                <article class="analysis-card summary-card">
                    <span>Total Attended</span>
                    <strong>{analysis.summary?.attendedCount || 0}</strong>
                    <p>Counted attendance rows marked attended.</p>
                </article>
                <article class="analysis-card summary-card">
                    <span>Total Absent</span>
                    <strong>{analysis.summary?.absentCount || 0}</strong>
                    <p>Counted attendance rows marked absent.</p>
                </article>
                <article class="analysis-card summary-card highlight">
                    <span>Attendance Rate</span>
                    <strong>{formatPercent(analysis.summary?.attendanceRate || 0)}</strong>
                    <p>{analysis.summary?.participationCount || 0} counted participations.</p>
                </article>
            </div>

            <div class="analysis-chart-grid">
                <section class="analysis-card analysis-table-card">
                    <div class="analysis-card-head">
                        <div>
                            <h2>Player Summary</h2>
                            <p>Players with at least one counted attendance decision.</p>
                        </div>
                    </div>
                    {#if analysis.players?.length}
                        <div class="analysis-table-wrap">
                            <table class="analysis-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Assigned State</th>
                                        <th>Attended</th>
                                        <th>Absent</th>
                                        <th>Total</th>
                                        <th>Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {#each analysis.players as player (player.fid)}
                                        <tr>
                                            <td>{player.nickname ? `${player.nickname} (${player.fid})` : `ID ${player.fid}`}</td>
                                            <td>{formatState(player.state)}</td>
                                            <td>{player.attendedCount}</td>
                                            <td>{player.absentCount}</td>
                                            <td>{player.participationCount}</td>
                                            <td>{formatPercent(player.attendanceRate)}</td>
                                        </tr>
                                    {/each}
                                </tbody>
                            </table>
                        </div>
                        <div class="analysis-player-cards">
                            {#each analysis.players as player (player.fid)}
                                <article class="analysis-player-card">
                                    <div class="analysis-player-card-head">
                                        <div>
                                            <strong>{player.nickname || `ID ${player.fid}`}</strong>
                                            <span>{player.nickname ? `Player ID ${player.fid}` : 'Player ID'}</span>
                                        </div>
                                        <span class="analysis-player-rate">{formatPercent(player.attendanceRate)}</span>
                                    </div>
                                    <div class="analysis-player-grid">
                                        <div class="analysis-player-stat">
                                            <span>Assigned State</span>
                                            <strong>{formatState(player.state)}</strong>
                                        </div>
                                        <div class="analysis-player-stat">
                                            <span>Attended</span>
                                            <strong>{player.attendedCount}</strong>
                                        </div>
                                        <div class="analysis-player-stat">
                                            <span>Absent</span>
                                            <strong>{player.absentCount}</strong>
                                        </div>
                                        <div class="analysis-player-stat">
                                            <span>Total</span>
                                            <strong>{player.participationCount}</strong>
                                        </div>
                                    </div>
                                </article>
                            {/each}
                        </div>
                    {:else}
                        <div class="analysis-empty">
                            No counted attendance data was found for this alliance and date range.
                        </div>
                    {/if}
                </section>

                <section class="analysis-card analysis-outcome-card">
                    <div class="analysis-card-head">
                        <div>
                            <h2>Overall Outcome Split</h2>
                            <p>All counted rows, excluding players left unassigned.</p>
                        </div>
                    </div>
                    <div class="totals-chart">
                        <svg viewBox="0 0 42 42" class="donut-chart" aria-label="Attendance totals">
                            <circle class="donut-track" cx="21" cy="21" r="15.9155"></circle>
                            <circle class="donut-attended" cx="21" cy="21" r="15.9155" stroke-dasharray={getTotalsDonut().attendedDash}></circle>
                            <circle class="donut-absent" cx="21" cy="21" r="15.9155" stroke-dasharray={getTotalsDonut().absentDash} stroke-dashoffset={getTotalsDonut().absentOffset}></circle>
                        </svg>
                        <div class="totals-copy">
                            <div class="totals-stat">
                                <span class="totals-label attended">Attended</span>
                                <strong>{analysis.summary?.attendedCount || 0}</strong>
                            </div>
                            <div class="totals-stat">
                                <span class="totals-label absent">Absent</span>
                                <strong>{analysis.summary?.absentCount || 0}</strong>
                            </div>
                            <div class="totals-stat">
                                <span class="totals-label neutral">Rate</span>
                                <strong>{formatPercent(analysis.summary?.attendanceRate || 0)}</strong>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
{:else if isAnalysisMode}
    <div class="attendance-workspace">
        <div class="workspace-topbar">
            <div class="workspace-topbar-left">
                <button class="workspace-back" type="button" onclick={closeWorkspace} aria-label="Back to attendance" title="Back to attendance">
                    <Icon name="chevron-left" size={16} />
                </button>
                <div class="workspace-title-group">
                    <strong>Loading attendance analysis</strong>
                    <p>Preparing alliance participation report...</p>
                </div>
            </div>
        </div>
        <div class="analysis-layout" aria-busy="true">
            <div class="analysis-summary-grid">
                <div class="skeleton" style="height: 120px;"></div>
                <div class="skeleton" style="height: 120px;"></div>
                <div class="skeleton" style="height: 120px;"></div>
                <div class="skeleton" style="height: 120px;"></div>
            </div>
            <div class="analysis-chart-grid">
                <div class="skeleton" style="height: 420px;"></div>
                <div class="skeleton" style="height: 280px;"></div>
            </div>
        </div>
    </div>
{:else}
    <div class="attendance-page">
        <section class="attendance-panel">
            <div class="list-toolbar">
                <div>
                    <h3>Attendance Records</h3>
                    <p>
                        {#if selectedAllianceId}
                            {selectedAlliance?.name || 'Selected alliance'}
                        {:else if records.length > 0}
                            {records.length} records across {recordAllianceOptions.length - 1} alliances
                        {:else}
                            Create the first attendance record
                        {/if}
                    </p>
                </div>
                <div class="toolbar-actions">
                    {#if showRecordAllianceFilter}
                        <Select
                            class="alliance-select"
                            value={selectedAllianceId}
                            options={recordAllianceOptions}
                            placeholder="Filter records"
                            onchange={selectAlliance}
                        />
                    {/if}
                    <div class:toolbar-button-row={canAnalyzeSelectedAlliance}>
                        {#if canAnalyzeSelectedAlliance}
                            <button class="btn" type="button" onclick={() => openAnalysisWorkspace(selectedAllianceId)}>
                                <Icon name="dashboard" size={14} /> Analyze
                            </button>
                        {/if}
                        <LoadingButton class="btn btn-primary" loading={isCreating} disabled={alliances.length === 0} onclick={openCreateModal}>
                            <Icon name="plus" size={14} /> New Record
                        </LoadingButton>
                    </div>
                </div>
            </div>

            {#if isLoading}
                <div class="skeleton" style="height: 220px;"></div>
            {:else if alliances.length === 0}
                <div class="empty-state">
                    <div class="empty-icon"><Icon name="calendar-days" size={32} /></div>
                    <span>No assigned alliances available for attendance.</span>
                </div>
            {:else if visibleRecords.length === 0}
                <div class="empty-state">
                    <div class="empty-icon"><Icon name="calendar-days" size={32} /></div>
                    <span>No attendance records yet.</span>
                </div>
            {:else}
                <div class="record-list">
                    {#each visibleRecords as record (record.id)}
                        <button class="record-card" type="button" onclick={() => openWorkspace(record.id)}>
                            <div class="record-card-main">
                                <strong>{record.title}</strong>
                                <span>{record.allianceName} · {formatRecordDate(record.eventDate)}</span>
                            </div>
                            <div class="record-counts">
                                <span>{record.attendedCount || 0} attended</span>
                                <span>{record.absentCount || 0} absent</span>
                            </div>
                        </button>
                    {/each}
                </div>
            {/if}
        </section>
    </div>
{/if}

<Modal bind:isOpen={showCreateModal} title="New Attendance Record">
    <div class="modal-form">
        <label>
            <span>Title</span>
            <input type="text" bind:value={createForm.title} maxlength="120" placeholder="Event title" />
        </label>
        <label>
            <span>Date</span>
            <input type="date" bind:value={createForm.eventDate} />
        </label>
        <div class="field-stack">
            <span>Alliance</span>
            <Select bind:value={createForm.allianceId} options={allianceOptions} placeholder="Select alliance" />
        </div>
        <div class="modal-actions">
            <button class="btn" type="button" onclick={() => showCreateModal = false}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={isCreating} disabled={!createForm.allianceId} onclick={createRecord}>
                Create Record
            </LoadingButton>
        </div>
    </div>
</Modal>

<Modal bind:isOpen={showEditModal} title="Edit Attendance Record">
    <div class="modal-form">
        <label>
            <span>Title</span>
            <input type="text" bind:value={editForm.title} maxlength="120" placeholder="Event title" />
        </label>
        <label>
            <span>Date</span>
            <input type="date" bind:value={editForm.eventDate} />
        </label>
        <div class="modal-actions">
            <button class="btn" type="button" onclick={() => showEditModal = false}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={isSavingMeta} onclick={saveMetadata}>
                Save Changes
            </LoadingButton>
        </div>
    </div>
</Modal>

<ConfirmDialog
    bind:isOpen={showDeleteDialog}
    title="Delete Attendance Record"
    message={`Delete "${detail?.title || 'this attendance record'}"? This cannot be undone.`}
    confirmLabel="Delete"
    variant="danger"
    onconfirm={deleteRecord}
/>

<style>
    .attendance-page {
        width: 100%;
        max-width: 1280px;
    }

    .attendance-workspace {
        width: 100%;
        max-width: none;
        box-sizing: border-box;
        padding: 14px clamp(16px, 2vw, 32px) 24px;
    }

    .attendance-panel {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 22px;
        box-shadow: var(--shadow-panel), var(--shadow-inset);
    }

    .list-toolbar,
    .workspace-topbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 16px;
    }

    .list-toolbar h3 {
        margin: 0;
        color: var(--color-text-primary);
        font-size: 18px;
        font-weight: 700;
    }

    .list-toolbar p,
    .workspace-title-group p {
        margin: 4px 0 0;
        color: var(--color-text-muted);
        font-size: 13px;
    }

    .toolbar-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: nowrap;
        justify-content: flex-end;
    }

    .toolbar-button-row {
        display: flex;
        align-items: center;
        gap: 10px;
        flex: 0 0 auto;
    }

    .workspace-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        justify-content: flex-end;
    }

    :global(.alliance-select) {
        min-width: 240px;
    }

    .record-list {
        display: grid;
        gap: 12px;
    }

    .record-card {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 16px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: color-mix(in oklab, var(--color-card) 88%, var(--color-accent) 12%);
        color: var(--color-text-primary);
        text-align: left;
        cursor: pointer;
        transition: border-color 0.15s ease, transform 0.15s ease, background 0.15s ease;
    }

    .record-card:hover {
        border-color: var(--color-border-accent);
        background: var(--color-card-hover);
        transform: translateY(-1px);
    }

    .record-card-main {
        min-width: 0;
        display: grid;
        gap: 4px;
    }

    .record-card-main strong,
    .player-copy strong {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .record-card-main span,
    .player-copy span,
    .player-meta {
        color: var(--color-text-muted);
        font-size: 12px;
    }

    .record-counts {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: flex-end;
        color: var(--color-text-secondary);
        font-size: 12px;
    }

    .record-counts span,
    .count-pill {
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        border-radius: var(--radius-pill);
        padding: 5px 9px;
        white-space: nowrap;
    }

    .count-pill.muted {
        color: var(--color-text-secondary);
    }

    .workspace-topbar {
        padding: 0 0 14px;
        border-bottom: 1px solid var(--color-border);
    }

    .workspace-topbar-left {
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .workspace-back {
        width: 30px;
        height: 30px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }

    .workspace-title-group {
        min-width: 0;
    }

    .workspace-title-group strong {
        display: block;
        color: var(--color-text-primary);
        font-size: 15px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .attendance-board {
        display: grid;
        grid-template-columns: minmax(220px, 300px) minmax(0, 1fr);
        gap: 14px;
        align-items: start;
        min-width: 0;
        overflow-x: hidden;
    }

    .result-columns {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 14px;
        min-width: 0;
    }

    .attendance-column {
        min-height: 486px;
        max-height: calc(100dvh - 132px);
        overflow: hidden;
        display: flex;
        flex-direction: column;
        min-width: 0;
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 12px;
        box-shadow: var(--shadow-panel), var(--shadow-inset);
    }

    .source-column {
        position: sticky;
        top: 0;
    }

    .column-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 10px;
        flex: 0 0 auto;
    }

    .column-header h2 {
        margin: 0;
        color: var(--color-text-primary);
        font-size: 13px;
        font-weight: 700;
    }

    .column-header span {
        color: var(--color-text-muted);
        font-size: 12px;
        font-family: var(--font-mono);
    }

    .member-search {
        min-height: 34px;
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 10px;
        padding: 0 10px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        color: var(--color-text-muted);
        flex: 0 0 auto;
    }

    .member-search:focus-within {
        border-color: var(--color-border-accent);
        color: var(--color-accent);
    }

    .member-search input {
        appearance: none;
        -webkit-appearance: none;
        width: 100%;
        min-width: 0;
        border: 0;
        outline: 0;
        box-shadow: none;
        background: transparent;
        color: var(--color-text-primary);
        font: inherit;
        font-size: 12px;
    }

    .member-search input:focus {
        outline: 0;
        box-shadow: none;
    }

    .member-search input::-webkit-search-decoration,
    .member-search input::-webkit-search-cancel-button,
    .member-search input::-webkit-search-results-button,
    .member-search input::-webkit-search-results-decoration {
        display: none;
    }

    .member-search input::placeholder {
        color: var(--color-text-muted);
    }

    .player-stack {
        display: grid;
        gap: 8px;
        align-content: start;
        flex: 1 1 auto;
        min-height: 0;
        min-width: 0;
        overflow-y: auto;
        overflow-x: hidden;
        padding: 1px 2px 0 0;
        scrollbar-gutter: stable;
    }

    .attendance-player-card {
        min-width: 0;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: color-mix(in oklab, var(--color-card) 88%, var(--color-secondary) 12%);
        padding: 10px;
        cursor: grab;
        transition: border-color 0.15s ease, transform 0.15s ease, background 0.15s ease;
    }

    .attendance-player-card:hover {
        border-color: var(--color-border-accent);
    }

    .attendance-player-card.is-attended {
        border-color: color-mix(in oklab, var(--color-success) 42%, var(--color-border));
    }

    .attendance-player-card.is-absent {
        border-color: color-mix(in oklab, var(--color-danger) 42%, var(--color-border));
    }

    .player-card-top {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
        min-width: 0;
    }

    .player-main {
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 9px;
        flex: 1 1 auto;
    }

    .player-avatar {
        width: 34px;
        height: 34px;
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--color-accent);
        font-weight: 700;
        overflow: hidden;
        flex: 0 0 auto;
    }

    .player-copy {
        min-width: 0;
        display: grid;
        gap: 2px;
    }

    .player-copy strong {
        color: var(--color-text-primary);
        font-size: 12px;
    }

    .player-meta {
        display: flex;
        justify-content: flex-start;
        gap: 10px;
        margin-top: 8px;
    }

    .attendance-actions {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
        flex: 0 0 auto;
        min-width: 0;
    }

    .status-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        min-height: 27px;
        padding: 0 9px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-secondary);
        cursor: pointer;
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
    }

    .source-column .attendance-actions {
        gap: 5px;
    }

    .source-column .status-btn {
        width: 28px;
        padding: 0;
    }

    .source-column .status-label {
        display: none;
    }

    .status-btn:disabled {
        opacity: 0.6;
        cursor: wait;
    }

    .status-btn.attended.active,
    .status-btn.attended:hover:not(:disabled) {
        border-color: var(--color-success);
        color: var(--color-success);
        background: var(--color-success-soft);
    }

    .status-btn.absent.active,
    .status-btn.absent:hover:not(:disabled) {
        border-color: var(--color-danger);
        color: var(--color-danger);
        background: var(--color-danger-soft);
    }

    .drop-empty {
        min-height: 54px;
        display: grid;
        place-items: center;
        color: var(--color-text-muted);
        font-size: 12px;
        text-align: center;
        padding: 8px 12px;
        pointer-events: none;
    }

    .analysis-topbar {
        align-items: flex-start;
    }

    .analysis-toolbar {
        gap: 12px;
    }

    .analysis-action-row {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .analysis-filter {
        display: grid;
        gap: 6px;
    }

    .analysis-filter span {
        color: var(--color-text-secondary);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
    }

    .analysis-filter input {
        min-height: 36px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        padding: 0 12px;
    }

    .analysis-layout {
        display: grid;
        gap: 14px;
        padding-top: 14px;
    }

    .analysis-summary-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
    }

    .analysis-chart-grid {
        display: grid;
        grid-template-columns: minmax(0, 1.45fr) minmax(280px, 0.95fr);
        gap: 14px;
        align-items: start;
    }

    .analysis-card {
        min-width: 0;
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 16px;
        box-shadow: var(--shadow-panel), var(--shadow-inset);
    }

    .analysis-card-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 14px;
    }

    .analysis-card-head h2 {
        margin: 0;
        color: var(--color-text-primary);
        font-size: 15px;
    }

    .analysis-card-head p,
    .summary-card p {
        margin: 4px 0 0;
        color: var(--color-text-muted);
        font-size: 12px;
    }

    .summary-card {
        display: grid;
        gap: 8px;
        align-content: start;
        min-height: 112px;
    }

    .summary-card span {
        color: var(--color-text-secondary);
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }

    .summary-card strong {
        color: var(--color-text-primary);
        font-size: clamp(24px, 3vw, 32px);
        line-height: 1;
    }

    .summary-card.highlight {
        background: color-mix(in oklab, var(--color-card) 84%, var(--color-accent) 16%);
        border-color: color-mix(in oklab, var(--color-border) 55%, var(--color-accent) 45%);
    }

    .totals-chart {
        min-height: 240px;
        display: grid;
        grid-template-columns: minmax(150px, 190px) minmax(0, 1fr);
        gap: 18px;
        align-items: center;
    }

    @media (min-width: 701px) {
        .analysis-chart-grid > .analysis-outcome-card {
            position: sticky;
            top: 14px;
            align-self: start;
        }
    }

    .donut-chart {
        width: 100%;
        max-width: 176px;
        margin: 0 auto;
    }

    .donut-track,
    .donut-attended,
    .donut-absent {
        fill: none;
        stroke-width: 4;
    }

    .donut-track {
        stroke: var(--color-secondary);
    }

    .donut-attended {
        stroke: var(--color-success);
        stroke-linecap: round;
    }

    .donut-absent {
        stroke: var(--color-danger);
        stroke-linecap: round;
    }

    .totals-copy {
        display: grid;
        gap: 12px;
    }

    .totals-stat {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
    }

    .totals-label {
        color: var(--color-text-secondary);
        font-size: 12px;
        font-weight: 700;
    }

    .totals-label.attended {
        color: var(--color-success);
    }

    .totals-label.absent {
        color: var(--color-danger);
    }

    .totals-label.neutral {
        color: var(--color-accent);
    }

    .totals-stat strong {
        color: var(--color-text-primary);
        font-size: 18px;
    }

    .analysis-table-card {
        padding-bottom: 8px;
    }

    .analysis-table-wrap {
        overflow: auto;
    }

    .analysis-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 720px;
    }

    .analysis-table th,
    .analysis-table td {
        padding: 12px 10px;
        border-bottom: 1px solid var(--color-border);
        text-align: left;
        font-size: 12px;
    }

    .analysis-table th {
        color: var(--color-text-secondary);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.04em;
    }

    .analysis-table td {
        color: var(--color-text-primary);
    }

    .analysis-player-cards {
        display: none;
    }

    .analysis-player-card {
        display: grid;
        gap: 12px;
        padding: 14px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: var(--color-secondary);
    }

    .analysis-player-card + .analysis-player-card {
        margin-top: 10px;
    }

    .analysis-player-card-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
    }

    .analysis-player-card-head strong {
        display: block;
        color: var(--color-text-primary);
        font-size: 14px;
        line-height: 1.2;
    }

    .analysis-player-card-head span {
        color: var(--color-text-muted);
        font-size: 12px;
    }

    .analysis-player-rate {
        flex: 0 0 auto;
        padding: 6px 10px;
        border-radius: var(--radius-pill);
        border: 1px solid color-mix(in oklab, var(--color-border) 50%, var(--color-accent) 50%);
        background: color-mix(in oklab, var(--color-card) 82%, var(--color-accent) 18%);
        color: var(--color-text-primary);
        font-size: 12px;
        font-weight: 700;
    }

    .analysis-player-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
    }

    .analysis-player-stat {
        display: grid;
        gap: 4px;
        min-width: 0;
        padding: 10px 12px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: color-mix(in oklab, var(--color-card) 90%, var(--color-secondary) 10%);
    }

    .analysis-player-stat span {
        color: var(--color-text-muted);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }

    .analysis-player-stat strong {
        color: var(--color-text-primary);
        font-size: 13px;
        line-height: 1.2;
        word-break: break-word;
    }

    .analysis-empty {
        min-height: 180px;
        display: grid;
        place-items: center;
        text-align: center;
        color: var(--color-text-muted);
        font-size: 13px;
        padding: 16px;
    }

    .modal-form {
        display: grid;
        gap: 16px;
    }

    .modal-form label,
    .field-stack {
        display: grid;
        gap: 8px;
    }

    .modal-form span,
    .field-stack > span {
        color: var(--color-text-secondary);
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
    }

    .modal-form input {
        width: 100%;
        min-height: 40px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        padding: 0 12px;
    }

    .modal-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 4px;
    }

    @media (max-width: 980px) {
        .analysis-summary-grid,
        .analysis-chart-grid {
            grid-template-columns: 1fr;
        }

        .totals-chart {
            grid-template-columns: 1fr;
        }

        .attendance-board,
        .result-columns {
            grid-template-columns: 1fr;
        }

        .source-column {
            position: static;
        }

        .attendance-column {
            min-height: 280px;
            max-height: none;
        }
    }

    @media (max-width: 700px) {
        .list-toolbar,
        .workspace-topbar {
            align-items: stretch;
            flex-direction: column;
        }

        .toolbar-actions,
        .workspace-actions {
            justify-content: stretch;
        }

        .analysis-toolbar {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
        }

        .analysis-action-row {
            grid-column: 1 / -1;
            display: grid;
            grid-template-columns: minmax(0, 0.8fr) minmax(0, 0.8fr) minmax(0, 1.4fr);
            gap: 10px;
        }

        .toolbar-actions {
            display: grid;
            gap: 10px;
        }

        .toolbar-button-row {
            display: flex;
        }

        .toolbar-actions > .toolbar-button-row {
            gap: 10px;
        }

        .toolbar-actions > .toolbar-button-row.toolbar-button-row {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px;
        }

        :global(.alliance-select),
        .toolbar-actions :global(.custom-select),
        .toolbar-actions :global(.btn),
        .workspace-actions :global(.btn),
        .analysis-action-row :global(.btn),
        .analysis-filter input {
            width: 100%;
        }

        .record-card {
            align-items: stretch;
            flex-direction: column;
        }

        .record-counts {
            justify-content: flex-start;
        }

        .analysis-chart-grid > .analysis-outcome-card {
            order: -1;
        }

        .analysis-table-wrap {
            display: none;
        }

        .analysis-player-cards {
            display: block;
        }

        .analysis-player-grid {
            grid-template-columns: 1fr 1fr;
        }

    }
</style>
