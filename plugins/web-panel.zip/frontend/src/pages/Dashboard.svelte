<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { botInfo, currentUser, navigateTo } from '../lib/stores.js';
    import { formatUptime, formatTime, showToast, hasPerm } from '../lib/utils.js';
    import { PERMS } from '../lib/constants.js';
    import Icon from '../components/ui/Icon.svelte';
    import StatCard from '../components/ui/StatCard.svelte';

    let isLoading = $state(true);
    let stats = $state([]);
    let memory = $state(null);
    let recentLogs = $state([]);

    let hasFullAccess = $derived(
        $currentUser?.isOwner || hasPerm(PERMS.FULL_ACCESS)
    );

    const STAT_ICONS = {
        Players: 'players',
        Alliances: 'alliances',
        Notifications: 'notifications',
        'Active Processes': 'processes',
        'Gift Codes': 'giftcodes',
        Uptime: 'uptime',
    };

    const STAT_COLORS = {
        Players: 'accent',
        Alliances: 'purple',
        Notifications: 'success',
        'Active Processes': 'warning',
        'Gift Codes': 'accent',
        Uptime: '',
    };

    let memoryPercent = $derived(memory ? Math.round((memory.heapUsedMB / memory.heapTotalMB) * 100) : 0);

    onMount(async () => {
        if (!hasFullAccess) {
            isLoading = false;
            return;
        }
        try {
            const data = await apiFetch('/api/dashboard');
            if (!data) return;

            const { counts, uptime } = data;
            const cards = [];

            if (counts.players !== undefined) cards.push({ label: 'Players', value: counts.players });
            if (counts.alliances !== undefined) cards.push({ label: 'Alliances', value: counts.alliances });
            if (counts.activeNotifications !== undefined) cards.push({ label: 'Notifications', value: counts.activeNotifications });
            if (counts.activeProcesses !== undefined) cards.push({ label: 'Active Processes', value: counts.activeProcesses });
            if (counts.giftCodes !== undefined) cards.push({ label: 'Gift Codes', value: counts.giftCodes });
            cards.push({ label: 'Uptime', value: formatUptime(uptime) });

            stats = cards;
            memory = data.memory || null;
            recentLogs = data.recentLogs || [];
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    });
</script>

<div class="dashboard">
    <!-- Welcome Banner -->
    <div class="welcome-banner animate-fade-in">
        <div class="welcome-left">
            <div class="brand-avatar">
                {($botInfo.name || 'B').charAt(0).toUpperCase()}
            </div>
            <div class="welcome-text">
                <span class="welcome-greeting">Welcome back</span>
                <h1 class="welcome-bot">{$botInfo.name || 'Bot'}</h1>
            </div>
        </div>
        <div class="welcome-status">
            <span class="status-dot"></span>
            Online
        </div>
    </div>

    <!-- Stat Cards -->
    {#if hasFullAccess}
    {#if isLoading}
        <div class="stats-grid stagger">
            {#each Array(6) as _}
                <div class="skeleton" style="height: 110px;"></div>
            {/each}
        </div>
    {:else}
        <div class="stats-grid stagger">
            {#each stats as card}
                <StatCard
                    label={card.label}
                    value={String(card.value)}
                    colorClass={STAT_COLORS[card.label] || ''}
                    icon={STAT_ICONS[card.label] || ''}
                />
            {/each}
        </div>

        <!-- Bottom Panels -->
        <div class="dashboard-panels">
            <!-- Memory Usage -->
            {#if memory}
                <div class="panel">
                    <div class="panel-header">
                        <Icon name="processes" size={16} />
                        <h2>System</h2>
                    </div>
                    <div class="memory-bar-container">
                        <div class="memory-label">
                            <span>Heap Memory</span>
                            <span class="memory-value">{memory.heapUsedMB} / {memory.heapTotalMB} MB</span>
                        </div>
                        <div class="memory-bar">
                            <div
                                class="memory-fill"
                                class:memory-warn={memoryPercent > 70}
                                class:memory-danger={memoryPercent > 90}
                                style="width: {memoryPercent}%"
                            ></div>
                        </div>
                    </div>
                    <div class="memory-bar-container">
                        <div class="memory-label">
                            <span>RSS</span>
                            <span class="memory-value">{memory.rssMB} MB</span>
                        </div>
                    </div>
                </div>
            {/if}

            <!-- Recent Activity -->
            {#if recentLogs.length > 0}
                <div class="panel panel-activity">
                    <div class="panel-header">
                        <Icon name="logs" size={16} />
                        <h2>Recent Activity</h2>
                        <button class="btn btn-ghost btn-sm" onclick={() => navigateTo('logs')}>View All</button>
                    </div>
                    <div class="activity-list">
                        {#each recentLogs.slice(0, 5) as log}
                            <div class="activity-item">
                                <div class="activity-dot"></div>
                                <div class="activity-content">
                                    <span class="activity-action">{log.action || log.type || 'Action'}</span>
                                    <span class="activity-detail">{log.detail || log.message || ''}</span>
                                </div>
                                <span class="activity-time">{formatTime(log.timestamp || log.created_at)}</span>
                            </div>
                        {/each}
                    </div>
                </div>
            {/if}
        </div>
    {/if}
    {/if}
</div>

<style>
    .dashboard {
        width: 100%;
        max-width: 1200px;
    }

    .welcome-banner {
        background: linear-gradient(135deg, var(--color-card) 0%, var(--color-accent-soft) 100%);
        border: 1px solid var(--color-border-accent);
        border-radius: var(--radius-lg);
        padding: 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 24px;
    }

    .welcome-left {
        display: flex;
        align-items: center;
        gap: 16px;
    }

    .brand-avatar {
        width: 48px;
        height: 48px;
        border-radius: var(--radius-md);
        background: linear-gradient(135deg, var(--color-accent), var(--color-purple));
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 20px;
        color: white;
        flex-shrink: 0;
    }

    .welcome-text {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .welcome-greeting {
        font-size: 13px;
        color: var(--color-text-muted);
    }

    .welcome-bot {
        font-size: 20px;
        font-weight: 700;
        color: var(--color-text-primary);
        margin: 0;
    }

    .welcome-status {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--color-success);
    }

    .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--color-success);
        box-shadow: 0 0 8px var(--color-success);
        animation: pulse-glow 2s ease-in-out infinite;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(6, minmax(0, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }

    @media (max-width: 1200px) {
        .stats-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
        }
    }

    /* Panels */
    .dashboard-panels {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .panel {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 20px;
        min-width: 0;
        overflow: hidden;
    }

    .panel-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 16px;
        color: var(--color-text-muted);
    }

    .panel-header h2 {
        font-size: 14px;
        font-weight: 600;
        color: var(--color-text-primary);
        margin: 0;
        flex: 1;
    }

    /* Memory */
    .memory-bar-container {
        margin-bottom: 12px;
    }

    .memory-label {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        font-size: 12px;
        color: var(--color-text-secondary);
        margin-bottom: 6px;
    }

    .memory-value {
        font-family: var(--font-mono);
        color: var(--color-text-primary);
    }

    .memory-bar {
        height: 6px;
        background: var(--color-secondary);
        border-radius: 3px;
        overflow: hidden;
    }

    .memory-fill {
        height: 100%;
        background: var(--color-accent);
        border-radius: 3px;
        transition: width 0.6s var(--ease-out);
    }

    .memory-fill.memory-warn {
        background: var(--color-warning);
    }

    .memory-fill.memory-danger {
        background: var(--color-danger);
    }

    /* Activity Feed */
    .panel-activity {
        grid-column: span 1;
    }

    .activity-list {
        display: flex;
        flex-direction: column;
        gap: 0;
    }

    .activity-item {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 8px 0;
        border-bottom: 1px solid var(--color-border);
        min-width: 0;
    }

    .activity-item:last-child {
        border-bottom: none;
    }

    .activity-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--color-accent);
        margin-top: 6px;
        flex-shrink: 0;
    }

    .activity-content {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .activity-action {
        display: block;
        font-size: 13px;
        font-weight: 500;
        color: var(--color-text-primary);
    }

    .activity-detail {
        display: block;
        font-size: 12px;
        color: var(--color-text-muted);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .activity-time {
        font-size: 11px;
        color: var(--color-text-muted);
        font-family: var(--font-mono);
        white-space: nowrap;
        flex-shrink: 0;
    }

    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .dashboard-panels {
            grid-template-columns: 1fr;
        }

        .welcome-left {
            gap: 12px;
        }

        .brand-avatar {
            width: 40px;
            height: 40px;
            font-size: 16px;
        }

        .welcome-bot {
            font-size: 16px;
        }

        .memory-label {
            flex-wrap: wrap;
        }

        .memory-value {
            word-break: break-word;
        }

        .activity-item {
            flex-wrap: wrap;
            gap: 8px;
        }

        .activity-content {
            flex-basis: calc(100% - 16px);
        }

        .activity-time {
            margin-left: 16px;
            width: 100%;
            white-space: normal;
        }

        .activity-detail {
            white-space: normal;
            overflow-wrap: anywhere;
            word-break: break-word;
            text-overflow: clip;
        }
    }

    @media (max-width: 520px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
