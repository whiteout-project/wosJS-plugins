<script>
    import { onMount, tick } from 'svelte';
    import { apiFetch, downloadFile } from '../lib/api.js';
    import { showToast, formatFurnaceLevel, getSettlementLevelLabel, formatTime } from '../lib/utils.js';
    import { navigateTo } from '../lib/stores.js';
    import { optionalPlayerSyncStatus } from '../lib/playerProfile.js';
    import PlayerAvatar from '../components/ui/PlayerAvatar.svelte';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';
    import Select from '../components/ui/Select.svelte';

    let alliances = $state([]);
    let playerSyncInstalled = $state(false);
    let selectedId = $state(null);
    let players = $state([]);
    let isLoading = $state(true);
    let isDetailLoading = $state(false);
    let sortOrder = $state('asc');
    let showMobileDetail = $state(false);
    let allianceLookup = $state('');
    let allianceLookupLoading = $state(false);
    let highlightedPlayerFid = $state(null);
    let allianceLookupMatches = $state([]);
    let allianceLookupMatchesQuery = $state('');
    let allianceLookupTotalMatches = $state(0);
    let allianceLookupModalOpen = $state(false);

    // Export modal
    let exportModalOpen = $state(false);
    let exportAllianceName = $state('');

    // Move modal
    let moveModalOpen = $state(false);
    let movePlayerFid = $state(null);
    let movePlayerLabel = $state('');
    let moveTargetId = $state(null);
    let isMoving = $state(false);

    // Edit player modal
    let editPlayerModalOpen = $state(false);
    let editPlayerFid = $state(null);
    let editNickname = $state('');
    let editState = $state('');
    let isSavingPlayer = $state(false);

    // Remove confirmation dialog
    let confirmRemoveOpen = $state(false);
    let removeFid = $state(null);

    // Player search
    let playerSearch = $state('');
    let addPlayerModalOpen = $state(false);
    let newPlayerIds = $state('');
    let isAddingPlayer = $state(false);
    let playerDetailModalOpen = $state(false);
    let selectedPlayerDetail = $state(null);

    // Create alliance wizard
    let createAllianceModalOpen = $state(false);
    let createAllianceStep = $state(1);
    let createAllianceName = $state('');
    let createAllianceState = $state('');
    let createGuildId = $state('');
    let createChannelId = $state('');
    let createGuilds = $state([]);
    let createChannels = $state([]);
    let isCreateSubmitting = $state(false);
    let isCreateLoadingGuilds = $state(false);
    let isCreateLoadingChannels = $state(false);

    let sortedPlayers = $derived(() => {
        let result = players;
        if (playerSearch.trim()) {
            const q = playerSearch.trim();
            const qLower = q.toLowerCase();
            result = result.filter(p =>
                String(p.fid).includes(q) ||
                String(p.nickname || '').toLowerCase().includes(qLower)
            );
        }
        if (sortOrder === 'asc') return [...result].sort((a, b) => Number(a.fid) - Number(b.fid));
        if (sortOrder === 'desc') return [...result].sort((a, b) => Number(b.fid) - Number(a.fid));
        return result;
    });

    let selectedAlliance = $derived(alliances.find(a => a.id === selectedId));
    let otherAlliances = $derived(alliances.filter(a => a.id !== selectedId));

    onMount(() => {
        let disposed = false;
        const capability = async () => {
            const status = await optionalPlayerSyncStatus(apiFetch);
            if (!disposed) playerSyncInstalled = !!status.installed;
        };
        capability();
        const timer = setInterval(() => { if (document.visibilityState !== 'hidden') capability(); }, 10000);
        (async () => {
            try {
                const data = await apiFetch('/api/alliances');
                if (!disposed && data) alliances = data;
            } catch (error) {
                if (!disposed) showToast(error.message, 'error');
            } finally {
                if (!disposed) isLoading = false;
            }
        })();
        return () => { disposed = true; clearInterval(timer); };
    });

    async function selectAlliance(id, options = {}) {
        const { preserveSearch = false, highlightFid = null } = options;
        selectedId = id;
        showMobileDetail = true;
        isDetailLoading = true;
        highlightedPlayerFid = highlightFid;
        if (!preserveSearch) {
            playerSearch = '';
        }

        try {
            const data = await apiFetch(`/api/alliances/${id}`);
            if (data) players = data.players || [];
        } catch (error) {
            showToast(error.message, 'error');
            players = [];
        } finally {
            isDetailLoading = false;
        }

        if (highlightFid !== null) {
            await tick();
            const targetCard = document.querySelector(`.player-card[data-fid="${highlightFid}"]`);
            targetCard?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }

    function goBackToList() {
        showMobileDetail = false;
    }

    function openPlayerDetail(player) {
        selectedPlayerDetail = player;
        playerDetailModalOpen = true;
    }

    function handlePlayerCardKeydown(event, player) {
        if (event.target !== event.currentTarget) return;
        if (event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault();
        openPlayerDetail(player);
    }

    async function runAllianceLookup() {
        const query = allianceLookup.trim();
        if (!query) {
            return;
        }

        allianceLookupLoading = true;
        try {
            const params = new URLSearchParams({ q: query });
            const data = await apiFetch(`/api/alliances/player-search?${params.toString()}`);
            const matches = data?.matches || [];

            if (matches.length === 0) {
                showToast(`No player found for "${query}"`, 'error');
                highlightedPlayerFid = null;
                return;
            }

            if (matches.length === 1) {
                await openAllianceLookupMatch(matches[0]);
                return;
            }

            allianceLookupMatches = matches;
            allianceLookupMatchesQuery = query;
            allianceLookupTotalMatches = data?.totalMatches || matches.length;
            allianceLookupModalOpen = true;
            highlightedPlayerFid = null;
            showToast(`Found ${allianceLookupTotalMatches} matching players for "${query}"`, 'info');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            allianceLookupLoading = false;
        }
    }

    async function openAllianceLookupMatch(match) {
        allianceLookupModalOpen = false;
        playerSearch = String(match.fid);
        await selectAlliance(match.allianceId, {
            preserveSearch: true,
            highlightFid: match.fid
        });
        showToast(`${match.nickname || `ID ${match.fid}`} is registered in ${match.allianceName}.`, 'success');
    }

    async function loadCreateGuilds() {
        isCreateLoadingGuilds = true;
        try {
            const guildData = await apiFetch('/api/guilds');
            createGuilds = Array.isArray(guildData) ? guildData : [];
        } catch (error) {
            createGuilds = [];
            showToast(error.message, 'error');
        } finally {
            isCreateLoadingGuilds = false;
        }
    }

    async function loadCreateChannels(guildId) {
        if (!guildId) {
            createChannels = [];
            createChannelId = '';
            return;
        }

        isCreateLoadingChannels = true;
        try {
            const channelData = await apiFetch(`/api/guilds/${guildId}/channels`);
            createChannels = Array.isArray(channelData) ? channelData : [];
            createChannelId = createChannels[0]?.id || '';
        } catch (error) {
            createChannels = [];
            createChannelId = '';
            showToast(error.message, 'error');
        } finally {
            isCreateLoadingChannels = false;
        }
    }

    async function openCreateAllianceModal() {
        createAllianceStep = 1;
        createAllianceName = '';
        createAllianceState = '';
        createGuildId = '';
        createChannelId = '';
        createChannels = [];
        createAllianceModalOpen = true;
        await loadCreateGuilds();
    }

    async function goToCreateAllianceStep2() {
        if (!createAllianceName.trim()) {
            showToast('Alliance name is required', 'error');
            return;
        }
        if (!/^\d+$/.test(createAllianceState) || Number(createAllianceState) <= 0) {
            showToast('Enter a valid state number', 'error');
            return;
        }

        createAllianceStep = 2;
    }

    async function handleCreateGuildChange() {
        createChannelId = '';
        await loadCreateChannels(createGuildId);
    }

    async function confirmCreateAlliance() {
        if (!createAllianceName.trim() || !String(createAllianceState).trim()) return;
        if (!createGuildId || !createChannelId) {
            showToast('Select both server and channel', 'error');
            return;
        }

        isCreateSubmitting = true;
        try {
            const createResult = await apiFetch('/api/alliances', {
                method: 'POST',
                body: {
                    name: createAllianceName.trim(),
                    state: Number(createAllianceState),
                },
            });

            if (!createResult?.alliance?.id) {
                showToast('Failed to create alliance', 'error');
                return;
            }

            const finalizeResult = await apiFetch(`/api/alliances/${createResult.alliance.id}/finalize`, {
                method: 'POST',
                body: {
                    guildId: createGuildId,
                    channelId: createChannelId,
                },
            });

            if (!finalizeResult?.ok) {
                showToast('Alliance created but finalization failed', 'error');
                return;
            }

            const data = await apiFetch('/api/alliances');
            if (data) alliances = data;

            createAllianceModalOpen = false;
            showToast(`Alliance "${finalizeResult.alliance?.name || createAllianceName.trim()}" created`, 'success');

            if (finalizeResult.alliance?.id) {
                await selectAlliance(finalizeResult.alliance.id);
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isCreateSubmitting = false;
        }
    }

    function openAddPlayerModal() {
        newPlayerIds = '';
        addPlayerModalOpen = true;
    }

    async function confirmAddPlayer() {
        if (!selectedId || !newPlayerIds.trim()) return;
        isAddingPlayer = true;

        try {
            const addResult = await apiFetch(`/api/alliances/${selectedId}/players`, {
                method: 'POST',
                body: { playerIds: newPlayerIds.trim() },
            });

            if (addResult?.ok) {
                const playerCount = addResult.playerCount || 0;
                const message = playerCount > 0
                    ? `Add ${playerCount} ${playerCount === 1 ? 'player' : 'players'} started (ID: ${addResult.processId})`
                    : `Add players started (ID: ${addResult.processId})`;
                showToast(message, 'success');
                addPlayerModalOpen = false;
                newPlayerIds = '';
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isAddingPlayer = false;
        }
    }

    function openExportModal() {
        exportAllianceName = selectedAlliance?.name || 'Unnamed';
        exportModalOpen = true;
    }

    async function confirmExport() {
        try {
            await downloadFile(`/api/alliances/${selectedId}/export`, `${exportAllianceName}_players.csv`);
            showToast('Export downloaded', 'success');
            exportModalOpen = false;
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    function openMoveModal(player) {
        movePlayerFid = player.fid;
        movePlayerLabel = player.nickname || `ID ${player.fid}`;
        moveTargetId = otherAlliances[0]?.id || null;
        moveModalOpen = true;
    }

    function openPlayerEdit(player) {
        editPlayerFid = player.fid;
        editNickname = player.nickname || '';
        editState = player.state_override != null ? String(player.state_override) : '';
        editPlayerModalOpen = true;
    }

    async function savePlayerEdit() {
        if (!editPlayerFid) return;
        if (editNickname.trim().length > 16) {
            showToast('Nickname must be 16 characters or fewer', 'error');
            return;
        }
        const stateValue = editState.trim();
        if (stateValue && (!/^\d+$/.test(stateValue) || Number(stateValue) <= 0)) {
            showToast('State must be a positive number (or empty to clear the override)', 'error');
            return;
        }

        isSavingPlayer = true;
        try {
            const body = {
                nickname: editNickname.trim(),
                state: stateValue === '' ? null : Number(stateValue),
            };
            const result = await apiFetch(`/api/players/${editPlayerFid}`, { method: 'PATCH', body });
            if (result?.ok) {
                players = players.map(p => p.fid === editPlayerFid
                    ? { ...p, nickname: body.nickname, state_override: body.state }
                    : p);
                editPlayerModalOpen = false;
                showToast('Player updated', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isSavingPlayer = false;
        }
    }

    async function confirmMove() {
        if (!moveTargetId || !movePlayerFid) return;
        isMoving = true;

        try {
            const moveResult = await apiFetch(`/api/players/${movePlayerFid}/move`, {
                method: 'POST',
                body: { allianceId: moveTargetId },
            });

            if (moveResult?.ok) {
                players = players.filter(p => p.fid !== movePlayerFid);
                const targetAlliance = alliances.find(a => a.id === moveTargetId);
                showToast(`Player moved to ${targetAlliance?.name || 'alliance'}`, 'success');
                moveModalOpen = false;
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isMoving = false;
        }
    }

    async function removePlayer(fid) {
        removeFid = fid;
        confirmRemoveOpen = true;
    }

    async function confirmRemovePlayer() {
        const fid = removeFid;
        try {
            const deleteResult = await apiFetch(`/api/players/${fid}`, { method: 'DELETE' });
            if (deleteResult?.ok) {
                players = players.filter(p => p.fid !== fid);
                showToast(`Player #${fid} removed`, 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        }
    }
</script>

<div class="alliances-page">
<PageHeader label="Alliances" />

{#if isLoading}
    <div class="skeleton" style="height: 400px;"></div>
{:else}
    {#if playerSyncInstalled}
        <div class="sync-entry"><button class="btn btn-sm" onclick={() => navigateTo('playersync')}>Player Sync</button></div>
    {/if}
    <div class="lookup-panel">
        <div class="lookup-copy">
            <div class="lookup-title">Player Alliance Lookup</div>
            <div class="lookup-subtitle">Search by player name or ID to see which alliance they are registered in.</div>
        </div>
        <div class="lookup-controls">
            <div class="lookup-input search-input">
                <Icon name="search" size={14} />
                <input
                    type="text"
                    bind:value={allianceLookup}
                    placeholder="Search players by ID..."
                    onkeydown={(event) => event.key === 'Enter' && runAllianceLookup()}
                />
            </div>
            <button class="btn btn-sm btn-primary lookup-btn" onclick={runAllianceLookup} disabled={allianceLookupLoading}>
                {allianceLookupLoading ? 'Searching...' : 'Search'}
            </button>
        </div>
    </div>

    <div class="alliance-layout" class:detail-active={showMobileDetail}>
        <!-- Alliance List -->
        <div class="alliance-list">
            <button class="alliance-item create-alliance-item" onclick={openCreateAllianceModal}>
                <div class="alliance-priority create-plus">+</div>
                <div class="alliance-info">
                    <div class="alliance-name">Create Alliance</div>
                    <div class="alliance-meta">
                        <span>Add a new alliance</span>
                    </div>
                </div>
            </button>

            {#each alliances as alliance (alliance.id)}
                <button
                    class="alliance-item"
                    class:active={selectedId === alliance.id}
                    onclick={() => selectAlliance(alliance.id)}
                >
                    <div class="alliance-priority">{alliance.priority}</div>
                    <div class="alliance-info">
                        <div class="alliance-name">{alliance.name || 'Unnamed'}</div>
                        <div class="alliance-meta">
                            <span>{alliance.playerCount} players</span>
                            <span class="badge">State {alliance.state || 'not set'}</span>
                        </div>
                    </div>
                </button>
            {/each}
        </div>

        <!-- Detail Panel -->
        <div class="alliance-detail">
            {#if !selectedId}
                <div class="empty-state">
                    <div class="empty-icon"><Icon name="shield" size={32} /></div>
                    <span>Pick an alliance to view its players</span>
                </div>
            {:else if isDetailLoading}
                <div class="skeleton" style="height: 200px;"></div>
            {:else}
                <div class="detail-header">
                    <div>
                        <button class="btn btn-sm back-btn" onclick={goBackToList}>◀ Back</button>
                        <div class="detail-title">{selectedAlliance?.name || 'Unnamed'}</div>
                        <div class="detail-stats">
                            <span>{players.length} players</span>
                            <span>Assigned state: {selectedAlliance?.state || 'not set'}</span>
                        </div>
                    </div>
                    <div class="header-actions">
                        <div class="filter-controls">
                            <div class="search-input">
                                <Icon name="search" size={14} />
                                <input type="text" inputmode="numeric" bind:value={playerSearch} placeholder="Search by ID..." />
                            </div>
                            <Select class="sort-select" bind:value={sortOrder} options={[
                                { value: 'asc', label: 'ID: Low → High' },
                                { value: 'desc', label: 'ID: High → Low' },
                                { value: 'default', label: 'Default Order' }
                            ]} />
                        </div>
                        <div class="action-buttons">
                            <button class="btn btn-sm" onclick={openAddPlayerModal} disabled={isAddingPlayer} aria-label="Add Player">
                                {#if isAddingPlayer}
                                    <span class="btn-spinner" aria-hidden="true"></span>
                                {:else}
                                    Add Player
                                {/if}
                            </button>
                            <button class="btn btn-sm" onclick={openExportModal} disabled={players.length === 0 || isAddingPlayer}>Export CSV</button>
                        </div>
                    </div>
                </div>

                {#if players.length === 0}
                    <div class="empty-state">
                        <div class="empty-icon"><Icon name="alliances" size={32} /></div>
                        <span>No players in this alliance</span>
                    </div>
                {:else}
                    <div class="player-grid">
                        {#each sortedPlayers() as player (player.fid)}
                            <div
                                class="player-card"
                                class:player-card-highlighted={highlightedPlayerFid === player.fid}
                                data-fid={player.fid}
                                role="button"
                                tabindex="0"
                                aria-label={`Open details for ID ${player.fid}`}
                                onclick={() => openPlayerDetail(player)}
                                onkeydown={(event) => handlePlayerCardKeydown(event, player)}
                            >
                                <div class="player-header">
                                    <div class="player-avatar">
                                        <PlayerAvatar src={player.image_url} />
                                    </div>
                                    <div class="player-identity">
                                        <div class="player-nickname" title={player.nickname || `ID ${player.fid}`}>{player.nickname || `ID ${player.fid}`}</div>
                                        <div class="player-fid">{player.nickname ? `Player ID ${player.fid}` : 'Player ID'}</div>
                                    </div>
                                </div>
                                <div class="player-stats">
                                    <div class="stat">
                                        <span class="stat-label">{getSettlementLevelLabel(player.game_type)}</span>
                                        <span class="stat-value">{formatFurnaceLevel(player.furnace_level, player.game_type)}</span>
                                    </div>
                                    <div class="stat">
                                        <span class="stat-label">Power</span>
                                        <span class="stat-value">{player.power?.toLocaleString() ?? '—'}</span>
                                    </div>
                                </div>
                                <div class="player-footer">
                                    <div class="stat player-state">
                                        <span class="stat-label">Assigned State</span>
                                        <span class="stat-value player-state-value">
                                            <span>{player.state_override ?? player.state ?? '-'}</span>
                                            {#if player.state_override != null}
                                                <span class="stat-override-badge" title="This player's state override is used instead of the alliance state">Override</span>
                                            {/if}
                                        </span>
                                    </div>
                                    <div class="player-actions">
                                        <button
                                            class="action-btn"
                                            type="button"
                                            title="Edit"
                                            onclick={(event) => {
                                                event.stopPropagation();
                                                openPlayerEdit(player);
                                            }}
                                        >
                                            <Icon name="edit" size={14} />
                                        </button>
                                        <button
                                            class="action-btn"
                                            type="button"
                                            title="Move"
                                            onclick={(event) => {
                                                event.stopPropagation();
                                                openMoveModal(player);
                                            }}
                                        >
                                            <Icon name="move" size={14} />
                                        </button>
                                        <button
                                            class="action-btn danger"
                                            type="button"
                                            title="Remove"
                                            onclick={(event) => {
                                                event.stopPropagation();
                                                removePlayer(player.fid);
                                            }}
                                        >
                                            <Icon name="delete" size={14} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        {/each}
                    </div>
                {/if}
            {/if}
        </div>
    </div>
{/if}
</div>

<!-- Export Modal -->
<Modal bind:isOpen={exportModalOpen} title="Export Players">
    <p>Export <strong>{players.length}</strong> players from <strong>{exportAllianceName}</strong> as CSV.</p>
    <p class="modal-note">Sorted by player ID. Includes: Player ID, nickname, and assigned state.</p>
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => exportModalOpen = false}>Cancel</button>
        <button class="btn btn-sm btn-primary" onclick={confirmExport}>Download CSV</button>
    </div>
</Modal>

<!-- Move Modal -->
<Modal bind:isOpen={moveModalOpen} title="Move Player">
    <p>Move <strong>{movePlayerLabel}</strong> to another alliance. Its assigned state will become the destination alliance state.</p>
    <Select class="move-select" bind:value={moveTargetId} options={otherAlliances.map(a => ({ value: a.id, label: a.name || 'Unnamed' }))} />
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => moveModalOpen = false}>Cancel</button>
        <button class="btn btn-sm btn-primary" onclick={confirmMove} disabled={isMoving}>
            {isMoving ? 'Moving...' : 'Move'}
        </button>
    </div>
</Modal>

<Modal bind:isOpen={editPlayerModalOpen} title="Edit Player">
    {#if editPlayerFid != null}
        <div class="form-group">
            <label for="edit-nickname">Nickname</label>
            <input
                id="edit-nickname"
                class="form-input"
                type="text"
                bind:value={editNickname}
                maxlength="16"
                placeholder="Nickname (primary label)"
            />
            <p class="modal-note">Shown instead of the player ID. Up to 16 characters.</p>
        </div>
        <div class="form-group">
            <label for="edit-state">State override</label>
            <input
                id="edit-state"
                class="form-input"
                type="number"
                inputmode="numeric"
                min="1"
                step="1"
                bind:value={editState}
                placeholder="e.g. 437"
            />
            <p class="modal-note">Overrides the alliance state when redeeming. Leave empty to clear the override.</p>
        </div>
        <div class="modal-actions">
            <button class="btn btn-sm" onclick={() => editPlayerModalOpen = false} disabled={isSavingPlayer}>Cancel</button>
            <button class="btn btn-sm btn-primary" onclick={savePlayerEdit} disabled={isSavingPlayer}>
                {#if isSavingPlayer}
                    <span class="btn-spinner" aria-hidden="true"></span>
                {:else}
                    Save
                {/if}
            </button>
        </div>
    {/if}
</Modal>

<Modal bind:isOpen={playerDetailModalOpen} title={selectedPlayerDetail ? (selectedPlayerDetail.nickname || `ID ${selectedPlayerDetail.fid}`) : 'Player Details'}>
    {#if selectedPlayerDetail}
        <div class="player-detail-modal">
            <div class="player-detail-overview">
                <div class="player-detail-avatar">
                    <PlayerAvatar src={selectedPlayerDetail.image_url} />
                </div>
                <div class="player-detail-headline">
                    <div class="player-detail-name">{selectedPlayerDetail.nickname || `ID ${selectedPlayerDetail.fid}`}</div>
                    <div class="player-detail-id">{selectedPlayerDetail.nickname ? `Player ID ${selectedPlayerDetail.fid}` : 'Player ID'}</div>
                </div>
            </div>

            <div class="player-detail-section">
                <div class="player-detail-section-title">General Info</div>
                <div class="player-detail-stats">
                    <div class="player-detail-stat">
                        <span class="player-detail-stat-label">{getSettlementLevelLabel(selectedPlayerDetail.game_type)}</span>
                        <span class="player-detail-stat-value">{formatFurnaceLevel(selectedPlayerDetail.furnace_level, selectedPlayerDetail.game_type)}</span>
                    </div>
                    <div class="player-detail-stat">
                        <span class="player-detail-stat-label">Power</span>
                        <span class="player-detail-stat-value">{selectedPlayerDetail.power?.toLocaleString() ?? '—'}</span>
                    </div>
                    <div class="player-detail-stat">
                        <span class="player-detail-stat-label">Last successful sync</span>
                        <span class="player-detail-stat-value">{formatTime(selectedPlayerDetail.profile_synced_at)}</span>
                    </div>
                    <div class="player-detail-stat">
                        <span class="player-detail-stat-label">Alliance</span>
                        <span class="player-detail-stat-value">{selectedAlliance?.name || 'Unknown'}</span>
                    </div>
                    <div class="player-detail-stat">
                        <span class="player-detail-stat-label">Assigned State</span>
                        <span class="player-detail-stat-value">
                            {selectedPlayerDetail.state_override ?? selectedPlayerDetail.state ?? '-'}
                            {#if selectedPlayerDetail.state_override != null}
                                <span class="stat-override-badge" title="This player's state override is used instead of the alliance state">Override</span>
                            {/if}
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-actions">
            <button class="btn btn-sm" onclick={() => playerDetailModalOpen = false}>Close</button>
            <button
                class="btn btn-sm btn-primary"
                onclick={() => {
                    const player = selectedPlayerDetail;
                    playerDetailModalOpen = false;
                    openPlayerEdit(player);
                }}
            >
                Edit
            </button>
        </div>
    {/if}
</Modal>

<Modal bind:isOpen={addPlayerModalOpen} title={`Add Player to ${selectedAlliance?.name || 'Alliance'}`}>
    <div class="form-group">
        <label for="new-player-ids">Player IDs</label>
        <textarea
            id="new-player-ids"
            class="form-input form-textarea"
            bind:value={newPlayerIds}
            placeholder="Enter one ID per line, or separate IDs with commas"
            rows="6"
        ></textarea>
        <p class="modal-note">You can paste multiple IDs from a list or spreadsheet.</p>
    </div>
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => addPlayerModalOpen = false} disabled={isAddingPlayer}>Cancel</button>
        <button class="btn btn-sm btn-primary" onclick={confirmAddPlayer} disabled={isAddingPlayer || !newPlayerIds.trim()}>
            {#if isAddingPlayer}
                <span class="btn-spinner" aria-hidden="true"></span>
            {:else}
                Add Players
            {/if}
        </button>
    </div>
</Modal>

<Modal bind:isOpen={allianceLookupModalOpen} title="Choose a Player Match">
    <p>
        Found <strong>{allianceLookupTotalMatches}</strong> matches for
        <strong>{allianceLookupMatchesQuery}</strong>.
    </p>
    <p class="modal-note">
        Select the correct player to open their alliance and highlight them in the list.
        {#if allianceLookupTotalMatches > allianceLookupMatches.length}
            Showing the first {allianceLookupMatches.length} matches, refine the search to narrow it down further.
        {/if}
    </p>
    <div class="lookup-match-list">
        {#each allianceLookupMatches as match (`${match.allianceId}:${match.fid}`)}
            <button class="lookup-match-card" type="button" onclick={() => openAllianceLookupMatch(match)}>
                <div class="lookup-match-main">
                    <strong>{match.nickname || `ID ${match.fid}`}</strong>
                    <span>{match.nickname ? `Player ID ${match.fid}` : 'Player ID'}</span>
                </div>
                <div class="lookup-match-meta">
                    <span>{match.allianceName}</span>
                    <span>Assigned state {match.state || '-'}</span>
                </div>
            </button>
        {/each}
    </div>
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => allianceLookupModalOpen = false}>Close</button>
    </div>
</Modal>

<Modal bind:isOpen={createAllianceModalOpen} title="Create Alliance">
    {#if createAllianceStep === 1}
        <div class="form-group">
            <label for="create-alliance-name">Alliance Name</label>
            <input
                id="create-alliance-name"
                class="form-input"
                type="text"
                bind:value={createAllianceName}
                placeholder="Enter alliance name"
                maxlength="50"
            />
        </div>
        <div class="form-group">
            <label for="create-alliance-state">State</label>
            <input
                id="create-alliance-state"
                class="form-input"
                type="number"
                inputmode="numeric"
                min="1"
                step="1"
                bind:value={createAllianceState}
                placeholder="e.g. 437"
            />
            <p class="modal-note">Every player added to this alliance inherits this state.</p>
        </div>
        <div class="modal-actions">
            <button class="btn btn-sm" onclick={() => createAllianceModalOpen = false} disabled={isCreateSubmitting}>Cancel</button>
            <button class="btn btn-sm btn-primary" onclick={goToCreateAllianceStep2} disabled={isCreateSubmitting}>Next</button>
        </div>
    {:else}
        <div class="form-group">
            <div class="form-label">Server</div>
            <Select
                class="move-select"
                bind:value={createGuildId}
                options={createGuilds.map(g => ({ value: g.id, label: g.name }))}
                placeholder={isCreateLoadingGuilds ? 'Loading servers...' : 'Select server'}
                onchange={handleCreateGuildChange}
            />
        </div>

        {#if createGuildId}
            <div class="form-group">
                <div class="form-label">Channel</div>
                <Select
                    class="move-select"
                    bind:value={createChannelId}
                    options={createChannels.map(ch => ({ value: ch.id, label: ch.name }))}
                    placeholder={isCreateLoadingChannels ? 'Loading channels...' : 'Select channel'}
                />
            </div>
        {/if}

        <div class="modal-actions">
            <button class="btn btn-sm" onclick={() => createAllianceStep = 1} disabled={isCreateSubmitting}>Back</button>
            <button class="btn btn-sm" onclick={() => createAllianceModalOpen = false} disabled={isCreateSubmitting}>Cancel</button>
            <button class="btn btn-sm btn-primary" onclick={confirmCreateAlliance} disabled={isCreateSubmitting || !createGuildId || !createChannelId}>
                {#if isCreateSubmitting}
                    <span class="btn-spinner" aria-hidden="true"></span>
                {:else}
                    Create
                {/if}
            </button>
        </div>
    {/if}
</Modal>

<ConfirmDialog
    bind:isOpen={confirmRemoveOpen}
    title="Remove Player"
    message={`Remove ID ${removeFid} from this alliance?`}
    confirmLabel="Remove"
    variant="danger"
    onconfirm={confirmRemovePlayer}
/>

<style>
    .sync-entry { display: flex; justify-content: flex-end; margin-bottom: 16px; }
    .lookup-panel {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 16px;
        padding: 16px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: linear-gradient(135deg, var(--color-card) 0%, var(--color-secondary) 100%);
    }

    .lookup-copy {
        min-width: 0;
    }

    .lookup-title {
        font-size: 15px;
        font-weight: 700;
    }

    .lookup-subtitle {
        margin-top: 4px;
        color: var(--color-text-muted);
        font-size: 13px;
    }

    .lookup-controls {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-shrink: 0;
    }

    .lookup-input {
        min-width: min(360px, 60vw);
    }

    .lookup-input input {
        width: 100%;
        min-width: 220px;
    }

    .lookup-btn {
        height: 36px;
        min-width: 92px;
    }

    .lookup-match-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 14px;
        max-height: min(60vh, 420px);
        overflow-y: auto;
    }

    .lookup-match-card {
        display: flex;
        flex-direction: column;
        gap: 6px;
        width: 100%;
        padding: 12px 14px;
        text-align: left;
        color: var(--color-text-primary);
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        cursor: pointer;
        transition: border-color 0.15s ease, background-color 0.15s ease, transform 0.15s ease;
    }

    .lookup-match-card:hover {
        border-color: var(--color-border-accent);
        background: var(--color-card-hover);
        transform: translateY(-1px);
    }

    .lookup-match-main {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        align-items: center;
    }

    .lookup-match-main span {
        color: var(--color-text-muted);
        font-family: var(--font-mono);
        font-size: 12px;
    }

    .lookup-match-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        color: var(--color-text-secondary);
        font-size: 12px;
    }

    .alliances-page {
        container: alliances / inline-size;
        min-width: 0;
    }

    .alliance-layout {
        display: flex;
        gap: 20px;
        height: calc(100vh - 240px);
        overflow: hidden;
    }

    .alliance-list {
        width: 280px;
        flex-shrink: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
        overflow-y: auto;
        scrollbar-width: none;
    }

    .alliance-list::-webkit-scrollbar {
        display: none;
    }

    .alliance-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        cursor: pointer;
        font-family: inherit;
        text-align: left;
        width: 100%;
        color: var(--color-text-primary);
        transition: all 0.15s ease;
    }

    .alliance-item:hover {
        border-color: var(--color-border-accent);
        background: var(--color-card-hover);
    }

    .alliance-item.active {
        border-color: var(--color-accent);
        background: var(--color-accent-soft);
    }

    .create-alliance-item {
        border-style: dashed;
    }

    .create-alliance-item:hover {
        border-color: var(--color-accent);
        background: var(--color-accent-soft);
    }

    .create-plus {
        font-size: 18px;
        font-weight: 700;
    }

    .alliance-priority {
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        background: var(--color-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
        color: var(--color-accent);
    }

    .alliance-info { min-width: 0; }

    .alliance-name {
        font-weight: 600;
        font-size: 14px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .alliance-meta {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        color: var(--color-text-muted);
        margin-top: 2px;
    }

    .alliance-detail {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .detail-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 16px;
        padding-bottom: 16px;
        margin-bottom: 4px;
        flex-shrink: 0;
        border-bottom: 1px solid var(--color-border);
    }

    .detail-title {
        font-size: 20px;
        font-weight: 700;
        margin: 8px 0 4px;
    }

    .detail-stats {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        font-size: 13px;
        color: var(--color-text-muted);
    }

    .header-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
    }

    .filter-controls {
        display: flex;
        gap: 8px;
        align-items: center;
        min-width: 0;
    }

    .action-buttons {
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .search-input {
        display: flex;
        align-items: center;
        gap: 6px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        height: 30px;
        padding: 0 10px 0 8px;
        color: var(--color-text-muted);
        overflow: hidden;
    }

    .search-input :global(svg) {
        flex: 0 0 auto;
    }

    .search-input input {
        border: none;
        background: none;
        padding: 0 0 0 2px;
        width: 100%;
        min-width: 0;
        flex: 1 1 auto;
        font-size: 12px;
        line-height: 1.4;
    }

    .search-input {
        min-width: 0;
    }

    .search-input input:focus {
        border-color: transparent;
        box-shadow: none;
        outline: none;
    }

    .search-input:focus-within {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    :global(.sort-select),
    :global(.move-select) {
        width: auto;
        min-width: auto;
    }

    :global(.sort-select .select-trigger) {
        height: 30px;
        padding: 5px 12px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        line-height: 1.4;
    }

    .action-buttons .btn {
        height: 30px;
    }

    .back-btn { display: none; }

    .btn-spinner {
        width: 14px;
        height: 14px;
        display: inline-block;
        border-radius: 50%;
        border: 2px solid currentColor;
        border-right-color: transparent;
        animation: spin 0.8s linear infinite;
        vertical-align: middle;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin: 12px 0;
    }

    .form-group label {
        font-size: 13px;
        color: var(--color-text-secondary);
        font-weight: 600;
    }

    .form-label {
        font-size: 13px;
        color: var(--color-text-secondary);
        font-weight: 600;
    }

    .form-input {
        width: 100%;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        padding: 9px 10px;
        font: inherit;
    }

    .form-textarea {
        min-height: 120px;
        resize: vertical;
    }

    .form-input:focus {
        outline: none;
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    .player-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(min(100%, 260px), 1fr));
        gap: 12px;
        overflow-y: auto;
        flex: 1;
        padding: 4px 2px 4px 0;
        align-content: start;
        scrollbar-width: none;
    }

    .player-grid::-webkit-scrollbar {
        display: none;
    }

    .player-card {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        padding: 14px;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 10px;
        text-align: left;
        cursor: pointer;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }

    .player-card:hover {
        border-color: var(--color-border-accent);
        box-shadow: var(--shadow-md);
    }

    .player-card-highlighted {
        border-color: var(--color-accent);
        background: var(--color-accent-soft);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    .player-card:focus-visible {
        outline: none;
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    .player-actions {
        display: flex;
        gap: 4px;
        flex-shrink: 0;
        margin-left: auto;
    }

    .action-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-secondary);
        font-size: 14px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s ease;
    }

    .action-btn:hover { border-color: var(--color-accent); background: var(--color-accent-soft); }
    .action-btn.danger:hover { border-color: var(--color-danger); background: var(--color-danger-soft); color: var(--color-danger); }
    .action-btn:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px; }

    .player-header {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .player-identity { min-width: 0; }

    .player-avatar {
        width: 40px;
        height: 40px;
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 16px;
        color: var(--color-accent);
        overflow: hidden;
        flex-shrink: 0;
    }

    .player-nickname {
        font-weight: 600;
        font-size: 14px;
        overflow-wrap: anywhere;
    }

    .player-fid {
        font-size: 12px;
        color: var(--color-text-muted);
        font-family: var(--font-mono);
        overflow-wrap: anywhere;
    }

    .player-stats {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(0, 1.3fr);
        gap: 12px;
    }

    .player-footer {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 10px 12px;
        margin-top: auto;
        padding-top: 10px;
        border-top: 1px solid var(--color-border);
    }

    .player-state-value {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 4px 6px;
    }

    .player-detail-modal {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    .player-detail-overview {
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .player-detail-avatar {
        width: 52px;
        height: 52px;
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        color: var(--color-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        font-weight: 700;
        overflow: hidden;
        flex-shrink: 0;
    }

    .player-detail-name {
        font-size: 18px;
        font-weight: 700;
        overflow-wrap: anywhere;
    }

    .player-detail-headline { min-width: 0; }

    .player-detail-id {
        margin-top: 4px;
        color: var(--color-text-muted);
        font-family: var(--font-mono);
        font-size: 12px;
    }

    .player-detail-section {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .player-detail-section-title {
        font-size: 13px;
        font-weight: 700;
        color: var(--color-text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.4px;
    }

    .player-detail-stats {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
    }

    .player-detail-stat {
        min-width: 0;
        padding: 12px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .player-detail-stat-label {
        font-size: 11px;
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    .player-detail-stat-value {
        font-size: 14px;
        font-weight: 600;
        overflow-wrap: anywhere;
    }

    .stat { display: flex; flex-direction: column; gap: 4px; min-width: 0; }
    .stat-label { font-size: 11px; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.3px; }
    .stat-value { font-size: 14px; font-weight: 600; overflow-wrap: anywhere; font-variant-numeric: tabular-nums; }
    .stat-override-badge {
        display: inline-block;
        max-width: 100%;
        padding: 1px 6px;
        border-radius: 999px;
        background: var(--color-accent-soft);
        color: var(--color-accent);
        font-size: 10px;
        font-weight: 600;
        line-height: 1.6;
        vertical-align: middle;
    }

    @media (pointer: coarse) {
        .action-btn { width: 44px; height: 44px; }
    }

    :global(.move-select) {
        width: 100%;
        margin-top: 12px;
    }

    @container alliances (max-width: 640px) {
        .lookup-panel {
            flex-direction: column;
            align-items: stretch;
            padding: 14px;
        }

        .lookup-controls {
            width: 100%;
            flex-direction: column;
            align-items: stretch;
        }

        .lookup-input {
            min-width: 0;
            width: 100%;
            flex: none;
        }

        .lookup-input input {
            width: 100%;
            min-width: 0;
        }

        .lookup-btn {
            width: 100%;
            min-width: 0;
        }

        .alliance-layout {
            flex-direction: column;
            height: auto;
        }

        .alliance-list {
            width: 100%;
            max-height: none;
            overflow-y: visible;
        }

        .alliance-detail {
            display: none;
            overflow: visible;
        }

        .alliance-layout.detail-active .alliance-list {
            display: none;
        }

        .alliance-layout.detail-active .alliance-detail {
            display: flex;
        }

        .player-grid {
            overflow-y: visible;
        }

        .back-btn {
            display: inline-flex;
        }

        .header-actions {
            display: grid;
            grid-template-columns: 1fr;
            width: 100%;
            gap: 8px;
        }

        .filter-controls {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            width: 100%;
        }

        .search-input input {
            width: 100%;
            min-width: 0;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            width: 100%;
        }

        .action-buttons .btn {
            width: 100%;
            justify-content: center;
        }
    }

    @media (max-width: 768px) {
        .player-detail-stats { grid-template-columns: 1fr; }
    }
</style>
