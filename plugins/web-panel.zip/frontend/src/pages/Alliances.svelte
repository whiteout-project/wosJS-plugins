<script>
    import { onMount } from 'svelte';
    import { apiFetch, downloadFile } from '../lib/api.js';
    import { formatFurnaceLevel, showToast } from '../lib/utils.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';
    import Select from '../components/ui/Select.svelte';

    let alliances = $state([]);
    let selectedId = $state(null);
    let players = $state([]);
    let isLoading = $state(true);
    let isDetailLoading = $state(false);
    let sortOrder = $state('desc');
    let showMobileDetail = $state(false);

    // Export modal
    let exportModalOpen = $state(false);
    let exportAllianceName = $state('');

    // Move modal
    let moveModalOpen = $state(false);
    let movePlayerFid = $state(null);
    let movePlayerName = $state('');
    let moveTargetId = $state(null);
    let isMoving = $state(false);

    // Remove confirmation dialog
    let confirmRemoveOpen = $state(false);
    let removeFid = $state(null);
    let removeName = $state('');

    // Player search
    let playerSearch = $state('');
    let addPlayerModalOpen = $state(false);
    let newPlayerId = $state('');
    let isAddingPlayer = $state(false);

    // Create alliance wizard
    let createAllianceModalOpen = $state(false);
    let createAllianceStep = $state(1);
    let createAllianceName = $state('');
    let createRefreshRate = $state('60');
    let createGuildId = $state('');
    let createChannelId = $state('');
    let createGuilds = $state([]);
    let createChannels = $state([]);
    let isCreateSubmitting = $state(false);
    let isCreateLoadingGuilds = $state(false);
    let isCreateLoadingChannels = $state(false);

    let sortedPlayers = $derived(() => {
        let result = players;
        if (playerSearch.trim()) {
            const q = playerSearch.toLowerCase();
            result = result.filter(p =>
                (p.nickname || '').toLowerCase().includes(q) ||
                String(p.fid).includes(q)
            );
        }
        if (sortOrder === 'asc') return [...result].sort((a, b) => (a.furnace_level || 0) - (b.furnace_level || 0));
        if (sortOrder === 'desc') return [...result].sort((a, b) => (b.furnace_level || 0) - (a.furnace_level || 0));
        return result;
    });

    let selectedAlliance = $derived(alliances.find(a => a.id === selectedId));
    let otherAlliances = $derived(alliances.filter(a => a.id !== selectedId));

    function isAutoRefreshEnabled(interval) {
        if (typeof interval === 'string' && interval.startsWith('@')) return true;
        const minutes = Number(interval);
        return Number.isFinite(minutes) && minutes > 0;
    }

    function formatAllianceInterval(interval) {
        if (!isAutoRefreshEnabled(interval)) return '';

        if (typeof interval === 'string' && interval.startsWith('@')) {
            return interval;
        }

        const minutes = Number(interval);
        const normalized = Number.isInteger(minutes)
            ? String(minutes)
            : String(minutes).replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1');

        return `${normalized}m`;
    }

    onMount(async () => {
        try {
            const data = await apiFetch('/api/alliances');
            if (data) alliances = data;
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    });

    async function selectAlliance(id) {
        selectedId = id;
        showMobileDetail = true;
        isDetailLoading = true;
        playerSearch = '';

        try {
            const data = await apiFetch(`/api/alliances/${id}`);
            if (data) players = data.players || [];
        } catch (error) {
            showToast(error.message, 'error');
            players = [];
        } finally {
            isDetailLoading = false;
        }
    }

    function goBackToList() {
        showMobileDetail = false;
    }

    async function refreshAlliance() {
        if (!selectedId) return;
        try {
            const refreshResult = await apiFetch(`/api/alliances/${selectedId}/refresh`, { method: 'POST' });
            if (refreshResult) showToast(`Refresh started (ID: ${refreshResult.processId})`, 'success');
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    async function loadCreateGuilds() {
        isCreateLoadingGuilds = true;
        try {
            const guildData = await apiFetch('/api/guilds');
            createGuilds = Array.isArray(guildData) ? guildData : [];
        } catch (error) {
            createGuilds = [];
            showToast(error.message, 'error');
        } finally {
            isCreateLoadingGuilds = false;
        }
    }

    async function loadCreateChannels(guildId) {
        if (!guildId) {
            createChannels = [];
            createChannelId = '';
            return;
        }

        isCreateLoadingChannels = true;
        try {
            const channelData = await apiFetch(`/api/guilds/${guildId}/channels`);
            createChannels = Array.isArray(channelData) ? channelData : [];
            createChannelId = createChannels[0]?.id || '';
        } catch (error) {
            createChannels = [];
            createChannelId = '';
            showToast(error.message, 'error');
        } finally {
            isCreateLoadingChannels = false;
        }
    }

    async function openCreateAllianceModal() {
        createAllianceStep = 1;
        createAllianceName = '';
        createRefreshRate = '60';
        createGuildId = '';
        createChannelId = '';
        createChannels = [];
        createAllianceModalOpen = true;
        await loadCreateGuilds();
    }

    async function goToCreateAllianceStep2() {
        if (!createAllianceName.trim()) {
            showToast('Alliance name is required', 'error');
            return;
        }
        if (!createRefreshRate.trim()) {
            showToast('Refresh rate is required', 'error');
            return;
        }

        createAllianceStep = 2;
    }

    async function handleCreateGuildChange() {
        createChannelId = '';
        await loadCreateChannels(createGuildId);
    }

    async function confirmCreateAlliance() {
        if (!createAllianceName.trim() || !createRefreshRate.trim()) return;
        if (!createGuildId || !createChannelId) {
            showToast('Select both server and channel', 'error');
            return;
        }

        isCreateSubmitting = true;
        try {
            const createResult = await apiFetch('/api/alliances', {
                method: 'POST',
                body: {
                    name: createAllianceName.trim(),
                    refreshRate: createRefreshRate.trim(),
                },
            });

            if (!createResult?.alliance?.id) {
                showToast('Failed to create alliance', 'error');
                return;
            }

            const finalizeResult = await apiFetch(`/api/alliances/${createResult.alliance.id}/finalize`, {
                method: 'POST',
                body: {
                    guildId: createGuildId,
                    channelId: createChannelId,
                },
            });

            if (!finalizeResult?.ok) {
                showToast('Alliance created but finalization failed', 'error');
                return;
            }

            const data = await apiFetch('/api/alliances');
            if (data) alliances = data;

            createAllianceModalOpen = false;
            showToast(`Alliance "${finalizeResult.alliance?.name || createAllianceName.trim()}" created`, 'success');

            if (finalizeResult.alliance?.id) {
                await selectAlliance(finalizeResult.alliance.id);
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isCreateSubmitting = false;
        }
    }

    function openAddPlayerModal() {
        newPlayerId = '';
        addPlayerModalOpen = true;
    }

    async function confirmAddPlayer() {
        if (!selectedId || !newPlayerId.trim()) return;
        isAddingPlayer = true;

        try {
            const addResult = await apiFetch(`/api/alliances/${selectedId}/players`, {
                method: 'POST',
                body: { playerId: newPlayerId.trim() },
            });

            if (addResult?.ok) {
                showToast(`Add player started (ID: ${addResult.processId})`, 'success');
                addPlayerModalOpen = false;
                newPlayerId = '';
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isAddingPlayer = false;
        }
    }

    function openExportModal() {
        exportAllianceName = selectedAlliance?.name || 'Unnamed';
        exportModalOpen = true;
    }

    async function confirmExport() {
        try {
            await downloadFile(`/api/alliances/${selectedId}/export`, `${exportAllianceName}_players.csv`);
            showToast('Export downloaded', 'success');
            exportModalOpen = false;
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    function openMoveModal(fid, name) {
        movePlayerFid = fid;
        movePlayerName = name;
        moveTargetId = otherAlliances[0]?.id || null;
        moveModalOpen = true;
    }

    async function confirmMove() {
        if (!moveTargetId || !movePlayerFid) return;
        isMoving = true;

        try {
            const moveResult = await apiFetch(`/api/players/${movePlayerFid}/move`, {
                method: 'POST',
                body: { allianceId: moveTargetId },
            });

            if (moveResult?.ok) {
                players = players.filter(p => p.fid !== movePlayerFid);
                const targetAlliance = alliances.find(a => a.id === moveTargetId);
                showToast(`Player moved to ${targetAlliance?.name || 'alliance'}`, 'success');
                moveModalOpen = false;
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isMoving = false;
        }
    }

    async function removePlayer(fid, name) {
        removeFid = fid;
        removeName = name;
        confirmRemoveOpen = true;
    }

    async function confirmRemovePlayer() {
        const fid = removeFid;
        try {
            const deleteResult = await apiFetch(`/api/players/${fid}`, { method: 'DELETE' });
            if (deleteResult?.ok) {
                players = players.filter(p => p.fid !== fid);
                showToast(`Player #${fid} removed`, 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        }
    }
</script>

<PageHeader label="Alliances" />

{#if isLoading}
    <div class="skeleton" style="height: 400px;"></div>
{:else}
    <div class="alliance-layout" class:detail-active={showMobileDetail}>
        <!-- Alliance List -->
        <div class="alliance-list">
            <button class="alliance-item create-alliance-item" onclick={openCreateAllianceModal}>
                <div class="alliance-priority create-plus">+</div>
                <div class="alliance-info">
                    <div class="alliance-name">Create Alliance</div>
                    <div class="alliance-meta">
                        <span>Add a new alliance</span>
                    </div>
                </div>
            </button>

            {#each alliances as alliance (alliance.id)}
                <button
                    class="alliance-item"
                    class:active={selectedId === alliance.id}
                    onclick={() => selectAlliance(alliance.id)}
                >
                    <div class="alliance-priority">{alliance.priority}</div>
                    <div class="alliance-info">
                        <div class="alliance-name">{alliance.name || 'Unnamed'}</div>
                        <div class="alliance-meta">
                            <span>{alliance.playerCount} players</span>
                            <span class="badge" class:badge-success={isAutoRefreshEnabled(alliance.interval)} class:badge-danger={!isAutoRefreshEnabled(alliance.interval)}>
                                {isAutoRefreshEnabled(alliance.interval) ? 'Auto' : 'Off'}
                            </span>
                            {#if isAutoRefreshEnabled(alliance.interval)}
                                <span>{formatAllianceInterval(alliance.interval)}</span>
                            {/if}
                        </div>
                    </div>
                </button>
            {/each}
        </div>

        <!-- Detail Panel -->
        <div class="alliance-detail">
            {#if !selectedId}
                <div class="empty-state">
                    <div class="empty-icon"><Icon name="shield" size={32} /></div>
                    <span>Pick an alliance to view its players</span>
                </div>
            {:else if isDetailLoading}
                <div class="skeleton" style="height: 200px;"></div>
            {:else}
                <div class="detail-header">
                    <div>
                        <button class="btn btn-sm back-btn" onclick={goBackToList}>◀ Back</button>
                        <div class="detail-title">{selectedAlliance?.name || 'Unnamed'}</div>
                        <div class="detail-stats">
                            <span>{players.length} players</span>
                            <span>
                                {#if isAutoRefreshEnabled(selectedAlliance?.interval)}
                                    Refresh Rate: {formatAllianceInterval(selectedAlliance?.interval)}
                                {:else}
                                    Auto refresh disabled
                                {/if}
                            </span>
                        </div>
                    </div>
                    <div class="header-actions">
                        <div class="filter-controls">
                            <div class="search-input">
                                <Icon name="search" size={14} />
                                <input type="text" bind:value={playerSearch} placeholder="Search players..." />
                            </div>
                            <Select class="sort-select" bind:value={sortOrder} options={[
                                { value: 'desc', label: 'Furnace: High → Low' },
                                { value: 'asc', label: 'Furnace: Low → High' },
                                { value: 'default', label: 'Default Order' }
                            ]} />
                        </div>
                        <div class="action-buttons">
                            <button class="btn btn-sm" onclick={refreshAlliance} disabled={players.length === 0 || isAddingPlayer}>Refresh</button>
                            <button class="btn btn-sm" onclick={openAddPlayerModal} disabled={isAddingPlayer} aria-label="Add Player">
                                {#if isAddingPlayer}
                                    <span class="btn-spinner" aria-hidden="true"></span>
                                {:else}
                                    Add Player
                                {/if}
                            </button>
                            <button class="btn btn-sm" onclick={openExportModal} disabled={players.length === 0 || isAddingPlayer}>Export CSV</button>
                        </div>
                    </div>
                </div>

                {#if players.length === 0}
                    <div class="empty-state">
                        <div class="empty-icon"><Icon name="alliances" size={32} /></div>
                        <span>No players in this alliance</span>
                    </div>
                {:else}
                    <div class="player-grid">
                        {#each sortedPlayers() as player (player.fid)}
                            <div class="player-card">
                                <div class="player-actions">
                                    <button class="action-btn" title="Move" onclick={() => openMoveModal(player.fid, player.nickname || 'Unknown')}>
                                        <Icon name="move" size={14} />
                                    </button>
                                    <button class="action-btn danger" title="Remove" onclick={() => removePlayer(player.fid, player.nickname || 'Unknown')}>
                                        <Icon name="delete" size={14} />
                                    </button>
                                </div>
                                <div class="player-header">
                                    <div class="player-avatar">
                                        {#if player.image_url?.trim()}
                                            <img src={player.image_url} alt={player.nickname || 'Unknown'} />
                                        {:else}
                                            {(player.nickname || '?')[0].toUpperCase()}
                                        {/if}
                                    </div>
                                    <div>
                                        <div class="player-nickname">{player.nickname || 'Unknown'}</div>
                                        <div class="player-fid">#{player.fid}</div>
                                    </div>
                                </div>
                                <div class="player-stats">
                                    <div class="stat">
                                        <span class="stat-label">Furnace</span>
                                        <span class="stat-value">{formatFurnaceLevel(player.furnace_level)}</span>
                                    </div>
                                    <div class="stat">
                                        <span class="stat-label">State</span>
                                        <span class="stat-value">{player.state || '-'}</span>
                                    </div>
                                </div>
                            </div>
                        {/each}
                    </div>
                {/if}
            {/if}
        </div>
    </div>
{/if}

<!-- Export Modal -->
<Modal bind:isOpen={exportModalOpen} title="Export Players">
    <p>Export <strong>{players.length}</strong> players from <strong>{exportAllianceName}</strong> as CSV.</p>
    <p class="modal-note">Sorted by furnace level (highest first). Includes: Player ID, Name, Furnace Level, State.</p>
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => exportModalOpen = false}>Cancel</button>
        <button class="btn btn-sm btn-primary" onclick={confirmExport}>Download CSV</button>
    </div>
</Modal>

<!-- Move Modal -->
<Modal bind:isOpen={moveModalOpen} title="Move Player">
    <p>Move <strong>{movePlayerName}</strong> (#{movePlayerFid}) to another alliance:</p>
    <Select class="move-select" bind:value={moveTargetId} options={otherAlliances.map(a => ({ value: a.id, label: a.name || 'Unnamed' }))} />
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => moveModalOpen = false}>Cancel</button>
        <button class="btn btn-sm btn-primary" onclick={confirmMove} disabled={isMoving}>
            {isMoving ? 'Moving...' : 'Move'}
        </button>
    </div>
</Modal>

<Modal bind:isOpen={addPlayerModalOpen} title="Add Player">
    <p>Add a player to <strong>{selectedAlliance?.name || 'this alliance'}</strong>.</p>
    <div class="form-group">
        <label for="new-player-id">Player ID</label>
        <input id="new-player-id" class="form-input" type="text" bind:value={newPlayerId} placeholder="Enter player identifier" />
    </div>
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => addPlayerModalOpen = false} disabled={isAddingPlayer}>Cancel</button>
        <button class="btn btn-sm btn-primary" onclick={confirmAddPlayer} disabled={isAddingPlayer || !newPlayerId.trim()}>
            {#if isAddingPlayer}
                <span class="btn-spinner" aria-hidden="true"></span>
            {:else}
                Add Player
            {/if}
        </button>
    </div>
</Modal>

<Modal bind:isOpen={createAllianceModalOpen} title="Create Alliance">
    {#if createAllianceStep === 1}
        <div class="form-group">
            <label for="create-alliance-name">Alliance Name</label>
            <input
                id="create-alliance-name"
                class="form-input"
                type="text"
                bind:value={createAllianceName}
                placeholder="Enter alliance name"
                maxlength="50"
            />
        </div>
        <div class="form-group">
            <label for="create-refresh-rate">Refresh Rate</label>
            <input
                id="create-refresh-rate"
                class="form-input"
                type="text"
                bind:value={createRefreshRate}
                placeholder="60 or @02:30"
                maxlength="6"
            />
            <p class="modal-note">Supports minutes (e.g. 60) or daily time format (e.g. @02:30).</p>
        </div>
        <div class="modal-actions">
            <button class="btn btn-sm" onclick={() => createAllianceModalOpen = false} disabled={isCreateSubmitting}>Cancel</button>
            <button class="btn btn-sm btn-primary" onclick={goToCreateAllianceStep2} disabled={isCreateSubmitting}>Next</button>
        </div>
    {:else}
        <div class="form-group">
            <div class="form-label">Server</div>
            <Select
                class="move-select"
                bind:value={createGuildId}
                options={createGuilds.map(g => ({ value: g.id, label: g.name }))}
                placeholder={isCreateLoadingGuilds ? 'Loading servers...' : 'Select server'}
                onchange={handleCreateGuildChange}
            />
        </div>

        {#if createGuildId}
            <div class="form-group">
                <div class="form-label">Channel</div>
                <Select
                    class="move-select"
                    bind:value={createChannelId}
                    options={createChannels.map(ch => ({ value: ch.id, label: ch.name }))}
                    placeholder={isCreateLoadingChannels ? 'Loading channels...' : 'Select channel'}
                />
            </div>
        {/if}

        <div class="modal-actions">
            <button class="btn btn-sm" onclick={() => createAllianceStep = 1} disabled={isCreateSubmitting}>Back</button>
            <button class="btn btn-sm" onclick={() => createAllianceModalOpen = false} disabled={isCreateSubmitting}>Cancel</button>
            <button class="btn btn-sm btn-primary" onclick={confirmCreateAlliance} disabled={isCreateSubmitting || !createGuildId || !createChannelId}>
                {#if isCreateSubmitting}
                    <span class="btn-spinner" aria-hidden="true"></span>
                {:else}
                    Create
                {/if}
            </button>
        </div>
    {/if}
</Modal>

<ConfirmDialog
    bind:isOpen={confirmRemoveOpen}
    title="Remove Player"
    message={`Remove ${removeName} (#${removeFid}) from this alliance?`}
    confirmLabel="Remove"
    variant="danger"
    onconfirm={confirmRemovePlayer}
/>

<style>
    .alliance-layout {
        display: flex;
        gap: 20px;
        height: calc(100vh - 180px);
        overflow: hidden;
    }

    .alliance-list {
        width: 280px;
        flex-shrink: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
        overflow-y: auto;
        scrollbar-width: none;
    }

    .alliance-list::-webkit-scrollbar {
        display: none;
    }

    .alliance-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        cursor: pointer;
        font-family: inherit;
        text-align: left;
        width: 100%;
        color: var(--color-text-primary);
        transition: all 0.15s ease;
    }

    .alliance-item:hover {
        border-color: var(--color-border-accent);
        background: var(--color-card-hover);
    }

    .alliance-item.active {
        border-color: var(--color-accent);
        background: var(--color-accent-soft);
    }

    .create-alliance-item {
        border-style: dashed;
    }

    .create-alliance-item:hover {
        border-color: var(--color-accent);
        background: var(--color-accent-soft);
    }

    .create-plus {
        font-size: 18px;
        font-weight: 700;
    }

    .alliance-priority {
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        background: var(--color-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 14px;
        flex-shrink: 0;
        color: var(--color-accent);
    }

    .alliance-info { min-width: 0; }

    .alliance-name {
        font-weight: 600;
        font-size: 14px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .alliance-meta {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        color: var(--color-text-muted);
        margin-top: 2px;
    }

    .alliance-detail {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .detail-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 16px;
        padding-bottom: 16px;
        margin-bottom: 4px;
        flex-shrink: 0;
        border-bottom: 1px solid var(--color-border);
    }

    .detail-title {
        font-size: 20px;
        font-weight: 700;
        margin: 8px 0 4px;
    }

    .detail-stats {
        display: flex;
        gap: 16px;
        font-size: 13px;
        color: var(--color-text-muted);
    }

    .header-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
    }

    .filter-controls {
        display: flex;
        gap: 8px;
        align-items: center;
        min-width: 0;
    }

    .action-buttons {
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .search-input {
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        height: 30px;
        padding: 0 10px;
        color: var(--color-text-muted);
    }

    .search-input input {
        border: none;
        background: none;
        padding: 0;
        width: 140px;
        font-size: 12px;
        line-height: 1.4;
    }

    .search-input {
        min-width: 0;
    }

    .search-input input:focus {
        border-color: transparent;
        box-shadow: none;
        outline: none;
    }

    .search-input:focus-within {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    :global(.sort-select),
    :global(.move-select) {
        width: auto;
        min-width: auto;
    }

    :global(.sort-select .select-trigger) {
        height: 30px;
        padding: 5px 12px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        line-height: 1.4;
    }

    .action-buttons .btn {
        height: 30px;
    }

    .back-btn { display: none; }

    .btn-spinner {
        width: 14px;
        height: 14px;
        display: inline-block;
        border-radius: 50%;
        border: 2px solid currentColor;
        border-right-color: transparent;
        animation: spin 0.8s linear infinite;
        vertical-align: middle;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin: 12px 0;
    }

    .form-group label {
        font-size: 13px;
        color: var(--color-text-secondary);
        font-weight: 600;
    }

    .form-label {
        font-size: 13px;
        color: var(--color-text-secondary);
        font-weight: 600;
    }

    .form-input {
        width: 100%;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        padding: 9px 10px;
        font: inherit;
    }

    .form-input:focus {
        outline: none;
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    .player-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
        gap: 12px;
        overflow-y: auto;
        flex: 1;
        padding: 4px 2px 4px 0;
        align-content: start;
        scrollbar-width: none;
    }

    .player-grid::-webkit-scrollbar {
        display: none;
    }

    .player-card {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        padding: 16px;
        position: relative;
        transition: all 0.2s ease;
    }

    .player-card:hover {
        border-color: var(--color-border-accent);
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }

    .player-actions {
        position: absolute;
        top: 8px;
        right: 8px;
        display: flex;
        gap: 4px;
        opacity: 0;
        transition: opacity 0.15s ease;
    }

    .player-card:hover .player-actions { opacity: 1; }

    .action-btn {
        width: 26px;
        height: 26px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-secondary);
        font-size: 14px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s ease;
    }

    .action-btn:hover { border-color: var(--color-accent); background: var(--color-accent-soft); }
    .action-btn.danger:hover { border-color: var(--color-danger); background: var(--color-danger-soft); color: var(--color-danger); }

    .player-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
    }

    .player-avatar {
        width: 40px;
        height: 40px;
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 16px;
        color: var(--color-accent);
        overflow: hidden;
        flex-shrink: 0;
    }

    .player-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .player-nickname {
        font-weight: 600;
        font-size: 14px;
    }

    .player-fid {
        font-size: 12px;
        color: var(--color-text-muted);
        font-family: var(--font-mono);
    }

    .player-stats {
        display: flex;
        gap: 16px;
    }

    .stat { display: flex; flex-direction: column; gap: 2px; }
    .stat-label { font-size: 11px; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.3px; }
    .stat-value { font-size: 14px; font-weight: 600; }

    :global(.move-select) {
        width: 100%;
        margin-top: 12px;
    }

    @media (max-width: 768px) {
        .alliance-layout {
            flex-direction: column;
            height: auto;
        }

        .alliance-list {
            width: 100%;
            max-height: none;
            overflow-y: visible;
        }

        .alliance-detail {
            display: none;
            overflow: visible;
        }

        .alliance-layout.detail-active .alliance-list {
            display: none;
        }

        .alliance-layout.detail-active .alliance-detail {
            display: flex;
        }

        .player-grid {
            overflow-y: visible;
        }

        .back-btn {
            display: inline-flex;
        }

        .header-actions {
            display: grid;
            grid-template-columns: 1fr;
            width: 100%;
            gap: 8px;
        }

        .filter-controls {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            width: 100%;
        }

        .search-input input {
            width: 100%;
            min-width: 0;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            width: 100%;
        }

        .action-buttons .btn {
            width: 100%;
            justify-content: center;
        }
    }
</style>
