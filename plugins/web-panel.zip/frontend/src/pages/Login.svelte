<script>
    import { botInfo } from '../lib/stores.js';
    import { getBasePath } from '../lib/api.js';

    const basePath = getBasePath();
    let initial = $derived($botInfo.name?.charAt(0).toUpperCase() || 'B');
</script>

<div class="login-screen">
    <div class="login-glow"></div>
    <div class="login-card">
        <div class="login-icon">{initial}</div>
        <h1>{$botInfo.name || 'Bot'} Panel</h1>
        <p class="login-subtitle">Manage your bot from anywhere</p>

        {#if $botInfo.hasOAuth2}
            <button class="login-btn" onclick={() => window.location.href = basePath + '/auth/login'}>
                <svg width="20" height="15" viewBox="0 0 71 55" fill="none">
                    <path d="M60.1 4.9A58.5 58.5 0 0045.4.2a.2.2 0 00-.2.1 40.8 40.8 0 00-1.8 3.7 54 54 0 00-16.2 0A37.3 37.3 0 0025.4.3a.2.2 0 00-.2-.1A58.4 58.4 0 0010.5 5 59.6 59.6 0 00.4 44.8a.3.3 0 00.1.2 58.9 58.9 0 0017.7 9 .2.2 0 00.3-.1 42 42 0 003.6-5.9.2.2 0 00-.1-.3 38.8 38.8 0 01-5.5-2.6.2.2 0 01 0-.4l1.1-.9a.2.2 0 01.2 0 42 42 0 0035.8 0 .2.2 0 01.2 0l1.1.9a.2.2 0 010 .3 36.4 36.4 0 01-5.5 2.7.2.2 0 00-.1.3 47.2 47.2 0 003.6 5.9.2.2 0 00.3 0 58.7 58.7 0 0017.7-8.9.2.2 0 00.1-.2c1.5-16 2.5-41.4-10.2-39.9zM23.7 36.7c-3.5 0-6.3-3.2-6.3-7.1s2.8-7.1 6.3-7.1 6.4 3.2 6.3 7.1c0 3.9-2.8 7.1-6.3 7.1zm23.2 0c-3.5 0-6.3-3.2-6.3-7.1s2.8-7.1 6.3-7.1 6.4 3.2 6.3 7.1c0 3.9-2.8 7.1-6.3 7.1z" fill="currentColor"/>
                </svg>
                Login with Discord
            </button>
        {:else}
            <div class="login-divider"></div>
            <p class="login-hint">
                Use the <code>/webpanel</code> command in Discord to get a login link.
            </p>
        {/if}
    </div>
</div>

<style>
    .login-screen {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--color-base);
        position: relative;
        overflow: hidden;
    }

    .login-glow {
        position: absolute;
        top: -200px;
        left: 50%;
        transform: translateX(-50%);
        width: 600px;
        height: 400px;
        background: radial-gradient(ellipse, var(--color-accent-glow) 0%, transparent 70%);
        opacity: 0.4;
        pointer-events: none;
    }

    .login-card {
        position: relative;
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-xl);
        padding: 48px 40px;
        text-align: center;
        max-width: 380px;
        width: 100%;
        box-shadow: var(--shadow-lg);
        animation: fadeIn 0.6s var(--ease-out) both;
    }

    .login-icon {
        width: 72px;
        height: 72px;
        border-radius: var(--radius-lg);
        background: linear-gradient(135deg, var(--color-accent), var(--color-purple));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        font-weight: 700;
        color: white;
        margin: 0 auto 20px;
        box-shadow: 0 8px 24px rgba(99, 139, 255, 0.25);
    }

    .login-card h1 {
        font-size: 22px;
        font-weight: 700;
        margin: 0 0 6px;
        color: var(--color-text-primary);
    }

    .login-subtitle {
        font-size: 14px;
        color: var(--color-text-muted);
        margin: 0 0 28px;
    }

    .login-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        background: #5865F2;
        color: white;
        border: none;
        border-radius: var(--radius-md);
        padding: 12px 32px;
        font-size: 15px;
        font-weight: 600;
        font-family: inherit;
        cursor: pointer;
        transition: all 0.2s ease;
        width: 100%;
    }

    .login-btn:hover {
        background: #4752c4;
        box-shadow: 0 4px 20px rgba(88, 101, 242, 0.4);
        transform: translateY(-1px);
    }

    .login-btn:active {
        transform: scale(0.98);
    }

    .login-divider {
        height: 1px;
        background: var(--color-border);
        margin: 4px 0 20px;
    }

    .login-hint {
        color: var(--color-text-secondary);
        font-size: 14px;
        line-height: 1.6;
        margin: 0;
    }

    .login-hint code {
        color: var(--color-accent);
        font-family: var(--font-mono);
        font-size: 13px;
        background: var(--color-accent-soft);
        padding: 2px 8px;
        border-radius: 4px;
    }
</style>
