<script>
    import { botInfo, publicConfig } from '../lib/stores.js';
    import { getBasePath } from '../lib/api.js';

    let { onContinueAsGuest = () => {} } = $props();
    const basePath = getBasePath();
    let initial = $derived($botInfo.name?.charAt(0).toUpperCase() || 'B');
    let canContinueAsGuest = $derived(!!($publicConfig?.guestPublicToolsEnabled && $publicConfig?.calculatorsPublic));

    function startDiscordLogin() {
        try {
            sessionStorage.setItem('webpanel_oauth_pending', '1');
            sessionStorage.setItem('webpanel_oauth_started_at', String(Date.now()));
        } catch {
            // best-effort only
        }
        window.location.href = basePath + '/auth/login';
    }
</script>

<div class="login-screen">
    <div class="login-glow"></div>
    <div class="login-card">
        <div class="login-icon">{initial}</div>
        <h1>{$botInfo.name || 'Bot'} Panel</h1>
        <p class="login-subtitle">Manage your bot from anywhere</p>

        {#if $botInfo.hasOAuth2}
            <button class="login-btn" onclick={startDiscordLogin}>
                <svg width="20" height="15" viewBox="0 0 71 55" fill="none">
                    <path d="M60.1 4.9A58.5 58.5 0 0045.4.2a.2.2 0 00-.2.1 40.8 40.8 0 00-1.8 3.7 54 54 0 00-16.2 0A37.3 37.3 0 0025.4.3a.2.2 0 00-.2-.1A58.4 58.4 0 0010.5 5 59.6 59.6 0 00.4 44.8a.3.3 0 00.1.2 58.9 58.9 0 0017.7 9 .2.2 0 00.3-.1 42 42 0 003.6-5.9.2.2 0 00-.1-.3 38.8 38.8 0 01-5.5-2.6.2.2 0 01 0-.4l1.1-.9a.2.2 0 01.2 0 42 42 0 0035.8 0 .2.2 0 01.2 0l1.1.9a.2.2 0 010 .3 36.4 36.4 0 01-5.5 2.7.2.2 0 00-.1.3 47.2 47.2 0 003.6 5.9.2.2 0 00.3 0 58.7 58.7 0 0017.7-8.9.2.2 0 00.1-.2c1.5-16 2.5-41.4-10.2-39.9zM23.7 36.7c-3.5 0-6.3-3.2-6.3-7.1s2.8-7.1 6.3-7.1 6.4 3.2 6.3 7.1c0 3.9-2.8 7.1-6.3 7.1zm23.2 0c-3.5 0-6.3-3.2-6.3-7.1s2.8-7.1 6.3-7.1 6.4 3.2 6.3 7.1c0 3.9-2.8 7.1-6.3 7.1z" fill="currentColor"/>
                </svg>
                Login with Discord
            </button>
        {/if}

        {#if canContinueAsGuest}
            <button class="login-btn guest-btn" onclick={onContinueAsGuest}>
                Continue as Guest
            </button>
        {/if}

        {#if !$botInfo.hasOAuth2 && !canContinueAsGuest}
            <div class="login-divider"></div>
            <p class="login-hint">
                Use the <code>/webpanel</code> command in Discord to get a login link.
            </p>
        {:else if $botInfo.hasOAuth2 && canContinueAsGuest}
            <div class="login-divider"></div>
            <p class="login-hint">
                Guest mode only includes public calculators. All management features still require Discord login.
            </p>
        {/if}
    </div>
</div>

<style>
    .login-screen {
        min-height: 100dvh;
        display: flex;
        align-items: center;
        justify-content: center;
        background:
            radial-gradient(circle at 50% 0%, rgba(148, 163, 184, 0.09), transparent 30%),
            linear-gradient(180deg, var(--color-canvas-2), var(--color-canvas));
        position: relative;
        overflow: hidden;
        padding: 24px;
    }

    .login-glow {
        position: absolute;
        inset: 0;
        left: 50%;
        transform: translateX(-50%);
        width: min(920px, 92vw);
        height: 520px;
        background:
            radial-gradient(ellipse, rgba(148, 163, 184, 0.12) 0%, transparent 62%);
        opacity: 0.7;
        pointer-events: none;
        filter: blur(10px);
    }

    .login-card {
        position: relative;
        background:
            linear-gradient(180deg, rgba(255, 244, 232, 0.04), transparent 22%),
            color-mix(in oklab, var(--color-panel) 95%, black);
        border: 1px solid rgba(255, 244, 232, 0.08);
        border-radius: var(--radius-xl);
        padding: 44px 38px 36px;
        text-align: center;
        max-width: 420px;
        width: 100%;
        box-shadow: var(--shadow-lg), var(--shadow-inset);
        animation: fadeIn 0.6s var(--ease-out) both;
    }

    .login-icon {
        width: 82px;
        height: 82px;
        border-radius: 26px;
        background:
            radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.16), transparent 42%),
            linear-gradient(135deg, var(--color-accent-strong), var(--color-accent));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 30px;
        font-weight: 800;
        color: var(--color-accent-ink);
        margin: 0 auto 24px;
        border: 1px solid rgba(255, 255, 255, 0.12);
        box-shadow: var(--shadow-glow);
    }

    .login-card h1 {
        font-size: clamp(28px, 4vw, 36px);
        font-weight: 700;
        margin: 0 0 8px;
        color: var(--color-text-primary);
        line-height: 1;
        letter-spacing: -0.04em;
    }

    .login-subtitle {
        font-size: 14px;
        color: var(--color-text-secondary);
        margin: 0 0 30px;
        line-height: 1.7;
    }

    .login-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        background: linear-gradient(135deg, var(--color-accent), var(--color-accent-strong));
        color: var(--color-accent-ink);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: var(--radius-pill);
        min-height: 50px;
        padding: 0 28px;
        font-size: 14px;
        font-weight: 600;
        font-family: inherit;
        cursor: pointer;
        transition:
            transform 160ms var(--ease-out),
            box-shadow 160ms var(--ease-out),
            filter 160ms var(--ease-out);
        width: 100%;
        box-shadow: var(--shadow-glow);
    }

    .login-btn:hover {
        transform: translateY(-1px);
        filter: brightness(1.03);
    }

    .login-btn:active {
        transform: scale(0.98);
    }

    .guest-btn {
        margin-top: 12px;
        background: color-mix(in oklab, var(--color-panel-muted) 84%, black);
        color: var(--color-text-primary);
        border: 1px solid var(--color-border);
        box-shadow: var(--shadow-inset);
    }

    .guest-btn:hover {
        background: color-mix(in oklab, var(--color-panel-elevated) 84%, black);
        box-shadow: none;
    }

    .login-divider {
        height: 1px;
        background: var(--color-border-subtle);
        margin: 4px 0 20px;
    }

    .login-hint {
        color: var(--color-text-secondary);
        font-size: 13px;
        line-height: 1.6;
        margin: 0;
    }

    .login-hint code {
        color: var(--color-accent-strong);
        font-family: var(--font-mono);
        font-size: 12px;
        background: var(--color-accent-soft);
        padding: 3px 8px;
        border-radius: 999px;
    }
</style>
