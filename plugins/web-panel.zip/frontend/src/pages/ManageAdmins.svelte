<script>
    import { onMount } from 'svelte';
    import { slide } from 'svelte/transition';
    import { apiFetch } from '../lib/api.js';
    import { showToast } from '../lib/utils.js';
    import { currentUser } from '../lib/stores.js';
    import { PERMS } from '../lib/constants.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import Checkbox from '../components/ui/Checkbox.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import Select from '../components/ui/Select.svelte';
    import Icon from '../components/ui/Icon.svelte';

    const PERMISSION_OPTIONS = [
        { flag: PERMS.ALLIANCE_MANAGEMENT, label: 'Alliance Management', description: 'Manage alliances and alliance-scoped tools.' },
        { flag: PERMS.PLAYER_MANAGEMENT, label: 'Player Management', description: 'Add, move, refresh, and remove players.' },
        { flag: PERMS.GIFT_CODE_MANAGEMENT, label: 'Gift Code Management', description: 'Create, validate, and redeem gift codes.' },
        { flag: PERMS.NOTIFICATIONS_MANAGEMENT, label: 'Notifications Management', description: 'Create and manage web-panel notifications.' },
        { flag: PERMS.FULL_ACCESS, label: 'Full Access', description: 'Access all full-admin web panel sections.' },
        { flag: PERMS.RESERVATIONS_MANAGEMENT, label: 'Reservations Management', description: 'Access and manage reservation lists you own or are assigned to.' },
    ];

    let admins = $state([]);
    let permissionDrafts = $state({});
    let guilds = $state([]);
    let memberResults = $state([]);
    let isLoading = $state(true);
    let isLoadingGuilds = $state(false);
    let isSearchingMembers = $state(false);
    let isAdding = $state(false);
    let savingUserId = $state('');
    let removingUserId = $state('');
    let showAddModal = $state(false);
    let showDeleteDialog = $state(false);
    let deleteTarget = $state(null);
    let selectedGuildId = $state('');
    let memberSearch = $state('');
    let selectedMember = $state(null);
    let newAdminPermissions = $state(0);
    let addFormErrors = $state({});
    let memberSearchTimeout = null;
    let expandedAdminUserId = $state('');

    const guildOptions = $derived(guilds.map((guild) => ({
        value: guild.id,
        label: guild.name,
    })));

    onMount(() => {
        if ($currentUser?.isOwner) {
            void Promise.all([loadAdmins(), loadGuilds()]);
        } else {
            isLoading = false;
        }
    });

    function normalizeAdmin(admin) {
        return {
            userId: String(admin?.userId || ''),
            username: admin?.username || '',
            permissions: Number(admin?.permissions) || 0,
            isOwner: !!admin?.isOwner,
            addedAt: admin?.addedAt || '',
        };
    }

    function sortAdmins(list) {
        return [...list].sort((a, b) => {
            if (a.isOwner !== b.isOwner) return a.isOwner ? -1 : 1;
            return a.userId.localeCompare(b.userId);
        });
    }

    function seedDrafts(list) {
        permissionDrafts = Object.fromEntries(list.map((admin) => [admin.userId, admin.permissions]));
    }

    async function loadAdmins() {
        isLoading = true;
        try {
            const data = await apiFetch('/api/admins');
            if (!data) return;
            admins = sortAdmins(data.map(normalizeAdmin));
            seedDrafts(admins);
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    async function loadGuilds() {
        isLoadingGuilds = true;
        try {
            const data = await apiFetch('/api/guilds');
            if (!data) return;
            guilds = data;
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoadingGuilds = false;
        }
    }

    function hasPermission(mask, flag) {
        return !!(Number(mask || 0) & flag);
    }

    function toggleNewPermission(flag, checked) {
        newAdminPermissions = checked
            ? (newAdminPermissions | flag)
            : (newAdminPermissions & ~flag);
    }

    function toggleDraftPermission(userId, flag, checked) {
        const currentMask = Number(permissionDrafts[userId] || 0);
        permissionDrafts = {
            ...permissionDrafts,
            [userId]: checked ? (currentMask | flag) : (currentMask & ~flag),
        };
    }

    function isDirty(admin) {
        return Number(permissionDrafts[admin.userId] || 0) !== Number(admin.permissions || 0);
    }

    function formatPermissionSummary(mask) {
        const labels = PERMISSION_OPTIONS
            .filter((item) => hasPermission(mask, item.flag))
            .map((item) => item.label);
        return labels.length ? labels.join(' • ') : 'No extra permissions';
    }

    function formatAddedDate(value) {
        if (!value) return '-';
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleString(undefined, {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        });
    }

    function openAddModal() {
        showAddModal = true;
        selectedGuildId = '';
        memberSearch = '';
        selectedMember = null;
        memberResults = [];
        newAdminPermissions = 0;
        addFormErrors = {};
    }

    function closeAddModal() {
        if (isAdding) return;
        showAddModal = false;
    }

    function handleGuildChange(guildId) {
        selectedGuildId = guildId;
        selectedMember = null;
        memberSearch = '';
        memberResults = [];
        if (addFormErrors.guild) {
            const { guild, ...rest } = addFormErrors;
            addFormErrors = rest;
        }
        if (addFormErrors.member) {
            const { member, ...rest } = addFormErrors;
            addFormErrors = rest;
        }
    }

    async function searchMembers(query) {
        if (!selectedGuildId || query.trim().length < 2) return [];
        try {
            const data = await apiFetch(`/api/guilds/${selectedGuildId}/members/search?q=${encodeURIComponent(query.trim())}&limit=10`);
            if (!data) return [];
            return data.map((member) => ({
                id: member.id,
                label: member.displayName,
                avatar: member.avatar || null,
            }));
        } catch {
            return [];
        }
    }

    function triggerMemberSearch(query) {
        memberSearch = query;
        selectedMember = null;
        if (addFormErrors.member) {
            const { member, ...rest } = addFormErrors;
            addFormErrors = rest;
        }
        if (memberSearchTimeout) clearTimeout(memberSearchTimeout);

        if (!selectedGuildId || query.trim().length < 2) {
            memberResults = [];
            isSearchingMembers = false;
            return;
        }

        isSearchingMembers = true;
        memberSearchTimeout = setTimeout(async () => {
            const queryAtRequest = query;
            const results = await searchMembers(queryAtRequest);
            if (memberSearch === queryAtRequest) {
                memberResults = results;
                isSearchingMembers = false;
            }
        }, 200);
    }

    function selectMember(member) {
        selectedMember = member;
        memberSearch = member.label;
        memberResults = [];
        isSearchingMembers = false;
    }

    function validateAddForm() {
        const errors = {};
        if (!selectedGuildId) errors.guild = 'Select a server.';
        if (!selectedMember?.id) errors.member = 'Select a member from the list.';
        addFormErrors = errors;
        return Object.keys(errors).length === 0;
    }

    async function addAdmin() {
        if (!validateAddForm()) return;

        isAdding = true;
        try {
            const created = await apiFetch('/api/admins', {
                method: 'POST',
                body: {
                    userId: selectedMember.id,
                    permissions: newAdminPermissions,
                },
            });
            if (!created) return;

            admins = sortAdmins([...admins, normalizeAdmin(created)]);
            seedDrafts(admins);
            showToast('Admin added', 'success');
            showAddModal = false;
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isAdding = false;
        }
    }

    async function saveAdmin(admin) {
        savingUserId = admin.userId;
        try {
            const updated = await apiFetch(`/api/admins/${encodeURIComponent(admin.userId)}`, {
                method: 'PATCH',
                body: {
                    permissions: Number(permissionDrafts[admin.userId] || 0),
                },
            });
            if (!updated) return;

            admins = sortAdmins(admins.map((item) => item.userId === admin.userId ? normalizeAdmin(updated) : item));
            seedDrafts(admins);
            showToast('Admin permissions updated', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            savingUserId = '';
        }
    }

    function promptRemoveAdmin(admin) {
        deleteTarget = admin;
        showDeleteDialog = true;
    }

    function toggleAdminExpansion(admin) {
        if (admin.isOwner) return;
        expandedAdminUserId = expandedAdminUserId === admin.userId ? '' : admin.userId;
    }

    async function confirmRemoveAdmin() {
        if (!deleteTarget) return;
        removingUserId = deleteTarget.userId;
        try {
            await apiFetch(`/api/admins/${encodeURIComponent(deleteTarget.userId)}`, {
                method: 'DELETE',
            });
            admins = admins.filter((admin) => admin.userId !== deleteTarget.userId);
            seedDrafts(admins);
            if (expandedAdminUserId === deleteTarget.userId) {
                expandedAdminUserId = '';
            }
            showToast('Admin removed', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            removingUserId = '';
            deleteTarget = null;
            showDeleteDialog = false;
        }
    }
</script>

<PageHeader label="Manage Admins">
    Owner-only control for adding, removing, and assigning web panel permissions.
</PageHeader>

{#if !$currentUser?.isOwner}
    <div class="locked-card">
        <div class="locked-icon">
            <Icon name="lock" size={18} />
        </div>
        <div>
            <h3>Owner access required</h3>
            <p>Only the bot owner can manage admins from the web panel.</p>
        </div>
    </div>
{:else if isLoading}
    <div class="skeleton" style="height: 320px;"></div>
{:else}
    <div class="admins-layout">
        <section class="admin-section">
            <div class="list-toolbar">
                <h3>Admins</h3>
                <LoadingButton class="btn btn-primary toolbar-btn" disabled={isLoadingGuilds} onclick={openAddModal}>
                    <Icon name="plus" size={14} />
                    Add Admin
                </LoadingButton>
            </div>

            <div class="admin-list">
                {#if admins.length === 0}
                    <div class="empty-state">No admins found.</div>
                {:else}
                    {#each admins as admin (admin.userId)}
                        <article class="admin-card" class:owner-card={admin.isOwner}>
                            <button
                                class="admin-top"
                                class:is-clickable={!admin.isOwner}
                                type="button"
                                onclick={() => toggleAdminExpansion(admin)}
                                disabled={admin.isOwner}
                            >
                                <div class="admin-identity">
                                    <div class="admin-name-row">
                                        <h4>{admin.username || 'Discord User'}</h4>
                                        {#if admin.isOwner}
                                            <span class="badge badge-owner">Owner</span>
                                        {/if}
                                    </div>
                                    <div class="admin-meta">Added {formatAddedDate(admin.addedAt)}</div>
                                    <div class="permission-summary">{formatPermissionSummary(admin.permissions)}</div>
                                </div>
                                {#if !admin.isOwner}
                                    <span class="expand-indicator" class:is-open={expandedAdminUserId === admin.userId}>
                                        <Icon name="chevronDown" size={16} />
                                    </span>
                                {/if}
                            </button>

                            {#if admin.isOwner}
                                <div class="owner-note">Owner permissions are fixed and cannot be changed from this page.</div>
                            {:else if expandedAdminUserId === admin.userId}
                                <div class="admin-expanded" transition:slide>
                                    <div class="permission-grid">
                                        {#each PERMISSION_OPTIONS as option}
                                            <div class="permission-card">
                                                <Checkbox
                                                    label={option.label}
                                                    checked={hasPermission(permissionDrafts[admin.userId], option.flag)}
                                                    onchange={(event) => toggleDraftPermission(admin.userId, option.flag, event.currentTarget.checked)}
                                                />
                                                <p>{option.description}</p>
                                            </div>
                                        {/each}
                                    </div>

                                    <div class="admin-actions">
                                        <LoadingButton
                                            class="btn btn-danger"
                                            loading={removingUserId === admin.userId}
                                            disabled={savingUserId === admin.userId}
                                            onclick={() => promptRemoveAdmin(admin)}
                                        >
                                            Remove
                                        </LoadingButton>
                                        <LoadingButton
                                            class="btn btn-primary"
                                            loading={savingUserId === admin.userId}
                                            disabled={!isDirty(admin) || removingUserId === admin.userId}
                                            onclick={() => saveAdmin(admin)}
                                        >
                                            Save Permissions
                                        </LoadingButton>
                                    </div>
                                </div>
                            {/if}
                        </article>
                    {/each}
                {/if}
            </div>
        </section>
    </div>
{/if}

<Modal bind:isOpen={showAddModal} title="Add Admin" wide={true} onclose={closeAddModal}>
    <div class="modal-fields">
        <div class="field-row">
            <label class="field-group">
                <span class="field-label">Server</span>
                <Select
                    value={selectedGuildId}
                    onchange={handleGuildChange}
                    disabled={isLoadingGuilds}
                    placeholder={isLoadingGuilds ? 'Loading servers...' : 'Select a server'}
                    options={guildOptions}
                />
                {#if addFormErrors.guild}<span class="field-error-msg">{addFormErrors.guild}</span>{/if}
            </label>
        </div>

        <div class="field-row">
            <label class="field-group">
                <span class="field-label">Member</span>
                <input
                    type="text"
                    placeholder={selectedGuildId ? 'Search member name...' : 'Select a server first'}
                    value={memberSearch}
                    disabled={!selectedGuildId}
                    oninput={(event) => triggerMemberSearch(event.currentTarget.value)}
                />
                {#if addFormErrors.member}<span class="field-error-msg">{addFormErrors.member}</span>{/if}
            </label>
        </div>

        {#if selectedGuildId}
            <div class="member-search-panel">
                {#if selectedMember}
                    <div class="selected-member">
                        <div class="member-chip">
                            {#if selectedMember.avatar}
                                <img class="member-avatar" src={selectedMember.avatar} alt={selectedMember.label} />
                            {:else}
                                <div class="member-avatar member-avatar-fallback">
                                    {selectedMember.label?.charAt(0)?.toUpperCase() || '?'}
                                </div>
                            {/if}
                            <div class="member-copy">
                                <strong>{selectedMember.label}</strong>
                                <span>{selectedMember.id}</span>
                            </div>
                        </div>
                    </div>
                {:else if isSearchingMembers}
                    <div class="member-search-state">Searching members...</div>
                {:else if memberSearch.trim().length >= 2}
                    <div class="member-results">
                        {#if memberResults.length > 0}
                            {#each memberResults as member}
                                <button class="member-result" type="button" onclick={() => selectMember(member)}>
                                    {#if member.avatar}
                                        <img class="member-avatar" src={member.avatar} alt={member.label} />
                                    {:else}
                                        <div class="member-avatar member-avatar-fallback">
                                            {member.label?.charAt(0)?.toUpperCase() || '?'}
                                        </div>
                                    {/if}
                                    <div class="member-copy">
                                        <strong>{member.label}</strong>
                                        <span>{member.id}</span>
                                    </div>
                                </button>
                            {/each}
                        {:else}
                            <div class="member-search-state">No members found.</div>
                        {/if}
                    </div>
                {:else}
                    <div class="member-search-state">Type at least 2 characters to search members.</div>
                {/if}
            </div>
        {/if}

        <div class="permission-grid">
            {#each PERMISSION_OPTIONS as option}
                <div class="permission-card">
                    <Checkbox
                        label={option.label}
                        checked={hasPermission(newAdminPermissions, option.flag)}
                        onchange={(event) => toggleNewPermission(option.flag, event.currentTarget.checked)}
                    />
                    <p>{option.description}</p>
                </div>
            {/each}
        </div>

        <div class="add-admin-actions">
            <button class="btn" type="button" onclick={closeAddModal}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={isAdding} onclick={addAdmin}>
                Add Admin
            </LoadingButton>
        </div>
    </div>
</Modal>

<ConfirmDialog
    bind:isOpen={showDeleteDialog}
    title="Remove Admin"
    message={deleteTarget ? `Remove admin access for ${deleteTarget.username || deleteTarget.userId}?` : 'Remove this admin?'}
    confirmLabel="Remove"
    onconfirm={confirmRemoveAdmin}
    oncancel={() => {
        showDeleteDialog = false;
        deleteTarget = null;
    }}
/>

<style>
    .admins-layout {
        display: grid;
        gap: 20px;
    }

    .admin-section,
    .locked-card {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 24px;
    }

    .locked-card {
        display: flex;
        gap: 14px;
        align-items: flex-start;
    }

    .locked-icon {
        width: 38px;
        height: 38px;
        flex: 0 0 38px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        background: rgba(124, 156, 255, 0.14);
        color: var(--color-accent);
    }

    .locked-card h3,
    .list-toolbar h3 {
        margin: 0;
        color: var(--color-text-primary);
        font-size: 18px;
        font-weight: 700;
    }

    .locked-card p {
        margin: 6px 0 0;
        color: var(--color-text-muted);
        font-size: 14px;
        line-height: 1.55;
    }

    .list-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 18px;
    }

    :global(.toolbar-btn) {
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .admin-list {
        display: grid;
        gap: 14px;
    }

    .admin-card {
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 18px;
        background: rgba(255, 255, 255, 0.02);
    }

    .owner-card {
        border-color: rgba(124, 156, 255, 0.28);
        background: rgba(124, 156, 255, 0.05);
    }

    .admin-top {
        display: flex;
        width: 100%;
        justify-content: space-between;
        align-items: flex-start;
        gap: 16px;
        margin-bottom: 16px;
        padding: 0;
        border: 0;
        background: none;
        text-align: left;
    }

    .admin-top.is-clickable {
        cursor: pointer;
    }

    .admin-top.is-clickable:hover .admin-name-row h4,
    .admin-top.is-clickable:hover .permission-summary {
        color: var(--color-text-primary);
    }

    .admin-identity {
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .admin-name-row {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .admin-name-row h4 {
        margin: 0;
        color: var(--color-text-primary);
        font-size: 17px;
        font-weight: 700;
    }

    .admin-meta,
    .permission-summary,
    .owner-note,
    .empty-state,
    .member-search-state {
        color: var(--color-text-muted);
        font-size: 13px;
        line-height: 1.5;
    }

    .permission-summary {
        color: var(--color-text-secondary);
    }

    .owner-note,
    .member-search-panel {
        padding: 14px 16px;
        border-radius: var(--radius-md);
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.05);
    }

    .badge {
        display: inline-flex;
        align-items: center;
        height: 28px;
        padding: 0 10px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
    }

    .badge-owner {
        background: rgba(124, 156, 255, 0.18);
        color: #c8d6ff;
    }

    .permission-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
    }

    .permission-card {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: var(--radius-md);
        padding: 14px 16px;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .permission-card p {
        margin: 0;
        font-size: 12px;
        line-height: 1.5;
        color: var(--color-text-muted);
    }

    .admin-actions,
    .add-admin-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 16px;
    }

    .admin-expanded {
        overflow: hidden;
    }

    .expand-indicator {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        flex: 0 0 34px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--color-text-secondary);
        transition: transform 0.16s ease, color 0.16s ease, background 0.16s ease;
    }

    .admin-top.is-clickable:hover .expand-indicator {
        color: var(--color-text-primary);
        background: rgba(124, 156, 255, 0.12);
    }

    .expand-indicator.is-open {
        transform: rotate(180deg);
        color: var(--color-text-primary);
    }

    .empty-state {
        padding: 18px;
        border-radius: var(--radius-md);
        background: rgba(255, 255, 255, 0.02);
        border: 1px dashed rgba(255, 255, 255, 0.12);
    }

    .modal-fields {
        display: grid;
        gap: 16px;
    }

    .field-row {
        display: grid;
        gap: 16px;
    }

    .field-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .field-label {
        color: var(--color-text-primary);
        font-size: 13px;
        font-weight: 600;
    }

    .field-error-msg {
        color: var(--color-danger, #ff7f9f);
        font-size: 12px;
    }

    .member-results,
    .selected-member {
        display: grid;
        gap: 10px;
    }

    .member-result,
    .member-chip {
        display: flex;
        align-items: center;
        gap: 12px;
        width: 100%;
        padding: 10px 12px;
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        background: rgba(255, 255, 255, 0.03);
    }

    .member-result {
        cursor: pointer;
        text-align: left;
        transition: border-color 0.15s ease, background 0.15s ease;
    }

    .member-result:hover {
        border-color: rgba(124, 156, 255, 0.32);
        background: rgba(124, 156, 255, 0.08);
    }

    .member-avatar {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        object-fit: cover;
        flex: 0 0 34px;
    }

    .member-avatar-fallback {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: rgba(124, 156, 255, 0.18);
        color: var(--color-text-primary);
        font-weight: 700;
    }

    .member-copy {
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .member-copy strong {
        color: var(--color-text-primary);
        font-size: 13px;
    }

    .member-copy span {
        color: var(--color-text-muted);
        font-size: 12px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    @media (max-width: 768px) {
        .admin-section,
        .locked-card {
            padding: 18px;
        }

        .list-toolbar {
            flex-direction: column;
            align-items: stretch;
        }

        :global(.toolbar-btn) {
            width: 100%;
            justify-content: center;
        }

        .permission-grid {
            grid-template-columns: 1fr;
        }

        .admin-actions {
            flex-direction: column;
        }

        .add-admin-actions {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            align-items: stretch;
        }
    }
</style>
