<script>
    import { onDestroy, onMount } from 'svelte';
    import { slide } from 'svelte/transition';
    import { apiFetch, getBasePath } from '../lib/api.js';
    import { showToast } from '../lib/utils.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import Select from '../components/ui/Select.svelte';
    import Checkbox from '../components/ui/Checkbox.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';

    const CATEGORY_ORDER = ['buildings', 'research', 'troops'];
    const CATEGORY_LABELS = {
        buildings: 'Buildings',
        research: 'Research',
        troops: 'Troops',
    };

    let lists = $state([]);
    let selectedListId = $state('');
    let detail = $state(null);
    let isLoadingLists = $state(true);
    let isLoadingDetail = $state(false);
    let isCreating = $state(false);
    let isSaving = $state(false);
    let isPublishing = $state(false);
    let isDeleting = $state(false);
    let newStateNumber = $state('');
    let showValidationErrors = $state(false);
    let showCreateModal = $state(false);

    let showSlotModal = $state(false);
    let slotForm = $state({ slotId: '', reservationId: '', status: 'reserved', playerId: '', allianceTag: '', label: '' });
    let showCategorySlotsModal = $state(false);
    let activeCategoryKey = $state('');
    let showDeleteModal = $state(false);
    let deleteTarget = $state({ id: '', label: '', hasReservations: false });
    let showConfirmDialog = $state(false);
    let showListSettingsModal = $state(false);
    let listSettingsStateNumber = $state('');
    let assignableAdmins = $state([]);
    let assigneeDraftUserIds = $state([]);
    let isLoadingAssignableAdmins = $state(false);
    let confirmTitle = $state('Confirm');
    let confirmMessage = $state('Are you sure?');
    let confirmLabel = $state('Confirm');
    let confirmVariant = $state('danger');
    let pendingConfirmResolve = null;
    let liveRefreshTimer = null;

    const basePath = getBasePath();

    onMount(async () => {
        await loadLists();
        liveRefreshTimer = setInterval(() => {
            void refreshActiveDetail();
        }, 4000);
    });

    onDestroy(() => {
        if (liveRefreshTimer) {
            clearInterval(liveRefreshTimer);
            liveRefreshTimer = null;
        }
    });

    function openCreateModal() {
        newStateNumber = '';
        showCreateModal = true;
    }

    function closeCreateModal() {
        if (isCreating) return;
        showCreateModal = false;
    }

    function openListSettingsModal() {
        if (!detail) return;
        listSettingsStateNumber = normalizeStateNumberInput(detail.stateNumber);
        assigneeDraftUserIds = (detail.assignees || []).map((assignee) => assignee.userId);
        showListSettingsModal = true;
        if (detail.canManageAssignments && assignableAdmins.length === 0) {
            void loadAssignableAdmins();
        }
    }

    function closeListSettingsModal() {
        if (isSaving) return;
        showListSettingsModal = false;
    }

    async function loadAssignableAdmins() {
        if (isLoadingAssignableAdmins) return;
        isLoadingAssignableAdmins = true;
        try {
            const data = await apiFetch('/api/admins/assignable');
            assignableAdmins = Array.isArray(data) ? data : [];
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoadingAssignableAdmins = false;
        }
    }

    function requestConfirmation({
        title = 'Confirm',
        message = 'Are you sure?',
        confirmLabel: nextConfirmLabel = 'Confirm',
        variant = 'danger',
    } = {}) {
        return new Promise((resolve) => {
            confirmTitle = title;
            confirmMessage = message;
            confirmLabel = nextConfirmLabel;
            confirmVariant = variant;
            pendingConfirmResolve = resolve;
            showConfirmDialog = true;
        });
    }

    function handleConfirmAccept() {
        showConfirmDialog = false;
        pendingConfirmResolve?.(true);
        pendingConfirmResolve = null;
    }

    function handleConfirmCancel() {
        showConfirmDialog = false;
        pendingConfirmResolve?.(false);
        pendingConfirmResolve = null;
    }

    function utcToTimeInput(isoString) {
        if (!isoString) return '';
        const date = new Date(isoString);
        if (Number.isNaN(date.getTime())) return '';
        return date.toISOString().slice(11, 16);
    }

    function normalizeTimeText(value) {
        const text = String(value || '').trim();
        const match = text.match(/^(\d{1,2}):(\d{2})$/);
        if (!match) return text;

        const hours = Number(match[1]);
        const minutes = Number(match[2]);
        if (!Number.isInteger(hours) || !Number.isInteger(minutes)) return text;
        if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return text;

        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
    }

    function formatTimeTextInput(value) {
        const digits = String(value || '').replace(/\D/g, '').slice(0, 4);
        if (digits.length <= 2) return digits;
        return `${digits.slice(0, 2)}:${digits.slice(2)}`;
    }

    function normalizeStateNumberInput(value) {
        return String(value || '')
            .replace(/\D/g, '')
            .slice(0, 4);
    }

    function normalizeAllowedSlotCountInput(value) {
        const digits = String(value || '').replace(/\D/g, '').slice(0, 2);
        if (!digits) return '1';
        const normalized = Math.min(48, Math.max(1, Number(digits)));
        return String(normalized);
    }

    function buildReservationWindow(timeValue) {
        if (!timeValue) {
            return {
                eventDateUtc: null,
                reservationStartUtc: null,
                reservationEndUtc: null,
            };
        }

        const [hours, minutes] = timeValue.split(':').map(Number);
        if (
            !Number.isInteger(hours) || !Number.isInteger(minutes)
        ) {
            return {
                eventDateUtc: null,
                reservationStartUtc: null,
                reservationEndUtc: null,
            };
        }

        const now = new Date();
        const year = now.getUTCFullYear();
        const month = now.getUTCMonth();
        const day = now.getUTCDate();
        const eventDate = new Date(Date.UTC(year, month, day, 0, 0, 0, 0));
        const reservationEnd = new Date(Date.UTC(year, month, day + 1, 0, 0, 0, 0));
        const isPreStartWindow = hours === 23 && minutes >= 30;
        const reservationStart = isPreStartWindow
            ? new Date(Date.UTC(year, month, day - 1, hours, minutes, 0, 0))
            : new Date(Date.UTC(year, month, day, hours, minutes, 0, 0));

        return {
            eventDateUtc: eventDate.toISOString(),
            reservationStartUtc: reservationStart.toISOString(),
            reservationEndUtc: reservationEnd.toISOString(),
        };
    }

    async function loadLists() {
        isLoadingLists = true;
        try {
            const data = await apiFetch('/api/admin/position-reservations');
            lists = data || [];
            if (selectedListId && !lists.some((list) => list.id === selectedListId)) {
                selectedListId = '';
                detail = null;
            }
            if (!selectedListId && lists[0]?.id) {
                selectedListId = lists[0].id;
                await loadDetail(selectedListId);
            } else if (selectedListId) {
                await loadDetail(selectedListId);
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoadingLists = false;
        }
    }

    async function loadDetail(listId, { silent = false } = {}) {
        if (!listId) return;
        if (!silent) {
            isLoadingDetail = true;
        }
        try {
            const data = await apiFetch(`/api/admin/position-reservations/${listId}`);
            if (data) {
                detail = normalizeDetail(data, detail);
                selectedListId = listId;
            }
        } catch (error) {
            if (!silent) {
                showToast(error.message, 'error');
            }
        } finally {
            if (!silent) {
                isLoadingDetail = false;
            }
        }
    }

    async function toggleList(listId) {
        if (selectedListId === listId) {
            selectedListId = '';
            detail = null;
            showValidationErrors = false;
            return;
        }

        showValidationErrors = false;
        await loadDetail(listId);
    }

    function normalizeDetail(data, previousDetail = null) {
        const matchingPreviousDetail = previousDetail?.id === data?.id ? previousDetail : null;
        return {
            ...data,
            categories: CATEGORY_ORDER.map((category) => {
                const item = data.categories.find((entry) => entry.category === category) || {
                    category,
                    enabled: false,
                    defaultSlotMinutes: 30,
                    slots: [],
                    display: { label: CATEGORY_LABELS[category] },
                };
                const previousCategory = matchingPreviousDetail?.categories?.find((entry) => entry.category === category);

                return {
                    ...item,
                    enabled: previousCategory?.enabled ?? item.enabled,
                    firstSlotTimeInput: previousCategory?.firstSlotTimeInput ?? utcToTimeInput(item.reservationStartUtc),
                    allowedSlotCount: previousCategory?.allowedSlotCount ?? String(item.allowedSlotCount || 1),
                };
            }),
        };
    }

    async function refreshActiveDetail() {
        if (!selectedListId) return;
        if (isLoadingDetail || isSaving || isPublishing || isCreating || isDeleting) return;
        await loadDetail(selectedListId, { silent: true });
    }

    function buildConfigsPayload() {
        if (!detail) return [];
        return detail.categories.map((category) => ({
            ...buildReservationWindow(category.firstSlotTimeInput),
            category: category.category,
            enabled: category.enabled,
            defaultSlotMinutes: 30,
            firstSlotMinutes: null,
            lastSlotMinutes: null,
            maxSlotMinutes: null,
            allowedSlotCount: Number(category.allowedSlotCount) || 1,
        }));
    }

    function shouldRegenerateSlots(previousDetail, nextConfigs, categories = null) {
        if (!previousDetail) return false;

        const scopedCategories = Array.isArray(categories) && categories.length
            ? new Set(categories)
            : null;

        for (const config of nextConfigs) {
            if (scopedCategories && !scopedCategories.has(config.category)) continue;
            const existing = previousDetail.categories.find((category) => category.category === config.category);
            if (!existing) return true;
            if (!!existing.enabled !== !!config.enabled) return true;
            if ((existing.eventDateUtc || null) !== (config.eventDateUtc || null)) return true;
            if ((existing.reservationStartUtc || null) !== (config.reservationStartUtc || null)) return true;
            if ((existing.reservationEndUtc || null) !== (config.reservationEndUtc || null)) return true;
            if (config.enabled && !existing.slots.length) return true;
        }

        return false;
    }

    async function persistDetail({ showSuccessToast = false, forceRegeneration = false, categories = null } = {}) {
        if (!detail) return null;
        const previousDetail = detail;
        const configs = buildConfigsPayload();

        const meta = await apiFetch(`/api/admin/position-reservations/${detail.id}`, {
            method: 'PATCH',
            body: {
                stateNumber: Number(detail.stateNumber),
            },
        });

        const updated = await apiFetch(`/api/admin/position-reservations/${detail.id}/config`, {
            method: 'POST',
            body: {
                configs,
            },
        });

        detail = normalizeDetail(updated || meta);
        if (forceRegeneration || shouldRegenerateSlots(previousDetail, configs, categories)) {
            const regenerated = await apiFetch(`/api/admin/position-reservations/${detail.id}/generate-slots`, {
                method: 'POST',
                body: {
                    force: forceRegeneration,
                    categories,
                },
            });
            detail = normalizeDetail(regenerated);
        }
        await loadLists();
        if (showSuccessToast) {
            showToast('Reservation setup saved', 'success');
        }
        return detail;
    }

    function getCategoryIssues(category) {
        const issues = [];
        if (!category?.enabled) return issues;

        if (!category.firstSlotTimeInput && showValidationErrors) {
            issues.push({
                field: 'firstSlotTimeInput',
                message: 'Set the first slot UTC time.',
            });
        }

        return issues;
    }

    function getPublishReadinessIssues() {
        if (!detail) return [];

        const issues = [];
        const enabledCategories = detail.categories.filter((category) => category.enabled);

        if (enabledCategories.length === 0) {
            issues.push('Enable at least one category before publishing.');
        }

        return issues;
    }

    async function createList() {
        isCreating = true;
        try {
            const created = await apiFetch('/api/admin/position-reservations', {
                method: 'POST',
                body: {
                    stateNumber: Number(newStateNumber),
                },
            });
            newStateNumber = '';
            showCreateModal = false;
            await loadLists();
            if (created?.id) {
                await loadDetail(created.id);
            }
            showToast('Reservation list created', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isCreating = false;
        }
    }

    async function saveDetail() {
        if (!detail) return;
        showValidationErrors = true;
        if (detail.categories.some((category) => getCategoryIssues(category).length > 0)) {
            showToast('Fill the required reservation fields first.', 'error');
            return;
        }
        isSaving = true;
        try {
            await persistDetail({ showSuccessToast: true });
        } catch (error) {
            if (/destructive regeneration/i.test(error.message) && await requestConfirmation({
                title: 'Regenerate Slots?',
                message: 'Reservations already exist. Updating the schedule will delete them. Continue?',
                confirmLabel: 'Continue',
                variant: 'danger',
            })) {
                try {
                    await persistDetail({ showSuccessToast: true, forceRegeneration: true });
                } catch (retryError) {
                    showToast(retryError.message, 'error');
                }
            } else {
                showToast(error.message, 'error');
            }
        } finally {
            isSaving = false;
        }
    }

    async function saveListSettings() {
        if (!detail) return;
        isSaving = true;
        try {
            const updated = await apiFetch(`/api/admin/position-reservations/${detail.id}`, {
                method: 'PATCH',
                body: {
                    stateNumber: Number(listSettingsStateNumber),
                },
            });
            detail = normalizeDetail(updated);
            if (detail.canManageAssignments) {
                detail = normalizeDetail(await apiFetch(`/api/admin/position-reservations/${detail.id}/assignees`, {
                    method: 'PUT',
                    body: {
                        userIds: assigneeDraftUserIds,
                    },
                }));
            }
            showListSettingsModal = false;
            await loadLists();
            showToast('List settings saved', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isSaving = false;
        }
    }

    async function saveActiveCategory() {
        if (!detail || !activeCategoryKey) return;
        showValidationErrors = true;
        const category = getCategoryDetail(activeCategoryKey);
        if (category && getCategoryIssues(category).length > 0) {
            showToast('Fill the required reservation fields first.', 'error');
            return;
        }

        isSaving = true;
        try {
            await persistDetail({ showSuccessToast: true, categories: [activeCategoryKey] });
            closeCategorySlots();
        } catch (error) {
            if (/destructive regeneration/i.test(error.message) && await requestConfirmation({
                title: 'Regenerate Slots?',
                message: `Reservations already exist for ${category?.display?.label || 'this type'}. Updating this schedule will delete only those reservations. Continue?`,
                confirmLabel: 'Continue',
                variant: 'danger',
            })) {
                try {
                    await persistDetail({ showSuccessToast: true, forceRegeneration: true, categories: [activeCategoryKey] });
                    closeCategorySlots();
                } catch (retryError) {
                    showToast(retryError.message, 'error');
                }
            } else {
                showToast(error.message, 'error');
            }
        } finally {
            isSaving = false;
        }
    }

    async function publish() {
        if (!detail) return;
        showValidationErrors = true;
        if (detail.categories.some((category) => getCategoryIssues(category).length > 0)) {
            showToast('Fill the required reservation fields first.', 'error');
            return;
        }
        isPublishing = true;
        try {
            await persistDetail();
            const issues = getPublishReadinessIssues();
            if (issues.length) {
                throw new Error(issues[0]);
            }
            detail = normalizeDetail(await apiFetch(`/api/admin/position-reservations/${detail.id}/publish`, { method: 'POST' }));
            await loadLists();
            showToast('Reservation list published', 'success');
        } catch (error) {
            if (/destructive regeneration/i.test(error.message) && await requestConfirmation({
                title: 'Regenerate Slots?',
                message: 'Reservations already exist. Updating the schedule will delete them. Continue?',
                confirmLabel: 'Continue',
                variant: 'danger',
            })) {
                try {
                    await persistDetail({ forceRegeneration: true });
                    detail = normalizeDetail(await apiFetch(`/api/admin/position-reservations/${detail.id}/publish`, { method: 'POST' }));
                    await loadLists();
                    showToast('Reservation list published', 'success');
                } catch (retryError) {
                    showToast(retryError.message, 'error');
                }
            } else {
                showToast(error.message, 'error');
            }
        } finally {
            isPublishing = false;
        }
    }

    async function unpublish() {
        if (!detail) return;
        try {
            detail = normalizeDetail(await apiFetch(`/api/admin/position-reservations/${detail.id}/unpublish`, { method: 'POST' }));
            await loadLists();
            showToast('Reservation list unpublished', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    async function deleteList() {
        if (!detail) return;
        if (detail.canDelete === false) {
            showToast('Only the creator, owner, or full-access admins can delete this list.', 'error');
            return;
        }
        deleteTarget = {
            id: detail.id,
            label: `State ${detail.stateNumber}`,
            hasReservations: detail.reservationCount > 0,
        };
        showDeleteModal = true;
    }

    async function confirmDeleteList() {
        if (!deleteTarget.id) return;
        isDeleting = true;
        try {
            await apiFetch(`/api/admin/position-reservations/${deleteTarget.id}`, {
                method: 'DELETE',
            });

            const deletedId = deleteTarget.id;
            detail = null;
            selectedListId = '';
            showDeleteModal = false;
            deleteTarget = { id: '', label: '', hasReservations: false };
            await loadLists();
            if (selectedListId === deletedId) {
                selectedListId = lists[0]?.id || '';
                if (selectedListId) {
                    await loadDetail(selectedListId);
                }
            }
            showToast('Reservation list deleted', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isDeleting = false;
        }
    }

    function cancelDeleteList() {
        if (isDeleting) return;
        showDeleteModal = false;
        deleteTarget = { id: '', label: '', hasReservations: false };
    }

    async function copyLink() {
        if (!detail?.publicSlug) return;
        const url = `${window.location.origin}${basePath}/r/positions/${detail.publicSlug}`;
        await navigator.clipboard.writeText(url);
        showToast('Public link copied', 'success');
    }

    function getCategoryDetail(categoryKey) {
        return detail?.categories?.find((category) => category.category === categoryKey) || null;
    }

    function toggleAssigneeSelection(userId, checked) {
        if (checked) {
            assigneeDraftUserIds = [...new Set([...assigneeDraftUserIds, userId])];
        } else {
            assigneeDraftUserIds = assigneeDraftUserIds.filter((value) => value !== userId);
        }
    }

    function getSlotPreview(category) {
        return (category?.slots || []).slice(0, 3);
    }

    function isCategoryConfigured(category) {
        if (!category) return false;
        return !!(category.enabled && category.firstSlotTimeInput);
    }

    function getCategoryStatusLabel(category) {
        if (!category?.enabled) return 'Disabled';
        return isCategoryConfigured(category) ? 'Configured' : 'Needs Setup';
    }

    function openCategorySlots(categoryKey) {
        activeCategoryKey = categoryKey;
        showCategorySlotsModal = true;
    }

    function closeCategorySlots() {
        showCategorySlotsModal = false;
        activeCategoryKey = '';
    }

    function openSlotModal(slot, category) {
        slotForm = {
            slotId: slot.id,
            reservationId: slot.reservation?.id || '',
            status: slot.status === 'locked' ? 'locked' : 'reserved',
            playerId: slot.reservation?.playerId || '',
            allianceTag: slot.reservation?.allianceTag || '',
            label: `${category.display.label}: ${formatSlot(slot)}`,
        };
        showSlotModal = true;
    }

    function handleSlotRowKeydown(event, slot, category) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            openSlotModal(slot, category);
        }
    }

    async function saveSlot() {
        try {
            detail = normalizeDetail(await apiFetch(`/api/admin/position-reservations/slots/${slotForm.slotId}`, {
                method: 'PATCH',
                body: {
                    status: slotForm.status,
                    playerId: slotForm.playerId,
                    allianceTag: slotForm.allianceTag,
                },
            }));
            showSlotModal = false;
            await loadLists();
            showToast('Slot updated', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    async function clearReservation(reservationId, { closeModal = false } = {}) {
        const confirmed = await requestConfirmation({
            title: 'Delete Reservation?',
            message: 'Delete this reservation?',
            confirmLabel: 'Delete',
            variant: 'danger',
        });
        if (!confirmed) return;
        try {
            detail = normalizeDetail(await apiFetch(`/api/admin/position-reservations/reservations/${reservationId}`, {
                method: 'DELETE',
            }));
            if (closeModal) {
                showSlotModal = false;
            }
            await loadLists();
            showToast('Reservation deleted', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    function formatSlot(slot) {
        return `${formatUtcShort(slot.startsAtUtc)} - ${formatUtcShort(slot.endsAtUtc)} UTC`;
    }

    function formatUtcShort(isoString) {
        if (!isoString) return '--:--';
        const date = new Date(isoString);
        return date.toISOString().slice(11, 16);
    }

    function reservationCount(category) {
        return category.slots.filter((slot) => slot.status === 'reserved').length;
    }

    const publishIssues = $derived(detail ? getPublishReadinessIssues() : []);
</script>

<PageHeader label="Reservations">
    Create and publish public UTC reservation lists for state positions.
</PageHeader>

<div class="reservations-layout">
    <aside class="sidebar-card">
        <div class="list-toolbar">
            <div class="panel-title">Reservation Lists</div>
            <button class="btn btn-primary create-list-button" onclick={openCreateModal}>
                <Icon name="plus" size={14} /> Create List
            </button>
        </div>
        {#if isLoadingLists}
            <div class="skeleton" style="height: 180px;"></div>
        {:else}
            <div class="list-stack">
                {#each lists as list (list.id)}
                    <div class="list-accordion" class:expanded={selectedListId === list.id}>
                    <button class="list-card" class:active={selectedListId === list.id} onclick={() => toggleList(list.id)}>
                        <div class="list-card-top">
                            <strong>State {list.stateNumber}</strong>
                            <div class="list-card-badges">
                                <span class="status-pill {list.status}">{list.status}</span>
                            </div>
                        </div>
                    </button>
                    {#if selectedListId === list.id}
                        <div class="list-card-detail" transition:slide={{ duration: 220 }}>
                            {#if isLoadingDetail}
                                <div class="skeleton" style="height: 320px;"></div>
                            {:else if detail}
                                <div class="detail-header">
                                    <div class="header-actions" class:published-actions={detail.status === 'published'} class:draft-actions={detail.status !== 'published'}>
                                        <div class="action-slot action-slot-settings">
                                            <button class="btn reservation-settings" type="button" onclick={openListSettingsModal}>
                                                <Icon name="settings" size={14} /> Settings
                                            </button>
                                        </div>
                                        {#if detail.status === 'published'}
                                            <div class="action-slot action-slot-copy">
                                                <button class="btn reservation-copy-link" onclick={copyLink}><Icon name="copy" size={14} /> Copy Link</button>
                                            </div>
                                            <div class="action-slot action-slot-unpublish">
                                                <button class="btn btn-danger reservation-unpublish" onclick={unpublish}>Unpublish</button>
                                            </div>
                                        {:else}
                                            <div class="action-slot action-slot-publish">
                                                <LoadingButton class="btn btn-primary reservation-publish" loading={isPublishing} onclick={publish} disabled={publishIssues.length > 0}>
                                                    <Icon name="share" size={14} /> Publish
                                                </LoadingButton>
                                            </div>
                                        {/if}
                                        {#if detail.canDelete !== false}
                                            <div class="action-slot action-slot-delete">
                                                <LoadingButton class="btn btn-danger reservation-delete" loading={isDeleting} onclick={deleteList}>
                                                    <Icon name="delete" size={14} /> Delete List
                                                </LoadingButton>
                                            </div>
                                        {/if}
                                    </div>
                                </div>

                                {#if detail.status !== 'published' && publishIssues.length > 0}
                                    <div class="publish-warning">
                                        {publishIssues[0]}
                                    </div>
                                {/if}

                                <div class="category-grid category-grid-cards">
                                    {#each detail.categories as category (category.category)}
                                        <button class="category-card category-card-button" onclick={() => openCategorySlots(category.category)}>
                                            <div class="category-card-top">
                                                <h4>{category.display.label}</h4>
                                                <span class="status-pill {isCategoryConfigured(category) ? 'configured' : (category.enabled ? 'needs-setup' : 'disabled')}">
                                                    {getCategoryStatusLabel(category)}
                                                </span>
                                            </div>
                                            <div class="category-card-meta">
                                                <span>{category.slots.length} slots</span>
                                                <span>{reservationCount(category)} reserved</span>
                                            </div>
                                        </button>
                                    {/each}
                                </div>
                            {/if}
                        </div>
                    {/if}
                    </div>
                {:else}
                    <div class="empty-state">No reservation lists yet.</div>
                {/each}
            </div>
        {/if}
    </aside>

    {#if false}
    <section class="detail-card">
        {#if !detail}
            <div class="empty-state large">Select or create a reservation list to configure it.</div>
        {:else if isLoadingDetail}
            <div class="skeleton" style="height: 320px;"></div>
        {:else}
            <div class="detail-header">
                <div>
                    <h3>State {detail.stateNumber}</h3>
                </div>
                <div class="header-actions">
                    <LoadingButton class="btn" loading={isSaving} onclick={saveDetail}>
                        <Icon name="check" size={14} /> Save Setup
                    </LoadingButton>
                    {#if detail.status === 'published'}
                        <button class="btn" onclick={copyLink}><Icon name="copy" size={14} /> Copy Link</button>
                        <button class="btn btn-danger" onclick={unpublish}>Unpublish</button>
                    {:else}
                        <LoadingButton class="btn btn-primary" loading={isPublishing} onclick={publish} disabled={publishIssues.length > 0}>
                            <Icon name="share" size={14} /> Publish
                        </LoadingButton>
                    {/if}
                    <LoadingButton class="btn btn-danger" loading={isDeleting} onclick={deleteList}>
                        <Icon name="delete" size={14} /> Delete List
                    </LoadingButton>
                </div>
            </div>

            {#if detail.status !== 'published' && publishIssues.length > 0}
                <div class="publish-warning">
                    {publishIssues[0]}
                </div>
            {/if}

            <div class="category-grid">
                {#each detail.categories as category, index (category.category)}
                    <div class="category-card">
                        <div class="category-header">
                            <div>
                                <h4>{category.display.label}</h4>
                                <p>{category.display.positionName}</p>
                            </div>
                                                <Checkbox class="toggle" bind:checked={detail.categories[index].enabled} label="Enabled" />
                        </div>

                        <div class="field-grid">
                            <label>
                                <span>First Slot UTC <span class="required-mark">*</span></span>
                                <input
                                    type="text"
                                    bind:value={detail.categories[index].firstSlotTimeInput}
                                    inputmode="numeric"
                                    placeholder="23:45"
                                    maxlength="5"
                                    oninput={(event) => detail.categories[index].firstSlotTimeInput = formatTimeTextInput(event.currentTarget.value)}
                                    onblur={() => detail.categories[index].firstSlotTimeInput = normalizeTimeText(detail.categories[index].firstSlotTimeInput)}
                                />
                                {#each getCategoryIssues(category).filter((issue) => issue.field === 'firstSlotTimeInput') as issue (issue.message)}
                                    <div class="field-error">{issue.message}</div>
                                {/each}
                            </label>
                            <label>
                                <span>Allowed Slots</span>
                                <input
                                    type="text"
                                    inputmode="numeric"
                                    pattern="[0-9]*"
                                    maxlength="2"
                                    bind:value={detail.categories[index].allowedSlotCount}
                                    oninput={(event) => detail.categories[index].allowedSlotCount = normalizeAllowedSlotCountInput(event.currentTarget.value)}
                                />
                            </label>
                        </div>

        <div class="slot-summary">
            <span>{category.slots.length} generated slots</span>
            <span>{reservationCount(category)} reserved</span>
        </div>

        <div class="slot-list">
                            {#each category.slots as slot (slot.id)}
                                <div
                                    class="slot-row slot-row-{slot.status}"
                                    role="button"
                                    tabindex="0"
                                    onclick={() => openSlotModal(slot, category)}
                                    onkeydown={(event) => handleSlotRowKeydown(event, slot, category)}
                                >
                                    <div class="slot-row-content">
                                        <strong>{formatSlot(slot)}</strong>
                                        {#if slot.reservation}
                                            <div class="slot-meta">{slot.reservation.playerName || slot.reservation.playerId} &bull; {slot.reservation.allianceTag}</div>
                                        {/if}
                                    </div>
                                    <button
                                        class="slot-row-trigger"
                                        type="button"
                                        aria-label="Manage slot"
                                        title="Manage slot"
                                        onclick={(event) => {
                                            event.stopPropagation();
                                            openSlotModal(slot, category);
                                        }}
                                    >
                                        <Icon name="settings" size={14} />
                                    </button>
                                </div>
                            {:else}
                                <div class="empty-slot-state">No slots generated yet for this category.</div>
                            {/each}
                        </div>
                    </div>
                {/each}
            </div>
        {/if}
    </section>
    {/if}
</div>

<Modal bind:isOpen={showSlotModal} title="Manage Slot">
    <div class="form-stack">
        <div class="slot-modal-label">{slotForm.label}</div>
        <label>
            <span>Status</span>
            <Select bind:value={slotForm.status} options={[
                { value: 'reserved', label: 'Reserved' },
                { value: 'locked', label: 'Locked' },
                { value: 'available', label: 'Available' },
            ]} />
        </label>
        {#if slotForm.status === 'reserved'}
            <label>
                <span>Player ID</span>
                <input type="text" bind:value={slotForm.playerId} maxlength="32" />
            </label>
            <label>
                <span>Alliance Tag</span>
                <input type="text" bind:value={slotForm.allianceTag} maxlength="12" />
            </label>
        {/if}
        <div class="modal-actions slot-modal-actions">
            <button class="btn" onclick={() => showSlotModal = false}>Cancel</button>
            {#if slotForm.reservationId}
                <button class="btn btn-danger" onclick={() => clearReservation(slotForm.reservationId, { closeModal: true })}>Clear</button>
            {/if}
            <button class="btn btn-primary" onclick={saveSlot}>Save Slot</button>
        </div>
    </div>
</Modal>

<Modal bind:isOpen={showCategorySlotsModal} title={getCategoryDetail(activeCategoryKey)?.display?.label || 'Reservation Type'} wide onclose={closeCategorySlots}>
    {#if getCategoryDetail(activeCategoryKey)}
        {@const category = getCategoryDetail(activeCategoryKey)}
        {@const categoryIndex = detail.categories.findIndex((entry) => entry.category === activeCategoryKey)}
        <div class="category-modal-shell">
            <div class="category-header">
                <div>
                    <h4>{category.display.label}</h4>
                    <p>{category.display.positionName}</p>
                </div>
                <Checkbox class="toggle" bind:checked={detail.categories[categoryIndex].enabled} label="Enabled" />
            </div>

            <div class="field-grid category-modal-grid">
                <label>
                    <span>First Slot UTC <span class="required-mark">*</span></span>
                    <input
                        type="text"
                        bind:value={detail.categories[categoryIndex].firstSlotTimeInput}
                        inputmode="numeric"
                        placeholder="23:45"
                        maxlength="5"
                        oninput={(event) => detail.categories[categoryIndex].firstSlotTimeInput = formatTimeTextInput(event.currentTarget.value)}
                        onblur={() => detail.categories[categoryIndex].firstSlotTimeInput = normalizeTimeText(detail.categories[categoryIndex].firstSlotTimeInput)}
                    />
                    {#each getCategoryIssues(category).filter((issue) => issue.field === 'firstSlotTimeInput') as issue (issue.message)}
                        <div class="field-error">{issue.message}</div>
                    {/each}
                </label>
                <label>
                    <span>Allowed Slots</span>
                    <input
                        type="text"
                        inputmode="numeric"
                        pattern="[0-9]*"
                        maxlength="2"
                        bind:value={detail.categories[categoryIndex].allowedSlotCount}
                        oninput={(event) => detail.categories[categoryIndex].allowedSlotCount = normalizeAllowedSlotCountInput(event.currentTarget.value)}
                    />
                </label>
            </div>

            <div class="slot-summary">
                <span>{category.slots.length} generated slots</span>
                <span>{reservationCount(category)} reserved</span>
            </div>

            <div class="slot-list">
                {#each category.slots as slot (slot.id)}
                    <div
                        class="slot-row slot-row-{slot.status}"
                        role="button"
                        tabindex="0"
                        onclick={() => openSlotModal(slot, category)}
                        onkeydown={(event) => handleSlotRowKeydown(event, slot, category)}
                    >
                        <div class="slot-row-content">
                            <strong>{formatSlot(slot)}</strong>
                            {#if slot.reservation}
                                <div class="slot-meta">{slot.reservation.playerName || slot.reservation.playerId} &bull; {slot.reservation.allianceTag}</div>
                            {/if}
                        </div>
                        <button
                            class="slot-row-trigger"
                            type="button"
                            aria-label="Manage slot"
                            title="Manage slot"
                            onclick={(event) => {
                                event.stopPropagation();
                                openSlotModal(slot, category);
                            }}
                        >
                            <Icon name="settings" size={14} />
                        </button>
                    </div>
                {:else}
                    <div class="empty-slot-state">No slots generated yet for this category.</div>
                {/each}
        </div>

            <div class="modal-actions">
                <button class="btn" onclick={closeCategorySlots} disabled={isSaving}>Close</button>
                <LoadingButton class="btn btn-primary" loading={isSaving} onclick={saveActiveCategory}>
                    Save
                </LoadingButton>
            </div>
        </div>
    {/if}
</Modal>

<Modal bind:isOpen={showCreateModal} title="Create Reservation List" onclose={closeCreateModal}>
    <div class="form-stack">
        <label>
            <span>State</span>
            <input
                type="text"
                inputmode="numeric"
                pattern="[0-9]*"
                maxlength="4"
                bind:value={newStateNumber}
                placeholder="e.g. 1234"
                oninput={(event) => newStateNumber = normalizeStateNumberInput(event.currentTarget.value)}
            />
        </label>
        <div class="modal-actions">
            <button class="btn" onclick={closeCreateModal} disabled={isCreating}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={isCreating} onclick={createList} disabled={!newStateNumber}>
                <Icon name="plus" size={14} /> Create List
            </LoadingButton>
        </div>
    </div>
</Modal>

<Modal bind:isOpen={showListSettingsModal} title="List Settings" onclose={closeListSettingsModal}>
    <div class="form-stack">
        <label>
            <span>State</span>
            <input
                type="text"
                inputmode="numeric"
                pattern="[0-9]*"
                maxlength="4"
                bind:value={listSettingsStateNumber}
                placeholder="e.g. 1234"
                oninput={(event) => listSettingsStateNumber = normalizeStateNumberInput(event.currentTarget.value)}
            />
        </label>
        {#if detail?.canManageAssignments}
            <div class="settings-assignees">
                <div class="settings-assignees-head">
                    <span>Assigned Admins</span>
                    <small>Assigned admins can manage this list, but only the creator, owner, or full-access admins can delete it.</small>
                </div>
                {#if isLoadingAssignableAdmins}
                    <div class="empty-state">Loading admins...</div>
                {:else}
                    <div class="assignee-list">
                        {#each assignableAdmins.filter((admin) => admin.userId !== detail.createdByUserId) as admin (admin.userId)}
                            <label class="assignee-row">
                                <Checkbox
                                    label={admin.username || 'Discord User'}
                                    checked={assigneeDraftUserIds.includes(admin.userId)}
                                    onchange={(event) => toggleAssigneeSelection(admin.userId, event.currentTarget.checked)}
                                />
                            </label>
                        {:else}
                            <div class="empty-state">No other admins available to assign.</div>
                        {/each}
                    </div>
                {/if}
            </div>
        {/if}
        <div class="modal-actions">
            <button class="btn" onclick={closeListSettingsModal} disabled={isSaving}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={isSaving} onclick={saveListSettings} disabled={!listSettingsStateNumber}>
                Save
            </LoadingButton>
        </div>
    </div>
</Modal>

<ConfirmDialog
    bind:isOpen={showConfirmDialog}
    title={confirmTitle}
    message={confirmMessage}
    confirmLabel={confirmLabel}
    variant={confirmVariant}
    onconfirm={handleConfirmAccept}
    oncancel={handleConfirmCancel}
/>

<Modal bind:isOpen={showDeleteModal} title="Delete Reservation List" onclose={cancelDeleteList}>
    <div class="delete-confirmation">
        <p>Delete <strong>{deleteTarget.label}</strong>?</p>
        <p class="delete-copy">
            {#if deleteTarget.hasReservations}
                This will permanently remove the list, all generated slots, and every reservation on it.
            {:else}
                This will permanently remove the list and all generated slots.
            {/if}
        </p>
        <div class="modal-actions">
            <button class="btn" onclick={cancelDeleteList} disabled={isDeleting}>Cancel</button>
            <LoadingButton class="btn btn-danger" loading={isDeleting} onclick={confirmDeleteList}>
                <Icon name="delete" size={14} /> Delete List
            </LoadingButton>
        </div>
    </div>
</Modal>

<style>
    .reservations-layout {
        display: block;
    }

    .sidebar-card,
    .detail-card,
    .category-card {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
    }

    .sidebar-card,
    .detail-card {
        padding: 20px;
    }

    .list-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 14px;
    }

    .panel-title,
    .detail-header h3,
    .category-header h4 {
        margin: 0;
        color: var(--color-text-primary);
    }

    .form-stack,
    .list-stack,
    .slot-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .list-accordion {
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        background: var(--color-card);
        overflow: hidden;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }

    .list-accordion.expanded {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 1px var(--color-accent);
    }

    .form-stack label,
    .field-grid label {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    input {
        width: 100%;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        padding: 10px 12px;
    }

    label span,
    .slot-meta,
    .list-card-meta,
    .category-header p,
    .empty-slot-state,
    .empty-state {
        color: var(--color-text-muted);
        font-size: 13px;
    }

    .list-card {
        width: 100%;
        text-align: left;
        padding: 14px;
        border-radius: 0;
        border: 0;
        background: transparent;
        color: inherit;
    }

    .list-card-badges,
    .accordion-meta {
        display: inline-flex;
        align-items: center;
        gap: 10px;
    }

    .list-card-detail {
        padding: 18px;
        border-top: 1px solid var(--color-border);
        background: rgba(255, 255, 255, 0.02);
    }

    .list-card-top,
    .detail-header,
    .category-header,
    .slot-row,
    .slot-actions,
    .slot-summary,
    .modal-actions {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
    }

    .detail-title-row {
        display: inline-flex;
        align-items: center;
        gap: 10px;
    }

    .detail-header {
        margin-bottom: 20px;
        flex-wrap: wrap;
    }

    .header-actions {
        display: flex;
        width: 100%;
        justify-content: flex-end;
        gap: 10px;
        flex-wrap: wrap;
    }

    .slot-modal-actions {
        justify-content: flex-end;
        align-items: center;
    }

    .published-actions .action-slot-copy {
        order: 1;
    }

    .published-actions .action-slot-unpublish {
        order: 2;
    }

    .published-actions .action-slot-delete {
        order: 3;
    }

    .published-actions .action-slot-settings {
        order: 4;
    }

    .draft-actions .action-slot-publish {
        order: 1;
    }

    .draft-actions .action-slot-delete {
        order: 2;
    }

    .draft-actions .action-slot-settings {
        order: 3;
    }

    .publish-warning {
        margin: 0 0 18px;
        padding: 12px 14px;
        border: 1px solid rgba(255, 180, 64, 0.28);
        border-radius: 12px;
        background: rgba(255, 180, 64, 0.1);
        color: #ffcb77;
        font-size: 0.92rem;
    }

    .delete-confirmation {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .delete-confirmation p {
        margin: 0;
        color: var(--color-text-primary);
    }

    .settings-assignees {
        display: flex;
        flex-direction: column;
        gap: 12px;
        padding: 14px;
        border: 1px solid var(--color-border);
        border-radius: 14px;
        background: rgba(255, 255, 255, 0.03);
    }

    .settings-assignees-head {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .settings-assignees-head span {
        color: var(--color-text-primary);
        font-size: 14px;
        font-weight: 600;
    }

    .settings-assignees-head small {
        color: var(--color-text-muted);
        font-size: 12px;
        line-height: 1.5;
    }

    .assignee-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
        max-height: 220px;
        overflow-y: auto;
    }

    .assignee-row {
        padding: 10px 12px;
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.06);
        background: rgba(255, 255, 255, 0.02);
    }

    .delete-copy {
        color: var(--color-text-secondary) !important;
        line-height: 1.5;
    }

    .field-error {
        color: #ff8f8f;
        font-size: 12px;
        line-height: 1.4;
    }

    .required-mark {
        color: #ff6b6b;
        font-weight: 700;
    }

    .action-slot {
        display: flex;
    }

    .field-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
    }

    .category-grid {
        display: flex;
        flex-direction: column;
        gap: 16px;
        margin-top: 20px;
    }

    .category-grid-cards {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
    }

    .category-card {
        padding: 18px;
    }

    .category-card-button {
        text-align: left;
        cursor: pointer;
        transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
    }

    .category-card-button:hover {
        transform: translateY(-2px);
        border-color: var(--color-accent);
        box-shadow: 0 12px 28px rgba(0, 0, 0, 0.22);
    }

    .category-card-top {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 10px;
    }

    .category-card-meta {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-top: 12px;
        color: var(--color-text-secondary);
        font-size: 12px;
    }

    .category-modal-shell {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .category-modal-grid {
        margin-top: 4px;
    }

    .toggle {
        justify-self: end;
    }

    .slot-summary {
        margin: 14px 0 10px;
        padding-top: 12px;
        border-top: 1px solid var(--color-border);
        color: var(--color-text-secondary);
        font-size: 13px;
    }

    .slot-list {
        max-height: 320px;
        overflow-y: auto;
        padding-right: 4px;
    }

    .slot-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        padding: 12px;
        border: 1px solid var(--color-border);
        border-left: 4px solid rgba(255, 255, 255, 0.12);
        border-radius: var(--radius-md);
        background: var(--color-secondary);
        cursor: pointer;
        transition: border-color 0.15s ease, background-color 0.15s ease, box-shadow 0.15s ease, transform 0.15s ease;
    }

    .slot-row:hover {
        border-color: var(--color-border-accent);
        background: rgba(255, 255, 255, 0.04);
    }

    .slot-row:focus-visible {
        outline: 2px solid var(--color-accent);
        outline-offset: 2px;
    }

    .slot-row-content {
        display: flex;
        flex-direction: column;
        gap: 6px;
        min-width: 0;
    }

    .slot-row-trigger {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 30px;
        height: 30px;
        flex: 0 0 30px;
        margin-left: auto;
        border-radius: 10px;
        border: 1px solid var(--color-border);
        background: rgba(255, 255, 255, 0.05);
        color: var(--color-text-secondary);
        cursor: pointer;
        transition: background-color 0.15s ease, border-color 0.15s ease, color 0.15s ease;
    }

    .slot-row-trigger:hover {
        color: var(--color-text-primary);
        border-color: var(--color-border-accent);
        background: rgba(255, 255, 255, 0.08);
    }

    .slot-row-available {
        border-left-color: #8bc8ff;
    }

    .slot-row-reserved {
        border-left-color: #76e6a5;
    }

    .slot-row-locked {
        border-left-color: #ffcb77;
    }

    .status-pill {
        display: inline-flex;
        align-items: center;
        padding: 4px 8px;
        border-radius: 999px;
        font-size: 12px;
        text-transform: capitalize;
        background: var(--color-base);
    }

    .status-pill.published,
    .status-pill.reserved {
        background: rgba(61, 196, 126, 0.14);
        color: #76e6a5;
    }

    .status-pill.draft,
    .status-pill.available {
        background: rgba(76, 169, 255, 0.14);
        color: #8bc8ff;
    }

    .status-pill.configured {
        background: rgba(61, 196, 126, 0.14);
        color: #76e6a5;
    }

    .status-pill.needs-setup {
        background: rgba(255, 180, 64, 0.14);
        color: #ffcb77;
    }

    .status-pill.disabled {
        background: rgba(130, 140, 160, 0.16);
        color: #aeb7c6;
    }

    .status-pill.unpublished,
    .status-pill.locked {
        background: rgba(255, 180, 64, 0.14);
        color: #ffcb77;
    }

    .slot-modal-label {
        color: var(--color-text-secondary);
        font-size: 13px;
        margin-bottom: 4px;
    }

    .large {
        min-height: 280px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    @media (max-width: 1100px) {
        .reservations-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .category-grid-cards,
        .field-grid {
            grid-template-columns: 1fr;
        }

        .list-toolbar {
            flex-direction: column;
            align-items: stretch;
        }

        .create-list-button {
            width: 100%;
            justify-content: center;
        }

        .header-actions {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            width: 100%;
        }

        .published-actions .action-slot-settings {
            grid-column: 1;
            grid-row: 1;
        }

        .published-actions .action-slot-copy {
            grid-column: 2;
            grid-row: 1;
        }

        .published-actions .action-slot-delete {
            grid-column: 2;
            grid-row: 2;
        }

        .published-actions .action-slot-unpublish {
            grid-column: 1;
            grid-row: 2;
        }

        .draft-actions .action-slot-settings {
            grid-column: 1 / -1;
            grid-row: 1;
        }

        .draft-actions .action-slot-publish {
            grid-column: 1;
            grid-row: 2;
        }

        .draft-actions .action-slot-delete {
            grid-column: 2;
            grid-row: 2;
        }

        .action-slot :global(.reservation-settings),
        .action-slot :global(.reservation-publish),
        .action-slot :global(.reservation-delete),
        .action-slot :global(.reservation-unpublish),
        .action-slot :global(.reservation-copy-link) {
            width: 100%;
            justify-content: center;
        }

        .detail-header {
            flex-direction: column;
            align-items: stretch;
        }

        .slot-row {
            align-items: flex-start;
            flex-direction: row;
        }
    }
</style>
