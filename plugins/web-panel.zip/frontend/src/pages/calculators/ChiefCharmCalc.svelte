<script>
    import { onMount } from 'svelte';
    import { apiFetch, getBasePath } from '../../lib/api.js';
    import { showToast } from '../../lib/utils.js';
    import { calculateMultipleCharmUpgrades } from '../../lib/calculators/chiefCharmCalculator.js';
    import { formatMaterialName, formatNumber, loadCalculatorData } from '../../lib/calculators/calculatorData.js';

    const SLOT_POSITIONS = [
        { id: 'hat', side: 'left', family: 'lancer', label: 'Lancer' },
        { id: 'coat', side: 'left', family: 'infantry', label: 'Infantry' },
        { id: 'ring', side: 'left', family: 'marksman', label: 'Marksman' },
        { id: 'watch', side: 'right', family: 'lancer', label: 'Lancer' },
        { id: 'pants', side: 'right', family: 'infantry', label: 'Infantry' },
        { id: 'staff', side: 'right', family: 'marksman', label: 'Marksman' },
    ];
    const CHARM_IMAGE_BASE = getBasePath() + '/images/calculators/charm';
    const CHIEF_GEAR_IMAGE_BASE = getBasePath() + '/images/calculators/chief_gear';
    const CHIEF_PORTRAIT_IMAGE = `${CHIEF_GEAR_IMAGE_BASE}/Jeronimo_Full.png`;
    const RESOURCE_IMAGE_BASE = getBasePath() + '/images/calculators/resources';
    const RESOURCE_IMAGE_MAP = {
        charmDesign: 'Charm_Designs.png',
        charmGuide: 'Charm_Guides.png',
        charmSecret: 'Secret_Jewels.png',
    };

    let isLoading = $state(false);
    let calculatorData = $state(null);
    let result = $state(null);
    let activeSlotId = $state(SLOT_POSITIONS[0].id);
    let slotSelections = $state({});
    let levelPicker = $state({
        slotId: null,
        gemIndex: null,
        step: 'current',
        currentLevel: 0,
        targetLevel: 0,
    });

    let charmLevels = $derived(calculatorData?.charmLevels ?? []);
    let activeSlot = $derived(SLOT_POSITIONS.find((slot) => slot.id === activeSlotId) ?? SLOT_POSITIONS[0]);
    let pickerSlot = $derived(SLOT_POSITIONS.find((slot) => slot.id === levelPicker.slotId) ?? null);
    let pickerLevelOptions = $derived(
        charmLevels.filter((level) => {
            if (levelPicker.step === 'current') {
                return level.level < charmLevels.length - 1;
            }

            return level.level > Number(levelPicker.currentLevel);
        })
    );

    function portal(node) {
        document.body.appendChild(node);
        return {
            destroy() {
                node.remove();
            }
        };
    }

    function getGemCount() {
        return Number(calculatorData?.equipment?.charmSlotsPerGearPiece) || 3;
    }

    function createGemSelection() {
        return {
            currentLevel: 0,
            targetLevel: 0,
        };
    }

    function getDefaultSelection(gemCount = getGemCount()) {
        return {
            gems: Array.from({ length: gemCount }, () => createGemSelection()),
        };
    }

    function buildInitialSlotSelections() {
        slotSelections = Object.fromEntries(
            SLOT_POSITIONS.map((slot) => [slot.id, { ...getDefaultSelection() }])
        );
    }

    function getSlotSelection(slotId) {
        return slotSelections[slotId] ?? getDefaultSelection();
    }

    function getGemSelection(slotId, gemIndex) {
        return getSlotSelection(slotId).gems?.[gemIndex] ?? createGemSelection();
    }

    function updateGemSelection(slotId, gemIndex, nextGemSelection) {
        const slotSelection = getSlotSelection(slotId);
        const nextGems = slotSelection.gems.map((gem, index) =>
            index === gemIndex ? { ...gem, ...nextGemSelection } : gem
        );

        slotSelections = {
            ...slotSelections,
            [slotId]: {
                ...slotSelection,
                gems: nextGems,
            },
        };
    }

    function getResourceImage(materialKey) {
        const fileName = RESOURCE_IMAGE_MAP[materialKey];
        return fileName ? `${RESOURCE_IMAGE_BASE}/${fileName}` : '';
    }

    function getDisplayedLevel(slotId, gemIndex) {
        const selection = getGemSelection(slotId, gemIndex);
        return Number(selection?.targetLevel) || Number(selection?.currentLevel) || 1;
    }

    function getCharmImage(family, level) {
        const numericLevel = Number(level) || 1;
        return `${CHARM_IMAGE_BASE}/${family}-level-${String(numericLevel).padStart(2, '0')}.png`;
    }

    function selectSlot(slotId) {
        activeSlotId = slotId;
    }

    function openLevelPicker(slotId, gemIndex) {
        const selection = getGemSelection(slotId, gemIndex);
        activeSlotId = slotId;
        levelPicker = {
            slotId,
            gemIndex,
            step: 'current',
            currentLevel: Number(selection.currentLevel),
            targetLevel: Number(selection.targetLevel),
        };
    }

    function closeLevelPicker() {
        levelPicker = {
            slotId: null,
            gemIndex: null,
            step: 'current',
            currentLevel: 0,
            targetLevel: 0,
        };
    }

    function updateCalculatedResult() {
        if (!calculatorData) return;

        result = calculateMultipleCharmUpgrades(
            calculatorData,
            SLOT_POSITIONS.flatMap((slot) =>
                getSlotSelection(slot.id).gems.map((gem, gemIndex) => ({
                    slotId: `${slot.id}-gem-${gemIndex + 1}`,
                    slotLabel: slot.label,
                    gemLabel: `Gem ${gemIndex + 1}`,
                    currentLevel: Number(gem.currentLevel),
                    targetLevel: Number(gem.targetLevel),
                    charmCount: 1,
                }))
            )
        );
    }

    function handleLevelOptionClick(level) {
        if (!levelPicker.slotId || levelPicker.gemIndex === null) return;

        if (levelPicker.step === 'current') {
            const nextTargetLevel = Number(levelPicker.targetLevel) > Number(level) ? Number(levelPicker.targetLevel) : Number(level);

            updateGemSelection(levelPicker.slotId, levelPicker.gemIndex, {
                currentLevel: Number(level),
                targetLevel: nextTargetLevel,
            });

            levelPicker = {
                ...levelPicker,
                step: 'target',
                currentLevel: Number(level),
                targetLevel: nextTargetLevel,
            };

            updateCalculatedResult();
            return;
        }

        updateGemSelection(levelPicker.slotId, levelPicker.gemIndex, {
            currentLevel: Number(levelPicker.currentLevel),
            targetLevel: Number(level),
        });

        activeSlotId = levelPicker.slotId;
        updateCalculatedResult();
        closeLevelPicker();
    }

    function handleLevelPickerBackdropClick(event) {
        if (event.target === event.currentTarget) {
            closeLevelPicker();
        }
    }

    function setLevelPickerStep(step) {
        if (step !== 'current' && step !== 'target') return;
        levelPicker = { ...levelPicker, step };
    }

    function formatDiscordCopyLine(label, amount) {
        return `  - ${label}: ${formatNumber(amount)}`;
    }

    function buildDiscordCopyText() {
        if (!result?.configuredPieceResults?.length) {
            return 'No charm upgrades configured yet.';
        }

        const lines = [];

        for (const pieceResult of result.configuredPieceResults) {
            lines.push(`- ${pieceResult.slotLabel} ${pieceResult.gemLabel} (Lv${pieceResult.currentLevel} → Lv${pieceResult.targetLevel})`);

            for (const [material, amount] of Object.entries(pieceResult.materialsTotal)) {
                if (amount > 0) {
                    lines.push(formatDiscordCopyLine(formatMaterialName(material), amount));
                }
            }
        }

        lines.push('- Total');
        for (const [material, amount] of Object.entries(result.materialsTotal)) {
            if (amount > 0) {
                lines.push(formatDiscordCopyLine(formatMaterialName(material), amount));
            }
        }

        return lines.join('\n');
    }

    async function copyDiscordBreakdown() {
        try {
            await navigator.clipboard.writeText(buildDiscordCopyText());
            showToast('Upgrade cost copied', 'success');
        } catch (error) {
            showToast('Failed to copy upgrade cost', 'error');
        }
    }

    async function loadData() {
        isLoading = true;

        try {
            const rawData = await apiFetch('/api/calculators/chief-gear-charms');
            if (!rawData) return;

            calculatorData = loadCalculatorData(rawData);
            buildInitialSlotSelections();
            updateCalculatedResult();
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    onMount(loadData);
</script>

<div class="chief-calc">
    <div class="chief-panel chief-left-panel">
        <div class="chief-panel-header">
            <div>
                <h3 class="chief-panel-title">Chief Charms</h3>
                <p class="chief-panel-copy">Click a charm piece, choose its current level, then choose its target level.</p>
            </div>
        </div>

        <div class="chief-profile-shell">
            <div class="charm-column left-column">
                {#each SLOT_POSITIONS.filter((slot) => slot.side === 'left') as slot, groupIndex (slot.id)}
                    <button
                        type="button"
                        class="charm-piece-card"
                        class:is-active-slot={slot.id === activeSlotId}
                        aria-label={`Select ${slot.label} charm`}
                        onclick={() => selectSlot(slot.id)}
                    >
                        <div class="charm-piece-image-wrap">
                            <div class="charm-gem-triangle" data-count={getSlotSelection(slot.id).gems.length}>
                                {#each getSlotSelection(slot.id).gems as gem, gemIndex (gemIndex)}
                                    <img
                                        class="charm-piece-image"
                                        src={getCharmImage(slot.family, getDisplayedLevel(slot.id, gemIndex))}
                                        alt=""
                                        aria-hidden="true"
                                    />
                                {/each}
                            </div>
                        </div>
                    </button>
                {/each}
            </div>

            <div class="chief-profile-card">
                <div class="chief-profile-portrait">
                    <img class="chief-portrait-image" src={CHIEF_PORTRAIT_IMAGE} alt="Jeronimo" />
                </div>

                <div class="active-gem-rail" aria-label={`${activeSlot.label} gems`}>
                    {#each getSlotSelection(activeSlot.id).gems as gem, gemIndex (gemIndex)}
                        <button
                            type="button"
                            class="active-gem-card"
                            onclick={() => openLevelPicker(activeSlot.id, gemIndex)}
                            aria-label={`Open ${activeSlot.label} gem ${gemIndex + 1} level picker`}
                        >
                            <img
                                class="active-gem-image"
                                src={getCharmImage(activeSlot.family, getDisplayedLevel(activeSlot.id, gemIndex))}
                                alt=""
                                aria-hidden="true"
                            />
                            <span class="active-gem-label">Gem {gemIndex + 1}</span>
                            <span class="active-gem-level">Lv{gem.currentLevel} → Lv{gem.targetLevel}</span>
                        </button>
                    {/each}
                </div>
            </div>

            <div class="charm-column right-column">
                {#each SLOT_POSITIONS.filter((slot) => slot.side === 'right') as slot, groupIndex (slot.id)}
                    <button
                        type="button"
                        class="charm-piece-card"
                        class:is-active-slot={slot.id === activeSlotId}
                        aria-label={`Select ${slot.label} charm`}
                        onclick={() => selectSlot(slot.id)}
                    >
                        <div class="charm-piece-image-wrap">
                            <div class="charm-gem-triangle" data-count={getSlotSelection(slot.id).gems.length}>
                                {#each getSlotSelection(slot.id).gems as gem, gemIndex (gemIndex)}
                                    <img
                                        class="charm-piece-image"
                                        src={getCharmImage(slot.family, getDisplayedLevel(slot.id, gemIndex))}
                                        alt=""
                                        aria-hidden="true"
                                    />
                                {/each}
                            </div>
                        </div>
                    </button>
                {/each}
            </div>
        </div>
    </div>

    <div class="chief-panel chief-right-panel">
        <div class="results-head">
            <div>
                <h3 class="chief-panel-title">Upgrade Cost</h3>
            </div>
            <button type="button" class="copy-cost-btn" onclick={copyDiscordBreakdown}>Copy</button>
        </div>

        <div class="chief-right-scroll">
            {#if result}
                <div class="result-stats-grid">
                    <div class="result-stat-card">
                        <span class="result-stat-label">Total Power</span>
                        <span class="result-stat-value">{formatNumber(result.power.increaseTotal)}</span>
                    </div>
                    <div class="result-stat-card">
                        <span class="result-stat-label">Total Stat Increase</span>
                        <span class="result-stat-value">{formatNumber(result.stats.increasePct)}%</span>
                    </div>
                    <div class="result-stat-card">
                        <span class="result-stat-label">Charm Count</span>
                        <span class="result-stat-value">{formatNumber(result.totalCharmCount)}</span>
                    </div>
                </div>

                <div class="piece-breakdown-section">
                    {#each result.configuredPieceResults as pieceResult (pieceResult.slotId)}
                        <div class="piece-breakdown-card">
                            <div class="piece-breakdown-head">
                                <span class="piece-breakdown-title">{pieceResult.slotLabel}</span>
                                <span class="piece-breakdown-path">{pieceResult.gemLabel} • Lv{pieceResult.currentLevel} → Lv{pieceResult.targetLevel}</span>
                            </div>

                            <div class="piece-breakdown-materials">
                                {#each Object.entries(pieceResult.materialsTotal) as [material, amount] (material)}
                                    {#if amount > 0}
                                        <div class="piece-inline-material">
                                            {#if getResourceImage(material)}
                                                <img class="piece-inline-material-icon" src={getResourceImage(material)} alt={formatMaterialName(material)} />
                                            {/if}
                                            <span class="material-value">{formatNumber(amount)}</span>
                                        </div>
                                    {/if}
                                {/each}
                            </div>
                        </div>
                    {/each}
                </div>

                <div class="materials-section">
                    {#each Object.entries(result.materialsTotal) as [material, amount] (material)}
                        {#if amount > 0}
                            <div class="total-inline-material">
                                {#if getResourceImage(material)}
                                    <img class="material-row-icon" src={getResourceImage(material)} alt={formatMaterialName(material)} />
                                {/if}
                                <span class="material-value">{formatNumber(amount)}</span>
                            </div>
                        {/if}
                    {/each}
                </div>
            {:else}
                <div class="chief-placeholder">
                    <div class="placeholder-title">No calculation yet</div>
                    <p class="placeholder-copy">Pick a charm piece and choose its current and target levels to see the material totals.</p>
                </div>
            {/if}
        </div>
    </div>

    {#if levelPicker.slotId}
        <div use:portal class="level-picker-backdrop" role="presentation" onclick={handleLevelPickerBackdropClick}>
            <div class="level-picker-modal" role="dialog" aria-modal="true" aria-label="Charm level picker" tabindex="-1">
                <div class="level-picker-head">
                    <div>
                        <h4 class="level-picker-title">{pickerSlot?.label} gem {Number(levelPicker.gemIndex) + 1} {levelPicker.step === 'current' ? 'current level' : 'target level'}</h4>
                        <p class="level-picker-copy">
                            {#if levelPicker.step === 'current'}
                                Pick the current level for this gem.
                            {:else}
                                Pick the target level for this gem.
                            {/if}
                        </p>
                    </div>
                    <button type="button" class="level-picker-close" onclick={closeLevelPicker} aria-label="Close charm level picker">Close</button>
                </div>

                <div class="picker-progress">
                    <button
                        type="button"
                        class="picker-step-button"
                        class:picker-step-active={levelPicker.step === 'current'}
                        onclick={() => setLevelPickerStep('current')}
                    >
                        Current
                    </button>
                    <span class="picker-progress-divider"></span>
                    <button
                        type="button"
                        class="picker-step-button"
                        class:picker-step-active={levelPicker.step === 'target'}
                        onclick={() => setLevelPickerStep('target')}
                    >
                        Target
                    </button>
                </div>

                <div class="level-option-scroll">
                    <div class="level-option-grid">
                        {#each pickerLevelOptions as level (level.level)}
                            <button
                                type="button"
                                class="level-option-card"
                                class:is-selected={level.level === (levelPicker.step === 'current' ? Number(levelPicker.currentLevel) : Number(levelPicker.targetLevel))}
                                onclick={() => handleLevelOptionClick(level.level)}
                                aria-label={`${pickerSlot?.label || 'Charm'} level ${level.level}`}
                            >
                                {#if level.level === 0}
                                    <div class="level-base-tile">Base</div>
                                {:else}
                                    <img
                                        class="charm-piece-image picker-image picker-single-image"
                                        src={getCharmImage(pickerSlot?.family, level.level)}
                                        alt={`${pickerSlot?.label || 'Charm'} gem level ${level.level}`}
                                    />
                                {/if}
                                <div class="level-option-label">Lv{level.level}</div>
                            </button>
                        {/each}
                    </div>
                </div>
            </div>
        </div>
    {/if}
</div>

<style>
    .chief-calc {
        display: grid;
        grid-template-columns: minmax(340px, 1.02fr) minmax(320px, 0.98fr);
        gap: 20px;
        align-items: start;
    }

    .chief-panel {
        background:
            linear-gradient(180deg, var(--theme-panel-sheen-line), transparent),
            var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 18px;
        box-shadow:
            inset 0 1px 0 var(--theme-panel-sheen-soft),
            var(--shadow-sm);
    }

    .chief-panel-header,
    .results-head {
        display: flex;
        justify-content: space-between;
        gap: 16px;
        align-items: flex-start;
        flex-shrink: 0;
    }

    .chief-panel-title {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
        color: var(--color-text-primary);
    }

    .chief-panel-copy {
        margin: 6px 0 0;
        color: var(--color-text-secondary);
        font-size: 13px;
        max-width: 58ch;
    }

    .chief-profile-shell {
        display: grid;
        grid-template-columns: 108px minmax(0, 1fr) 108px;
        gap: 14px;
        align-items: center;
        min-height: 420px;
        padding: 18px;
        border-radius: var(--radius-lg);
        background:
            radial-gradient(circle at 50% 18%, rgba(234, 225, 255, 0.24), transparent 26%),
            linear-gradient(180deg, rgba(180, 168, 232, 0.11), transparent 70%),
            var(--theme-underlay-ink);
        border: 1px solid var(--theme-accent-cool-border-soft);
    }

    .charm-column {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    .charm-piece-card,
    .result-stat-card,
    .piece-breakdown-card {
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
    }

    .charm-piece-card {
        appearance: none;
        padding: 14px 12px;
        display: flex;
        flex-direction: column;
        gap: 12px;
        min-height: 126px;
        justify-content: center;
        cursor: pointer;
        transition: transform 0.16s var(--ease-out), border-color 0.16s var(--ease-out), opacity 0.16s var(--ease-out);
        opacity: 0.78;
    }

    .charm-piece-card:hover,
    .charm-piece-card.is-active-slot {
        transform: translateY(-1px);
        border-color: var(--color-border-accent);
        opacity: 1;
    }

    .charm-piece-image-wrap {
        display: grid;
        place-items: center;
        min-height: 74px;
    }

    .charm-gem-triangle {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        grid-template-areas:
            "top top"
            "left right";
        justify-items: center;
        align-items: center;
        row-gap: 2px;
        column-gap: 6px;
    }

    .charm-gem-triangle :global(img:nth-child(1)) {
        grid-area: top;
    }

    .charm-gem-triangle :global(img:nth-child(2)) {
        grid-area: left;
    }

    .charm-gem-triangle :global(img:nth-child(3)) {
        grid-area: right;
    }

    .charm-gem-triangle[data-count='1'] {
        grid-template-columns: 1fr;
        grid-template-areas: "top";
    }

    .charm-gem-triangle[data-count='2'] {
        grid-template-columns: repeat(2, 1fr);
        grid-template-areas: "left right";
        column-gap: 10px;
    }

    .charm-piece-image {
        width: auto;
        max-width: 100%;
        height: 34px;
        object-fit: contain;
        display: block;
        filter: drop-shadow(0 8px 14px rgba(0, 0, 0, 0.22));
    }

    .chief-profile-card {
        min-height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 14px;
    }

    .chief-profile-portrait {
        position: relative;
        width: min(100%, 240px);
        display: grid;
        place-items: center;
        aspect-ratio: 0.82;
        background: transparent;
    }

    .chief-portrait-image {
        width: 100%;
        height: 100%;
        object-fit: contain;
        object-position: center bottom;
        display: block;
        filter: drop-shadow(0 18px 28px rgba(0, 0, 0, 0.28));
    }

    .active-gem-rail {
        width: min(100%, 260px);
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
    }

    .active-gem-card {
        appearance: none;
        min-height: 110px;
        padding: 12px 8px;
        border-radius: 18px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        background: rgba(10, 16, 34, 0.42);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 8px;
        cursor: pointer;
        transition: transform 0.16s var(--ease-out), border-color 0.16s var(--ease-out), background 0.16s var(--ease-out);
    }

    .active-gem-card:hover {
        transform: translateY(-1px);
        border-color: rgba(100, 190, 255, 0.24);
        background: rgba(24, 42, 74, 0.72);
    }

    .active-gem-image {
        height: 30px;
        object-fit: contain;
        filter: drop-shadow(0 8px 14px rgba(0, 0, 0, 0.22));
    }

    .active-gem-label {
        color: var(--color-text-primary);
        font-size: 11px;
        font-weight: 700;
    }

    .active-gem-level {
        color: var(--color-text-secondary);
        font-size: 10px;
        font-weight: 700;
        line-height: 1.35;
        text-align: center;
    }

    .chief-right-panel {
        position: sticky;
        top: 16px;
        max-height: calc(100dvh - 32px);
        overflow: hidden;
    }

    .chief-right-scroll {
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        overflow-x: hidden;
        padding-right: 4px;
        scrollbar-gutter: stable;
    }

    .chief-right-scroll::-webkit-scrollbar,
    .level-option-scroll::-webkit-scrollbar,
    .piece-breakdown-section::-webkit-scrollbar {
        width: 8px;
    }

    .chief-right-scroll::-webkit-scrollbar-track,
    .level-option-scroll::-webkit-scrollbar-track,
    .piece-breakdown-section::-webkit-scrollbar-track {
        background: transparent;
    }

    .chief-right-scroll::-webkit-scrollbar-thumb,
    .level-option-scroll::-webkit-scrollbar-thumb,
    .piece-breakdown-section::-webkit-scrollbar-thumb {
        background: rgba(122, 151, 202, 0.42);
        border-radius: 999px;
    }

    .result-stats-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
    }

    .copy-cost-btn {
        min-height: 34px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        font: inherit;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        transition: transform 0.16s var(--ease-out), border-color 0.16s var(--ease-out);
    }

    .copy-cost-btn:hover {
        transform: translateY(-1px);
        border-color: var(--color-border-accent);
    }

    .result-stat-card {
        padding: 14px;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .result-stat-label {
        color: var(--color-text-muted);
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .result-stat-value {
        color: var(--color-text-primary);
        font-size: 18px;
        font-weight: 800;
        font-variant-numeric: tabular-nums;
    }

    .piece-breakdown-section {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin: 12px 0;
        max-height: 332px;
        overflow-y: auto;
        overflow-x: hidden;
        padding-right: 4px;
        scrollbar-gutter: stable;
    }

    .piece-breakdown-card {
        padding: 14px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .piece-breakdown-head {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        align-items: flex-start;
    }

    .piece-breakdown-title {
        color: var(--color-text-primary);
        font-size: 13px;
        font-weight: 700;
    }

    .piece-breakdown-path {
        color: var(--color-text-secondary);
        font-size: 12px;
        text-align: right;
    }

    .piece-breakdown-materials {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 8px;
    }

    .piece-inline-material,
    .total-inline-material {
        min-height: 34px;
        padding: 0 10px;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.06);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
    }

    .piece-inline-material-icon,
    .material-row-icon {
        width: 16px;
        height: 16px;
        object-fit: contain;
        flex-shrink: 0;
    }

    .materials-section {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 8px;
        margin-top: 12px;
    }

    .material-value {
        color: var(--color-text-primary);
        font-weight: 700;
        font-variant-numeric: tabular-nums;
        font-size: 12px;
    }

    .chief-placeholder {
        padding: 22px 18px;
        text-align: center;
        display: flex;
        flex-direction: column;
        gap: 8px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
    }

    .placeholder-title {
        color: var(--color-text-primary);
        font-size: 15px;
        font-weight: 700;
    }

    .placeholder-copy {
        margin: 0;
        color: var(--color-text-secondary);
        font-size: 13px;
    }

    .level-picker-backdrop {
        position: fixed;
        inset: 0;
        z-index: 60;
        background: rgba(6, 10, 24, 0.56);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        overflow: auto;
    }

    .level-picker-modal {
        width: min(760px, calc(100vw - 40px));
        max-height: min(84vh, 860px);
        margin: auto;
        padding: 18px;
        border-radius: var(--radius-lg);
        border: 1px solid var(--color-border);
        background:
            linear-gradient(180deg, var(--theme-panel-sheen-line), transparent),
            var(--color-card);
        box-shadow:
            inset 0 1px 0 var(--theme-panel-sheen-soft),
            var(--shadow-lg);
        display: flex;
        flex-direction: column;
        gap: 16px;
        overflow: hidden;
    }

    .level-picker-head {
        display: flex;
        justify-content: space-between;
        gap: 16px;
        align-items: flex-start;
    }

    .level-picker-title {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
        color: var(--color-text-primary);
        text-transform: capitalize;
    }

    .level-picker-copy {
        margin: 6px 0 0;
        color: var(--color-text-secondary);
        font-size: 13px;
    }

    .level-picker-close,
    .picker-step-button {
        appearance: none;
        font: inherit;
    }

    .level-picker-close {
        min-height: 36px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        cursor: pointer;
    }

    .picker-progress {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .picker-step-button {
        border: none;
        background: transparent;
        padding: 0;
        color: var(--color-text-muted);
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        cursor: pointer;
    }

    .picker-step-active {
        color: var(--color-text-primary);
    }

    .picker-progress-divider {
        width: 44px;
        height: 1px;
        background: var(--color-border);
    }

    .level-option-scroll {
        flex: 1;
        min-height: 0;
        overflow: auto;
        overflow-x: hidden;
        padding-top: 6px;
        padding-right: 4px;
        scrollbar-gutter: stable;
    }

    .level-option-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(92px, 1fr));
        gap: 12px;
    }

    .level-option-card {
        appearance: none;
        min-height: 110px;
        padding: 10px;
        border-radius: 18px;
        border: none;
        background: rgba(10, 16, 34, 0.46);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 8px;
        cursor: pointer;
        transition: transform 0.16s var(--ease-out), background 0.16s var(--ease-out), box-shadow 0.16s var(--ease-out);
    }

    .level-option-card:hover,
    .level-option-card.is-selected {
        transform: translateY(-1px);
        background: rgba(24, 42, 74, 0.76);
        box-shadow: inset 0 0 0 1px rgba(100, 190, 255, 0.16);
    }

    .picker-image {
        height: 26px;
    }

    .picker-single-image {
        height: 40px;
    }

    .level-base-tile {
        width: 68px;
        height: 58px;
        border-radius: 16px;
        display: grid;
        place-items: center;
        background: rgba(255, 255, 255, 0.05);
        color: var(--color-text-primary);
        font-size: 12px;
        font-weight: 700;
    }

    .level-option-label {
        color: var(--color-text-secondary);
        font-size: 12px;
        font-weight: 700;
    }

    @media (max-width: 1100px) {
        .chief-calc,
        .result-stats-grid {
            grid-template-columns: 1fr;
        }

        .chief-profile-shell {
            grid-template-columns: 1fr;
            min-height: 0;
        }

        .charm-column {
            flex-direction: row;
            overflow-x: auto;
            padding-bottom: 4px;
            scrollbar-width: none;
            -ms-overflow-style: none;
            gap: 12px;
        }

        .charm-column::-webkit-scrollbar {
            display: none;
        }

        .charm-piece-card {
            min-width: 136px;
            min-height: 140px;
            padding: 16px 14px;
        }

        .charm-piece-image-wrap {
            min-height: 88px;
        }

        .charm-piece-image {
            height: 40px;
        }

        .active-gem-rail {
            width: 100%;
        }

        .chief-right-panel {
            position: static;
            max-height: none;
        }

        .chief-right-scroll,
        .piece-breakdown-section {
            overflow: visible;
            max-height: none;
            padding-right: 0;
        }

        .piece-breakdown-materials,
        .materials-section {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .active-gem-rail {
            grid-template-columns: repeat(3, minmax(86px, 1fr));
        }
    }
</style>
