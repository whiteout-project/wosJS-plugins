<script>
    import { onMount } from 'svelte';
    import { apiFetch, getBasePath } from '../../lib/api.js';
    import { showToast } from '../../lib/utils.js';
    import { calculateMultipleGearUpgrades } from '../../lib/calculators/chiefGearCalculator.js';
    import { formatMaterialName, formatNumber, loadCalculatorData } from '../../lib/calculators/calculatorData.js';

    const SLOT_POSITIONS = [
        { id: 'hat', side: 'left', assetKey: 'hat', label: 'Lancer' },
        { id: 'coat', side: 'left', assetKey: 'coat', label: 'Infantry' },
        { id: 'ring', side: 'left', assetKey: 'ring', label: 'Marksman' },
        { id: 'clock', side: 'right', assetKey: 'clock', label: 'Lancer' },
        { id: 'pants', side: 'right', assetKey: 'pants', label: 'Infantry' },
        { id: 'staff', side: 'right', assetKey: 'staff', label: 'Marksman' },
    ];
    const CHIEF_GEAR_IMAGE_BASE = getBasePath() + '/images/calculators/chief_gear';
    const CHIEF_PORTRAIT_IMAGE = `${CHIEF_GEAR_IMAGE_BASE}/Jeronimo_Full.png`;
    const RESOURCE_IMAGE_BASE = getBasePath() + '/images/calculators/resources';
    const RESOURCE_IMAGE_MAP = {
        hardenedAlloy: 'Hardened_Alloy.png',
        polishingSolution: 'Polishing_Solution.png',
        designPlan: 'Design_Plans.png',
        lunarAmber: 'Lunar_Amber.png',
    };

    let isLoading = $state(false);
    let calculatorData = $state(null);
    let result = $state(null);
    let activeSlotId = $state(SLOT_POSITIONS[0].id);
    let slotSelections = $state({});
    let stagePicker = $state({
        slotId: null,
        step: 'current',
        currentValue: '',
        targetValue: '',
    });

    let gearStages = $derived(calculatorData?.gearStages ?? []);
    let activeSlot = $derived(SLOT_POSITIONS.find((slot) => slot.id === activeSlotId) ?? SLOT_POSITIONS[0]);
    let pickerSlot = $derived(SLOT_POSITIONS.find((slot) => slot.id === stagePicker.slotId) ?? null);
    let pickerCurrentIndex = $derived(getStageIndexById(stagePicker.currentValue));
    let pickerStageOptions = $derived(
        gearStages.filter((stage) => {
            const stageIndex = getStageIndexById(stage.id);
            if (stagePicker.step === 'current') {
                return stageIndex < gearStages.length - 1;
            }

            return stageIndex > pickerCurrentIndex;
        })
    );

    function portal(node) {
        document.body.appendChild(node);
        return {
            destroy() {
                node.remove();
            }
        };
    }

    function getDefaultSelection() {
        const firstStage = gearStages[0];
        if (!firstStage) return null;

        return {
            currentId: firstStage.id,
            targetId: firstStage.id,
        };
    }

    function buildInitialSlotSelections() {
        const defaultSelection = getDefaultSelection();
        if (!defaultSelection) return;

        slotSelections = Object.fromEntries(
            SLOT_POSITIONS.map((slot) => [
                slot.id,
                { ...defaultSelection },
            ])
        );
    }

    function resetResult() {
        result = null;
    }

    function buildGearUpgradeEntries() {
        return SLOT_POSITIONS.map((slot) => {
            const selection = getSlotSelection(slot.id);
            const currentStage = getStageById(selection?.currentId);
            const targetStage = getStageById(selection?.targetId);

            return {
                slotId: slot.id,
                slotLabel: slot.label,
                current: getStageSelection(currentStage),
                target: getStageSelection(targetStage),
            };
        });
    }

    function updateCalculatedResult() {
        if (!calculatorData) return;

        result = calculateMultipleGearUpgrades(
            calculatorData,
            buildGearUpgradeEntries()
        );
    }

    function getStageIndexById(stageId) {
        return gearStages.findIndex((stage) => stage.id === stageId);
    }

    function getStageById(stageId) {
        return gearStages.find((stage) => stage.id === stageId) ?? null;
    }

    function getStageSelection(stage) {
        if (!stage) return { quality: '', tier: '', star: '' };
        return {
            quality: stage.quality,
            tier: String(stage.tier),
            star: String(stage.star),
        };
    }

    function getStageLevelNumber(stageId) {
        const index = getStageIndexById(stageId);
        return index >= 0 ? index + 1 : 0;
    }

    function getSlotImage(assetKey, stageId) {
        const level = getStageLevelNumber(stageId);
        if (!assetKey || level <= 0) return '';
        return `${CHIEF_GEAR_IMAGE_BASE}/${assetKey}-level-${String(level).padStart(2, '0')}.png`;
    }

    function getSlotSelection(slotId) {
        return slotSelections[slotId] ?? getDefaultSelection();
    }

    function getResourceImage(materialKey) {
        const fileName = RESOURCE_IMAGE_MAP[materialKey];
        return fileName ? `${RESOURCE_IMAGE_BASE}/${fileName}` : '';
    }

    function getDisplayedStageId(slotId) {
        return getSlotSelection(slotId)?.targetId || getSlotSelection(slotId)?.currentId || '';
    }

    function formatStageBadge(stage) {
        if (!stage) return 'Not selected';
        const starLabel = stage.star === 0 ? 'Base' : `${stage.star}★`;
        return `${formatMaterialName(stage.quality)} T${stage.tier} ${starLabel}`;
    }

    function formatCompactStageLabel(stageId) {
        const stage = getStageById(stageId);
        if (!stage) return 'Not selected';
        return stage.star === 0 ? `T${stage.tier} Base` : `T${stage.tier} ${stage.star}★`;
    }

    function openStagePicker(slotId) {
        const selection = getSlotSelection(slotId);
        if (!selection) return;

        activeSlotId = slotId;
        stagePicker = {
            slotId,
            step: 'current',
            currentValue: selection.currentId,
            targetValue: selection.targetId,
        };
    }

    function closeStagePicker() {
        stagePicker = {
            slotId: null,
            step: 'current',
            currentValue: '',
            targetValue: '',
        };
    }

    function handleStageOptionClick(stageId) {
        if (!stagePicker.slotId) return;

        if (stagePicker.step === 'current') {
            const currentIndex = getStageIndexById(stageId);
            const targetIndex = getStageIndexById(stagePicker.targetValue);
            const nextTargetValue = targetIndex >= currentIndex ? stagePicker.targetValue : stageId;

            slotSelections = {
                ...slotSelections,
                [stagePicker.slotId]: {
                    currentId: stageId,
                    targetId: nextTargetValue,
                },
            };

            stagePicker = {
                ...stagePicker,
                step: 'target',
                currentValue: stageId,
                targetValue: nextTargetValue,
            };
            updateCalculatedResult();
            return;
        }

        slotSelections = {
            ...slotSelections,
            [stagePicker.slotId]: {
                currentId: stagePicker.currentValue,
                targetId: stageId,
            },
        };

        activeSlotId = stagePicker.slotId;
        updateCalculatedResult();
        closeStagePicker();
    }

    function handleStagePickerBackdropClick(event) {
        if (event.target === event.currentTarget) {
            closeStagePicker();
        }
    }

    function setStagePickerStep(step) {
        if (step !== 'current' && step !== 'target') return;
        stagePicker = { ...stagePicker, step };
    }

    function formatDiscordCopyLine(label, amount) {
        return `  - ${label}: ${formatNumber(amount)}`;
    }

    function buildDiscordCopyText() {
        if (!result?.configuredGearResults?.length) {
            return 'No gear upgrades configured yet.';
        }

        const lines = [];

        for (const gearResult of result.configuredGearResults) {
            lines.push(`- ${gearResult.slotLabel} (${formatStageBadge(gearResult.current)} → ${formatStageBadge(gearResult.target)})`);

            for (const [material, amount] of Object.entries(gearResult.materialsPerItem)) {
                if (amount > 0) {
                    lines.push(formatDiscordCopyLine(formatMaterialName(material), amount));
                }
            }
        }

        lines.push('- Total');
        for (const [material, amount] of Object.entries(result.materialsTotal)) {
            if (amount > 0) {
                lines.push(formatDiscordCopyLine(formatMaterialName(material), amount));
            }
        }

        return lines.join('\n');
    }

    async function copyDiscordBreakdown() {
        try {
            await navigator.clipboard.writeText(buildDiscordCopyText());
            showToast('Upgrade cost copied', 'success');
        } catch (error) {
            showToast('Failed to copy upgrade cost', 'error');
        }
    }

    function calculate() {
        if (!calculatorData) {
            showToast('Chief Gear data is still loading', 'info');
            return;
        }

        try {
            updateCalculatedResult();
        } catch (error) {
            result = null;
            showToast(error.message, 'error');
        }
    }

    async function loadData() {
        isLoading = true;

        try {
            const rawData = await apiFetch('/api/calculators/chief-gear-charms');
            if (!rawData) return;

            calculatorData = loadCalculatorData(rawData);
            buildInitialSlotSelections();
            updateCalculatedResult();
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    onMount(loadData);
</script>

<div class="chief-calc">
    <div class="chief-panel chief-left-panel">
        <div class="chief-panel-header">
            <div>
                <h3 class="chief-panel-title">Chief Gear</h3>
                <p class="chief-panel-copy">Pick a gear piece, choose its current stage, then choose its target stage.</p>
            </div>
        </div>

        <div class="chief-profile-shell">
            <div class="gear-slot-column left-column">
                {#each SLOT_POSITIONS.filter((slot) => slot.side === 'left') as slot (slot.id)}
                    <button
                        type="button"
                        class="gear-slot-card gear-slot-button"
                        class:is-active-slot={slot.id === activeSlotId}
                        onclick={() => openStagePicker(slot.id)}
                    >
                        <div class="gear-slot-icon">
                            {#if getSlotImage(slot.assetKey, getDisplayedStageId(slot.id))}
                                <img class="gear-slot-image" src={getSlotImage(slot.assetKey, getDisplayedStageId(slot.id))} alt={slot.label} />
                            {:else}
                                <span>{slot.label}</span>
                            {/if}
                        </div>
                        <div class="gear-slot-stage">{formatCompactStageLabel(getSlotSelection(slot.id)?.currentId)} → {formatCompactStageLabel(getSlotSelection(slot.id)?.targetId)}</div>
                    </button>
                {/each}
            </div>

            <div class="chief-profile-card">
                <div class="chief-profile-portrait">
                    <img class="chief-portrait-image" src={CHIEF_PORTRAIT_IMAGE} alt="Jeronimo" />
                </div>
            </div>

            <div class="gear-slot-column right-column">
                {#each SLOT_POSITIONS.filter((slot) => slot.side === 'right') as slot (slot.id)}
                    <button
                        type="button"
                        class="gear-slot-card gear-slot-button"
                        class:is-active-slot={slot.id === activeSlotId}
                        onclick={() => openStagePicker(slot.id)}
                    >
                        <div class="gear-slot-icon">
                            {#if getSlotImage(slot.assetKey, getDisplayedStageId(slot.id))}
                                <img class="gear-slot-image" src={getSlotImage(slot.assetKey, getDisplayedStageId(slot.id))} alt={slot.label} />
                            {:else}
                                <span>{slot.label}</span>
                            {/if}
                        </div>
                        <div class="gear-slot-stage">{formatCompactStageLabel(getSlotSelection(slot.id)?.currentId)} → {formatCompactStageLabel(getSlotSelection(slot.id)?.targetId)}</div>
                    </button>
                {/each}
            </div>
        </div>

    </div>

    <div class="chief-panel chief-right-panel">
        <div class="results-head">
            <div>
                <h3 class="chief-panel-title">Upgrade Cost</h3>
            </div>
            <button type="button" class="copy-cost-btn" onclick={copyDiscordBreakdown}>Copy</button>
        </div>

        <div class="chief-right-scroll">
            {#if result}
                <div class="result-stats-grid">
                    <div class="result-stat-card">
                        <span class="result-stat-label">Total Power</span>
                        <span class="result-stat-value">{formatNumber(result.power.increaseTotal)}</span>
                    </div>
                    <div class="result-stat-card">
                        <span class="result-stat-label">Total Stat Increase</span>
                        <span class="result-stat-value">{formatNumber(result.stats.increasePct)}%</span>
                    </div>
                    <div class="result-stat-card">
                        <span class="result-stat-label">Total Deployment</span>
                        <span class="result-stat-value">{formatNumber(result.deploymentCapacity.increaseTotal)}</span>
                    </div>
                </div>

                {#if result.configuredGearResults.length > 0}
                    <div class="gear-breakdown-section">
                        {#each result.configuredGearResults as gearResult (gearResult.slotId)}
                            <div class="gear-breakdown-card">
                                <div class="gear-breakdown-head">
                                    <span class="gear-breakdown-title">{gearResult.slotLabel}</span>
                                    <span class="gear-breakdown-path">{formatStageBadge(gearResult.current)} → {formatStageBadge(gearResult.target)}</span>
                                </div>

                                <div class="gear-breakdown-materials">
                                    {#each Object.entries(gearResult.materialsPerItem) as [material, amount] (material)}
                                        {#if amount > 0}
                                            <div class="gear-inline-material">
                                                {#if getResourceImage(material)}
                                                    <img class="gear-inline-material-icon" src={getResourceImage(material)} alt={formatMaterialName(material)} />
                                                {/if}
                                                <span class="material-value">{formatNumber(amount)}</span>
                                            </div>
                                        {/if}
                                    {/each}
                                </div>
                            </div>
                        {/each}
                    </div>
                {/if}

                <div class="materials-section">
                    {#each Object.entries(result.materialsTotal) as [material, amount] (material)}
                        {#if amount > 0}
                            <div class="total-inline-material">
                                <span class="material-name-group">
                                    {#if getResourceImage(material)}
                                        <img class="material-row-icon" src={getResourceImage(material)} alt={formatMaterialName(material)} />
                                    {/if}
                                </span>
                                <span class="material-value">{formatNumber(amount)}</span>
                            </div>
                        {/if}
                    {/each}
                </div>
            {:else}
                <div class="chief-placeholder">
                    <div class="placeholder-title">No calculation yet</div>
                    <p class="placeholder-copy">Pick one gear piece on the left, choose its current and target stage, then calculate to see the exact material totals.</p>
                </div>
            {/if}
        </div>
    </div>

    {#if stagePicker.slotId}
        <div use:portal class="stage-picker-backdrop" role="presentation" onclick={handleStagePickerBackdropClick}>
            <div class="stage-picker-modal" role="dialog" aria-modal="true" aria-label="Stage picker" tabindex="-1">
                <div class="stage-picker-head">
                    <div>
                        <h4 class="stage-picker-title">{pickerSlot?.label} {stagePicker.step === 'current' ? 'current stage' : 'target stage'}</h4>
                        <p class="stage-picker-copy">
                            {#if stagePicker.step === 'current'}
                                Pick the current image first.
                            {:else}
                                Pick the target image next.
                            {/if}
                        </p>
                    </div>
                    <button type="button" class="stage-picker-close" onclick={closeStagePicker} aria-label="Close stage picker">Close</button>
                </div>

                <div class="picker-progress">
                    <button
                        type="button"
                        class="picker-step-button"
                        class:picker-step-active={stagePicker.step === 'current'}
                        onclick={() => setStagePickerStep('current')}
                    >
                        Current
                    </button>
                    <span class="picker-progress-divider"></span>
                    <button
                        type="button"
                        class="picker-step-button"
                        class:picker-step-active={stagePicker.step === 'target'}
                        onclick={() => setStagePickerStep('target')}
                    >
                        Target
                    </button>
                </div>

                <div class="stage-option-scroll">
                    <div class="stage-option-grid">
                        {#each pickerStageOptions as stage (stage.id)}
                            <button
                                type="button"
                                class="stage-option-card"
                                class:is-selected={stage.id === (stagePicker.step === 'current' ? stagePicker.currentValue : stagePicker.targetValue)}
                                onclick={() => handleStageOptionClick(stage.id)}
                                aria-label={`${pickerSlot?.label || 'Gear'} ${formatMaterialName(stage.quality)} tier ${stage.tier} ${stage.star === 0 ? 'base' : `${stage.star} star`}`}
                            >
                                <img
                                    class="stage-option-image"
                                    src={getSlotImage(pickerSlot?.assetKey, stage.id)}
                                    alt={`${pickerSlot?.label || 'Gear'} stage`}
                                />
                            </button>
                        {/each}
                    </div>
                </div>
            </div>
        </div>
    {/if}
</div>

<style>
    .chief-calc {
        display: grid;
        grid-template-columns: minmax(340px, 1.02fr) minmax(320px, 0.98fr);
        gap: 20px;
        align-items: start;
    }

    .chief-panel {
        background:
            linear-gradient(180deg, var(--theme-panel-sheen-line), transparent),
            var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 18px;
        box-shadow:
            inset 0 1px 0 var(--theme-panel-sheen-soft),
            var(--shadow-sm);
    }

    .chief-panel-title {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
        color: var(--color-text-primary);
    }

    .chief-panel-copy {
        margin: 6px 0 0;
        color: var(--color-text-secondary);
        font-size: 13px;
        max-width: 58ch;
    }

    .chief-profile-shell {
        display: grid;
        grid-template-columns: 108px minmax(0, 1fr) 108px;
        gap: 14px;
        align-items: center;
        min-height: 420px;
        padding: 18px;
        border-radius: var(--radius-lg);
        background:
            radial-gradient(circle at 50% 18%, rgba(234, 225, 255, 0.24), transparent 26%),
            linear-gradient(180deg, rgba(180, 168, 232, 0.11), transparent 70%),
            var(--theme-underlay-ink);
        border: 1px solid var(--theme-accent-cool-border-soft);
    }

    .gear-slot-column {
        display: flex;
        flex-direction: column;
        gap: 18px;
        align-items: stretch;
    }

    .gear-slot-card,
    .stage-option-card,
    .stage-picker-close {
        appearance: none;
        font: inherit;
    }

    .gear-slot-card {
        min-height: 108px;
        padding: 0;
        border: none;
        background: transparent;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        color: var(--color-text-primary);
        opacity: 0.72;
        cursor: pointer;
        transition: opacity 0.16s var(--ease-out), transform 0.16s var(--ease-out);
    }

    .gear-slot-card:hover,
    .gear-slot-card.is-active-slot {
        opacity: 1;
        transform: translateY(-1px);
    }

    .gear-slot-icon {
        min-height: 0;
        display: grid;
        place-items: center;
        background: transparent;
        padding: 0;
        overflow: hidden;
    }

    .gear-slot-image {
        width: auto;
        max-width: 100%;
        height: 76px;
        object-fit: contain;
        display: block;
        filter: drop-shadow(0 8px 14px rgba(0, 0, 0, 0.22));
    }

    .gear-slot-stage {
        font-size: 10px;
        font-weight: 700;
        text-align: center;
        color: var(--color-text-muted);
        line-height: 1.35;
    }

    .chief-profile-card {
        min-height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .chief-profile-portrait {
        position: relative;
        width: min(100%, 240px);
        aspect-ratio: 0.82;
        display: grid;
        place-items: center;
        background: transparent;
    }

    .chief-portrait-image {
        width: 100%;
        height: 100%;
        object-fit: contain;
        object-position: center bottom;
        display: block;
        filter: drop-shadow(0 18px 28px rgba(0, 0, 0, 0.28));
    }

    .results-head {
        display: flex;
        justify-content: space-between;
        gap: 16px;
        align-items: flex-start;
        flex-shrink: 0;
    }

    .chief-right-panel {
        position: sticky;
        top: 16px;
        max-height: calc(100dvh - 32px);
        overflow: hidden;
    }

    .chief-right-scroll {
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        overflow-x: hidden;
        padding-right: 4px;
        scrollbar-gutter: stable;
    }

    .chief-right-scroll::-webkit-scrollbar {
        width: 8px;
    }

    .chief-right-scroll::-webkit-scrollbar-track {
        background: transparent;
    }

    .chief-right-scroll::-webkit-scrollbar-thumb {
        background: rgba(122, 151, 202, 0.42);
        border-radius: 999px;
    }

    .copy-cost-btn {
        min-height: 34px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        font: inherit;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        transition: transform 0.16s var(--ease-out), border-color 0.16s var(--ease-out);
    }

    .copy-cost-btn:hover {
        transform: translateY(-1px);
        border-color: var(--color-border-accent);
    }

    .chief-placeholder,
    .result-stat-card {
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
    }

    .result-stats-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
    }

    .result-stat-card {
        padding: 14px;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .result-stat-label {
        color: var(--color-text-muted);
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .result-stat-value {
        color: var(--color-text-primary);
        font-size: 18px;
        font-weight: 800;
        font-variant-numeric: tabular-nums;
    }

    .materials-section {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        margin-top: 12px;
    }

    .gear-breakdown-section {
        display: flex;
        flex-direction: column;
        gap: 10px;
        max-height: 316px;
        overflow-y: auto;
        overflow-x: hidden;
        margin: 12px 0;
        padding: 2px 4px 2px 0;
        padding-right: 4px;
        scrollbar-gutter: stable;
    }

    .gear-breakdown-section::-webkit-scrollbar {
        width: 8px;
    }

    .gear-breakdown-section::-webkit-scrollbar-track {
        background: transparent;
    }

    .gear-breakdown-section::-webkit-scrollbar-thumb {
        background: rgba(122, 151, 202, 0.42);
        border-radius: 999px;
    }

    .gear-breakdown-card {
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        padding: 14px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .gear-breakdown-head {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        align-items: flex-start;
    }

    .gear-breakdown-title {
        color: var(--color-text-primary);
        font-size: 13px;
        font-weight: 700;
    }

    .gear-breakdown-path {
        color: var(--color-text-secondary);
        font-size: 12px;
        text-align: right;
    }

    .gear-breakdown-materials {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        align-items: center;
    }

    .gear-inline-material {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        min-height: 30px;
        padding: 0 8px;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.06);
        min-width: 0;
    }

    .gear-inline-material-icon {
        width: 16px;
        height: 16px;
        object-fit: contain;
        flex-shrink: 0;
    }

    .total-inline-material {
        padding: 12px 14px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        font-size: 13px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        min-width: 0;
    }

    .material-name-group {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
    }

    .material-row-icon {
        width: 18px;
        height: 18px;
        object-fit: contain;
        flex-shrink: 0;
    }

    .material-value {
        color: var(--color-text-primary);
        font-weight: 700;
        font-variant-numeric: tabular-nums;
        font-size: 12px;
    }

    .chief-placeholder {
        padding: 22px 18px;
        text-align: center;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .placeholder-title {
        color: var(--color-text-primary);
        font-size: 15px;
        font-weight: 700;
    }

    .placeholder-copy {
        margin: 0;
        color: var(--color-text-secondary);
        font-size: 13px;
    }

    .stage-picker-backdrop {
        position: fixed;
        inset: 0;
        z-index: 60;
        background: rgba(6, 10, 24, 0.56);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        overflow: auto;
    }

    .stage-picker-modal {
        width: min(760px, calc(100vw - 40px));
        max-height: min(84vh, 860px);
        margin: auto;
        padding: 18px;
        border-radius: var(--radius-lg);
        border: 1px solid var(--color-border);
        background:
            linear-gradient(180deg, var(--theme-panel-sheen-line), transparent),
            var(--color-card);
        box-shadow:
            inset 0 1px 0 var(--theme-panel-sheen-soft),
            var(--shadow-lg);
        display: flex;
        flex-direction: column;
        gap: 16px;
        overflow: hidden;
    }

    .stage-picker-head {
        display: flex;
        justify-content: space-between;
        gap: 16px;
        align-items: flex-start;
    }

    .stage-picker-title {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
        color: var(--color-text-primary);
        text-transform: capitalize;
    }

    .stage-picker-copy {
        margin: 6px 0 0;
        color: var(--color-text-secondary);
        font-size: 13px;
    }

    .stage-picker-close {
        min-height: 36px;
        padding: 0 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        color: var(--color-text-primary);
        cursor: pointer;
    }

    .picker-progress {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .picker-step-button {
        appearance: none;
        border: none;
        background: transparent;
        padding: 0;
        color: var(--color-text-muted);
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        cursor: pointer;
    }

    .picker-step-active {
        color: var(--color-text-primary);
    }

    .picker-progress-divider {
        width: 44px;
        height: 1px;
        background: var(--color-border);
    }

    .stage-option-scroll {
        flex: 1;
        min-height: 0;
        overflow: auto;
        overflow-x: hidden;
        padding-top: 6px;
        padding-right: 4px;
        scrollbar-gutter: stable;
    }

    .stage-option-scroll::-webkit-scrollbar {
        width: 8px;
    }

    .stage-option-scroll::-webkit-scrollbar-track {
        background: transparent;
    }

    .stage-option-scroll::-webkit-scrollbar-thumb {
        background: rgba(122, 151, 202, 0.42);
        border-radius: 999px;
    }

    .stage-option-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(92px, 1fr));
        gap: 12px;
    }

    .stage-option-card {
        min-height: 92px;
        padding: 10px;
        border-radius: 18px;
        border: none;
        background: rgba(10, 16, 34, 0.46);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: transform 0.16s var(--ease-out), background 0.16s var(--ease-out), box-shadow 0.16s var(--ease-out);
    }

    .stage-option-card:hover,
    .stage-option-card.is-selected {
        transform: translateY(-1px);
        background: rgba(24, 42, 74, 0.76);
        box-shadow: inset 0 0 0 1px rgba(100, 190, 255, 0.16);
    }

    .stage-option-image {
        width: 100%;
        height: 70px;
        object-fit: contain;
        display: block;
        filter: drop-shadow(0 10px 16px rgba(0, 0, 0, 0.24));
    }

    @media (max-width: 1100px) {
        .chief-calc,
        .result-stats-grid {
            grid-template-columns: 1fr;
        }

        .chief-right-panel {
            position: static;
            max-height: none;
        }

        .chief-right-scroll {
            overflow: visible;
            padding-right: 0;
        }

        .chief-profile-shell {
            grid-template-columns: 1fr;
            min-height: 0;
        }

        .gear-slot-column {
            flex-direction: row;
            overflow-x: auto;
            padding-bottom: 4px;
        }

        .gear-slot-card {
            min-width: 110px;
        }

        .stage-option-grid {
            grid-template-columns: repeat(auto-fit, minmax(84px, 1fr));
        }

        .gear-breakdown-materials {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .gear-breakdown-section {
            max-height: none;
            overflow: visible;
            padding-right: 0;
        }

        .materials-section {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }
</style>
