<script>
    import { onMount } from 'svelte';
    import { apiFetch, getBasePath } from '../../lib/api.js';
    import { showToast } from '../../lib/utils.js';
    import Select from '../../components/ui/Select.svelte';

    const CATEGORIES = [
        { id: 'battle', label: 'Battle' },
        { id: 'economy', label: 'Economy' },
        { id: 'growth', label: 'Growth' },
    ];

    const basePath = getBasePath();

    const CALCULATOR_IMAGE_BASE = basePath + '/images/calculators/resources';
    const RESOURCE_IMAGES = {
        meat:      CALCULATOR_IMAGE_BASE + '/Meat.png',
        wood:      CALCULATOR_IMAGE_BASE + '/Wood.png',
        coal:      CALCULATOR_IMAGE_BASE + '/Coal.png',
        iron:      CALCULATOR_IMAGE_BASE + '/Iron.png',
        steel:     CALCULATOR_IMAGE_BASE + '/Steel.png',
        fc_shards: CALCULATOR_IMAGE_BASE + '/Fire_Crystal_Shard.png',
    };

    const RESOURCE_LABELS = {
        meat: 'Meat', wood: 'Wood', coal: 'Coal', iron: 'Iron',
        steel: 'Steel', fc_shards: 'FC Shards',
    };

    // Roman numerals I–X at end of skill name
    const ROMAN_RE = / (X|IX|VIII|VII|VI|V|IV|III|II|I)$/;

    function saveBuffs() {
        try { localStorage.setItem('calc_research_buffs', JSON.stringify({ researchSpeed, vpBonus })); } catch (_) {}
    }

    function loadSavedBuffs() {
        try {
            const saved = localStorage.getItem('calc_research_buffs');
            if (saved) return JSON.parse(saved);
        } catch (_) {}
        return null;
    }

    // ── State ─────────────────────────────────────────────────────────────
    let activeCategory = $state('battle');
    let categoryData = $state({});
    let isLoading = $state(false);
    let searchQuery = $state('');

    let selectedGroup = $state('');
    let selectedSkill = $state('');
    let fromLevel = $state('');
    let toLevel = $state('');

    const _savedBuffs = loadSavedBuffs();
    let researchSpeed = $state(_savedBuffs?.researchSpeed ?? 0);
    let vpBonus = $state(_savedBuffs?.vpBonus ?? 0);

    let currentResult = $state(null);
    let accumulatedItems = $state([]);
    let calcDone = $state(false);

    // ── Derived ───────────────────────────────────────────────────────────
    let skillsData = $derived(categoryData[activeCategory]?.skills ?? null);

    // Group skills by their base name (strip Roman numeral suffix)
    let groupedSkills = $derived.by(() => {
        if (!skillsData) return {};
        const groups = {};
        for (const name of Object.keys(skillsData)) {
            const base = name.replace(ROMAN_RE, '');
            if (!groups[base]) groups[base] = [];
            const grade = base !== name ? name.slice(base.length + 1) : null;
            groups[base].push({ grade, fullName: name });
        }
        return groups;
    });

    let filteredBaseNames = $derived(
        Object.keys(groupedSkills).filter(n =>
            n.toLowerCase().includes(searchQuery.toLowerCase())
        )
    );

    let selectedSkillData = $derived(selectedSkill && skillsData ? skillsData[selectedSkill] : null);

    let availableLevelKeys = $derived(
        selectedSkillData?.levels
            ? Object.keys(selectedSkillData.levels).sort((a, b) => parseInt(a) - parseInt(b))
            : []
    );

    let fromLevelOptions = $derived(buildFromOptions(availableLevelKeys));
    let toLevelOptions = $derived(buildToOptions(availableLevelKeys, fromLevel));

    let accumulatedTotal = $derived(computeTotal(accumulatedItems));

    // ── Helpers ───────────────────────────────────────────────────────────
    function buildFromOptions(levelKeys) {
        if (!levelKeys.length) return [];
        const options = [{ value: '0', label: 'Level 0' }];
        levelKeys.slice(0, -1).forEach(k => options.push({ value: k, label: `Level ${k}` }));
        return options;
    }

    function buildToOptions(levelKeys, from) {
        if (!levelKeys.length || from === '') return [];
        return levelKeys
            .filter(k => parseInt(k) > parseInt(from))
            .map(k => ({ value: k, label: `Level ${k}` }));
    }

    function timeToSeconds(time) {
        if (!time) return 0;
        return (time['raw-seconds'] ?? (
            (time.days || 0) * 86400
          + (time.hours || 0) * 3600
          + (time.minutes || 0) * 60
          + (time.seconds || 0)
        ));
    }

    function formatSeconds(totalSecs) {
        if (!totalSecs || totalSecs <= 0) return '0s';
        const d = Math.floor(totalSecs / 86400);
        const h = Math.floor((totalSecs % 86400) / 3600);
        const m = Math.floor((totalSecs % 3600) / 60);
        const s = totalSecs % 60;
        const parts = [];
        if (d) parts.push(`${d}d`);
        if (h) parts.push(`${h}h`);
        if (m) parts.push(`${m}m`);
        if (s) parts.push(`${s}s`);
        return parts.length ? parts.join(' ') : '0s';
    }

    function formatNumber(n) {
        if (!n || n === 0) return '0';
        return n.toLocaleString();
    }

    /**
     * Get the minimum Research Center level required for a given skill level.
     * @param {object} levelData
     * @returns {number|null}
     */
    function getRequiredRCLevel(levelData) {
        const rc = levelData?.requirements?.['research-center'];
        return rc ? parseInt(rc) : null;
    }

    function computeRange(skillData, from, to) {
        const fromNum = parseInt(from);
        const toNum = parseInt(to);

        const levelKeys = Object.keys(skillData.levels)
            .sort((a, b) => parseInt(a) - parseInt(b))
            .filter(k => parseInt(k) > fromNum && parseInt(k) <= toNum);

        const resources = { meat: 0, wood: 0, coal: 0, iron: 0, steel: 0, fc_shards: 0 };
        let rawSeconds = 0;

        for (const key of levelKeys) {
            const lvl = skillData.levels[key];
            if (lvl?.cost) {
                for (const [res, amount] of Object.entries(lvl.cost)) {
                    if (res in resources) resources[res] += amount;
                }
            }
            rawSeconds += timeToSeconds(lvl?.time);
        }

        let reducedSeconds = rawSeconds;
        const speed = (parseInt(researchSpeed, 10) || 0) + (parseInt(vpBonus, 10) || 0);
        if (speed > 0) {
            reducedSeconds = Math.ceil(rawSeconds / (1 + speed / 100));
        }

        return { resources, rawSeconds, reducedSeconds, levelCount: levelKeys.length };
    }

    function computeTotal(items) {
        const totals = {
            resources: { meat: 0, wood: 0, coal: 0, iron: 0, steel: 0, fc_shards: 0 },
            rawSeconds: 0,
            reducedSeconds: 0,
        };
        for (const item of items) {
            for (const [res, amount] of Object.entries(item.resources)) {
                totals.resources[res] += amount;
            }
            totals.rawSeconds += item.rawSeconds;
            totals.reducedSeconds += item.reducedSeconds;
        }
        return totals;
    }

    // ── Loaders ───────────────────────────────────────────────────────────
    async function loadCategory(cat) {
        if (categoryData[cat]) return;
        isLoading = true;
        try {
            const data = await apiFetch(`/api/calculators/research/${cat}`);
            if (data) categoryData = { ...categoryData, [cat]: data };
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    function switchCategory(cat) {
        activeCategory = cat;
        selectedGroup = '';
        selectedSkill = '';
        fromLevel = '';
        toLevel = '';
        currentResult = null;
        loadCategory(cat);
    }

    function handleSkillSelect(name) {
        selectedGroup = '';
        selectedSkill = name;
        fromLevel = '';
        toLevel = '';
        currentResult = null;
    }

    function calculate() {
        if (!selectedSkill || fromLevel === '' || !toLevel) {
            showToast('Please select a skill and level range', 'info');
            return;
        }
        currentResult = {
            skillName: selectedSkill,
            category: activeCategory,
            fromLabel: `Level ${fromLevel}`,
            toLabel: `Level ${toLevel}`,
            ...computeRange(selectedSkillData, fromLevel, toLevel),
        };
        calcDone = true;
        setTimeout(() => { calcDone = false; }, 1500);
    }

    function addToTotal() {
        if (!currentResult) {
            showToast('Calculate first before adding to total', 'info');
            return;
        }
        const key = `${currentResult.skillName}|${currentResult.fromLabel}|${currentResult.toLabel}`;
        const existingIndex = accumulatedItems.findIndex(
            item => `${item.skillName}|${item.fromLabel}|${item.toLabel}` === key
        );
        if (existingIndex !== -1) {
            accumulatedItems = accumulatedItems.map((item, i) =>
                i === existingIndex ? { ...currentResult } : item
            );
            showToast(`${currentResult.skillName} updated in total`, 'info');
        } else {
            accumulatedItems = [...accumulatedItems, { ...currentResult }];
            showToast(`${currentResult.skillName} added to total`, 'success');
        }
    }

    function removeFromTotal(index) {
        accumulatedItems = accumulatedItems.filter((_, i) => i !== index);
    }

    function clearTotal() {
        accumulatedItems = [];
    }

    function buildCopyText(items, total) {
        const lines = [];
        for (const item of items) {
            lines.push(`${item.skillName} (${item.fromLabel} → ${item.toLabel})`);
        }
        lines.push('');
        lines.push('Required Resources:');
        for (const [res, amount] of Object.entries(total.resources)) {
            if (amount > 0) lines.push(`  - ${RESOURCE_LABELS[res]}: ${formatNumber(amount)}`);
        }
        lines.push('');
        lines.push(`Original Time: ${formatSeconds(total.rawSeconds)}`);
        lines.push(`With Buffs: ${formatSeconds(total.reducedSeconds)}`);
        return lines.join('\n');
    }

    async function copyTotal() {
        if (accumulatedItems.length === 0) {
            showToast('Nothing to copy', 'info');
            return;
        }
        try {
            await navigator.clipboard.writeText(buildCopyText(accumulatedItems, accumulatedTotal));
            showToast('Copied to clipboard!', 'success');
        } catch (_) {
            showToast('Failed to copy', 'error');
        }
    }

    function onBuffChange() {
        saveBuffs();
        if (currentResult) calculate();
    }

    onMount(() => loadCategory('battle'));
</script>

<div class="research-calc">
    <!-- Left panel -->
    <div class="calc-panel left-panel">
        <!-- Category tabs -->
        <div class="category-tabs">
            {#each CATEGORIES as cat (cat.id)}
                <button
                    class="cat-tab"
                    class:active={activeCategory === cat.id}
                    onclick={() => switchCategory(cat.id)}
                >
                    {cat.label}
                </button>
            {/each}
        </div>

        <!-- Search -->
        <div class="search-box">
            <svg class="search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input
                type="text"
                placeholder="Search skills…"
                bind:value={searchQuery}
                class="search-input"
            />
            {#if searchQuery}
                <button class="clear-btn" onclick={() => { searchQuery = ''; }}>×</button>
            {/if}
        </div>

        <!-- Skill list (grouped by base name) -->
        {#if isLoading}
            <div class="loading-text">Loading…</div>
        {:else if skillsData}
            <div class="skill-list">
                {#each filteredBaseNames as baseName (baseName)}
                    {@const gradeEntries = groupedSkills[baseName]}
                    {@const isSingle = gradeEntries.length === 1 && gradeEntries[0].grade === null}
                    <div class="skill-group">
                        <button
                            class="skill-item"
                            class:selected={isSingle && selectedSkill === gradeEntries[0].fullName}
                            class:group-active={selectedGroup === baseName}
                            onclick={() => {
                                if (isSingle) {
                                    handleSkillSelect(gradeEntries[0].fullName);
                                } else {
                                    selectedGroup = selectedGroup === baseName ? '' : baseName;
                                }
                            }}
                        >
                            <span>{baseName}</span>
                            {#if !isSingle}
                                <span class="grade-count">{gradeEntries.length}</span>
                            {/if}
                        </button>
                        {#if !isSingle && selectedGroup === baseName}
                            <div class="grade-buttons">
                                {#each gradeEntries as entry (entry.grade)}
                                    <button
                                        class="grade-btn"
                                        class:active={selectedSkill === entry.fullName}
                                        onclick={() => handleSkillSelect(entry.fullName)}
                                    >
                                        {entry.grade}
                                    </button>
                                {/each}
                            </div>
                        {/if}
                    </div>
                {/each}
                {#if filteredBaseNames.length === 0}
                    <p class="empty-text">No skills match your search.</p>
                {/if}
            </div>
        {:else}
            <p class="empty-text">Select a category to load skills.</p>
        {/if}

        <!-- Level range selectors -->
        {#if selectedSkill && selectedSkillData}
            <div class="level-selectors">
                <div class="select-group">
                    <div class="select-label">From</div>
                    <Select
                        class="level-select"
                        bind:value={fromLevel}
                        options={fromLevelOptions}
                        placeholder="Select level…"
                        onchange={() => { toLevel = ''; currentResult = null; }}
                    />
                </div>
                <div class="select-group">
                    <div class="select-label">To</div>
                    <Select
                        class="level-select"
                        bind:value={toLevel}
                        options={toLevelOptions}
                        placeholder="Select level…"
                        disabled={fromLevel === ''}
                    />
                </div>
            </div>
            <button class="calc-btn" class:done={calcDone} onclick={calculate} disabled={!fromLevel || !toLevel}>
                {calcDone ? '✓ Done' : 'Calculate'}
            </button>
        {/if}

        <!-- Buffs section -->
        <div class="buffs-section">
            <h3 class="buffs-title">Buffs</h3>
            <div class="buff-row">
                <div class="buff-label">VP</div>
                <Select
                    class="buff-select"
                    bind:value={vpBonus}
                    onchange={onBuffChange}
                    options={[
                        { value: 0, label: 'Off' },
                        { value: 10, label: '10%' },
                        { value: 15, label: '15%' }
                    ]}
                />
            </div>
            <div class="buff-row">
                <label class="buff-label" for="res-speed">Research Speed %</label>
                <input
                    id="res-speed"
                    type="number"
                    min="0"
                    max="999"
                    class="buff-input no-spin"
                    bind:value={researchSpeed}
                    onchange={onBuffChange}
                    onblur={() => {
                        const v = parseInt(researchSpeed, 10);
                        researchSpeed = isNaN(v) ? 0 : Math.min(999, Math.max(0, v));
                        onBuffChange();
                    }}
                />
            </div>
        </div>
    </div>

    <!-- Right panel -->
    <div class="calc-panel right-panel">
        <div class="result-section">
            <h3 class="section-title">Calculation Result</h3>
            {#if currentResult}
                <div class="result-header">
                    <span class="result-name">{currentResult.skillName}</span>
                    <span class="result-range">{currentResult.fromLabel} → {currentResult.toLabel}</span>
                </div>

                {#if currentResult.unmetRequirements?.length > 0}
                    <div class="warning-box">
                        ⚠️ Your Research Center (Level {researchCenterLevel}) is too low for:
                        {#each currentResult.unmetRequirements as req}
                            <span class="warning-item">Level {req.level} requires RC {req.requiredRC}</span>
                        {/each}
                    </div>
                {/if}

                <div class="resource-grid">
                    {#each Object.entries(currentResult.resources) as [res, amount] (res)}
                        {#if amount > 0}
                            <div class="resource-row">
                                <span class="res-name">
                                    <img src={RESOURCE_IMAGES[res]} alt={RESOURCE_LABELS[res]} class="res-icon" />
                                    {RESOURCE_LABELS[res]}
                                </span>
                                <span class="res-value">{formatNumber(amount)}</span>
                            </div>
                        {/if}
                    {/each}
                </div>
                <div class="time-section">
                    <div class="time-row">
                        <span class="time-label">Original Time</span>
                        <span class="time-value">{formatSeconds(currentResult.rawSeconds)}</span>
                    </div>
                    {#if currentResult.reducedSeconds !== currentResult.rawSeconds}
                        <div class="time-row">
                            <span class="time-label">With Buffs</span>
                            <span class="time-value accent">{formatSeconds(currentResult.reducedSeconds)}</span>
                        </div>
                    {/if}
                </div>
                <button class="add-btn" onclick={addToTotal}>+ Add to Total</button>
            {:else}
                <p class="placeholder-text">Select a skill and level range, then click Calculate.</p>
            {/if}
        </div>

        {#if accumulatedItems.length > 0}
            <div class="accumulated-section">
                <div class="accumulated-header">
                    <h3 class="section-title">Accumulated Total</h3>
                    <div class="header-actions">
                        <button class="copy-total-btn" onclick={copyTotal}>Copy</button>
                        <button class="clear-total-btn" onclick={clearTotal}>Clear All</button>
                    </div>
                </div>
                <div class="accumulated-items">
                    {#each accumulatedItems as item, i (i)}
                        <div class="acc-item">
                            <span class="acc-item-name">
                                {item.skillName}
                                <span class="acc-range">({item.fromLabel} → {item.toLabel})</span>
                            </span>
                            <button class="remove-btn" onclick={() => removeFromTotal(i)}>×</button>
                        </div>
                    {/each}
                </div>
                <div class="resource-grid total-grid">
                    {#each Object.entries(accumulatedTotal.resources) as [res, amount] (res)}
                        {#if amount > 0}
                            <div class="resource-row">
                                <span class="res-name">
                                    <img src={RESOURCE_IMAGES[res]} alt={RESOURCE_LABELS[res]} class="res-icon" />
                                    {RESOURCE_LABELS[res]}
                                </span>
                                <span class="res-value">{formatNumber(amount)}</span>
                            </div>
                        {/if}
                    {/each}
                </div>
                <div class="time-section">
                    <div class="time-row">
                        <span class="time-label">Total Original Time</span>
                        <span class="time-value">{formatSeconds(accumulatedTotal.rawSeconds)}</span>
                    </div>
                    <div class="time-row">
                        <span class="time-label">Total With Buffs</span>
                        <span class="time-value accent">{formatSeconds(accumulatedTotal.reducedSeconds)}</span>
                    </div>
                </div>
            </div>
        {/if}
    </div>
</div>

<style>
    .research-calc {
        display: grid;
        grid-template-columns: 320px 1fr;
        gap: 20px;
        align-items: start;
    }

    @media (max-width: 768px) {
        .research-calc { grid-template-columns: 1fr; }
    }

    .calc-panel {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .category-tabs {
        display: flex;
        gap: 4px;
        background: color-mix(in oklab, var(--color-panel-muted) 92%, black);
        border: 1px solid var(--color-border-subtle);
        border-radius: var(--radius-md);
        padding: 4px;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
    }

    .cat-tab {
        flex: 1;
        min-height: 36px;
        padding: 0 10px;
        border-radius: calc(var(--radius-md) - 2px);
        border: none;
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition:
            transform 150ms var(--ease-out),
            background-color 150ms var(--ease-out),
            color 150ms var(--ease-out),
            box-shadow 150ms var(--ease-out);
    }

    .cat-tab:hover {
        color: var(--color-text-primary);
    }

    .cat-tab.active {
        background:
            linear-gradient(180deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.04)),
            color-mix(in oklab, var(--color-panel-elevated) 92%, black);
        color: var(--color-accent-strong);
        box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.08),
            0 0 0 1px rgba(255, 255, 255, 0.06);
    }

    .search-box {
        position: relative;
        display: flex;
        align-items: center;
    }

    .search-icon {
        position: absolute;
        left: 10px;
        color: var(--color-text-muted);
        pointer-events: none;
    }

    .search-input {
        width: 100%;
        padding: 8px 30px 8px 32px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        color: var(--color-text-primary);
        font-size: 13px;
    }

    .search-input:focus {
        outline: none;
        border-color: var(--color-border-accent);
    }

    .clear-btn {
        position: absolute;
        right: 8px;
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        padding: 2px 4px;
    }

    .skill-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
        max-height: 300px;
        overflow-y: auto;
    }

    .skill-item {
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 9px 12px;
        border-radius: var(--radius-sm);
        border: 1px solid transparent;
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 13px;
        text-align: left;
        cursor: pointer;
        transition: all 0.1s ease;
    }

    .skill-item:hover {
        background: var(--color-card-hover);
        color: var(--color-text-primary);
    }

    .skill-item.selected {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }

    .skill-item.group-active {
        background: var(--color-secondary);
        color: var(--color-text-primary);
    }

    .grade-count {
        font-size: 11px;
        color: var(--color-text-muted);
        background: var(--color-secondary);
        padding: 1px 6px;
        border-radius: 10px;
    }

    .grade-buttons {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
        padding: 4px 12px 6px;
    }

    .grade-btn {
        padding: 3px 10px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-secondary);
        font-size: 12px;
        cursor: pointer;
        transition: all 0.1s;
    }

    .grade-btn:hover {
        background: var(--color-card-hover);
        color: var(--color-text-primary);
    }

    .grade-btn.active {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }

    .level-selectors {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }

    .select-group {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .select-label {
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--color-text-muted);
    }

    :global(.level-select) {
        width: 100%;
        min-width: 0;
    }

    :global(.level-select .select-trigger) {
        padding: 7px 10px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
    }

    :global(.level-select.is-disabled .select-trigger) {
        opacity: 0.5;
        cursor: not-allowed;
    }

    .calc-btn {
        padding: 9px;
        background: var(--color-accent);
        color: #fff;
        border: none;
        border-radius: var(--radius-md);
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.15s ease;
    }

    .calc-btn:hover:not(:disabled):not(.done) { background: var(--color-accent-hover); }
    .calc-btn.done { background: var(--color-success); pointer-events: none; }
    .calc-btn:disabled { opacity: 0.5; cursor: not-allowed; }

    .buffs-section {
        border-top: 1px solid var(--color-border);
        padding-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .buffs-title {
        font-size: 13px;
        font-weight: 600;
        color: var(--color-text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin: 0;
    }

    .buff-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
    }

    .buff-label {
        font-size: 13px;
        color: var(--color-text-primary);
    }

    .buff-input {
        width: 64px;
        padding: 6px 8px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
        text-align: center;
    }

    .no-spin::-webkit-outer-spin-button,
    .no-spin::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    .no-spin { -moz-appearance: textfield; }

    :global(.buff-select) {
        width: 120px;
        min-width: 120px;
    }

    :global(.buff-select .select-trigger) {
        padding: 6px 8px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
    }

    .buff-input:focus {
        outline: none;
        border-color: var(--color-border-accent);
    }

    :global(.buff-select .select-trigger:focus) {
        border-color: var(--color-border-accent);
    }

    .section-title {
        font-size: 14px;
        font-weight: 600;
        color: var(--color-text-primary);
        margin: 0;
    }

    .result-section {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .result-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 4px;
    }

    .result-name {
        font-size: 15px;
        font-weight: 600;
        color: var(--color-accent);
    }

    .result-range {
        font-size: 13px;
        color: var(--color-text-muted);
    }

    .warning-box {
        padding: 10px 12px;
        background: var(--color-warning-soft);
        border: 1px solid rgba(251, 191, 36, 0.25);
        border-radius: var(--radius-md);
        font-size: 13px;
        color: var(--color-warning);
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .warning-item {
        font-size: 12px;
        opacity: 0.85;
        padding-left: 8px;
    }

    .resource-grid {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .resource-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 10px;
        background: var(--color-secondary);
        border-radius: var(--radius-sm);
        font-size: 13px;
    }

    .res-name {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--color-text-secondary);
    }

    .res-icon {
        width: 22px;
        height: 22px;
        object-fit: contain;
        border-radius: 2px;
    }
    .res-value { font-weight: 600; color: var(--color-text-primary); font-variant-numeric: tabular-nums; }

    .time-section {
        display: flex;
        flex-direction: column;
        gap: 6px;
        padding: 12px;
        background: var(--color-secondary);
        border-radius: var(--radius-md);
    }

    .time-row {
        display: flex;
        justify-content: space-between;
        font-size: 13px;
    }

    .time-label { color: var(--color-text-secondary); }
    .time-value { font-weight: 600; color: var(--color-text-primary); }
    .time-value.accent { color: var(--color-success); }

    .add-btn {
        padding: 8px 16px;
        background: var(--color-success-soft);
        color: var(--color-success);
        border: 1px solid rgba(52, 211, 153, 0.25);
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        align-self: flex-start;
        transition: all 0.15s ease;
    }

    .add-btn:hover { background: rgba(52, 211, 153, 0.2); }

    .accumulated-section {
        border-top: 1px solid var(--color-border);
        padding-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .accumulated-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header-actions {
        display: flex;
        gap: 6px;
    }

    .copy-total-btn {
        padding: 4px 12px;
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border: 1px solid var(--color-border-accent);
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.15s;
    }

    .copy-total-btn:hover { background: rgba(99, 102, 241, 0.2); }

    .clear-total-btn {
        padding: 4px 12px;
        background: var(--color-danger-soft);
        color: var(--color-danger);
        border: 1px solid rgba(248, 113, 113, 0.2);
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
    }

    .accumulated-items {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .acc-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 10px;
        background: var(--color-secondary);
        border-radius: var(--radius-sm);
        font-size: 12px;
    }

    .acc-item-name { color: var(--color-text-primary); }
    .acc-range { color: var(--color-text-muted); font-size: 11px; }

    .remove-btn {
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        padding: 0 4px;
        transition: color 0.1s;
    }

    .remove-btn:hover { color: var(--color-danger); }

    .total-grid {
        border-top: 1px solid var(--color-border-accent);
        padding-top: 12px;
    }

    .loading-text, .empty-text, .placeholder-text {
        color: var(--color-text-muted);
        font-size: 13px;
        text-align: center;
        padding: 16px 0;
    }
</style>
