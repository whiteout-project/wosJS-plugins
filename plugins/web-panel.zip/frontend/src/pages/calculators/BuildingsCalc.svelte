<script>
    import { onMount } from 'svelte';
    import { apiFetch, getBasePath } from '../../lib/api.js';
    import { showToast } from '../../lib/utils.js';
    import { FURNACE_LEVEL_MAP } from '../../lib/constants.js';
    import Select from '../../components/ui/Select.svelte';

    // ── Buff tables (mirrored from buildings.js) ──────────────────────────
    const PET_SPEED     = [0, 5, 7, 9, 12, 15];
    const ZINMAN_REDUCE = [0, 3, 6, 9, 12, 15];
    const EXPERT_SECS   = [0, 7200, 10800, 14400, 21600, 28800];

    const basePath = getBasePath();

    const CALCULATOR_IMAGE_BASE = basePath + '/images/calculators/resources';
    const RESOURCE_IMAGES = {
        meat:               CALCULATOR_IMAGE_BASE + '/Meat.png',
        wood:               CALCULATOR_IMAGE_BASE + '/Wood.png',
        coal:               CALCULATOR_IMAGE_BASE + '/Coal.png',
        iron:               CALCULATOR_IMAGE_BASE + '/Iron.png',
        steel:              CALCULATOR_IMAGE_BASE + '/Steel.png',
        fireCrystal:        CALCULATOR_IMAGE_BASE + '/Fire_Crystal.png',
        refinedFireCrystal: CALCULATOR_IMAGE_BASE + '/Refined_fire-crystal.png',
    };

    const RESOURCE_LABELS = {
        meat: 'Meat', wood: 'Wood', coal: 'Coal', iron: 'Iron',
        steel: 'Steel', fireCrystal: 'Fire Crystal', refinedFireCrystal: 'Refined FC',
    };

    // ── LocalStorage helpers ──────────────────────────────────────────────
    function saveBuffs() {
        try { localStorage.setItem('calc_buildings_buffs', JSON.stringify(buffs)); } catch (_) {}
    }

    function loadSavedBuffs() {
        try {
            const saved = localStorage.getItem('calc_buildings_buffs');
            if (saved) return JSON.parse(saved);
        } catch (_) {}
        return null;
    }

    // ── State ─────────────────────────────────────────────────────────────
    let buildingType = $state('basic');
    let buildingsData = $state(null);
    let isLoading = $state(false);
    let searchQuery = $state('');

    let selectedBuilding = $state('');
    let fromLevel = $state('');
    let toLevel = $state('');

    const _savedBuffs = loadSavedBuffs();
    let buffs = $state({
        constructionSpeed: _savedBuffs?.constructionSpeed ?? 0,
        petLevel:          _savedBuffs?.petLevel          ?? 0,
        zinmanLevel:       _savedBuffs?.zinmanLevel       ?? 0,
        expertLevel:       _savedBuffs?.expertLevel       ?? 0,
        vpBonus:           _savedBuffs?.vpBonus           ?? 0,
        doubleTime:        _savedBuffs?.doubleTime        ?? false,
    });

    let currentResult = $state(null);
    let accumulatedItems = $state([]);
    let calcDone = $state(false);

    // ── Derived values ────────────────────────────────────────────────────
    let buildingKeys = $derived(buildingsData ? Object.keys(buildingsData) : []);

    let filteredBuildingKeys = $derived(
        buildingKeys.filter(k =>
            getBuildingDisplayName(k).toLowerCase().includes(searchQuery.toLowerCase())
        )
    );

    let selectedBuildingData = $derived(
        selectedBuilding && buildingsData ? buildingsData[selectedBuilding] : null
    );

    let availableLevelKeys = $derived(
        selectedBuildingData
            ? Object.keys(selectedBuildingData).sort((a, b) => parseInt(a) - parseInt(b))
            : []
    );

    let fromLevelOptions = $derived(buildFromLevelOptions(selectedBuildingData, availableLevelKeys, buildingType));
    let toLevelOptions = $derived(buildToLevelOptions(availableLevelKeys, fromLevel));

    let accumulatedTotal = $derived(computeAccumulatedTotal(accumulatedItems));

    // ── Helpers ───────────────────────────────────────────────────────────
    /**
     * Convert a camelCase building key to a readable display name.
     * @param {string} key
     * @returns {string}
     */
    function getBuildingDisplayName(key) {
        return key
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, s => s.toUpperCase())
            .trim();
    }

    /**
     * Get the display label for a level key.
     * Basic levels show as "Level N"; FC levels use FURNACE_LEVEL_MAP.
     * @param {string} key
     * @returns {string}
     */
    function getLevelLabel(key) {
        if (key === '0') return 'Not Built';
        const num = parseInt(key);
        if (num >= 31 && FURNACE_LEVEL_MAP[num]) return FURNACE_LEVEL_MAP[num];
        return `Level ${key}`;
    }

    /**
     * Compute raw seconds from a level's time object.
     * @param {{ days: number, hours: number, minutes: number, seconds: number }} time
     * @returns {number}
     */
    function timeToSeconds(time) {
        if (!time) return 0;
        return (time.days || 0) * 86400
             + (time.hours || 0) * 3600
             + (time.minutes || 0) * 60
             + (time.seconds || 0);
    }

    /**
     * Format a seconds count as "Xd Xh Xm Xs", omitting zero parts.
     * Returns "0s" for zero.
     * @param {number} totalSeconds
     * @returns {string}
     */
    function formatSeconds(totalSeconds) {
        if (!totalSeconds || totalSeconds <= 0) return '0s';
        const d = Math.floor(totalSeconds / 86400);
        const h = Math.floor((totalSeconds % 86400) / 3600);
        const m = Math.floor((totalSeconds % 3600) / 60);
        const s = totalSeconds % 60;
        const parts = [];
        if (d > 0) parts.push(`${d}d`);
        if (h > 0) parts.push(`${h}h`);
        if (m > 0) parts.push(`${m}m`);
        if (s > 0) parts.push(`${s}s`);
        return parts.length ? parts.join(' ') : '0s';
    }

    /**
     * Format a large number with comma separators.
     * @param {number} n
     * @returns {string}
     */
    function formatNumber(n) {
        if (!n || n === 0) return '0';
        return n.toLocaleString();
    }

    function buildFromLevelOptions(bldData, levelKeys, type) {
        if (!bldData || levelKeys.length === 0) return [];
        const startOption = type === 'fire_crystal'
            ? { value: '30', label: 'Level 30' }
            : { value: '0', label: 'Not Built (0)' };
        const options = [startOption];
        for (let i = 0; i < levelKeys.length - 1; i++) {
            options.push({ value: levelKeys[i], label: getLevelLabel(levelKeys[i]) });
        }
        return options;
    }

    function buildToLevelOptions(levelKeys, from) {
        if (!levelKeys.length || from === '') return [];

        const fromNum = parseInt(from);
        return levelKeys
            .filter(k => parseInt(k) > fromNum)
            .map(k => ({ value: k, label: getLevelLabel(k) }));
    }

    /**
     * Compute the total resources and time for a building level range with buffs.
     * @param {object} bldData - The building's level data object
     * @param {string} from - From level key
     * @param {string} to - To level key
     * @param {object} buffsObj - { constructionSpeed, petLevel, zinmanLevel, expertLevel }
     * @returns {{ resources: object, rawSeconds: number, reducedSeconds: number, levelCount: number }}
     */
    function computeLevelRange(bldData, from, to) {
        const fromNum = parseInt(from);
        const toNum = parseInt(to);

        const allKeys = Object.keys(bldData)
            .sort((a, b) => parseInt(a) - parseInt(b))
            .filter(k => parseInt(k) > fromNum && parseInt(k) <= toNum);

        const vpBonus = parseInt(buffs.vpBonus) || 0;
        const doubleTimeBonus = buffs.doubleTime ? 20 : 0;
        const totalSpeed = (parseInt(buffs.constructionSpeed) || 0)
                         + PET_SPEED[buffs.petLevel]
                         + vpBonus
                         + doubleTimeBonus;
        const zinmanFactor = 1 - ZINMAN_REDUCE[buffs.zinmanLevel] / 100;

        const resources = {
            meat: 0, wood: 0, coal: 0, iron: 0,
            steel: 0, fireCrystal: 0, refinedFireCrystal: 0,
        };
        let rawSeconds = 0;

        for (const key of allKeys) {
            const levelData = bldData[key];
            if (levelData?.cost) {
                for (const [res, amount] of Object.entries(levelData.cost)) {
                    if (res in resources) resources[res] += amount;
                }
            }
            rawSeconds += timeToSeconds(levelData?.time);
        }

        // Apply Zinman resource reduction
        for (const res of Object.keys(resources)) {
            resources[res] = Math.round(resources[res] * zinmanFactor);
        }

        // Apply speed buff and expert reduction
        let reducedSeconds = rawSeconds;
        if (totalSpeed > 0) {
            reducedSeconds = Math.ceil(rawSeconds / (1 + totalSpeed / 100));
        }
        const expertReduction = EXPERT_SECS[buffs.expertLevel] * allKeys.length;
        reducedSeconds = Math.max(0, reducedSeconds - expertReduction);

        return { resources, rawSeconds, reducedSeconds, levelCount: allKeys.length };
    }

    function computeAccumulatedTotal(items) {
        const totals = {
            resources: { meat: 0, wood: 0, coal: 0, iron: 0, steel: 0, fireCrystal: 0, refinedFireCrystal: 0 },
            rawSeconds: 0,
            reducedSeconds: 0,
        };
        for (const item of items) {
            for (const [res, amount] of Object.entries(item.resources)) {
                totals.resources[res] += amount;
            }
            totals.rawSeconds += item.rawSeconds;
            totals.reducedSeconds += item.reducedSeconds;
        }
        return totals;
    }

    // ── Event handlers ────────────────────────────────────────────────────
    async function loadBuildingsData(type) {
        isLoading = true;
        buildingsData = null;
        currentResult = null;
        selectedBuilding = '';
        fromLevel = '';
        toLevel = '';

        try {
            const data = await apiFetch(`/api/calculators/buildings/${type}`);
            if (data) buildingsData = data;
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    function handleTypeChange(type) {
        buildingType = type;
        accumulatedItems = [];
        loadBuildingsData(type);
    }

    function handleBuildingSelect(key) {
        selectedBuilding = key;
        fromLevel = '';
        toLevel = '';
        currentResult = null;
    }

    function handleFromLevelChange() {
        toLevel = '';
        currentResult = null;
    }

    function calculate() {
        if (!selectedBuilding || fromLevel === '' || !toLevel) {
            showToast('Please select a building and level range', 'info');
            return;
        }
        const bldData = buildingsData[selectedBuilding];
        currentResult = {
            buildingName: getBuildingDisplayName(selectedBuilding),
            fromLabel: getLevelLabel(fromLevel),
            toLabel: getLevelLabel(toLevel),
            ...computeLevelRange(bldData, fromLevel, toLevel),
        };
        calcDone = true;
        setTimeout(() => { calcDone = false; }, 1500);
    }

    function addToTotal() {
        if (!currentResult) {
            showToast('Calculate first before adding to total', 'info');
            return;
        }
        const key = `${currentResult.buildingName}|${currentResult.fromLabel}|${currentResult.toLabel}`;
        const existingIndex = accumulatedItems.findIndex(
            item => `${item.buildingName}|${item.fromLabel}|${item.toLabel}` === key
        );
        if (existingIndex !== -1) {
            accumulatedItems = accumulatedItems.map((item, i) =>
                i === existingIndex ? { ...currentResult } : item
            );
            showToast(`${currentResult.buildingName} updated in total`, 'info');
        } else {
            accumulatedItems = [...accumulatedItems, { ...currentResult }];
            showToast(`${currentResult.buildingName} added to total`, 'success');
        }
    }

    function removeFromTotal(index) {
        accumulatedItems = accumulatedItems.filter((_, i) => i !== index);
    }

    function clearTotal() {
        accumulatedItems = [];
    }

    function buildCopyText(items, total) {
        const lines = [];
        for (const item of items) {
            lines.push(`${item.buildingName} (${item.fromLabel} → ${item.toLabel})`);
        }
        lines.push('');
        lines.push('Required Resources:');
        for (const [res, amount] of Object.entries(total.resources)) {
            if (amount > 0) lines.push(`  - ${RESOURCE_LABELS[res]}: ${formatNumber(amount)}`);
        }
        lines.push('');
        lines.push(`Original Time: ${formatSeconds(total.rawSeconds)}`);
        lines.push(`With Buffs: ${formatSeconds(total.reducedSeconds)}`);
        return lines.join('\n');
    }

    async function copyTotal() {
        if (accumulatedItems.length === 0) {
            showToast('Nothing to copy', 'info');
            return;
        }
        try {
            await navigator.clipboard.writeText(buildCopyText(accumulatedItems, accumulatedTotal));
            showToast('Copied to clipboard!', 'success');
        } catch (_) {
            showToast('Failed to copy', 'error');
        }
    }

    function onBuffChange() {
        saveBuffs();
        if (currentResult) calculate();
    }

    onMount(() => loadBuildingsData('basic'));
</script>

<div class="buildings-calc">
    <!-- Left panel -->
    <div class="calc-panel left-panel">
        <!-- Type toggle -->
        <div class="type-toggle">
            <button
                class="toggle-btn"
                class:active={buildingType === 'basic'}
                onclick={() => handleTypeChange('basic')}
            >Basic</button>
            <button
                class="toggle-btn"
                class:active={buildingType === 'fire_crystal'}
                onclick={() => handleTypeChange('fire_crystal')}
            >Fire Crystal</button>
        </div>

        <!-- Search -->
        <div class="search-box">
            <svg class="search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input
                type="text"
                placeholder="Search buildings…"
                bind:value={searchQuery}
                class="search-input"
            />
            {#if searchQuery}
                <button class="clear-btn" onclick={() => { searchQuery = ''; }}>×</button>
            {/if}
        </div>

        <!-- Building list -->
        {#if isLoading}
            <div class="loading-text">Loading…</div>
        {:else if buildingsData}
            <div class="building-list">
                {#each filteredBuildingKeys as key (key)}
                    <button
                        class="building-item"
                        class:selected={selectedBuilding === key}
                        onclick={() => handleBuildingSelect(key)}
                    >
                        {getBuildingDisplayName(key)}
                    </button>
                {/each}
                {#if filteredBuildingKeys.length === 0}
                    <p class="empty-text">No buildings match your search.</p>
                {/if}
            </div>
        {/if}

        <!-- Level range selectors -->
        {#if selectedBuilding && selectedBuildingData}
            <div class="level-selectors">
                <div class="select-group">
                    <div class="select-label">From</div>
                    <Select
                        class="level-select"
                        bind:value={fromLevel}
                        options={fromLevelOptions}
                        placeholder="Select level…"
                        onchange={handleFromLevelChange}
                    />
                </div>
                <div class="select-group">
                    <div class="select-label">To</div>
                    <Select
                        class="level-select"
                        bind:value={toLevel}
                        options={toLevelOptions}
                        placeholder="Select level…"
                        disabled={fromLevel === ''}
                    />
                </div>
            </div>
            <button class="calc-btn" class:done={calcDone} onclick={calculate} disabled={!fromLevel || !toLevel}>
                {calcDone ? '✓ Done' : 'Calculate'}
            </button>
        {/if}

        <!-- Buffs -->
        <div class="buffs-section">
            <h3 class="buffs-title">Buffs</h3>
            <div class="buff-row">
                <div class="buff-label">VP</div>
                <Select
                    class="buff-select"
                    bind:value={buffs.vpBonus}
                    onchange={onBuffChange}
                    options={[
                        { value: 0, label: 'Off' },
                        { value: 10, label: '10%' },
                        { value: 15, label: '15%' }
                    ]}
                />
            </div>
            <div class="buff-row">
                <label class="buff-label checkbox-label" for="double-time">
                    <input id="double-time" type="checkbox" class="buff-checkbox" bind:checked={buffs.doubleTime} onchange={onBuffChange} />
                    Double Time (+20%)
                </label>
            </div>
            <div class="buff-row">
                <div class="buff-label">Pet</div>
                <Select
                    class="buff-select"
                    bind:value={buffs.petLevel}
                    onchange={onBuffChange}
                    options={[
                        { value: 0, label: 'Off' },
                        { value: 1, label: 'Lv.1 (+5%)' },
                        { value: 2, label: 'Lv.2 (+7%)' },
                        { value: 3, label: 'Lv.3 (+9%)' },
                        { value: 4, label: 'Lv.4 (+12%)' },
                        { value: 5, label: 'Lv.5 (+15%)' }
                    ]}
                />
            </div>
            <div class="buff-row">
                <div class="buff-label">Zinman</div>
                <Select
                    class="buff-select"
                    bind:value={buffs.zinmanLevel}
                    onchange={onBuffChange}
                    options={[
                        { value: 0, label: 'Off' },
                        { value: 1, label: 'Lv.1 (-3%)' },
                        { value: 2, label: 'Lv.2 (-6%)' },
                        { value: 3, label: 'Lv.3 (-9%)' },
                        { value: 4, label: 'Lv.4 (-12%)' },
                        { value: 5, label: 'Lv.5 (-15%)' }
                    ]}
                />
            </div>
            <div class="buff-row">
                <div class="buff-label">Expert</div>
                <Select
                    class="buff-select"
                    bind:value={buffs.expertLevel}
                    onchange={onBuffChange}
                    options={[
                        { value: 0, label: 'Off' },
                        { value: 1, label: 'Lv.1 (-2h/lvl)' },
                        { value: 2, label: 'Lv.2 (-3h/lvl)' },
                        { value: 3, label: 'Lv.3 (-4h/lvl)' },
                        { value: 4, label: 'Lv.4 (-6h/lvl)' },
                        { value: 5, label: 'Lv.5 (-8h/lvl)' }
                    ]}
                />
            </div>
            <div class="buff-row">
                <label class="buff-label" for="constr-speed">Const. Speed %</label>
                <input
                    id="constr-speed"
                    type="number"
                    min="0"
                    max="999"
                    class="buff-input no-spin"
                    bind:value={buffs.constructionSpeed}
                    onchange={onBuffChange}
                    onblur={() => {
                        const v = parseInt(buffs.constructionSpeed, 10);
                        buffs.constructionSpeed = isNaN(v) ? 0 : Math.min(999, Math.max(0, v));
                        onBuffChange();
                    }}
                />
            </div>
        </div>
    </div>

    <!-- Right panel -->
    <div class="calc-panel right-panel">
        <!-- Current result -->
        <div class="result-section">
            <h3 class="section-title">Calculation Result</h3>
            {#if currentResult}
                <div class="result-header">
                    <span class="result-building">{currentResult.buildingName}</span>
                    <span class="result-range">{currentResult.fromLabel} → {currentResult.toLabel}</span>
                </div>
                <div class="resource-grid">
                    {#each Object.entries(currentResult.resources) as [res, amount] (res)}
                        {#if amount > 0}
                            <div class="resource-row">
                                <span class="res-name">
                                    <img src={RESOURCE_IMAGES[res]} alt={RESOURCE_LABELS[res]} class="res-icon" />
                                    {RESOURCE_LABELS[res]}
                                </span>
                                <span class="res-value">{formatNumber(amount)}</span>
                            </div>
                        {/if}
                    {/each}
                </div>
                <div class="time-section">
                    <div class="time-row">
                        <span class="time-label">Original Time</span>
                        <span class="time-value">{formatSeconds(currentResult.rawSeconds)}</span>
                    </div>
                    {#if currentResult.reducedSeconds !== currentResult.rawSeconds}
                        <div class="time-row reduced">
                            <span class="time-label">With Buffs</span>
                            <span class="time-value accent">{formatSeconds(currentResult.reducedSeconds)}</span>
                        </div>
                    {/if}
                </div>
                <button class="add-btn" onclick={addToTotal}>+ Add to Total</button>
            {:else}
                <p class="placeholder-text">Select a building and level range, then click Calculate.</p>
            {/if}
        </div>

        <!-- Accumulated total -->
        {#if accumulatedItems.length > 0}
            <div class="accumulated-section">
                <div class="accumulated-header">
                    <h3 class="section-title">Accumulated Total</h3>
                    <div class="header-actions">
                        <button class="copy-total-btn" onclick={copyTotal}>Copy</button>
                        <button class="clear-total-btn" onclick={clearTotal}>Clear All</button>
                    </div>
                </div>

                <!-- Item list -->
                <div class="accumulated-items">
                    {#each accumulatedItems as item, i (i)}
                        <div class="acc-item">
                            <span class="acc-item-name">{item.buildingName} <span class="acc-range">({item.fromLabel} → {item.toLabel})</span></span>
                            <button class="remove-btn" onclick={() => removeFromTotal(i)} title="Remove">×</button>
                        </div>
                    {/each}
                </div>

                <!-- Running totals -->
                <div class="resource-grid total-grid">
                    {#each Object.entries(accumulatedTotal.resources) as [res, amount] (res)}
                        {#if amount > 0}
                            <div class="resource-row">
                                <span class="res-name">
                                    <img src={RESOURCE_IMAGES[res]} alt={RESOURCE_LABELS[res]} class="res-icon" />
                                    {RESOURCE_LABELS[res]}
                                </span>
                                <span class="res-value">{formatNumber(amount)}</span>
                            </div>
                        {/if}
                    {/each}
                </div>
                <div class="time-section">
                    <div class="time-row">
                        <span class="time-label">Total Original Time</span>
                        <span class="time-value">{formatSeconds(accumulatedTotal.rawSeconds)}</span>
                    </div>
                    <div class="time-row reduced">
                        <span class="time-label">Total With Buffs</span>
                        <span class="time-value accent">{formatSeconds(accumulatedTotal.reducedSeconds)}</span>
                    </div>
                </div>
            </div>
        {/if}
    </div>
</div>

<style>
    .buildings-calc {
        display: grid;
        grid-template-columns: 320px 1fr;
        gap: 20px;
        align-items: start;
    }

    @media (max-width: 768px) {
        .buildings-calc {
            grid-template-columns: 1fr;
        }
    }

    .calc-panel {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    /* Type toggle */
    .type-toggle {
        display: flex;
        gap: 4px;
        background: var(--color-secondary);
        border-radius: var(--radius-md);
        padding: 4px;
    }

    .toggle-btn {
        flex: 1;
        padding: 6px 12px;
        border-radius: calc(var(--radius-md) - 2px);
        border: none;
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
    }

    .toggle-btn.active {
        background: var(--color-accent);
        color: #fff;
    }

    /* Search */
    .search-box {
        position: relative;
        display: flex;
        align-items: center;
    }

    .search-icon {
        position: absolute;
        left: 10px;
        color: var(--color-text-muted);
        pointer-events: none;
    }

    .search-input {
        width: 100%;
        padding: 8px 30px 8px 32px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        color: var(--color-text-primary);
        font-size: 13px;
    }

    .search-input:focus {
        outline: none;
        border-color: var(--color-border-accent);
    }

    .clear-btn {
        position: absolute;
        right: 8px;
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        padding: 2px 4px;
    }

    /* Building list */
    .building-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
        max-height: 280px;
        overflow-y: auto;
    }

    .building-item {
        padding: 9px 12px;
        border-radius: var(--radius-sm);
        border: 1px solid transparent;
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 13px;
        text-align: left;
        cursor: pointer;
        transition: all 0.1s ease;
    }

    .building-item:hover {
        background: var(--color-card-hover);
        color: var(--color-text-primary);
    }

    .building-item.selected {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }

    /* Level selectors */
    .level-selectors {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }

    .select-group {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .select-label {
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--color-text-muted);
    }

    :global(.level-select) {
        width: 100%;
        min-width: 0;
    }

    :global(.level-select .select-trigger) {
        padding: 7px 10px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
    }

    :global(.level-select.is-disabled .select-trigger) {
        opacity: 0.5;
        cursor: not-allowed;
    }

    /* Calculate button */
    .calc-btn {
        padding: 9px;
        background: var(--color-accent);
        color: #fff;
        border: none;
        border-radius: var(--radius-md);
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.15s ease;
    }

    .calc-btn:hover:not(:disabled):not(.done) {
        background: var(--color-accent-hover);
    }

    .calc-btn.done {
        background: var(--color-success);
        pointer-events: none;
    }

    .calc-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    /* Buffs section */
    .buffs-section {
        border-top: 1px solid var(--color-border);
        padding-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .buffs-title {
        font-size: 13px;
        font-weight: 600;
        color: var(--color-text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin: 0;
    }

    .buff-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
    }

    .buff-label {
        font-size: 13px;
        color: var(--color-text-primary);
    }

    :global(.buff-select) {
        width: 140px;
        min-width: 140px;
        font-size: 13px;
    }

    :global(.buff-select .select-trigger) {
        padding: 6px 8px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
    }

    .buff-input {
        width: 64px;
        padding: 6px 8px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        color: var(--color-text-primary);
        font-size: 13px;
        text-align: center;
    }

    :global(.buff-select .select-trigger:focus) {
        border-color: var(--color-border-accent);
    }

    .buff-input:focus {
        outline: none;
        border-color: var(--color-border-accent);
    }

    /* Remove number spinner arrows */
    .no-spin::-webkit-outer-spin-button,
    .no-spin::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    .no-spin { -moz-appearance: textfield; }

    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
    }

    .buff-checkbox {
        width: 16px;
        height: 16px;
        accent-color: var(--color-accent);
        cursor: pointer;
    }

    /* Results */
    .section-title {
        font-size: 14px;
        font-weight: 600;
        color: var(--color-text-primary);
        margin: 0;
    }

    .result-section {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .result-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 4px;
    }

    .result-building {
        font-size: 15px;
        font-weight: 600;
        color: var(--color-accent);
    }

    .result-range {
        font-size: 13px;
        color: var(--color-text-muted);
    }

    .resource-grid {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .resource-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 10px;
        background: var(--color-secondary);
        border-radius: var(--radius-sm);
        font-size: 13px;
    }

    .res-name {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--color-text-secondary);
    }

    .res-icon {
        width: 22px;
        height: 22px;
        object-fit: contain;
        border-radius: 2px;
    }

    .res-value {
        font-weight: 600;
        color: var(--color-text-primary);
        font-variant-numeric: tabular-nums;
    }

    .time-section {
        display: flex;
        flex-direction: column;
        gap: 6px;
        padding: 12px;
        background: var(--color-secondary);
        border-radius: var(--radius-md);
    }

    .time-row {
        display: flex;
        justify-content: space-between;
        font-size: 13px;
    }

    .time-label {
        color: var(--color-text-secondary);
    }

    .time-value {
        font-weight: 600;
        color: var(--color-text-primary);
    }

    .time-value.accent {
        color: var(--color-success);
    }

    .add-btn {
        padding: 8px 16px;
        background: var(--color-success-soft);
        color: var(--color-success);
        border: 1px solid rgba(52, 211, 153, 0.25);
        border-radius: var(--radius-md);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        align-self: flex-start;
        transition: all 0.15s ease;
    }

    .add-btn:hover {
        background: rgba(52, 211, 153, 0.2);
    }

    /* Accumulated */
    .accumulated-section {
        border-top: 1px solid var(--color-border);
        padding-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .accumulated-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header-actions {
        display: flex;
        gap: 6px;
    }

    .copy-total-btn {
        padding: 4px 12px;
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border: 1px solid var(--color-border-accent);
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.15s;
    }

    .copy-total-btn:hover { background: rgba(99, 102, 241, 0.2); }

    .clear-total-btn {
        padding: 4px 12px;
        background: var(--color-danger-soft);
        color: var(--color-danger);
        border: 1px solid rgba(248, 113, 113, 0.2);
        border-radius: var(--radius-sm);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
    }

    .accumulated-items {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .acc-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 10px;
        background: var(--color-secondary);
        border-radius: var(--radius-sm);
        font-size: 12px;
    }

    .acc-item-name {
        color: var(--color-text-primary);
    }

    .acc-range {
        color: var(--color-text-muted);
        font-size: 11px;
    }

    .remove-btn {
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        padding: 0 4px;
        transition: color 0.1s;
    }

    .remove-btn:hover {
        color: var(--color-danger);
    }

    .total-grid {
        border-top: 1px solid var(--color-border-accent);
        padding-top: 12px;
    }

    .loading-text, .empty-text, .placeholder-text {
        color: var(--color-text-muted);
        font-size: 13px;
        text-align: center;
        padding: 16px 0;
    }
</style>
