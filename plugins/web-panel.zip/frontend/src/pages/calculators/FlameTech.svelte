<script>
    import { onMount } from 'svelte';
    import { apiFetch, getBasePath } from '../../lib/api.js';
    import { showToast } from '../../lib/utils.js';
    import Select from '../../components/ui/Select.svelte';
    import SkillTree from '../../components/ui/SkillTree.svelte';
    import Modal from '../../components/ui/Modal.svelte';

    const TROOPS = [
        { id: 'infantry', label: 'Infantry' },
        { id: 'marksman', label: 'Marksman' },
        { id: 'lancer', label: 'Lancer' },
    ];

    const TIER_META = [
        { id: 'exalted', label: 'Exalted Gear', shortLabel: 'Gear', description: '5 gear upgrades, 5 levels each' },
        { id: 'tier_1', label: 'Tier 1: Molten I', shortLabel: 'T1', description: '4 molten stat skills, 20 levels each' },
        { id: 'tier_2', label: 'Tier 2: Core Skill', shortLabel: 'T2', description: '1 core skill, 3 levels' },
        { id: 'tier_3', label: 'Tier 3: Molten II', shortLabel: 'T3', description: '4 molten stat skills, 50 levels each' },
        { id: 'tier_4', label: 'Tier 4: Solar Skill', shortLabel: 'T4', description: '1 core skill, 15 levels' },
        { id: 'tier_5', label: 'Tier 5: Molten III', shortLabel: 'T5', description: '4 molten stat skills, 50 levels each' },
    ];

    const TROOP_LABELS = Object.fromEntries(TROOPS.map((troop) => [troop.id, troop.label]));
    const TIER_LABELS = Object.fromEntries(TIER_META.map((tier) => [tier.id, tier.label]));
    const RESOURCE_ORDER = ['steel', 'rfc', 'fcs', 'meat', 'wood', 'coal', 'iron'];
    const VP_OPTIONS = [
        { value: 0, label: 'Off' },
        { value: 10, label: '10%' },
        { value: 15, label: '15%' },
    ];

    const basePath = getBasePath();
    const CALCULATOR_IMAGE_BASE = basePath + '/images/calculators/resources';
    const T12_IMAGE_BASE = basePath + '/images/calculators/t12';
    const RESOURCE_IMAGES = {
        steel: CALCULATOR_IMAGE_BASE + '/Steel.png',
        rfc: CALCULATOR_IMAGE_BASE + '/Refined_fire-crystal.png',
        fcs: CALCULATOR_IMAGE_BASE + '/Fire_Crystal_Shard.png',
        meat: CALCULATOR_IMAGE_BASE + '/Meat.png',
        wood: CALCULATOR_IMAGE_BASE + '/Wood.png',
        coal: CALCULATOR_IMAGE_BASE + '/Coal.png',
        iron: CALCULATOR_IMAGE_BASE + '/Iron.png',
    };

    function loadSavedBuffs() {
        try {
            const saved = localStorage.getItem('calc_flametech_t12_buffs');
            if (saved) return JSON.parse(saved);
        } catch (_) {}
        return null;
    }

    function saveBuffs() {
        try {
            localStorage.setItem('calc_flametech_t12_buffs', JSON.stringify({ researchSpeed, vpBonus }));
        } catch (_) {}
    }

    let isLoading = $state(false);
    let data = $state(null);
    let activeTroop = $state('infantry');
    let selectedTier = $state('exalted');
    let selectedSkillId = $state('');
    let targetLevel = $state('');

    const savedBuffs = loadSavedBuffs();
    let researchSpeed = $state(savedBuffs?.researchSpeed ?? 0);
    let vpBonus = $state(savedBuffs?.vpBonus ?? 0);

    let currentLevelsByTroop = $state(createEmptyLevels());
    let accumulatedItems = $state([]);
    let isCalculatorModalOpen = $state(false);
    let isBuffsModalOpen = $state(false);
    let modalCurrentLevel = $state('');
    let modalTargetLevel = $state('');

    function createEmptyLevels() {
        return {
            infantry: {},
            marksman: {},
            lancer: {},
        };
    }

    let templates = $derived(data?.templates ?? {});
    let troopResearch = $derived(data?.troop_research ?? {});
    let resourceLabels = $derived(data?.cost_items ?? {});

    let troopTiers = $derived(troopResearch[activeTroop] ?? {});

    let tierSections = $derived.by(() =>
        TIER_META.map((tier) => {
            const rawEntry = troopTiers[tier.id];
            const skills = Array.isArray(rawEntry) ? rawEntry : rawEntry ? [rawEntry] : [];

            return {
                ...tier,
                skills,
            };
        })
    );

    let skillTreeTiers = $derived.by(() =>
        tierSections.map((section) => ({
            id: section.id,
            title: section.label,
            subtitle: section.description,
            nodes: section.skills.map((skill) => ({
                id: skill.id,
                name: skill.name,
                short: formatNodeGlyph(skill.stat),
                stat: formatStat(skill.stat),
                level: getDisplayedSkillLevel(activeTroop, skill.id),
                maxLevel: templates[skill.template]?.max_level ?? 0,
                ...getSkillTreeImageMeta(activeTroop, section.id, skill),
            })),
        }))
    );

    let selectedSection = $derived(
        tierSections.find((section) => section.id === selectedTier) ?? tierSections[0] ?? null
    );

    let selectedSkill = $derived.by(() => {
        if (!selectedSection) return null;

        const selectedFromAll = selectedSection.skills.find((skill) => skill.id === selectedSkillId);
        if (selectedFromAll) return selectedFromAll;
        return selectedSection.skills[0] ?? null;
    });

    let resolvedSkill = $derived(
        selectedSkill ? resolveSkill(selectedSkill, templates) : null
    );

    let currentLevel = $derived(
        selectedSkill ? getCurrentSkillLevel(activeTroop, selectedSkill.id) : 0
    );

    let levelOptions = $derived(
        resolvedSkill ? buildLevelOptions(resolvedSkill.max_level, modalCurrentLevel || currentLevel) : []
    );

    let targetLevelOptions = $derived(
        resolvedSkill ? buildTargetOptions(resolvedSkill.max_level, modalCurrentLevel || currentLevel) : []
    );

    let dependencyWarnings = $derived(
        resolvedSkill
            ? getDependencyWarnings(
                activeTroop,
                selectedTier,
                resolvedSkill,
                modalCurrentLevel || currentLevel,
                modalTargetLevel || targetLevel
            )
            : []
    );

    let modalResult = $derived.by(() => {
        if (!resolvedSkill) return null;

        const current = Number(modalCurrentLevel || currentLevel) || 0;
        const target = Number(modalTargetLevel || targetLevel) || 0;
        if (!target || target <= current) return null;

        const warnings = getDependencyWarnings(activeTroop, selectedTier, resolvedSkill, current, target);
        const totals = calculateUpgradeCost(resolvedSkill, current, target);

        return {
            troopId: activeTroop,
            troopLabel: TROOP_LABELS[activeTroop],
            tierId: selectedTier,
            tierLabel: TIER_LABELS[selectedTier],
            skillId: resolvedSkill.id,
            skillName: resolvedSkill.name,
            statLabel: formatStat(resolvedSkill.stat),
            fromLevel: current,
            toLevel: target,
            fromLabel: `Level ${current}`,
            toLabel: `Level ${target}`,
            cost: totals.cost,
            time_seconds: totals.time_seconds,
            buffed_time_seconds: getBuffedSeconds(totals.time_seconds),
            power: totals.power,
            warnings,
            currentBonus: getBonusAtLevel(resolvedSkill, current),
            targetBonus: getBonusAtLevel(resolvedSkill, target),
            buffGainLabel: getBuffGainLabel(resolvedSkill, current, target),
        };
    });

    let accumulatedTotal = $derived(computeTotal(accumulatedItems));

    function resolveSkill(skill, allTemplates) {
        const template = allTemplates?.[skill.template];
        return template
            ? {
                ...skill,
                max_level: template.max_level,
                levels: template.levels ?? [],
            }
            : null;
    }

    function getCurrentSkillLevel(troopId, skillId) {
        const troopLevels = currentLevelsByTroop[troopId] ?? {};
        return Number(troopLevels[skillId] ?? 0);
    }

    function getAccumulatedItem(troopId, skillId) {
        return accumulatedItems.find((item) => item.troopId === troopId && item.skillId === skillId) ?? null;
    }

    function getDisplayedSkillLevel(troopId, skillId) {
        const committedLevel = getCurrentSkillLevel(troopId, skillId);
        const accumulatedItem = getAccumulatedItem(troopId, skillId);
        const savedTargetLevel = Number(accumulatedItem?.toLevel) || 0;
        const baseDisplayLevel = savedTargetLevel > committedLevel ? savedTargetLevel : committedLevel;

        if (!isCalculatorModalOpen || selectedSkillId !== skillId) {
            return baseDisplayLevel;
        }

        const selectedTargetLevel = Number(modalTargetLevel || 0);
        return selectedTargetLevel > baseDisplayLevel ? selectedTargetLevel : baseDisplayLevel;
    }

    function setCurrentSkillLevel(troopId, skillId, level) {
        const parsedLevel = Number(level) || 0;
        currentLevelsByTroop = {
            ...currentLevelsByTroop,
            [troopId]: {
                ...(currentLevelsByTroop[troopId] ?? {}),
                [skillId]: parsedLevel,
            },
        };
    }

    function buildLevelOptions(maxLevel, currentOwnedLevel) {
        const options = [];
        for (let level = 0; level < maxLevel; level += 1) {
            options.push({
                value: String(level),
                label: level === currentOwnedLevel ? `Current ${level}` : `Level ${level}`,
            });
        }
        return options;
    }

    function buildTargetOptions(maxLevel, fromLevel) {
        const from = Number(fromLevel ?? 0);
        const options = [];
        for (let level = from + 1; level <= maxLevel; level += 1) {
            options.push({ value: String(level), label: `Level ${level}` });
        }
        return options;
    }

    function formatNumber(value) {
        if (!value) return '0';
        return Number(value).toLocaleString();
    }

    function formatDuration(totalSeconds) {
        const secondsValue = Number(totalSeconds) || 0;
        const days = Math.floor(secondsValue / 86400);
        let remainder = secondsValue % 86400;
        const hours = Math.floor(remainder / 3600);
        remainder %= 3600;
        const minutes = Math.floor(remainder / 60);

        const parts = [];
        if (days) parts.push(`${days}d`);
        if (hours) parts.push(`${hours}h`);
        if (minutes) parts.push(`${minutes}m`);

        return parts.length ? parts.join(' ') : '0m';
    }

    function formatStat(stat) {
        if (!stat) return 'Core';
        return stat
            .split('_')
            .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
            .join(' ');
    }

    function getSkillBuffLabel(skill) {
        return skill?.stat ? formatStat(skill.stat) : '';
    }

    function formatNodeGlyph(stat) {
        switch (stat) {
            case 'attack': return 'ATK';
            case 'defense': return 'DEF';
            case 'lethality': return 'LTH';
            case 'health': return 'HP';
            case 'deployment_capacity': return 'CAP';
            default: return 'CORE';
        }
    }

    function normalizeT12ImageId(skillId) {
        return skillId.replace(/_(?:i|ii|iii)$/i, '');
    }

    function getSkillTreeImageMeta(troopId, tierId, skill) {
        if (!troopId || !skill?.id) {
            return {
                imageMode: 'fallback',
                imageSrc: '',
            };
        }

        const imageId = tierId === 'exalted' ? skill.id : normalizeT12ImageId(skill.id);
        const imageMode = tierId === 'exalted' ? 'gear' : 'full';

        return {
            imageMode,
            imageSrc: `${T12_IMAGE_BASE}/${troopId}/${imageId}.png`,
        };
    }

    function getTierSkills(troopId, tierId) {
        const troop = troopResearch[troopId];
        if (!troop) return [];
        const entry = troop[tierId];
        return Array.isArray(entry) ? entry : entry ? [entry] : [];
    }

    function getTemplateRequirementName(troopId, templateId) {
        if (!troopId || !templateId) return templateId;

        const troop = troopResearch[troopId];
        if (!troop) return templateId;

        for (const tierId of Object.keys(troop)) {
            const skills = Array.isArray(troop[tierId]) ? troop[tierId] : [troop[tierId]];
            const match = skills.find((entry) => entry?.template === templateId);
            if (match?.name) return match.name;
        }

        return templateId;
    }

    function formatRequirementText(troopId, requirementText) {
        if (!requirementText) return '';

        return requirementText.replace(/([a-z0-9_]+)\s+Lv\.(\d+)/gi, (_, templateId, level) => {
            const label = getTemplateRequirementName(troopId, templateId);
            return `${label} Lv.${level}`;
        });
    }

    function getDependencyWarnings(troopId, tierId, skill, fromLevel, toLevel) {
        const warnings = [];
        const current = Number(fromLevel) || 0;
        const target = Number(toLevel) || 0;

        if (!target || target <= current) {
            return warnings;
        }

        if (tierId !== 'exalted') {
            const exaltedSkills = getTierSkills(troopId, 'exalted');
            const incompleteExalted = exaltedSkills.filter((entry) => getCurrentSkillLevel(troopId, entry.id) < 5);
            if (incompleteExalted.length > 0) {
                warnings.push('Research tiers unlock only after all 5 exalted gear pieces reach level 5.');
            }
        }

        if (tierId === 'tier_2') {
            const previousSkills = getTierSkills(troopId, 'tier_1');
            for (const levelData of skill.levels) {
                if (levelData.level <= current || levelData.level > target) continue;
                const required = levelData.requires_previous_group_level;
                if (!required) continue;
                const missing = previousSkills.filter((entry) => getCurrentSkillLevel(troopId, entry.id) < required);
                if (missing.length > 0) {
                    warnings.push(`Core level ${levelData.level} requires all Tier 1 skills at level ${required}.`);
                }
            }
        }

        for (const levelData of skill.levels) {
            if (levelData.level <= current || levelData.level > target) continue;
            if (levelData.requirement) {
                warnings.push(`Level ${levelData.level}: ${formatRequirementText(troopId, levelData.requirement)}`);
            }
            if (levelData.extra_requirement) {
                warnings.push(`Level ${levelData.level}: ${formatRequirementText(troopId, levelData.extra_requirement)}`);
            }
        }

        return [...new Set(warnings)];
    }

    function calculateUpgradeCost(skill, currentLevelValue, targetLevelValue) {
        const current = Number(currentLevelValue) || 0;
        const target = Number(targetLevelValue) || 0;

        const result = {
            cost: Object.fromEntries(RESOURCE_ORDER.map((resource) => [resource, 0])),
            time_seconds: 0,
            power: 0,
        };

        if (!skill || target <= current) {
            return result;
        }

        for (const levelData of skill.levels) {
            if (levelData.level <= current) continue;
            if (levelData.level > target) continue;

            for (const [resource, amount] of Object.entries(levelData.cost || {})) {
                result.cost[resource] = (result.cost[resource] || 0) + amount;
            }

            result.time_seconds += levelData.time_seconds || 0;
            result.power += levelData.power || 0;
        }

        return result;
    }

    function getBonusAtLevel(skill, levelValue) {
        const level = Number(levelValue) || 0;
        if (!skill || level <= 0) return null;
        const match = skill.levels.find((entry) => entry.level === level);
        if (!match) return null;

        if (match.bonus_percent !== undefined) {
            return `+${match.bonus_percent}% ${formatStat(skill.stat)}`;
        }
        if (match.bonus !== undefined) {
            return `+${formatNumber(match.bonus)} ${formatStat(skill.stat)}`;
        }
        return null;
    }

    function getBonusValueAtLevel(skill, levelValue) {
        const level = Number(levelValue) || 0;
        if (!skill || level <= 0) return null;

        const match = skill.levels.find((entry) => entry.level === level);
        if (!match) return null;

        if (match.bonus_percent !== undefined) {
            return { value: Number(match.bonus_percent) || 0, unit: '%', statLabel: formatStat(skill.stat) };
        }

        if (match.bonus !== undefined) {
            return { value: Number(match.bonus) || 0, unit: 'flat', statLabel: formatStat(skill.stat) };
        }

        return null;
    }

    function getBuffGainLabel(skill, fromLevelValue, toLevelValue) {
        const fromBonus = getBonusValueAtLevel(skill, fromLevelValue);
        const toBonus = getBonusValueAtLevel(skill, toLevelValue);
        if (!toBonus) return '';

        const fromValue = fromBonus?.value || 0;
        const gain = toBonus.value - fromValue;
        if (gain <= 0) return '';

        if (toBonus.unit === '%') {
            return `+${gain}% ${toBonus.statLabel}`;
        }

        return `+${formatNumber(gain)} ${toBonus.statLabel}`;
    }

    function computeTotal(items) {
        const total = {
            cost: Object.fromEntries(RESOURCE_ORDER.map((resource) => [resource, 0])),
            time_seconds: 0,
            buffed_time_seconds: 0,
            power: 0,
        };

        for (const item of items) {
            for (const resource of RESOURCE_ORDER) {
                total.cost[resource] += item.cost?.[resource] || 0;
            }
            total.time_seconds += item.time_seconds || 0;
            total.power += item.power || 0;
        }

        total.buffed_time_seconds = getBuffedSeconds(total.time_seconds);

        return total;
    }

    function getBuffedSeconds(seconds) {
        const speedBonus = (Number(researchSpeed) || 0) + (Number(vpBonus) || 0);
        if (!speedBonus || seconds <= 0) return seconds;
        return Math.ceil(seconds / (1 + speedBonus / 100));
    }

    function buildCopyText(items, total) {
        const lines = [];

        lines.push('- Upgrades');
        for (const item of items) {
            lines.push(`  - ${item.skillName} (${item.fromLabel} → ${item.toLabel})`);
            if (item.buffGainLabel) {
                lines.push(`    - Buff: ${item.buffGainLabel}`);
            }
        }

        lines.push('- Required Resources');
        for (const resource of RESOURCE_ORDER) {
            const amount = total.cost[resource];
            if (amount > 0) {
                lines.push(`  - ${resourceLabels[resource] || resource}: ${formatNumber(amount)}`);
            }
        }

        lines.push('- Time Required');
        lines.push(`  - Original: ${formatDuration(total.time_seconds)}`);
        lines.push(`  - With Buffs: ${formatDuration(total.buffed_time_seconds)}`);
        lines.push('- Power gained');
        lines.push(`  - ${formatNumber(total.power)}`);

        return lines.join('\n');
    }

    async function loadData() {
        if (data) return;
        isLoading = true;
        try {
            const response = await apiFetch('/api/calculators/flametech/t12');
            if (response) {
                data = response;
                initializeCurrentLevels(response);
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    function initializeCurrentLevels(dataset) {
        if (!dataset?.troop_research) return;

        const nextLevels = createEmptyLevels();
        for (const troopId of Object.keys(dataset.troop_research)) {
            const troop = dataset.troop_research[troopId];
            for (const tierId of Object.keys(troop)) {
                const skills = Array.isArray(troop[tierId]) ? troop[tierId] : [troop[tierId]];
                for (const skill of skills) {
                    if (skill?.id) nextLevels[troopId][skill.id] = 0;
                }
            }
        }
        currentLevelsByTroop = nextLevels;
    }

    function syncSelectedSkill() {
        if (!selectedSection) {
            selectedSkillId = '';
            targetLevel = '';
            return;
        }

        const stillVisible = selectedSection.skills.some((skill) => skill.id === selectedSkillId);
        if (!stillVisible) {
            selectedSkillId = selectedSection.skills[0]?.id || '';
            targetLevel = '';
        }
    }

    function switchTroop(troopId) {
        activeTroop = troopId;
        selectedTier = 'exalted';
        selectedSkillId = '';
        targetLevel = '';
        isCalculatorModalOpen = false;
        modalCurrentLevel = '';
        modalTargetLevel = '';
        syncSelectedSkill();
    }

    function handleTreeSelect({ tier, node }) {
        if (!tier || !node) return;
        selectedTier = tier.id;
        selectedSkillId = node.id;
        targetLevel = '';
        const existingItem = getAccumulatedItem(activeTroop, node.id);
        modalCurrentLevel = String(existingItem?.fromLevel ?? getCurrentSkillLevel(activeTroop, node.id));
        modalTargetLevel = existingItem ? String(existingItem.toLevel) : '';
        isCalculatorModalOpen = true;
    }

    function handleCurrentLevelChange(value) {
        if (!selectedSkill) return;
        const nextCurrentLevel = Number(value) || 0;
        modalCurrentLevel = String(nextCurrentLevel);

        const currentTargetLevel = Number(modalTargetLevel || targetLevel) || 0;
        if (!currentTargetLevel) return;

        if (nextCurrentLevel >= currentTargetLevel) {
            const nextValidTarget = nextCurrentLevel + 1;
            const maxLevel = Number(resolvedSkill?.max_level) || 0;
            modalTargetLevel = nextValidTarget <= maxLevel ? String(nextValidTarget) : '';
        }
    }

    function closeCalculatorModal() {
        isCalculatorModalOpen = false;
        modalCurrentLevel = '';
        modalTargetLevel = '';
    }

    function addItemToAccumulated(result) {
        if (!result) {
            showToast('Please select a target level', 'info');
            return;
        }

        const itemKey = `${result.troopId}|${result.skillId}`;
        const existingIndex = accumulatedItems.findIndex((item) =>
            `${item.troopId}|${item.skillId}` === itemKey
        );

        if (existingIndex !== -1) {
            accumulatedItems = accumulatedItems.map((item, index) =>
                index === existingIndex ? { ...result } : item
            );
            showToast(`${result.skillName} updated in total`, 'info');
        } else {
            accumulatedItems = [...accumulatedItems, { ...result }];
            showToast(`${result.skillName} added to total`, 'success');
        }
    }

    function handleAddTotalFromModal() {
        if (!modalResult) {
            showToast('Please select a target level', 'info');
            return;
        }

        if (selectedSkill) {
            setCurrentSkillLevel(activeTroop, selectedSkill.id, modalResult.fromLevel);
        }
        addItemToAccumulated(modalResult);
        closeCalculatorModal();
    }

    function handleConfirmModal() {
        if (!modalResult) {
            showToast('Please select a target level', 'info');
            return;
        }

        if (selectedSkill) {
            setCurrentSkillLevel(activeTroop, selectedSkill.id, modalResult.fromLevel);
        }
        closeCalculatorModal();
    }

    function removeFromTotal(index) {
        accumulatedItems = accumulatedItems.filter((_, itemIndex) => itemIndex !== index);
    }

    function clearTotal() {
        accumulatedItems = [];
    }

    async function copyTotal() {
        if (accumulatedItems.length === 0) {
            showToast('Nothing to copy', 'info');
            return;
        }

        try {
            await navigator.clipboard.writeText(buildCopyText(accumulatedItems, accumulatedTotal));
            showToast('Copied to clipboard!', 'success');
        } catch (_) {
            showToast('Failed to copy', 'error');
        }
    }

    function onBuffChange() {
        saveBuffs();
    }

    $effect(() => {
        syncSelectedSkill();
    });

    onMount(loadData);
</script>

<div class="flametech-calc">
    <div class="calc-panel left-panel">
        <div class="toolbar-row">
            <div class="troop-tabs">
                {#each TROOPS as troop (troop.id)}
                    <button
                        class="troop-tab"
                        class:active={activeTroop === troop.id}
                        onclick={() => switchTroop(troop.id)}
                    >
                        {troop.label}
                    </button>
                {/each}
            </div>

            <button class="buffs-trigger" onclick={() => isBuffsModalOpen = true}>Buffs</button>
        </div>

        {#if isLoading}
            <div class="loading-text">Loading T12 research...</div>
        {:else if data}
            <SkillTree
                tiers={skillTreeTiers}
                selectedNodeId={selectedSkillId}
                selectedTierId={selectedTier}
                onselect={handleTreeSelect}
            />
        {:else}
            <div class="empty-text">T12 data is not available yet.</div>
        {/if}
    </div>

    <div class="calc-panel right-panel">
        {#if accumulatedItems.length > 0}
            <div class="accumulated-section">
                <div class="accumulated-header">
                    <h3 class="section-title">Accumulated Total</h3>
                    <div class="header-actions">
                        <button class="copy-total-btn" onclick={copyTotal}>Copy</button>
                        <button class="clear-total-btn" onclick={clearTotal}>Clear All</button>
                    </div>
                </div>

                <div class="accumulated-items">
                    {#each accumulatedItems as item, index (`${item.troopId}|${item.skillId}`)}
                        <div class="acc-item">
                            <span class="acc-item-name">
                                {item.troopLabel} · {item.skillName}
                                <span class="acc-range">({item.fromLabel} -> {item.toLabel})</span>
                            </span>
                            <button class="remove-btn" onclick={() => removeFromTotal(index)}>×</button>
                        </div>
                    {/each}
                </div>

                <div class="resource-grid total-grid">
                    {#each RESOURCE_ORDER as resource (resource)}
                        {#if accumulatedTotal.cost[resource] > 0}
                            <div class="resource-row">
                                <span class="res-name">
                                    <img class="res-icon" src={RESOURCE_IMAGES[resource]} alt={resourceLabels[resource] || resource} />
                                    {resourceLabels[resource] || resource}
                                </span>
                                <span class="res-value">{formatNumber(accumulatedTotal.cost[resource])}</span>
                            </div>
                        {/if}
                    {/each}
                </div>

                <div class="time-section">
                    <div class="time-row">
                        <span class="time-label">Total Original Time</span>
                        <span class="time-value">{formatDuration(accumulatedTotal.time_seconds)}</span>
                    </div>
                    <div class="time-row">
                        <span class="time-label">Total With Buffs</span>
                        <span class="time-value accent">{formatDuration(accumulatedTotal.buffed_time_seconds)}</span>
                    </div>
                    <div class="time-row">
                        <span class="time-label">Total Power Gain</span>
                        <span class="time-value">{formatNumber(accumulatedTotal.power)}</span>
                    </div>
                </div>
            </div>
        {:else}
            <div class="placeholder-card">
                <h3 class="section-title">Accumulated Total</h3>
                <p class="placeholder-text">Tap a skill or gear node to calculate it in a popup, then add it to your total.</p>
            </div>
        {/if}
    </div>
</div>

<Modal
    bind:isOpen={isCalculatorModalOpen}
    title={resolvedSkill ? resolvedSkill.name : 'Upgrade'}
    onclose={closeCalculatorModal}
>
    {#if resolvedSkill}
        <div class="modal-content">
            <div class="selection-summary">
                <div>
                    <div class="selection-name">{resolvedSkill.name}</div>
                    {#if getSkillBuffLabel(resolvedSkill)}
                        <div class="selection-meta">{getSkillBuffLabel(resolvedSkill)}</div>
                    {/if}
                </div>
            </div>

            <div class="level-selectors">
                <div class="select-group">
                    <div class="select-label">Current</div>
                    <Select
                        class="level-select"
                        options={levelOptions}
                        value={modalCurrentLevel || String(currentLevel)}
                        onchange={handleCurrentLevelChange}
                    />
                </div>

                <div class="select-group">
                    <div class="select-label">Target</div>
                    <Select
                        class="level-select"
                        options={targetLevelOptions}
                        placeholder="Select level..."
                        bind:value={modalTargetLevel}
                        disabled={targetLevelOptions.length === 0}
                    />
                </div>
            </div>

            {#if dependencyWarnings.length > 0}
                <div class="warning-box">
                    <span class="warning-title">Manual checks needed</span>
                    {#each dependencyWarnings as warning (warning)}
                        <span class="warning-item">{warning}</span>
                    {/each}
                </div>
            {/if}

            {#if modalResult}
                {#if modalResult.currentBonus || modalResult.targetBonus}
                    <div class="bonus-strip">
                        <span>{modalResult.currentBonus || 'No current bonus'}</span>
                        <span>{modalResult.targetBonus || 'No target bonus'}</span>
                    </div>
                {/if}

                <div class="modal-summary-box">
                    <div class="resource-grid resource-grid-modal">
                        {#each RESOURCE_ORDER as resource (resource)}
                            {#if modalResult.cost[resource] > 0}
                                <div class="resource-row">
                                    <span class="res-name">
                                        <img class="res-icon" src={RESOURCE_IMAGES[resource]} alt={resourceLabels[resource] || resource} />
                                        {resourceLabels[resource] || resource}
                                    </span>
                                    <span class="res-value">{formatNumber(modalResult.cost[resource])}</span>
                                </div>
                            {/if}
                        {/each}
                    </div>

                    <div class="time-section">
                        <div class="time-row">
                            <span class="time-label">Original Time</span>
                            <span class="time-value">{formatDuration(modalResult.time_seconds)}</span>
                        </div>
                        <div class="time-row">
                            <span class="time-label">With Buffs</span>
                            <span class="time-value accent">{formatDuration(modalResult.buffed_time_seconds)}</span>
                        </div>
                        <div class="time-row">
                            <span class="time-label">Power Gain</span>
                            <span class="time-value">{formatNumber(modalResult.power)}</span>
                        </div>
                    </div>
                </div>
            {:else}
                <p class="placeholder-text">Choose a target level to preview the upgrade cost and time.</p>
            {/if}

            <div class="modal-actions">
                <button class="modal-btn" onclick={closeCalculatorModal}>Close</button>
                <button class="modal-btn modal-btn-success" onclick={handleAddTotalFromModal} disabled={!modalResult}>Add Total</button>
                <button class="modal-btn modal-btn-primary" onclick={handleConfirmModal} disabled={!modalResult}>OK</button>
            </div>
        </div>
    {/if}
</Modal>

<Modal
    bind:isOpen={isBuffsModalOpen}
    title="Buffs"
    onclose={() => isBuffsModalOpen = false}
>
    <div class="buffs-modal-content">
        <div class="buff-row">
            <div class="buff-label">VP</div>
            <Select
                class="buff-select"
                options={VP_OPTIONS}
                bind:value={vpBonus}
                onchange={onBuffChange}
            />
        </div>
        <div class="buff-row">
            <label class="buff-label" for="flametech-speed">Research Speed %</label>
            <input
                id="flametech-speed"
                type="number"
                min="0"
                max="999"
                step="0.1"
                inputmode="decimal"
                class="buff-input no-spin"
                bind:value={researchSpeed}
                onchange={onBuffChange}
                onblur={() => {
                    const parsed = parseFloat(researchSpeed);
                    researchSpeed = Number.isNaN(parsed) ? 0 : Math.min(999, Math.max(0, parsed));
                    onBuffChange();
                }}
            />
        </div>
        <div class="modal-actions">
            <button class="modal-btn modal-btn-primary" onclick={() => isBuffsModalOpen = false}>Done</button>
        </div>
    </div>
</Modal>

<style>
    .flametech-calc {
        display: grid;
        grid-template-columns: minmax(320px, 0.95fr) minmax(360px, 1.05fr);
        gap: 20px;
        align-items: start;
    }

    .calc-panel {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: 8px;
        padding: 18px;
        display: flex;
        flex-direction: column;
        gap: 16px;
        min-height: 0;
    }

    .toolbar-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
    }

    .troop-tabs {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        flex: 1;
    }

    .troop-tab,
    .buffs-trigger,
    .copy-total-btn,
    .clear-total-btn,
    .remove-btn {
        cursor: pointer;
        transition: all 0.15s ease;
    }

    .troop-tab {
        padding: 8px 14px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 13px;
        font-weight: 600;
    }

    .troop-tab:hover,
    .troop-tab.active {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }

    .buffs-trigger {
        padding: 8px 12px;
        border-radius: var(--radius-sm);
        border: 1px solid var(--color-border);
        background: transparent;
        color: var(--color-text-secondary);
        font-size: 13px;
        font-weight: 600;
        white-space: nowrap;
    }

    .buffs-trigger:hover {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }

    .accumulated-header,
    .time-row,
    .resource-row,
    .selection-summary,
    .acc-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
    }

    .selection-name {
        color: var(--color-text-primary);
        font-weight: 600;
    }

    .selection-meta,
    .acc-range,
    .time-label,
    .res-name,
    .empty-text,
    .loading-text,
    .placeholder-text {
        color: var(--color-text-muted);
    }

    .section-title {
        font-size: 14px;
        font-weight: 600;
        color: var(--color-text-primary);
        margin: 0;
    }

    .selection-summary,
    .warning-box,
    .time-section,
    .accumulated-section,
    .placeholder-card {
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
    }

    .selection-summary,
    .warning-box,
    .time-section,
    .accumulated-section,
    .placeholder-card {
        padding: 14px;
    }

    .level-selectors {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
    }

    .select-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .select-label,
    .buff-label {
        font-size: 12px;
        color: var(--color-text-secondary);
    }

    .warning-box {
        gap: 6px;
        display: flex;
        flex-direction: column;
        background: var(--color-warning-soft);
        border-color: rgba(251, 191, 36, 0.25);
    }

    .warning-title {
        color: var(--color-warning);
        font-weight: 600;
        font-size: 13px;
    }

    .warning-item {
        color: var(--color-warning);
        font-size: 12px;
        opacity: 0.9;
    }

    .modal-content,
    .resource-grid,
    .buffs-modal-content,
    .accumulated-section,
    .placeholder-card {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .bonus-strip {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
        font-size: 12px;
        color: var(--color-text-secondary);
    }

    .bonus-strip span {
        padding: 8px 10px;
        border-radius: var(--radius-sm);
        background: rgba(255, 255, 255, 0.03);
    }

    .modal-summary-box {
        display: flex;
        flex-direction: column;
        gap: 12px;
        padding: 12px;
        border: 1px solid rgba(99, 102, 241, 0.22);
        border-radius: var(--radius-md);
        background: rgba(9, 11, 24, 0.18);
        box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.03),
            0 12px 28px rgba(0, 0, 0, 0.16);
    }

    .resource-grid-modal {
        padding: 6px;
        border-radius: var(--radius-md);
        background: rgba(255, 255, 255, 0.02);
    }

    .resource-row {
        padding: 8px 10px;
        background: var(--color-card);
        border-radius: var(--radius-sm);
        font-size: 13px;
    }

    .res-name {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .res-icon {
        width: 20px;
        height: 20px;
        object-fit: contain;
        border-radius: 2px;
    }

    .res-value,
    .time-value {
        color: var(--color-text-primary);
        font-weight: 600;
        font-variant-numeric: tabular-nums;
    }

    .time-value.accent {
        color: var(--color-success);
    }

    .modal-summary-box .time-section {
        background: rgba(255, 255, 255, 0.02);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.03);
    }

    .modal-actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
        flex-wrap: wrap;
    }

    .modal-btn {
        padding: 8px 14px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--color-card);
        color: var(--color-text-primary);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.15s ease;
    }

    .modal-btn:hover:not(:disabled) {
        background: rgba(255, 255, 255, 0.05);
    }

    .modal-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    .modal-btn-primary {
        border-color: transparent;
        background: var(--color-accent);
        color: white;
    }

    .modal-btn-primary:hover:not(:disabled) {
        background: var(--color-accent-hover);
    }

    .modal-btn-success {
        border: 1px solid rgba(52, 211, 153, 0.24);
        background: var(--color-success-soft);
        color: var(--color-success);
    }

    .modal-btn-success:hover:not(:disabled) {
        background: rgba(52, 211, 153, 0.18);
    }

    .buff-row,
    .header-actions {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
    }

    .buff-row {
        padding: 12px 14px;
        border: 1px solid rgba(99, 102, 241, 0.18);
        border-radius: var(--radius-md);
        background:
            linear-gradient(180deg, rgba(255, 255, 255, 0.025), rgba(255, 255, 255, 0.01)),
            var(--color-secondary);
        box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.03),
            0 10px 22px rgba(0, 0, 0, 0.12);
    }

    .buff-input {
        width: 132px;
        max-width: 100%;
        direction: ltr;
        unicode-bidi: plaintext;
        text-align: left;
        padding: 10px 12px;
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        color: var(--color-text-primary);
        font-size: 13px;
        font-weight: 600;
        font-variant-numeric: tabular-nums;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.03);
        transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
    }

    .buff-input:hover,
    .buff-input:focus {
        border-color: var(--color-border-accent);
        outline: none;
        background: rgba(255, 255, 255, 0.03);
        box-shadow:
            0 0 0 3px rgba(99, 102, 241, 0.12),
            inset 0 1px 0 rgba(255, 255, 255, 0.04);
    }

    .buffs-modal-content {
        min-width: min(100%, 320px);
        gap: 14px;
    }

    .buff-label {
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.02em;
        text-transform: uppercase;
        color: var(--color-text-primary);
    }

    .copy-total-btn,
    .clear-total-btn {
        padding: 6px 10px;
        border-radius: var(--radius-sm);
        border: 1px solid transparent;
        font-size: 12px;
        font-weight: 600;
    }

    .copy-total-btn {
        background: var(--color-accent-soft);
        color: var(--color-accent);
        border-color: var(--color-border-accent);
    }

    .clear-total-btn {
        background: var(--color-danger-soft);
        color: var(--color-danger);
        border-color: rgba(248, 113, 113, 0.25);
    }

    .accumulated-items {
        display: flex;
        flex-direction: column;
        gap: 6px;
        max-height: 278px;
        overflow-y: auto;
        padding-right: 4px;
        scrollbar-gutter: stable;
    }

    .accumulated-items::-webkit-scrollbar {
        width: 8px;
    }

    .accumulated-items::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.03);
        border-radius: 999px;
    }

    .accumulated-items::-webkit-scrollbar-thumb {
        background: rgba(99, 102, 241, 0.35);
        border-radius: 999px;
    }

    .accumulated-items::-webkit-scrollbar-thumb:hover {
        background: rgba(99, 102, 241, 0.48);
    }

    .acc-item-name {
        display: flex;
        align-items: baseline;
        gap: 4px;
        flex-wrap: wrap;
        min-width: 0;
    }

    .acc-item {
        position: relative;
        padding: 8px 10px;
        border-radius: var(--radius-sm);
        background: var(--color-card);
        font-size: 12px;
    }

    .remove-btn {
        width: 24px;
        height: 24px;
        border-radius: 999px;
        border: none;
        background: transparent;
        color: var(--color-text-muted);
        font-size: 16px;
        line-height: 1;
    }

    .remove-btn:hover {
        color: var(--color-danger);
        background: rgba(248, 113, 113, 0.08);
    }

    .empty-text,
    .loading-text,
    .placeholder-text {
        font-size: 13px;
        text-align: center;
        padding: 8px;
    }

    :global(.buff-select .select-trigger),
    :global(.level-select .select-trigger) {
        background: var(--color-card);
    }

    :global(.buff-select .select-trigger) {
        min-width: 132px;
        min-height: 42px;
        padding: 0 12px;
        border-radius: var(--radius-md);
        border-color: rgba(99, 102, 241, 0.2);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.03);
        font-weight: 600;
        color: var(--color-text-primary);
        transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
    }

    :global(.buff-select .select-trigger:hover),
    :global(.buff-select .select-trigger:focus-visible) {
        border-color: var(--color-border-accent);
        background: rgba(255, 255, 255, 0.03);
        box-shadow:
            0 0 0 3px rgba(99, 102, 241, 0.12),
            inset 0 1px 0 rgba(255, 255, 255, 0.04);
    }

    @media (max-width: 1080px) {
        .flametech-calc {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 640px) {
        .calc-panel {
            padding: 14px;
        }

        .level-selectors,
        .bonus-strip {
            grid-template-columns: 1fr;
        }

        .selection-summary,
        .accumulated-header,
        .buff-row {
            align-items: flex-start;
            flex-direction: column;
        }

        .acc-item {
            align-items: flex-start;
            padding-right: 42px;
        }

        .acc-item-name {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 2px;
            max-width: 100%;
        }

        .acc-range {
            display: block;
        }

        .remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
        }

        .buff-input,
        :global(.buff-select .select-trigger) {
            width: 100%;
            min-width: 0;
        }

        .toolbar-row {
            align-items: stretch;
        }

        .buffs-trigger {
            width: 100%;
        }

        .header-actions {
            width: 100%;
            justify-content: flex-start;
            flex-wrap: wrap;
        }

        .modal-actions {
            flex-direction: column;
        }

        .modal-btn {
            width: 100%;
        }
    }
</style>
