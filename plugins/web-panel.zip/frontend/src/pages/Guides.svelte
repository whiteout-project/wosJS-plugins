<script>
    import { onDestroy, onMount, tick } from 'svelte';
    import { apiFetch, apiUpload, getBasePath } from '../lib/api.js';
    import { immersivePage, selectedGameType } from '../lib/stores.js';
    import { showToast } from '../lib/utils.js';
    import { PERMS } from '../lib/constants.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import Select from '../components/ui/Select.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import Icon from '../components/ui/Icon.svelte';

    const BLOCK_TYPE_OPTIONS = [
        { value: 'heading', label: 'Heading' },
        { value: 'text', label: 'Text' },
        { value: 'image', label: 'Image' },
        { value: 'button', label: 'Button / Link' },
        { value: 'divider', label: 'Divider' },
        { value: 'collapsible', label: 'Collapsible Section' },
        { value: 'table', label: 'Table' },
        { value: 'table_of_contents', label: 'Table of Contents' },
    ];

    const PICKABLE_BLOCK_TYPE_OPTIONS = [
        { value: 'heading', label: 'Heading', description: 'Large section titles and subheads.', eyebrow: 'Structure' },
        { value: 'text', label: 'Text', description: 'Paragraphs, bullet points, and inline links.', eyebrow: 'Writing' },
        { value: 'image', label: 'Image', description: 'Visuals with optional caption and size.', eyebrow: 'Media' },
        { value: 'table', label: 'Table', description: 'Structured rows and columns for plans or stats.', eyebrow: 'Data' },
        { value: 'table_of_contents', label: 'Table of contents', description: 'Auto-build jump links from your headings.', eyebrow: 'Navigation' },
        { value: 'divider', label: 'Divider', description: 'A horizontal break between sections.', eyebrow: 'Spacing' },
    ];

    const STATUS_LABELS = {
        draft: 'Draft',
        published: 'Published',
        unpublished: 'Unpublished',
        archived: 'Archived',
    };

    const GUIDE_ACCESS_OPTIONS = [
        { value: 'public', label: 'None' },
        { value: 'password', label: 'Password' },
        { value: 'discord_bot_user', label: 'Discord + Bot User' },
        { value: 'discord_mutual_guild', label: 'Discord + Shared Server' },
    ];

    const GUIDE_TABS = {
        active: 'active',
        archived: 'archived',
    };

    let guideList = $state([]);
    let selectedGuideTab = $state(GUIDE_TABS.active);
    let selectedGuideId = $state('');
    let contentGuideId = $state('');
    let detail = $state(null);
    let isLoadingList = $state(true);
    let isLoadingDetail = $state(false);
    let isCreatingGuide = $state(false);
    let isSavingMeta = $state(false);
    let isSavingAssignments = $state(false);
    let actionGuideId = $state('');
    let showCreateModal = $state(false);
    let showBlockModal = $state(false);
    let showAssignmentsModal = $state(false);
    let showAssigneeMenu = $state(false);
    let showWorkspaceActionMenu = $state(false);
    let workspaceActionMenuRef = $state();
    let openBlockActionMenuId = $state('');
    let selectedBlockId = $state('');
    let createForm = $state(createEmptyGuideCreateForm());
    let blockForm = $state(createEmptyBlockForm());
    let editingBlockId = $state('');
    let assignableAdmins = $state([]);
    let selectedAssigneeUserIds = $state([]);
    let isLoadingAssignableAdmins = $state(false);
    let blockMutationId = $state('');
    let inlineDrafts = $state({});
    let isUploadingImage = $state(false);
    let isImageDropActive = $state(false);
    let imageUploadInput = $state();
    let tempImagePreviewUrl = $state('');
    let tableDraftHeaders = $state([]);
    let tableDraftRows = $state([]);
    let tablePickerHoverColumns = $state(0);
    let tablePickerHoverRows = $state(0);
    let tableInlineDrafts = $state({});
    let guideGuildOptions = $state([]);
    let isLoadingGuideGuildOptions = $state(false);
    let contentHeadingEntries = $derived(getBlockHeadingEntries(detail?.blocks || []));
    let activeGuideCount = $derived(guideList.filter((guide) => guide.status !== 'archived').length);
    let archivedGuideCount = $derived(guideList.filter((guide) => guide.status === 'archived').length);
    let guideStatusOptions = $derived([
        { value: GUIDE_TABS.active, label: `Active (${activeGuideCount})` },
        { value: GUIDE_TABS.archived, label: `Archived (${archivedGuideCount})` },
    ]);
    let visibleGuides = $derived(
        guideList.filter((guide) => (
            selectedGuideTab === GUIDE_TABS.archived
                ? guide.status === 'archived'
                : guide.status !== 'archived'
        ))
    );

    const basePath = getBasePath();
    const inlineSaveTimers = new Map();
    const inlineEditorRefs = new Map();
    let guideAccessPasswordDraft = $state('');
    let previousGameType = null;

    onMount(() => {
        void loadGuides();

        const workspaceGuideId = getImmersiveGuideId($immersivePage);
        if (workspaceGuideId) {
            contentGuideId = workspaceGuideId;
            void loadGuideDetail(workspaceGuideId);
        }

        const handleWorkspaceActionMenuPointerDown = (event) => {
            if (!showWorkspaceActionMenu) return;
            if (workspaceActionMenuRef?.contains(event.target)) return;
            showWorkspaceActionMenu = false;
        };

        window.addEventListener('paste', handleGuideImagePaste);
        document.addEventListener('pointerdown', handleWorkspaceActionMenuPointerDown);

        return () => {
            window.removeEventListener('paste', handleGuideImagePaste);
            document.removeEventListener('pointerdown', handleWorkspaceActionMenuPointerDown);
        };
    });

    onDestroy(() => {
        showAssigneeMenu = false;
        showWorkspaceActionMenu = false;
        for (const timer of inlineSaveTimers.values()) {
            clearTimeout(timer);
        }
        inlineSaveTimers.clear();
        clearTempImagePreview();
    });

    $effect(() => {
        const gameType = $selectedGameType;
        if (!gameType) return;

        if (previousGameType === null) {
            previousGameType = gameType;
            return;
        }

        if (previousGameType !== gameType) {
            previousGameType = gameType;
            selectedGuideId = '';
            contentGuideId = '';
            detail = null;
            guideList = [];
            if ($immersivePage?.startsWith('guides-content:')) {
                immersivePage.set('');
            }
            void loadGuides();
        }
    });

    $effect(() => {
        if (!showBlockModal && tempImagePreviewUrl) {
            clearTempImagePreview();
        }
    });

    $effect(() => {
        if (!showBlockModal) return;
        if (blockForm.blockType !== 'table') return;
        if (blockForm.tableHeaders || blockForm.tableRows) return;
        if (tableDraftHeaders.length && tableDraftRows.length) return;
        const draft = createEmptyTableDraft();
        setTableDraft(draft.headers, draft.rows);
    });

    $effect(() => {
        const createNeedsGuilds = showCreateModal && createForm.accessMode === 'discord_mutual_guild';
        const detailNeedsGuilds = showAssignmentsModal && detail?.accessMode === 'discord_mutual_guild';
        if ((createNeedsGuilds || detailNeedsGuilds) && !guideGuildOptions.length && !isLoadingGuideGuildOptions) {
            void loadGuideGuildOptions();
        }
    });

    function createEmptyBlockForm() {
        return {
            blockType: 'text',
            headingText: '',
            headingLevel: '2',
            textContent: '',
            imageSource: 'url',
            imageAssetId: '',
            imageUrl: '',
            imageAlt: '',
            imageCaption: '',
            imageWidth: '100',
            buttonLabel: '',
            buttonUrl: '',
            buttonStyle: 'primary',
            collapsibleTitle: '',
            collapsibleContent: '',
            tableHeaders: '',
            tableRows: '',
            tocTitle: '',
        };
    }

    function createEmptyGuideCreateForm() {
        return {
            title: '',
            summary: '',
            accessMode: 'public',
            accessPassword: '',
            accessGuildId: '',
        };
    }

    function getGuideAccessHelpText(mode) {
        if (mode === 'public') {
            return 'No security. Anyone with the link can open this guide directly.';
        }
        if (mode === 'password') {
            return 'Readers must enter a password before the guide content is shown.';
        }
        if (mode === 'discord_bot_user') {
            return 'Readers must log in with Discord and already be a bot user.';
        }
        if (mode === 'discord_mutual_guild') {
            return 'Readers must log in with Discord and be in the selected server with the bot.';
        }
        return 'No security. Anyone with the link can open this guide directly.';
    }

    function createEmptyTableDraft(columnCount = 3, rowCount = 2) {
        const safeColumnCount = Math.max(1, columnCount);
        const safeRowCount = Math.max(1, rowCount);
        return {
            headers: Array.from({ length: safeColumnCount }, (_, index) => `Column ${index + 1}`),
            rows: Array.from({ length: safeRowCount }, () => Array.from({ length: safeColumnCount }, () => '')),
        };
    }

    function cloneTableRows(rows, columnCount) {
        return (rows || []).map((row) => Array.from({ length: columnCount }, (_, index) => row?.[index] || ''));
    }

    function setTableDraft(nextHeaders, nextRows) {
        tableDraftHeaders = [...nextHeaders];
        tableDraftRows = cloneTableRows(nextRows, tableDraftHeaders.length || 1);
        syncTableFormFromDraft();
    }

    function syncTableDraftFromPayload(headersInput = [], rowsInput = []) {
        const normalizedHeaders = Array.isArray(headersInput)
            ? headersInput.map((header, index) => String(header || '').trim() || `Column ${index + 1}`)
            : [];
        const normalizedRows = Array.isArray(rowsInput) ? rowsInput : [];
        const columnCount = Math.max(
            normalizedHeaders.length,
            ...normalizedRows.map((row) => (Array.isArray(row) ? row.length : 0)),
            2,
        );
        const headers = Array.from({ length: columnCount }, (_, index) => normalizedHeaders[index] || `Column ${index + 1}`);
        const rows = normalizedRows.length
            ? normalizedRows.map((row) => Array.from({ length: columnCount }, (_, index) => String(row?.[index] || '')))
            : createEmptyTableDraft(columnCount, 2).rows;
        setTableDraft(headers, rows);
    }

    function syncTableDraftFromStrings(headersText = '', rowsText = '') {
        const headers = parseTableTextLine(headersText);
        const rows = String(rowsText || '')
            .replace(/\r\n/g, '\n')
            .split('\n')
            .map((line) => parseTableTextLine(line))
            .filter((row) => row.length > 0);
        syncTableDraftFromPayload(headers, rows);
    }

    function syncTableFormFromDraft() {
        blockForm.tableHeaders = tableDraftHeaders.join(' | ');
        blockForm.tableRows = tableDraftRows
            .map((row) => row.map((cell) => String(cell || '').trim()).join(' | '))
            .filter((row) => row.trim().length > 0)
            .join('\n');
    }

    function updateTableHeaderCell(index, value) {
        const nextHeaders = [...tableDraftHeaders];
        nextHeaders[index] = value;
        setTableDraft(nextHeaders, tableDraftRows);
    }

    function updateTableRowCell(rowIndex, columnIndex, value) {
        const nextRows = tableDraftRows.map((row, currentRowIndex) => (
            currentRowIndex === rowIndex
                ? row.map((cell, currentColumnIndex) => (currentColumnIndex === columnIndex ? value : cell))
                : [...row]
        ));
        setTableDraft(tableDraftHeaders, nextRows);
    }

    function addTableColumn() {
        const nextHeaders = [...tableDraftHeaders, `Column ${tableDraftHeaders.length + 1}`];
        const nextRows = tableDraftRows.map((row) => [...row, '']);
        setTableDraft(nextHeaders, nextRows);
    }

    function removeTableColumn(columnIndex) {
        if (tableDraftHeaders.length <= 1) return;
        const nextHeaders = tableDraftHeaders.filter((_, index) => index !== columnIndex);
        const nextRows = tableDraftRows.map((row) => row.filter((_, index) => index !== columnIndex));
        setTableDraft(nextHeaders, nextRows);
    }

    function addTableRow() {
        setTableDraft(tableDraftHeaders, [
            ...tableDraftRows,
            Array.from({ length: tableDraftHeaders.length || 1 }, () => ''),
        ]);
    }

    function removeTableRow(rowIndex) {
        if (tableDraftRows.length <= 1) return;
        setTableDraft(
            tableDraftHeaders,
            tableDraftRows.filter((_, index) => index !== rowIndex),
        );
    }

    function resizeTableDraft(rowCount, columnCount) {
        const safeColumnCount = Math.max(1, Number(columnCount) || 1);
        const safeRowCount = Math.max(1, Number(rowCount) || 1);
        const nextHeaders = Array.from({ length: safeColumnCount }, (_, index) => tableDraftHeaders[index] || `Column ${index + 1}`);
        const nextRows = Array.from({ length: safeRowCount }, (_, rowIndex) => (
            Array.from({ length: safeColumnCount }, (_, columnIndex) => tableDraftRows[rowIndex]?.[columnIndex] || '')
        ));
        setTableDraft(nextHeaders, nextRows);
    }

    function setTablePickerPreview(rowCount, columnCount) {
        tablePickerHoverRows = rowCount;
        tablePickerHoverColumns = columnCount;
    }

    function clearTablePickerPreview() {
        tablePickerHoverRows = 0;
        tablePickerHoverColumns = 0;
    }

    function getTablePickerRows() {
        return tablePickerHoverRows || tableDraftRows.length || 0;
    }

    function getTablePickerColumns() {
        return tablePickerHoverColumns || tableDraftHeaders.length || 0;
    }

    function getImmersiveGuideId(value) {
        if (typeof value !== 'string') return '';
        const match = value.match(/^guides-content:(.+)$/);
        return match ? match[1] : '';
    }

    function selectGuideTab(nextTab) {
        selectedGuideTab = nextTab;
    }

    function sortGuides(list) {
        return [...list].sort((a, b) => {
            const aTime = Date.parse(a.updatedAt || a.createdAt || 0) || 0;
            const bTime = Date.parse(b.updatedAt || b.createdAt || 0) || 0;
            return bTime - aTime;
        });
    }

    function summarizeGuide(nextDetail) {
        if (!nextDetail) return null;
        return {
            id: nextDetail.id,
            title: nextDetail.title,
            summary: nextDetail.summary,
            publicSlug: nextDetail.publicSlug,
            status: nextDetail.status,
            accessMode: nextDetail.accessMode,
            accessGuildId: nextDetail.accessGuildId || '',
            hasPassword: !!nextDetail.hasPassword,
            createdByUserId: nextDetail.createdByUserId,
            updatedByUserId: nextDetail.updatedByUserId,
            createdAt: nextDetail.createdAt,
            updatedAt: nextDetail.updatedAt,
            publishedAt: nextDetail.publishedAt,
            blockCount: Array.isArray(nextDetail.blocks) ? nextDetail.blocks.length : 0,
            assigneeCount: Array.isArray(nextDetail.assignees) ? nextDetail.assignees.length : 0,
            pendingDeleteRequestCount: Array.isArray(nextDetail.deleteRequests)
                ? nextDetail.deleteRequests.filter((request) => request.status === 'pending').length
                : 0,
            isCreator: !!nextDetail.isCreator,
            isAssigned: !!nextDetail.isAssigned,
            canEdit: !!nextDetail.canEdit,
            canManageAssignments: !!nextDetail.canManageAssignments,
        };
    }

    function upsertGuideSummary(nextDetail) {
        const summary = summarizeGuide(nextDetail);
        if (!summary) return;
        const existingIndex = guideList.findIndex((guide) => guide.id === summary.id);
        if (existingIndex === -1) {
            guideList = sortGuides([summary, ...guideList]);
            return;
        }

        const nextList = [...guideList];
        nextList[existingIndex] = { ...nextList[existingIndex], ...summary };
        guideList = sortGuides(nextList);
    }

    function removeGuideSummary(guideId) {
        guideList = guideList.filter((guide) => guide.id !== guideId);
        if (selectedGuideId === guideId) {
            selectedGuideId = '';
            detail = null;
        }
    }

    function applyDetail(nextDetail) {
        detail = nextDetail;
        selectedGuideId = nextDetail?.id || '';
        if (selectedBlockId && !nextDetail?.blocks?.some((block) => block.id === selectedBlockId)) {
            selectedBlockId = '';
        }
        if (nextDetail?.blocks?.length) {
            const validIds = new Set(nextDetail.blocks.map((block) => block.id));
            inlineDrafts = Object.fromEntries(
                Object.entries(inlineDrafts).filter(([blockId]) => validIds.has(blockId)),
            );
            tableInlineDrafts = Object.fromEntries(
                Object.entries(tableInlineDrafts).filter(([blockId]) => validIds.has(blockId)),
            );
        } else if (Object.keys(inlineDrafts).length) {
            inlineDrafts = {};
            tableInlineDrafts = {};
        }
        if (nextDetail?.canManageAssignments) {
            selectedAssigneeUserIds = (nextDetail.assignees || [])
                .map((assignee) => assignee.userId)
                .filter(Boolean);
            if (!assignableAdmins.length) {
                void loadAssignableAdmins();
            }
        } else {
            selectedAssigneeUserIds = [];
        }
        upsertGuideSummary(nextDetail);
    }

    async function loadGuides() {
        isLoadingList = true;
        try {
            const data = await apiFetch('/api/guides');
            guideList = sortGuides(Array.isArray(data) ? data : []);

            if (selectedGuideId && guideList.some((guide) => guide.id === selectedGuideId)) {
                await loadGuideDetail(selectedGuideId);
            } else {
                selectedGuideId = '';
                detail = null;
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoadingList = false;
        }
    }

    async function loadGuideDetail(guideId, { silent = false } = {}) {
        if (!guideId) return;
        if (!silent) isLoadingDetail = true;
        try {
            const data = await apiFetch(`/api/guides/${guideId}`);
            if (data) {
                applyDetail(data);
            }
        } catch (error) {
            if (!silent) {
                showToast(error.message, 'error');
            }
        } finally {
            if (!silent) isLoadingDetail = false;
        }
    }

    async function openContentWorkspace(guideId) {
        if (!guideId) return;
        contentGuideId = guideId;
        selectedBlockId = '';
        immersivePage.set(`guides-content:${guideId}`);
        void loadGuideDetail(guideId);
    }

    function closeContentWorkspace() {
        contentGuideId = '';
        immersivePage.set('');
        openBlockActionMenuId = '';
        selectedBlockId = '';
    }

    function openCreateModal() {
        createForm = createEmptyGuideCreateForm();
        showCreateModal = true;
    }

    async function createGuide() {
        isCreatingGuide = true;
        try {
            const data = await apiFetch('/api/guides', {
                method: 'POST',
                body: {
                    title: createForm.title || 'Untitled Guide',
                    summary: createForm.summary || '',
                    accessMode: createForm.accessMode,
                    accessPassword: createForm.accessPassword,
                    accessGuildId: createForm.accessGuildId,
                },
            });
            if (data) {
                applyDetail(data);
                contentGuideId = data.id;
                immersivePage.set(`guides-content:${data.id}`);
                showCreateModal = false;
                showToast('Guide created', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isCreatingGuide = false;
        }
    }

    async function saveMetadata({ silent = false } = {}) {
        if (!detail) return;
        isSavingMeta = true;
        try {
            const data = await apiFetch(`/api/guides/${detail.id}`, {
                method: 'PATCH',
                body: {
                    title: detail.title,
                    summary: detail.summary,
                    accessMode: detail.accessMode,
                    accessPassword: guideAccessPasswordDraft,
                    accessGuildId: detail.accessGuildId,
                },
            });
            if (data) {
                applyDetail(data);
                guideAccessPasswordDraft = '';
                if (!silent) {
                    showToast('Guide details saved', 'success');
                }
            }
            return data;
        } catch (error) {
            showToast(error.message, 'error');
            return null;
        } finally {
            isSavingMeta = false;
        }
    }

    async function runGuideAction(guideId, action) {
        if (!guideId) return;
        actionGuideId = `${guideId}:${action}`;
        try {
            const data = await apiFetch(`/api/guides/${guideId}/${action}`, {
                method: 'POST',
            });
            if (data) {
                applyDetail(data);
                showToast(`Guide ${action}d`, 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            actionGuideId = '';
        }
    }

    function getShareUrl() {
        if (!detail?.publicSlug || typeof window === 'undefined') return '';
        return `${window.location.origin}${basePath}/g/${encodeURIComponent(detail.publicSlug)}`;
    }

    function getGuideMediaUrl(assetId) {
        const normalized = String(assetId || '').trim();
        if (!normalized) return '';
        return `${basePath}/api/public/guide-media/${encodeURIComponent(normalized)}`;
    }

    function getBlockImageUrl(payload) {
        if (!payload || typeof payload !== 'object') return '';
        const source = String(payload.source || '').trim().toLowerCase();
        if (source === 'upload' && payload.assetId) {
            return getGuideMediaUrl(payload.assetId);
        }
        return payload.imageUrl || '';
    }

    async function copyShareUrl() {
        const url = getShareUrl();
        if (!url) return;
        try {
            await navigator.clipboard.writeText(url);
            showToast('Share link copied', 'success');
        } catch {
            showToast('Unable to copy share link', 'error');
        }
    }

    async function loadGuideGuildOptions() {
        if (isLoadingGuideGuildOptions) return;
        isLoadingGuideGuildOptions = true;
        try {
            const data = await apiFetch('/api/guilds');
            guideGuildOptions = (Array.isArray(data) ? data : []).map((guild) => ({
                value: String(guild.id),
                label: guild.name || guild.id,
            }));
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoadingGuideGuildOptions = false;
        }
    }

    async function loadAssignableAdmins() {
        if (isLoadingAssignableAdmins) return;
        isLoadingAssignableAdmins = true;
        try {
            const data = await apiFetch('/api/admins/assignable');
            assignableAdmins = Array.isArray(data) ? data : [];
            const allowedUserIds = new Set(getGuideAssignableAdmins().map((admin) => admin.userId));
            selectedAssigneeUserIds = selectedAssigneeUserIds.filter((userId) => allowedUserIds.has(userId));
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoadingAssignableAdmins = false;
        }
    }

    function toggleAssignee(userId, checked) {
        if (checked) {
            selectedAssigneeUserIds = [...new Set([...selectedAssigneeUserIds, userId])];
            return;
        }
        selectedAssigneeUserIds = selectedAssigneeUserIds.filter((value) => value !== userId);
    }

    async function saveAssignments({ silent = false, closeOnSuccess = true } = {}) {
        if (!detail?.canManageAssignments) return;
        isSavingAssignments = true;
        try {
            const allowedUserIds = new Set(getGuideAssignableAdmins().map((admin) => admin.userId));
            const data = await apiFetch(`/api/guides/${detail.id}/assignees`, {
                method: 'PUT',
                body: { userIds: selectedAssigneeUserIds.filter((userId) => allowedUserIds.has(userId)) },
            });
            if (data) {
                applyDetail(data);
                if (closeOnSuccess) {
                    showAssignmentsModal = false;
                    showAssigneeMenu = false;
                }
                if (!silent) {
                    showToast('Guide settings updated', 'success');
                }
            }
            return data;
        } catch (error) {
            showToast(error.message, 'error');
            return null;
        } finally {
            isSavingAssignments = false;
        }
    }

    async function saveGuideSettings() {
        const metaSaved = await saveMetadata({ silent: true });
        if (!metaSaved) return;

        const assignmentsSaved = await saveAssignments({ silent: true, closeOnSuccess: false });
        if (!assignmentsSaved) return;

        showAssignmentsModal = false;
        showAssigneeMenu = false;
        showToast('Guide settings updated', 'success');
    }

    async function openAssignmentsModal(guideId) {
        if (!guideId) return;
        if (!detail || detail.id !== guideId) {
            await loadGuideDetail(guideId);
        }
        if (!detail?.canManageAssignments || detail.id !== guideId) return;
        if (!assignableAdmins.length) {
            await loadAssignableAdmins();
        }
        guideAccessPasswordDraft = '';
        showAssigneeMenu = false;
        showAssignmentsModal = true;
    }

    function isGuideAssignableAdmin(admin) {
        if (!admin) return false;
        if (admin.isOwner) return false;
        return !(Number(admin.permissions || 0) & PERMS.FULL_ACCESS);
    }

    function getGuideAssignableAdmins() {
        return assignableAdmins.filter(isGuideAssignableAdmin);
    }

    function getSelectedAssigneeLabels() {
        const byId = new Map(getGuideAssignableAdmins().map((admin) => [admin.userId, admin.username || admin.userId]));
        return selectedAssigneeUserIds
            .filter((userId) => byId.has(userId))
            .map((userId) => ({ userId, label: byId.get(userId) }));
    }

    function toggleAssigneeMenu() {
        showAssigneeMenu = !showAssigneeMenu;
    }

    function toggleWorkspaceActionMenu() {
        showWorkspaceActionMenu = !showWorkspaceActionMenu;
    }

    function closeWorkspaceActionMenu() {
        showWorkspaceActionMenu = false;
    }

    function toggleBlockActionMenu(blockId) {
        openBlockActionMenuId = openBlockActionMenuId === blockId ? '' : blockId;
    }

    function openNewBlockModal(blockType = 'text') {
        editingBlockId = '';
        blockForm = createEmptyBlockForm();
        blockForm.blockType = blockType;
        if (blockType === 'table') {
            const draft = createEmptyTableDraft();
            setTableDraft(draft.headers, draft.rows);
        }
        clearTempImagePreview();
        showBlockModal = true;
    }

    function openEditBlockModal(block) {
        selectedBlockId = block.id;
        editingBlockId = block.id;
        blockForm = createEmptyBlockForm();
        blockForm.blockType = block.blockType;
        clearTempImagePreview();

        if (block.blockType === 'heading') {
            blockForm.headingText = block.payload?.text || '';
            blockForm.headingLevel = String(block.payload?.level || 2);
        } else if (block.blockType === 'text') {
            blockForm.textContent = block.payload?.content || '';
        } else if (block.blockType === 'image') {
            blockForm.imageSource = String(block.payload?.source || '').trim().toLowerCase() === 'upload' ? 'upload' : 'url';
            blockForm.imageAssetId = block.payload?.assetId || '';
            blockForm.imageUrl = block.payload?.imageUrl || '';
            blockForm.imageAlt = block.payload?.alt || '';
            blockForm.imageCaption = block.payload?.caption || '';
            blockForm.imageWidth = String(block.payload?.width || 100);
        } else if (block.blockType === 'button') {
            blockForm.buttonLabel = block.payload?.label || '';
            blockForm.buttonUrl = block.payload?.url || '';
            blockForm.buttonStyle = block.payload?.style || 'primary';
        } else if (block.blockType === 'collapsible') {
            blockForm.collapsibleTitle = block.payload?.title || '';
            blockForm.collapsibleContent = block.payload?.content || '';
        } else if (block.blockType === 'table') {
            syncTableDraftFromPayload(block.payload?.headers, block.payload?.rows);
        } else if (block.blockType === 'table_of_contents') {
            blockForm.tocTitle = block.payload?.title || '';
        }

        showBlockModal = true;
    }

    function clearTempImagePreview() {
        if (tempImagePreviewUrl?.startsWith('blob:')) {
            URL.revokeObjectURL(tempImagePreviewUrl);
        }
        tempImagePreviewUrl = '';
    }

    function setTempImagePreview(file) {
        clearTempImagePreview();
        if (!file) return;
        tempImagePreviewUrl = URL.createObjectURL(file);
    }

    function getImageModalPreviewUrl() {
        if (tempImagePreviewUrl) return tempImagePreviewUrl;
        if (blockForm.imageSource === 'upload' && blockForm.imageAssetId) {
            return getGuideMediaUrl(blockForm.imageAssetId);
        }
        if (blockForm.imageSource === 'url') {
            return String(blockForm.imageUrl || '').trim();
        }
        return '';
    }

    function clearSelectedBlock() {
        selectedBlockId = '';
        openBlockActionMenuId = '';
    }

    function stopBlockSelectionEvent(event) {
        event.stopPropagation();
    }

    async function selectBlock(blockId, event, block = null) {
        event?.stopPropagation();
        selectedBlockId = blockId;
        openBlockActionMenuId = '';
        if (block && isInlineEditableBlock(block.blockType)) {
            await tick();
            const editor = inlineEditorRefs.get(blockId);
            if (editor && document.activeElement !== editor) {
                editor.focus();
                if (typeof editor.setSelectionRange === 'function') {
                    const length = editor.value?.length || 0;
                    editor.setSelectionRange(length, length);
                }
            }
        }
    }

    function editSelectedBlock(block, event) {
        event?.stopPropagation();
        selectedBlockId = block.id;
        openEditBlockModal(block);
    }

    function isInlineEditableBlock(blockType) {
        return blockType === 'heading' || blockType === 'text';
    }

    function getInlineDraftValue(block) {
        if (block.id in inlineDrafts) return inlineDrafts[block.id];
        if (block.blockType === 'heading') return block.payload?.text || '';
        if (block.blockType === 'text') return block.payload?.content || '';
        return '';
    }

    function setInlineEditorRef(blockId, node) {
        if (node) {
            inlineEditorRefs.set(blockId, node);
        } else {
            inlineEditorRefs.delete(blockId);
        }
    }

    function autoResizeTextarea(node) {
        if (!node) return;
        node.style.height = '0px';
        node.style.height = `${Math.max(node.scrollHeight, 24)}px`;
    }

    function autoResizeAndStore(node, blockId) {
        setInlineEditorRef(blockId, node);
        autoResizeTextarea(node);
    }

    function inlineEditor(node, blockId) {
        autoResizeAndStore(node, blockId);

        return {
            update(nextBlockId) {
                if (nextBlockId !== blockId) {
                    inlineEditorRefs.delete(blockId);
                    blockId = nextBlockId;
                }
                autoResizeAndStore(node, blockId);
            },
            destroy() {
                inlineEditorRefs.delete(blockId);
            },
        };
    }

    function buildInlinePayload(block, value) {
        if (block.blockType === 'heading') {
            return {
                ...block.payload,
                text: value,
                level: Number(block.payload?.level || 2),
            };
        }
        if (block.blockType === 'text') {
            return {
                ...block.payload,
                content: value,
            };
        }
        return block.payload || {};
    }

    function updateLocalBlockPayload(blockId, payload) {
        if (!detail?.blocks?.length) return;
        const nextBlocks = detail.blocks.map((item) => (
            item.id === blockId
                ? { ...item, payload: { ...item.payload, ...payload } }
                : item
        ));
        detail = {
            ...detail,
            blocks: nextBlocks,
        };
        upsertGuideSummary(detail);
    }

    async function saveInlineBlock(block, value) {
        if (!block?.id || !isInlineEditableBlock(block.blockType)) return;
        if (block.blockType === 'text' && !hasMeaningfulInlineText(value)) {
            updateLocalBlockPayload(block.id, buildInlinePayload(block, value));
            return;
        }
        const payload = buildInlinePayload(block, value);
        updateLocalBlockPayload(block.id, payload);
        blockMutationId = `${block.id}:inline`;
        try {
            const data = await apiFetch(`/api/guides/blocks/${block.id}`, {
                method: 'PATCH',
                body: { payload },
            });
            if (data) {
                if (selectedBlockId !== block.id) {
                    applyDetail(data);
                    const nextDrafts = { ...inlineDrafts };
                    delete nextDrafts[block.id];
                    inlineDrafts = nextDrafts;
                }
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            blockMutationId = '';
        }
    }

    function scheduleInlineSave(block, value) {
        const existing = inlineSaveTimers.get(block.id);
        if (existing) clearTimeout(existing);
        const timer = setTimeout(() => {
            inlineSaveTimers.delete(block.id);
            void saveInlineBlock(block, value);
        }, 500);
        inlineSaveTimers.set(block.id, timer);
    }

    function handleInlineInput(block, value, node) {
        inlineDrafts = {
            ...inlineDrafts,
            [block.id]: value,
        };
        autoResizeTextarea(node);
        scheduleInlineSave(block, value);
    }

    function replaceSelection(node, text, start, end = start) {
        node.setRangeText(text, start, end, 'end');
    }

    function getBulletDepthFromMarkdownLine(line) {
        const match = String(line || '').match(/^(\s*)-\s/);
        if (!match) return 0;
        const indentSize = (match[1] || '').replace(/\t/g, '  ').length;
        return Math.min(3, Math.floor(indentSize / 2) + 1);
    }

    function getPreviousMarkdownBulletDepth(value, lineStart) {
        const previousLines = value.slice(0, lineStart).replace(/\r\n/g, '\n').split('\n');
        for (let index = previousLines.length - 1; index >= 0; index -= 1) {
            const depth = getBulletDepthFromMarkdownLine(previousLines[index]);
            if (depth) return depth;
            if (previousLines[index].trim()) break;
        }
        return 0;
    }

    function hasMeaningfulInlineText(value) {
        const normalized = String(value || '')
            .replace(/\r\n/g, '\n')
            .split('\n')
            .map((line) => line.replace(/^(\s*)-\s?$/, '').trim())
            .join('');
        return normalized.trim().length > 0;
    }

    function handleInlineTextKeydown(block, event) {
        event.stopPropagation();
        const node = event.currentTarget;
        if (!(node instanceof HTMLTextAreaElement)) return;

        const value = node.value;
        const start = node.selectionStart ?? 0;
        const lineStart = value.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
        const lineBeforeCursor = value.slice(lineStart, start);

        if (event.key === ' ' && /^(\s*)-$/.test(lineBeforeCursor)) {
            event.preventDefault();
            const indent = lineBeforeCursor.match(/^(\s*)-/)?.[1] || '';
            replaceSelection(node, `${indent}• `, lineStart, start);
            handleInlineInput(block, node.value, node);
            return;
        }

        if (event.key === 'Enter') {
            const fullLineEnd = value.indexOf('\n', start);
            const lineEnd = fullLineEnd === -1 ? value.length : fullLineEnd;
            const fullLine = value.slice(lineStart, lineEnd);
            const bulletMatch = fullLine.match(/^(\s*)•\s(.*)$/);

            if (bulletMatch) {
                event.preventDefault();
                const indent = bulletMatch[1] || '';
                const content = bulletMatch[2] || '';
                const insert = content.trim() ? `\n${indent}• ` : '\n';
                replaceSelection(node, insert, start, start);
                handleInlineInput(block, node.value, node);
            }
        }
    }

    function flushInlineSave(block) {
        const pending = inlineSaveTimers.get(block.id);
        if (pending) {
            clearTimeout(pending);
            inlineSaveTimers.delete(block.id);
            void saveInlineBlock(block, getInlineDraftValue(block));
            return;
        }
        updateLocalBlockPayload(block.id, buildInlinePayload(block, getInlineDraftValue(block)));
    }

    function handleInlineTextKeydownV2(block, event) {
        event.stopPropagation();
        const node = event.currentTarget;
        if (!(node instanceof HTMLTextAreaElement)) return;

        const value = node.value;
        const start = node.selectionStart ?? 0;
        const end = node.selectionEnd ?? start;
        const lineStart = value.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
        const lineBeforeCursor = value.slice(lineStart, start);

        if (event.key === ' ' && /^(\s*)-$/.test(lineBeforeCursor)) {
            return;
        }

        if (event.key === ' ' && /^(\s*)-\s$/.test(lineBeforeCursor) && start === end) {
            event.preventDefault();
            const currentIndent = lineBeforeCursor.match(/^(\s*)-\s$/)?.[1] || '';
            const currentIndentSize = currentIndent.length;
            const previousDepth = getPreviousMarkdownBulletDepth(value, lineStart);
            const maxDepth = previousDepth ? Math.min(3, previousDepth + 1) : 1;
            const nextIndentSize = Math.min((maxDepth - 1) * 2, currentIndentSize + 1);
            const nextIndent = ' '.repeat(nextIndentSize);
            replaceSelection(node, `${nextIndent}- `, lineStart, start);
            handleInlineInput(block, node.value, node);
            return;
        }

        if (event.key === 'Enter') {
            const fullLineEnd = value.indexOf('\n', start);
            const lineEnd = fullLineEnd === -1 ? value.length : fullLineEnd;
            const fullLine = value.slice(lineStart, lineEnd);
            const bulletMatch = fullLine.match(/^(\s*)-\s(.*)$/);

            if (bulletMatch) {
                event.preventDefault();
                const indent = bulletMatch[1] || '';
                const content = bulletMatch[2] || '';
                const insert = content.trim() ? `\n${indent}- ` : '\n';
                replaceSelection(node, insert, start, start);
                handleInlineInput(block, node.value, node);
            }
        }
    }

    function buildBlockPayload() {
        switch (blockForm.blockType) {
            case 'heading':
                return {
                    text: blockForm.headingText,
                    level: Number(blockForm.headingLevel || 2),
                };
            case 'text':
                return { content: blockForm.textContent };
            case 'image':
                return {
                    source: blockForm.imageSource === 'upload' ? 'upload' : 'url',
                    assetId: blockForm.imageSource === 'upload' ? blockForm.imageAssetId : '',
                    imageUrl: blockForm.imageSource === 'upload' ? '' : blockForm.imageUrl,
                    alt: blockForm.imageAlt,
                    caption: blockForm.imageCaption,
                    width: Math.max(20, Math.min(100, Number(blockForm.imageWidth || 100))),
                };
            case 'button':
                return {
                    label: blockForm.buttonLabel,
                    url: blockForm.buttonUrl,
                    style: blockForm.buttonStyle,
                };
            case 'divider':
                return {};
            case 'collapsible':
                return {
                    title: blockForm.collapsibleTitle,
                    content: blockForm.collapsibleContent,
                };
            case 'table':
                return {
                    headers: tableDraftHeaders
                        .map((header, index) => String(header || '').trim() || `Column ${index + 1}`)
                        .filter((_, index, headers) => index < headers.length),
                    rows: tableDraftRows
                        .map((row) => row.map((cell) => String(cell || '').trim())),
                };
            case 'table_of_contents':
                return {
                    title: blockForm.tocTitle,
                };
            default:
                return {};
        }
    }

    async function saveBlock() {
        if (!detail) return;
        blockMutationId = editingBlockId || 'new';
        try {
            const endpoint = editingBlockId
                ? `/api/guides/blocks/${editingBlockId}`
                : `/api/guides/${detail.id}/blocks`;
            const method = editingBlockId ? 'PATCH' : 'POST';
            const body = editingBlockId
                ? { payload: buildBlockPayload() }
                : { blockType: blockForm.blockType, payload: buildBlockPayload() };

            const data = await apiFetch(endpoint, { method, body });
            if (data) {
                applyDetail(data);
                showBlockModal = false;
                openBlockActionMenuId = '';
                showToast(editingBlockId ? 'Block updated' : 'Block added', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            blockMutationId = '';
        }
    }

    async function moveBlock(blockId, direction) {
        blockMutationId = `${blockId}:${direction}`;
        try {
            const data = await apiFetch(`/api/guides/blocks/${blockId}/move`, {
                method: 'POST',
                body: { direction },
            });
            if (data) {
                applyDetail(data);
                openBlockActionMenuId = '';
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            blockMutationId = '';
        }
    }

    async function duplicateBlock(blockId) {
        blockMutationId = `${blockId}:duplicate`;
        try {
            const data = await apiFetch(`/api/guides/blocks/${blockId}/duplicate`, {
                method: 'POST',
            });
            if (data) {
                applyDetail(data);
                openBlockActionMenuId = '';
                showToast('Block duplicated', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            blockMutationId = '';
        }
    }

    async function removeBlock(blockId) {
        blockMutationId = `${blockId}:delete`;
        try {
            const data = await apiFetch(`/api/guides/blocks/${blockId}`, {
                method: 'DELETE',
            });
            if (data) {
                applyDetail(data);
                openBlockActionMenuId = '';
                showToast('Block removed', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            blockMutationId = '';
        }
    }

    function formatDate(value) {
        if (!value) return '—';
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleString(undefined, {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        });
    }

    function formatPublishedAt(value) {
        if (!value) return '';
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return '';
        return date.toLocaleDateString(undefined, {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    }

    function getStatusLabel(status) {
        return STATUS_LABELS[status] || status || 'Unknown';
    }

    function blockPreviewText(block) {
        if (block.blockType === 'heading') return block.payload?.text || 'Untitled heading';
        if (block.blockType === 'text') return block.payload?.content || 'Empty text block';
        if (block.blockType === 'image') return block.payload?.caption || getBlockImageUrl(block.payload) || 'Image block';
        if (block.blockType === 'button') return `${block.payload?.label || 'Button'} -> ${block.payload?.url || ''}`;
        if (block.blockType === 'collapsible') return block.payload?.title || 'Collapsible section';
        if (block.blockType === 'table') return (block.payload?.headers || []).join(' | ') || 'Table';
        if (block.blockType === 'table_of_contents') return block.payload?.title || 'Table of contents';
        return 'Divider';
    }

    function parseTableTextLine(value) {
        const stripped = String(value || '').trim().replace(/^\|+|\|+$/g, '');
        if (!stripped) return [];
        return stripped
            .split('|')
            .map((cell) => String(cell || '').trim())
            .filter((cell) => cell.length > 0);
    }

    function slugifyHeading(text) {
        const base = String(text || '')
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
        return base || 'section';
    }

    function getBlockHeadingEntries(blocks) {
        const seen = new Map();
        const entries = [];
        for (const block of blocks || []) {
            if (block.blockType !== 'heading') continue;
            const text = getInlineDraftValue(block) || block.payload?.text || '';
            const label = String(text || '').trim();
            if (!label) continue;
            const base = slugifyHeading(label);
            const nextCount = (seen.get(base) || 0) + 1;
            seen.set(base, nextCount);
            entries.push({
                blockId: block.id,
                label,
                level: Math.max(1, Math.min(4, Number(block.payload?.level) || 2)),
                anchorId: nextCount === 1 ? `guide-heading-${base}` : `guide-heading-${base}-${nextCount}`,
            });
        }
        return entries;
    }

    function getHeadingAnchorId(block, blocks) {
        return getBlockHeadingEntries(blocks).find((entry) => entry.blockId === block.id)?.anchorId || '';
    }

    function scrollToGuideHeading(anchorId, event) {
        event?.preventDefault?.();
        event?.stopPropagation?.();
        const target = typeof document !== 'undefined' ? document.getElementById(anchorId) : null;
        if (!target) return;
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    async function uploadGuideImageFile(file) {
        if (!file || !detail?.id) return;

        setTempImagePreview(file);
        const formData = new FormData();
        formData.append('image', file);
        isUploadingImage = true;
        try {
            const data = await apiUpload(`/api/guides/${detail.id}/image-assets`, formData);
            if (data?.id) {
                blockForm.imageSource = 'upload';
                blockForm.imageAssetId = data.id;
                clearTempImagePreview();
                showToast('Image uploaded', 'success');
            }
        } catch (error) {
            clearTempImagePreview();
            showToast(error.message, 'error');
        } finally {
            isUploadingImage = false;
        }
    }

    async function uploadGuideImage(event) {
        const file = event.currentTarget?.files?.[0];
        await uploadGuideImageFile(file);
        event.currentTarget.value = '';
    }

    function getClipboardImageFile(event) {
        const items = Array.from(event.clipboardData?.items || []);
        for (const item of items) {
            if (item.kind !== 'file') continue;
            if (!String(item.type || '').startsWith('image/')) continue;
            const file = item.getAsFile?.();
            if (file) return file;
        }
        return null;
    }

    async function handleGuideImagePaste(event) {
        if (!showBlockModal) return;
        if (blockForm.blockType !== 'image') return;
        if (blockForm.imageSource !== 'upload') return;
        if (isUploadingImage) return;

        const file = getClipboardImageFile(event);
        if (!file) return;

        event.preventDefault();
        await uploadGuideImageFile(file);
    }

    function openImageUploadPicker() {
        if (isUploadingImage) return;
        imageUploadInput?.click();
    }

    function closeBlockModal() {
        clearTempImagePreview();
        showBlockModal = false;
    }

    function handleImageDropZoneDragOver(event) {
        event.preventDefault();
        if (!isUploadingImage) {
            isImageDropActive = true;
        }
    }

    function handleImageDropZoneDragLeave(event) {
        event.preventDefault();
        const nextTarget = event.relatedTarget;
        if (nextTarget && event.currentTarget?.contains?.(nextTarget)) return;
        isImageDropActive = false;
    }

    async function handleImageDrop(event) {
        event.preventDefault();
        isImageDropActive = false;
        const file = event.dataTransfer?.files?.[0];
        await uploadGuideImageFile(file);
    }

    function escapeHtml(value) {
        return String(value || '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#39;');
    }

    function escapeHtmlAttr(value) {
        return escapeHtml(value);
    }

    function formatInlineRichText(value) {
        const linkTokens = [];
        let output = String(value || '');

        output = output.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_match, label, url) => {
            const safeUrl = escapeHtmlAttr(url);
            const safeLabel = escapeHtml(label);
            const token = `@@LINK_${linkTokens.length}@@`;
            linkTokens.push(`<a href="${safeUrl}" target="_blank" rel="noreferrer">${safeLabel}</a>`);
            return token;
        });

        output = escapeHtml(output);
        output = output.replace(/(https?:\/\/[^\s<]+)/g, (match) => {
            const safeUrl = escapeHtmlAttr(match);
            return `<a href="${safeUrl}" target="_blank" rel="noreferrer">${safeUrl}</a>`;
        });
        output = output.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

        linkTokens.forEach((html, index) => {
            output = output.replace(`@@LINK_${index}@@`, html);
        });

        return output;
    }

    function renderRichText(content) {
        const lines = String(content || '').replace(/\r\n/g, '\n').split('\n');
        let html = '';
        let paragraphLines = [];

        function flushParagraph() {
            if (!paragraphLines.length) return;
            html += `<p>${paragraphLines.map((line) => formatInlineRichText(line)).join('<br>')}</p>`;
            paragraphLines = [];
        }

        for (const rawLine of lines) {
            const line = rawLine ?? '';
            const listMatch = line.match(/^(\s*)(?:-|•)\s+(.*)$/);

            if (listMatch) {
                flushParagraph();
                const indent = listMatch[1] || '';
                const indentSize = indent.replace(/\t/g, '  ').length;
                const depth = Math.min(3, Math.floor(indentSize / 2) + 1);
                html += `<div class="rich-list depth-${depth}"><span class="rich-bullet">•</span><span class="rich-list-content">${formatInlineRichText(listMatch[2] || '')}</span></div>`;
                continue;
            }

            if (!line.trim()) {
                flushParagraph();
                if (html) {
                    html += '<div class="rich-spacer" aria-hidden="true"></div>';
                }
                continue;
            }

            paragraphLines.push(line);
        }

        flushParagraph();
        return html || '<p></p>';
    }

    function isGuideActionLoading(guideId, action) {
        return actionGuideId === `${guideId}:${action}`;
    }

    function blockTypeLabel(blockType) {
        return BLOCK_TYPE_OPTIONS.find((option) => option.value === blockType)?.label || blockType;
    }

    function getTableInlineDraft(block) {
        if (!block) return { headers: [], rows: [] };
        const existing = tableInlineDrafts[block.id];
        if (existing) {
            return {
                headers: existing.headers.map((header) => String(header || '')),
                rows: existing.rows.map((row) => row.map((cell) => String(cell || ''))),
            };
        }
        const headers = Array.isArray(block.payload?.headers)
            ? block.payload.headers.map((header) => String(header || ''))
            : [];
        const rows = Array.isArray(block.payload?.rows)
            ? block.payload.rows.map((row) => Array.isArray(row) ? row.map((cell) => String(cell || '')) : [])
            : [];
        return { headers, rows };
    }

    function syncTableInlineDraft(blockId, nextDraft) {
        tableInlineDrafts = {
            ...tableInlineDrafts,
            [blockId]: {
                headers: nextDraft.headers.map((header) => String(header || '')),
                rows: nextDraft.rows.map((row) => row.map((cell) => String(cell || ''))),
            },
        };
    }

    async function saveTableInlineBlock(block, draft) {
        if (!block?.id || block.blockType !== 'table') return;
        const payload = {
            headers: draft.headers.map((header, index) => String(header || '').trim() || `Column ${index + 1}`),
            rows: draft.rows.map((row) => row.map((cell) => String(cell || '').trim())),
        };
        updateLocalBlockPayload(block.id, payload);
        blockMutationId = `${block.id}:inline-table`;
        try {
            const data = await apiFetch(`/api/guides/blocks/${block.id}`, {
                method: 'PATCH',
                body: { payload },
            });
            if (data && selectedBlockId !== block.id) {
                applyDetail(data);
                const nextDrafts = { ...tableInlineDrafts };
                delete nextDrafts[block.id];
                tableInlineDrafts = nextDrafts;
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            blockMutationId = '';
        }
    }

    function scheduleTableInlineSave(block, draft) {
        const existing = inlineSaveTimers.get(block.id);
        if (existing) clearTimeout(existing);
        const timer = setTimeout(() => {
            inlineSaveTimers.delete(block.id);
            void saveTableInlineBlock(block, draft);
        }, 500);
        inlineSaveTimers.set(block.id, timer);
    }

    function handleTableInlineHeaderInput(block, columnIndex, value) {
        const draft = getTableInlineDraft(block);
        const nextDraft = {
            headers: draft.headers.map((header, index) => index === columnIndex ? value : header),
            rows: draft.rows.map((row) => [...row]),
        };
        syncTableInlineDraft(block.id, nextDraft);
        updateLocalBlockPayload(block.id, {
            headers: nextDraft.headers,
            rows: nextDraft.rows,
        });
        scheduleTableInlineSave(block, nextDraft);
    }

    function handleTableInlineCellInput(block, rowIndex, columnIndex, value) {
        const draft = getTableInlineDraft(block);
        const nextDraft = {
            headers: [...draft.headers],
            rows: draft.rows.map((row, currentRowIndex) => (
                currentRowIndex === rowIndex
                    ? row.map((cell, currentColumnIndex) => currentColumnIndex === columnIndex ? value : cell)
                    : [...row]
            )),
        };
        syncTableInlineDraft(block.id, nextDraft);
        updateLocalBlockPayload(block.id, {
            headers: nextDraft.headers,
            rows: nextDraft.rows,
        });
        scheduleTableInlineSave(block, nextDraft);
    }

    function flushTableInlineSave(block) {
        const pending = inlineSaveTimers.get(block.id);
        if (pending) {
            clearTimeout(pending);
            inlineSaveTimers.delete(block.id);
        }
        void saveTableInlineBlock(block, getTableInlineDraft(block));
    }
</script>

{#if !(contentGuideId && detail?.id === contentGuideId)}
    <PageHeader label="Guides">
        Build shareable guides with ordered content blocks, publishing controls, and direct public links.
    </PageHeader>
{/if}

{#if contentGuideId && detail?.id === contentGuideId}
    <div class="content-workspace-shell">
        <div class="workspace-topbar">
            <div class="workspace-topbar-left">
                <button class="workspace-back" type="button" onclick={closeContentWorkspace} aria-label="Back to guides" title="Back to guides">
                    <Icon name="chevron-left" size={16} />
                </button>
                <div class="workspace-title-group">
                    <strong>{detail.title}</strong>
                    {#if detail.summary}
                        <p>{detail.summary}</p>
                    {/if}
                </div>
            </div>

            <div class="workspace-topbar-right">
                <span class="workspace-status status-badge status-{detail.status}">{getStatusLabel(detail.status)}</span>
                <div class="workspace-actions">
                    {#if detail.canManageAssignments}
                        <button class="btn" type="button" onclick={() => openAssignmentsModal(detail.id)}>
                            Settings
                        </button>
                    {/if}

                    {#if detail.status === 'published'}
                        <button class="btn" type="button" onclick={copyShareUrl}>
                            <Icon name="copy" size={14} />
                            Copy Link
                        </button>
                        <a class="btn" href={getShareUrl()} target="_blank" rel="noreferrer">
                            <Icon name="external-link" size={14} />
                            Open Link
                        </a>
                    {/if}

                    {#if detail.status !== 'published'}
                        <LoadingButton class="btn btn-primary" loading={isGuideActionLoading(detail.id, 'publish')} onclick={() => runGuideAction(detail.id, 'publish')}>
                            Publish
                        </LoadingButton>
                    {:else}
                        <LoadingButton class="btn" loading={isGuideActionLoading(detail.id, 'unpublish')} onclick={() => runGuideAction(detail.id, 'unpublish')}>
                            Unpublish
                        </LoadingButton>
                    {/if}

                    {#if detail.status !== 'archived'}
                        <LoadingButton class="btn btn-danger" loading={isGuideActionLoading(detail.id, 'archive')} onclick={() => runGuideAction(detail.id, 'archive')}>
                            Archive
                        </LoadingButton>
                    {/if}
                </div>

                <div class="workspace-actions-mobile" bind:this={workspaceActionMenuRef}>
                    <button class="btn workspace-actions-trigger" type="button" onclick={toggleWorkspaceActionMenu} aria-expanded={showWorkspaceActionMenu} aria-label="Guide actions">
                        Actions
                    </button>

                    {#if showWorkspaceActionMenu}
                        <div class="workspace-actions-menu">
                            {#if detail.canManageAssignments}
                                <button class="workspace-actions-menu-item" type="button" onclick={() => { closeWorkspaceActionMenu(); openAssignmentsModal(detail.id); }}>
                                    Settings
                                </button>
                            {/if}

                            {#if detail.status === 'published'}
                                <button class="workspace-actions-menu-item" type="button" onclick={() => { closeWorkspaceActionMenu(); copyShareUrl(); }}>
                                    Copy Link
                                </button>
                                <a class="workspace-actions-menu-item" href={getShareUrl()} target="_blank" rel="noreferrer" onclick={closeWorkspaceActionMenu}>
                                    Open Link
                                </a>
                            {/if}

                            {#if detail.status !== 'published'}
                                <LoadingButton class="workspace-actions-menu-item is-primary" loading={isGuideActionLoading(detail.id, 'publish')} onclick={() => { closeWorkspaceActionMenu(); runGuideAction(detail.id, 'publish'); }}>
                                    Publish
                                </LoadingButton>
                            {:else}
                                <LoadingButton class="workspace-actions-menu-item" loading={isGuideActionLoading(detail.id, 'unpublish')} onclick={() => { closeWorkspaceActionMenu(); runGuideAction(detail.id, 'unpublish'); }}>
                                    Unpublish
                                </LoadingButton>
                            {/if}

                            {#if detail.status !== 'archived'}
                                <LoadingButton class="workspace-actions-menu-item is-danger" loading={isGuideActionLoading(detail.id, 'archive')} onclick={() => { closeWorkspaceActionMenu(); runGuideAction(detail.id, 'archive'); }}>
                                    Archive
                                </LoadingButton>
                            {/if}
                        </div>
                    {/if}
                </div>
            </div>
        </div>

        <div class="content-workspace-canvas" role="presentation" onmousedown={clearSelectedBlock}>
            <div class="content-stage">
                <div class="content-stage-column">
                {#if detail.blocks?.length}
                    <article class="content-page-preview">
                        <header class="content-guide-hero">
                            <h1 class="content-guide-title">{detail.title}</h1>
                            {#if detail.summary}
                                <p class="content-guide-summary">{detail.summary}</p>
                            {/if}
                            {#if formatPublishedAt(detail.publishedAt)}
                                <div class="content-guide-meta">Published {formatPublishedAt(detail.publishedAt)}</div>
                            {/if}
                        </header>
                        <div class="block-list content-block-list">
                        {#each detail.blocks as block, index (block.id)}
                            <div
                                class="content-block-row"
                                class:first-row={index === 0}
                                class:selected={selectedBlockId === block.id}
                                class:type-heading={block.blockType === 'heading'}
                                class:type-text={block.blockType === 'text'}
                                class:type-image={block.blockType === 'image'}
                                class:type-button={block.blockType === 'button'}
                                class:type-divider={block.blockType === 'divider'}
                                class:type-collapsible={block.blockType === 'collapsible'}
                                class:type-table={block.blockType === 'table'}
                                class:type-table-of-contents={block.blockType === 'table_of_contents'}
                                role="button"
                                tabindex="0"
                                onclick={(event) => selectBlock(block.id, event, block)}
                                onkeydown={(event) => {
                                    if (event.key === 'Enter' || event.key === ' ') {
                                        event.preventDefault();
                                        selectBlock(block.id, event, block);
                                    }
                                }}
                                aria-label={`Select ${blockTypeLabel(block.blockType)} block`}
                            >
                                <div class="block-row-toolbar">
                                    <div class="block-row-meta">
                                        <span class="block-type">{blockTypeLabel(block.blockType)}</span>
                                        <strong>{blockPreviewText(block)}</strong>
                                    </div>
                                    <div class="block-row-controls">
                                        <div class="move-controls">
                                        <button class="icon-btn move-btn" type="button" disabled={index === 0 || blockMutationId === `${block.id}:up`} onclick={() => moveBlock(block.id, 'up')} aria-label="Move block up">
                                            ↑
                                        </button>
                                        <button class="icon-btn move-btn" type="button" disabled={index === detail.blocks.length - 1 || blockMutationId === `${block.id}:down`} onclick={() => moveBlock(block.id, 'down')} aria-label="Move block down">
                                            ↓
                                        </button>
                                        </div>
                                        <div class="block-action-menu">
                                            <button class="icon-btn menu-trigger" type="button" onclick={() => toggleBlockActionMenu(block.id)} aria-label="More actions">
                                                ...
                                            </button>

                                            {#if openBlockActionMenuId === block.id}
                                                <div class="block-action-popover">
                                                    <button class="block-action-option" type="button" onclick={() => { openEditBlockModal(block); openBlockActionMenuId = ''; }}>
                                                        Edit
                                                    </button>
                                                    <button class="block-action-option" type="button" disabled={blockMutationId === `${block.id}:duplicate`} onclick={() => duplicateBlock(block.id)}>
                                                        Duplicate
                                                    </button>
                                                    <button class="block-action-option danger" type="button" disabled={blockMutationId === `${block.id}:delete`} onclick={() => removeBlock(block.id)}>
                                                        Remove
                                                    </button>
                                                </div>
                                            {/if}
                                        </div>
                                    </div>
                                </div>

                                <div class="block-preview content-block-preview">
                                    {#if block.blockType === 'heading'}
                                        {#if selectedBlockId === block.id}
                                            <textarea
                                                class="inline-heading-editor preview-heading level-{block.payload?.level || 2}"
                                                use:inlineEditor={block.id}
                                                value={getInlineDraftValue(block)}
                                                rows="1"
                                                spellcheck="false"
                                                placeholder="Write a heading"
                                                onfocus={(event) => selectBlock(block.id, event, block)}
                                                onmousedown={(event) => event.stopPropagation()}
                                                onkeydown={(event) => event.stopPropagation()}
                                                oninput={(event) => handleInlineInput(block, event.currentTarget.value, event.currentTarget)}
                                                onblur={() => flushInlineSave(block)}
                                            ></textarea>
                                        {:else}
                                            <div id={getHeadingAnchorId(block, detail.blocks)} class="preview-heading level-{block.payload?.level || 2}">{getInlineDraftValue(block)}</div>
                                        {/if}
                                    {:else if block.blockType === 'text'}
                                        {#if selectedBlockId === block.id}
                                            <textarea
                                                class="inline-text-editor"
                                                use:inlineEditor={block.id}
                                                value={getInlineDraftValue(block)}
                                                rows="1"
                                                placeholder="Write your guide content"
                                                onfocus={(event) => selectBlock(block.id, event, block)}
                                                onmousedown={(event) => event.stopPropagation()}
                                                onkeydown={(event) => handleInlineTextKeydownV2(block, event)}
                                                oninput={(event) => handleInlineInput(block, event.currentTarget.value, event.currentTarget)}
                                                onblur={() => flushInlineSave(block)}
                                            ></textarea>
                                        {:else}
                                            <div class="rendered-rich-text" aria-label="Guide text content">
                                                {@html renderRichText(getInlineDraftValue(block))}
                                            </div>
                                        {/if}
                                    {:else if block.blockType === 'image'}
                                        {@const imageSrc = getBlockImageUrl(block.payload)}
                                        <figure class="preview-image-media" style={`--image-width: ${Math.max(20, Math.min(100, Number(block.payload?.width || 100)))}%;`}>
                                            {#if imageSrc}
                                                <img src={imageSrc} alt={block.payload?.alt || block.payload?.caption || 'Guide image'} loading="lazy" />
                                            {:else}
                                                <span>No image selected</span>
                                            {/if}
                                            {#if block.payload?.caption}<p>{block.payload.caption}</p>{/if}
                                        </figure>
                                    {:else if block.blockType === 'button'}
                                        <div class="preview-button-card">{block.payload?.label} -> {block.payload?.url}</div>
                                    {:else if block.blockType === 'divider'}
                                        <hr />
                                    {:else if block.blockType === 'collapsible'}
                                        <details open>
                                            <summary>{block.payload?.title}</summary>
                                            <p>{block.payload?.content}</p>
                                        </details>
                                    {:else if block.blockType === 'table'}
                                        {@const tableDraft = getTableInlineDraft(block)}
                                        <div class="preview-table-wrap">
                                            <table class="preview-table" class:is-editing={selectedBlockId === block.id}>
                                                <thead>
                                                    <tr>
                                                        {#each tableDraft.headers || [] as header, columnIndex}
                                                            <th>
                                                                {#if selectedBlockId === block.id}
                                                                    <input
                                                                        class="table-inline-input table-inline-header-input"
                                                                        type="text"
                                                                        value={header}
                                                                        placeholder={`Column ${columnIndex + 1}`}
                                                                        onmousedown={stopBlockSelectionEvent}
                                                                        onclick={stopBlockSelectionEvent}
                                                                        onkeydown={stopBlockSelectionEvent}
                                                                        onfocus={(event) => selectBlock(block.id, event, block)}
                                                                        oninput={(event) => handleTableInlineHeaderInput(block, columnIndex, event.currentTarget.value)}
                                                                        onblur={() => flushTableInlineSave(block)}
                                                                    />
                                                                {:else}
                                                                    {header}
                                                                {/if}
                                                            </th>
                                                        {/each}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {#each tableDraft.rows || [] as row, rowIndex}
                                                        <tr>
                                                            {#each row as cell, columnIndex}
                                                                <td>
                                                                    {#if selectedBlockId === block.id}
                                                                        <input
                                                                            class="table-inline-input"
                                                                            type="text"
                                                                            value={cell}
                                                                            placeholder="Enter value"
                                                                            onmousedown={stopBlockSelectionEvent}
                                                                            onclick={stopBlockSelectionEvent}
                                                                            onkeydown={stopBlockSelectionEvent}
                                                                            onfocus={(event) => selectBlock(block.id, event, block)}
                                                                            oninput={(event) => handleTableInlineCellInput(block, rowIndex, columnIndex, event.currentTarget.value)}
                                                                onblur={() => flushTableInlineSave(block)}
                                                                        />
                                                                    {:else}
                                                                        <span class:table-empty-cell={!cell}>{cell || 'Empty'}</span>
                                                                    {/if}
                                                                </td>
                                                            {/each}
                                                        </tr>
                                                    {/each}
                                                </tbody>
                                            </table>
                                        </div>
                                    {:else if block.blockType === 'table_of_contents'}
                                        <nav class="preview-toc" aria-label="Table of contents">
                                            <div class="preview-toc-title">{block.payload?.title || 'Table of contents'}</div>
                                            {#if contentHeadingEntries.length}
                                                    <div class="preview-toc-list">
                                                    {#each contentHeadingEntries as entry}
                                                        <button
                                                            class="preview-toc-link level-{entry.level}"
                                                            type="button"
                                                            onclick={(event) => scrollToGuideHeading(entry.anchorId, event)}
                                                        >
                                                            {entry.label}
                                                        </button>
                                                    {/each}
                                                </div>
                                            {:else}
                                                <p class="preview-toc-empty">Add heading blocks to generate this list.</p>
                                            {/if}
                                        </nav>
                                    {/if}
                                </div>

                                {#if selectedBlockId === block.id}
                                    <div class="selected-block-toolbar" role="presentation" onmousedown={(event) => event.stopPropagation()}>
                                        <button class="selected-block-action" type="button" disabled={index === 0 || blockMutationId === `${block.id}:up`} onclick={(event) => { event.stopPropagation(); void moveBlock(block.id, 'up'); }} aria-label="Move block up">
                                            ↑
                                        </button>
                                        <button class="selected-block-action" type="button" disabled={index === detail.blocks.length - 1 || blockMutationId === `${block.id}:down`} onclick={(event) => { event.stopPropagation(); void moveBlock(block.id, 'down'); }} aria-label="Move block down">
                                            ↓
                                        </button>
                                        <button class="selected-block-action" type="button" onclick={(event) => { event.stopPropagation(); openEditBlockModal(block); }} aria-label="Edit block">
                                            <Icon name="edit" size={18} />
                                        </button>
                                        <button class="selected-block-action" type="button" disabled={blockMutationId === `${block.id}:duplicate`} onclick={(event) => { event.stopPropagation(); void duplicateBlock(block.id); }} aria-label="Duplicate block">
                                            <Icon name="copy" size={18} />
                                        </button>
                                        <button class="selected-block-action danger" type="button" disabled={blockMutationId === `${block.id}:delete`} onclick={(event) => { event.stopPropagation(); void removeBlock(block.id); }} aria-label="Remove block">
                                            <Icon name="delete" size={18} />
                                        </button>
                                    </div>
                                {/if}
                            </div>
                        {/each}
                        </div>
                    </article>
                    <div class="block-picker add-component-picker" role="presentation" onmousedown={(event) => event.stopPropagation()}>
                        <button class="add-component-card" type="button" onclick={() => openNewBlockModal()}>
                            <span class="add-component-copy">+ Add Component</span>
                        </button>
                    </div>
                {:else}
                    <div class="block-picker add-component-picker" role="presentation" onmousedown={(event) => event.stopPropagation()}>
                        <button class="add-component-card is-empty" type="button" onclick={() => openNewBlockModal()}>
                            <span class="add-component-copy">+ Add Component</span>
                        </button>
                    </div>
                {/if}
                </div>
            </div>
        </div>
    </div>
{:else}
<div class="guides-layout">
    <aside class="sidebar-card">
        <div class="list-toolbar list-toolbar-guides">
            <div class="list-toolbar-copy">
                <div class="panel-title">Guide Library</div>
                <p class="panel-subtitle">{visibleGuides.length} guide{visibleGuides.length === 1 ? '' : 's'}</p>
            </div>
            <div class="guide-toolbar-actions">
                <Select
                    class="guide-status-select"
                    bind:value={selectedGuideTab}
                    options={guideStatusOptions}
                    onchange={selectGuideTab}
                />
                <LoadingButton class="btn btn-primary create-guide-button" loading={isCreatingGuide} onclick={openCreateModal}>
                    <Icon name="plus" size={14} /> New Guide
                </LoadingButton>
            </div>
        </div>

        {#if isLoadingList}
            <div class="skeleton" style="height: 220px;"></div>
        {:else}
            <div class="list-stack">
                {#each visibleGuides as guide (guide.id)}
                    <div class="list-accordion" class:expanded={selectedGuideId === guide.id}>
                        <div class="list-card-shell">
                            <button class="list-card" class:active={selectedGuideId === guide.id} onclick={() => openContentWorkspace(guide.id)}>
                                <div class="list-card-top">
                                    <strong>{guide.title}</strong>
                                    <span class="status-badge status-{guide.status}">{getStatusLabel(guide.status)}</span>
                                </div>
                                <p>{guide.summary || 'No summary yet.'}</p>
                                <div class="guide-list-meta">
                                    <span>Updated {formatDate(guide.updatedAt)}</span>
                                </div>
                                <div class="guide-list-tags">
                                {#if guide.isAssigned}<span class="mini-tag">Assigned</span>{/if}
                                {#if guide.pendingDeleteRequestCount}<span class="mini-tag warn">Delete pending</span>{/if}
                            </div>
                        </button>
                        </div>

                        {#if selectedGuideId === guide.id && false}
                            <div class="list-card-detail" transition:slide={{ duration: 220 }}>
                                {#if isLoadingDetail}
                                    <div class="skeleton" style="height: 380px;"></div>
                                {:else if detail}
                                    <div class="editor-stack">
                                        <div class="panel-card">
                                            <div class="section-heading">
                                                <div>
                                                    <h3>Content</h3>
                                                    <p>Add content sections and order them exactly how readers should see them.</p>
                                                </div>
                                            </div>

                                            <div class="block-toolbar">
                                                <div class="block-picker">
                                                    <button class="btn btn-primary block-picker-trigger" type="button" onclick={() => openNewBlockModal()}>
                                                        Add Content Block
                                                    </button>
                                                </div>
                                            </div>

                                            {#if detail.blocks?.length}
                                                <div class="block-list">
                                                    {#each detail.blocks as block, index (block.id)}
                                                        <div class="block-card">
                                                            <div class="block-card-header">
                                                                <div>
                                                                    <span class="block-type">{blockTypeLabel(block.blockType)}</span>
                                                                    <strong>{blockPreviewText(block)}</strong>
                                                                </div>
                                                                <div class="block-actions">
                                                                    <button class="icon-btn" type="button" disabled={index === 0 || blockMutationId === `${block.id}:up`} onclick={() => moveBlock(block.id, 'up')} aria-label="Move block up">
                                                                        ↑
                                                                    </button>
                                                                    <button class="icon-btn" type="button" disabled={index === detail.blocks.length - 1 || blockMutationId === `${block.id}:down`} onclick={() => moveBlock(block.id, 'down')} aria-label="Move block down">
                                                                        ↓
                                                                    </button>
                                                                    <button class="btn btn-small" type="button" onclick={() => openEditBlockModal(block)}>Edit</button>
                                                                    <button class="btn btn-small" type="button" disabled={blockMutationId === `${block.id}:duplicate`} onclick={() => duplicateBlock(block.id)}>Duplicate</button>
                                                                    <button class="btn btn-small btn-danger" type="button" disabled={blockMutationId === `${block.id}:delete`} onclick={() => removeBlock(block.id)}>Remove</button>
                                                                </div>
                                                            </div>

                                                            <div class="block-preview">
                                                                {#if block.blockType === 'heading'}
                                                                    <div class="preview-heading level-{block.payload?.level || 2}">{block.payload?.text}</div>
                                                                {:else if block.blockType === 'text'}
                                                                    <p>{block.payload?.content}</p>
                                                                {:else if block.blockType === 'image'}
                                                                    <div class="preview-image-card">
                                                                        <span>{block.payload?.imageUrl}</span>
                                                                        {#if block.payload?.caption}<p>{block.payload.caption}</p>{/if}
                                                                    </div>
                                                                {:else if block.blockType === 'button'}
                                                                    <div class="preview-button-card">{block.payload?.label} -> {block.payload?.url}</div>
                                                                {:else if block.blockType === 'divider'}
                                                                    <hr />
                                                                {:else if block.blockType === 'collapsible'}
                                                                    <details open>
                                                                        <summary>{block.payload?.title}</summary>
                                                                        <p>{block.payload?.content}</p>
                                                                    </details>
                                                                {/if}
                                                            </div>
                                                        </div>
                                                    {/each}
                                                </div>
                                            {/if}
                                        </div>

                                    </div>
                                {/if}
                            </div>
                        {/if}
                    </div>
                {:else}
                    <div class="empty-state">
                        {selectedGuideTab === GUIDE_TABS.archived ? 'No archived guides yet.' : 'No active guides yet.'}
                    </div>
                {/each}
            </div>
        {/if}
    </aside>
</div>
{/if}

<Modal bind:isOpen={showCreateModal} title="Create Guide">
    <div class="modal-form">
        <label>
            <span>Title</span>
            <input type="text" bind:value={createForm.title} maxlength="120" placeholder="Guide title" />
        </label>
        <label>
            <span>Summary</span>
            <textarea bind:value={createForm.summary} rows="3" maxlength="400" placeholder="What is this guide for?"></textarea>
        </label>
        <div class="field-stack">
            <span>Security</span>
            <Select bind:value={createForm.accessMode} options={GUIDE_ACCESS_OPTIONS} />
            <small>{getGuideAccessHelpText(createForm.accessMode)}</small>
        </div>
        {#if createForm.accessMode === 'discord_mutual_guild'}
            <div class="field-stack">
                <span>Required Server</span>
                <Select bind:value={createForm.accessGuildId} options={guideGuildOptions} disabled={isLoadingGuideGuildOptions} placeholder={isLoadingGuideGuildOptions ? 'Loading servers...' : 'Select server'} />
                <small>Readers must be in this specific Discord server with the bot.</small>
            </div>
        {/if}
        {#if createForm.accessMode === 'password'}
            <label>
                <span>Password</span>
                <input type="password" bind:value={createForm.accessPassword} maxlength="120" placeholder="Set a password for readers" />
                <small>Readers must enter this password before the guide opens.</small>
            </label>
        {/if}
        <div class="modal-actions">
            <button class="btn" type="button" onclick={() => showCreateModal = false}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={isCreatingGuide} onclick={createGuide}>
                Create Guide
            </LoadingButton>
        </div>
    </div>
</Modal>

<Modal bind:isOpen={showBlockModal} title={editingBlockId ? 'Edit Block' : 'Add Block'} wide={true}>
    <div class="modal-form">
        <div class="field-stack">
            <span>Block Type</span>
            <Select bind:value={blockForm.blockType} options={editingBlockId ? BLOCK_TYPE_OPTIONS : PICKABLE_BLOCK_TYPE_OPTIONS} disabled={!!editingBlockId} />
        </div>

        {#if blockForm.blockType === 'heading'}
            <div class="two-column">
                <div class="field-stack">
                    <span>Heading Text</span>
                    <input type="text" bind:value={blockForm.headingText} maxlength="200" placeholder="Enter heading" />
                </div>
                <div class="field-stack">
                    <span>Heading Level</span>
                    <Select bind:value={blockForm.headingLevel} options={[
                        { value: '1', label: 'Level 1' },
                        { value: '2', label: 'Level 2' },
                        { value: '3', label: 'Level 3' },
                        { value: '4', label: 'Level 4' },
                    ]} />
                </div>
            </div>
        {:else if blockForm.blockType === 'text'}
            <div class="field-stack">
                <span>Content</span>
                <textarea bind:value={blockForm.textContent} rows="8" placeholder="Write your guide content"></textarea>
            </div>
        {:else if blockForm.blockType === 'image'}
            <div class="field-stack">
                <span>Image Source</span>
                <Select bind:value={blockForm.imageSource} options={[
                    { value: 'url', label: 'External URL' },
                    { value: 'upload', label: 'Upload file' },
                ]} />
            </div>
            {#if blockForm.imageSource === 'upload'}
                <div class="field-stack">
                    <span>Upload Image</span>
                    <input
                        class="sr-only-input"
                        type="file"
                        accept="image/png,image/jpeg,image/webp,image/gif"
                        bind:this={imageUploadInput}
                        onchange={uploadGuideImage}
                        disabled={isUploadingImage}
                    />
                    <button
                        class="image-upload-dropzone"
                        class:drag-active={isImageDropActive}
                        type="button"
                        onclick={openImageUploadPicker}
                        ondragover={handleImageDropZoneDragOver}
                        ondragleave={handleImageDropZoneDragLeave}
                        ondrop={handleImageDrop}
                        disabled={isUploadingImage}
                    >
                        <strong>{isUploadingImage ? 'Uploading image...' : 'Drop image here or click to browse'}</strong>
                        <span>
                            {#if blockForm.imageAssetId}
                                Uploaded image ready and linked to this block.
                            {:else}
                                PNG, JPEG, WebP, or GIF up to 8MB.
                            {/if}
                        </span>
                    </button>
                    {#if isUploadingImage}
                        <small>Keep this window open while the upload finishes.</small>
                    {:else if blockForm.imageAssetId}
                        <small>The uploaded image will be used for this block when you save.</small>
                    {/if}
                </div>
            {:else}
                <div class="field-stack">
                    <span>Image URL</span>
                    <input type="url" bind:value={blockForm.imageUrl} placeholder="https://example.com/image.png" />
                </div>
            {/if}
            {#if getImageModalPreviewUrl()}
                <div class="image-upload-preview-shell">
                    <span>Preview</span>
                    <div class="image-upload-preview-card">
                        <img src={getImageModalPreviewUrl()} alt={blockForm.imageAlt || 'Guide image preview'} />
                    </div>
                </div>
            {/if}
            <div class="field-stack">
                <span>Alt Text</span>
                <input type="text" bind:value={blockForm.imageAlt} maxlength="200" placeholder="Describe the image" />
            </div>
            <div class="field-stack">
                <span>Caption</span>
                <textarea bind:value={blockForm.imageCaption} rows="3" maxlength="500" placeholder="Optional caption"></textarea>
            </div>
            <div class="field-stack">
                <span>Image Width (%)</span>
                <input type="range" bind:value={blockForm.imageWidth} min="20" max="100" step="5" />
                <small>{blockForm.imageWidth}%</small>
            </div>
        {:else if blockForm.blockType === 'button'}
            <div class="field-stack">
                <span>Button Label</span>
                <input type="text" bind:value={blockForm.buttonLabel} maxlength="120" placeholder="Open resource" />
            </div>
            <div class="field-stack">
                <span>Destination URL</span>
                <input type="url" bind:value={blockForm.buttonUrl} placeholder="https://example.com" />
            </div>
            <div class="field-stack">
                <span>Style</span>
                <Select bind:value={blockForm.buttonStyle} options={[
                    { value: 'primary', label: 'Primary' },
                    { value: 'secondary', label: 'Secondary' },
                    { value: 'ghost', label: 'Ghost' },
                ]} />
            </div>
        {:else if blockForm.blockType === 'divider'}
            <div class="muted-state inline-empty">Divider blocks add a visual break between guide sections.</div>
        {:else if blockForm.blockType === 'collapsible'}
            <div class="field-stack">
                <span>Section Title</span>
                <input type="text" bind:value={blockForm.collapsibleTitle} maxlength="200" placeholder="Section title" />
            </div>
            <div class="field-stack">
                <span>Section Content</span>
                <textarea bind:value={blockForm.collapsibleContent} rows="8" placeholder="Hidden content that opens on click"></textarea>
            </div>
        {:else if blockForm.blockType === 'table'}
            <div class="table-builder-shell">
                <div class="table-builder-header">
                    <div>
                        <span>{editingBlockId ? 'Table Block' : 'Insert Table'}</span>
                        <strong>{editingBlockId ? 'Resize the table here, then edit headers and cell values in the live guide preview.' : 'Choose the table size now. You can enter the data after inserting it.'}</strong>
                    </div>
                    <div class="table-builder-stats">
                        <span>{getTablePickerColumns()} column{getTablePickerColumns() === 1 ? '' : 's'}</span>
                        <span>{getTablePickerRows()} row{getTablePickerRows() === 1 ? '' : 's'}</span>
                    </div>
                </div>

                <div class="table-insert-picker" role="presentation" onmouseleave={clearTablePickerPreview}>
                    {#each Array.from({ length: 6 }, (_, rowIndex) => rowIndex + 1) as rowCount}
                        {#each Array.from({ length: 8 }, (_, columnIndex) => columnIndex + 1) as columnCount}
                            <button
                                class="table-insert-cell"
                                class:is-active={columnCount <= getTablePickerColumns() && rowCount <= getTablePickerRows()}
                                type="button"
                                onclick={() => resizeTableDraft(rowCount, columnCount)}
                                onmouseenter={() => setTablePickerPreview(rowCount, columnCount)}
                                aria-label={`Insert ${columnCount} by ${rowCount} table`}
                            ></button>
                        {/each}
                    {/each}
                </div>
                <small class="table-insert-hint">Hover to preview dimensions. Click to set the table size.</small>

                {#if editingBlockId}
                    <div class="table-builder-footer is-inline-edit-note">
                        <small>Select the table block in the guide and edit the columns or cells directly there. This modal only controls the table size.</small>
                    </div>
                {:else}
                    <div class="table-builder-footer">
                        <small>After you add the table, select it in the guide to fill the cells inline.</small>
                    </div>
                {/if}
            </div>
        {:else if blockForm.blockType === 'table_of_contents'}
            <div class="field-stack">
                <span>Section Title</span>
                <input type="text" bind:value={blockForm.tocTitle} maxlength="120" placeholder="Table of contents" />
                <small>Leave blank to use the default title.</small>
            </div>
        {/if}

        <div class="modal-actions">
            <button class="btn" type="button" onclick={closeBlockModal}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={!!blockMutationId && blockMutationId === (editingBlockId || 'new')} onclick={saveBlock}>
                {editingBlockId ? 'Save Block' : 'Add Block'}
            </LoadingButton>
        </div>
    </div>
</Modal>

<Modal bind:isOpen={showAssignmentsModal} title={`Guide Settings${detail?.title ? ` - ${detail.title}` : ''}`} wide={true}>
    <div class="modal-form">
        <div class="panel-card settings-panel">
            <div class="section-heading">
                <div>
                    <h3>Guide Details</h3>
                </div>
                <span class="status-badge status-{detail?.status}">{getStatusLabel(detail?.status)}</span>
            </div>

            <div class="form-grid">
                <label>
                    <span>Title</span>
                    <input
                        type="text"
                        value={detail?.title || ''}
                        oninput={(event) => detail = { ...detail, title: event.currentTarget.value }}
                        maxlength="120"
                        placeholder="Guide title"
                    />
                </label>
                <label class="summary-field">
                    <span>Summary</span>
                    <textarea
                        rows="3"
                        oninput={(event) => detail = { ...detail, summary: event.currentTarget.value }}
                        maxlength="400"
                        placeholder="Short description for admins and readers"
                    >{detail?.summary || ''}</textarea>
                </label>
                <div class="field-stack">
                    <span>Security</span>
                    <Select
                        value={detail?.accessMode || 'public'}
                        options={GUIDE_ACCESS_OPTIONS}
                        onchange={(value) => detail = { ...detail, accessMode: value }}
                    />
                    <small>{getGuideAccessHelpText(detail?.accessMode)}</small>
                </div>
                {#if detail?.accessMode === 'discord_mutual_guild'}
                    <div class="field-stack summary-field">
                        <span>Required Server</span>
                        <Select
                            value={detail?.accessGuildId || ''}
                            options={guideGuildOptions}
                            disabled={isLoadingGuideGuildOptions}
                            placeholder={isLoadingGuideGuildOptions ? 'Loading servers...' : 'Select server'}
                            onchange={(value) => detail = { ...detail, accessGuildId: value }}
                        />
                        <small>Readers must be in this specific Discord server with the bot.</small>
                    </div>
                {/if}
                {#if detail?.accessMode === 'password'}
                    <label class="summary-field">
                        <span>{detail?.hasPassword ? 'Change Password' : 'Password'}</span>
                        <input
                            type="password"
                            bind:value={guideAccessPasswordDraft}
                            maxlength="120"
                            placeholder={detail?.hasPassword ? '' : 'Set a password for readers'}
                        />
                        <small>{detail?.hasPassword ? 'Leave this blank to keep the current password.' : 'Readers must enter this password before the guide opens.'}</small>
                    </label>
                {/if}
            </div>

        </div>

        <div class="panel-card settings-panel">
            <div class="section-heading">
                <div>
                    <h3>Assigned Admins</h3>
                    <p>Choose which guide-management admins can help edit this guide.</p>
                </div>
            </div>

            {#if isLoadingAssignableAdmins}
                <div class="muted-state inline-empty">Loading admins...</div>
            {:else if !getGuideAssignableAdmins().length}
                <div class="muted-state inline-empty">No assignable admins found.</div>
            {:else}
                <div class="assignee-select-shell">
                    <button class="assignee-select-trigger" type="button" onclick={toggleAssigneeMenu}>
                        <span>
                            {#if getSelectedAssigneeLabels().length}
                                {getSelectedAssigneeLabels().length} admin{getSelectedAssigneeLabels().length === 1 ? '' : 's'} selected
                            {:else}
                                Select admins
                            {/if}
                        </span>
                        <Icon name="chevronDown" size={14} />
                    </button>

                    {#if showAssigneeMenu}
                        <div class="assignee-select-menu">
                            {#each getGuideAssignableAdmins() as admin (admin.userId)}
                                <button
                                    class="assignee-option"
                                    class:is-selected={selectedAssigneeUserIds.includes(admin.userId)}
                                    type="button"
                                    onclick={() => toggleAssignee(admin.userId, !selectedAssigneeUserIds.includes(admin.userId))}
                                >
                                    <div class="assignee-option-copy">
                                        <strong>{admin.username || admin.userId}</strong>
                                    </div>
                                    {#if selectedAssigneeUserIds.includes(admin.userId)}
                                        <Icon name="check" size={14} />
                                    {/if}
                                </button>
                            {/each}
                        </div>
                    {/if}
                </div>
            {/if}
        </div>

        <div class="modal-actions">
            <button class="btn" type="button" onclick={() => { showAssignmentsModal = false; showAssigneeMenu = false; guideAccessPasswordDraft = ''; }}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={isSavingMeta || isSavingAssignments} onclick={saveGuideSettings}>
                Save
            </LoadingButton>
        </div>
    </div>
</Modal>

<style>
    .content-workspace-shell {
        display: grid;
        min-height: 100vh;
        background:
            linear-gradient(180deg, var(--theme-bg-subtle), transparent),
            var(--color-base);
    }

    .workspace-topbar {
        position: sticky;
        top: 0;
        z-index: 20;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        align-self: start;
        min-height: 0;
        height: auto;
        padding: 8px 14px;
        background: color-mix(in srgb, var(--color-card) 92%, transparent);
        backdrop-filter: blur(14px);
        border-bottom: 1px solid var(--color-border);
    }

    .workspace-back {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 0;
        background: transparent;
        color: var(--color-text-primary);
        font: inherit;
        font-weight: 600;
        cursor: pointer;
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--radius-md);
        flex: 0 0 auto;
    }

    .workspace-back:hover {
        background: var(--theme-bg-medium-strong);
    }

    .workspace-topbar-left {
        min-width: 0;
        flex: 1 1 auto;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .workspace-title-group {
        min-width: 0;
        display: grid;
        gap: 2px;
    }

    .workspace-title-group strong {
        color: var(--color-text-primary);
        font-size: 15px;
        line-height: 1.2;
    }

    .workspace-title-group p {
        margin: 0;
        color: var(--color-text-muted);
        font-size: 12px;
        line-height: 1.4;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 560px;
    }

    .workspace-topbar-right {
        min-width: 0;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 10px;
        flex-wrap: nowrap;
    }

    .workspace-status {
        flex-shrink: 0;
    }

    .workspace-topbar :global(.btn),
    .workspace-topbar :global(button.btn) {
        min-height: 30px;
        font-size: 13px;
        padding-top: 0;
        padding-bottom: 0;
    }

    .workspace-actions :global(a.btn),
    .workspace-actions :global(button.btn) {
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .content-workspace-canvas {
        display: grid;
        gap: 20px;
        padding: 12px 24px 120px;
    }

    .workspace-actions {
        min-width: 0;
        display: flex;
        flex-wrap: nowrap;
        gap: 8px;
        align-items: center;
        justify-content: flex-end;
    }

    .workspace-actions-mobile {
        display: none;
        position: relative;
        flex: 0 0 auto;
    }

    .workspace-actions-trigger {
        min-width: 104px;
        justify-content: center;
    }

    .workspace-actions-menu {
        position: absolute;
        top: calc(100% + 8px);
        right: 0;
        min-width: 196px;
        display: grid;
        gap: 6px;
        padding: 8px;
        border: 1px solid color-mix(in srgb, var(--theme-accent-cool-border) 60%, var(--theme-border-strong));
        border-radius: 18px;
        background:
            linear-gradient(180deg, color-mix(in srgb, var(--theme-panel-sheen-strong) 92%, transparent), transparent 72%),
            color-mix(in srgb, var(--theme-panel-ink-strong) 96%, black 4%);
        box-shadow:
            0 18px 40px rgba(2, 8, 18, 0.34),
            inset 0 1px 0 var(--theme-panel-topline);
        backdrop-filter: blur(18px);
        z-index: 30;
        transform-origin: top right;
    }

    .workspace-actions-menu::before {
        content: '';
        position: absolute;
        top: -6px;
        right: 18px;
        width: 12px;
        height: 12px;
        border-top: 1px solid color-mix(in srgb, var(--theme-accent-cool-border) 60%, var(--theme-border-strong));
        border-left: 1px solid color-mix(in srgb, var(--theme-accent-cool-border) 60%, var(--theme-border-strong));
        background: color-mix(in srgb, var(--theme-panel-ink-strong) 97%, black 3%);
        transform: rotate(45deg);
    }

    .workspace-actions-menu-item,
    .workspace-actions-menu :global(button.workspace-actions-menu-item) {
        width: 100%;
        min-height: 42px;
        display: inline-flex;
        align-items: center;
        justify-content: flex-start;
        padding: 0 14px;
        border: 1px solid color-mix(in srgb, var(--theme-border-medium) 82%, transparent);
        border-radius: 12px;
        background: color-mix(in srgb, var(--theme-bg-soft) 72%, transparent);
        color: var(--color-text-primary);
        font: inherit;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition:
            background-color 160ms ease,
            border-color 160ms ease,
            color 160ms ease,
            transform 160ms ease;
    }

    .workspace-actions-menu-item:hover,
    .workspace-actions-menu :global(button.workspace-actions-menu-item:hover) {
        background: color-mix(in srgb, var(--theme-accent-cool-fill-soft) 76%, var(--theme-bg-soft));
        border-color: color-mix(in srgb, var(--theme-accent-cool-border-medium) 82%, transparent);
        transform: translateY(-1px);
    }

    .workspace-actions-menu-item.is-primary,
    .workspace-actions-menu :global(button.workspace-actions-menu-item.is-primary) {
        background: color-mix(in srgb, var(--theme-accent-cool-fill-soft) 86%, var(--theme-bg-soft));
        border-color: var(--theme-accent-cool-border-medium);
        color: var(--theme-accent-cool-text-strong);
    }

    .workspace-actions-menu-item.is-danger,
    .workspace-actions-menu :global(button.workspace-actions-menu-item.is-danger) {
        background: color-mix(in srgb, var(--color-danger-soft) 72%, var(--theme-bg-soft));
        border-color: color-mix(in srgb, var(--theme-danger-border-bright) 78%, transparent);
        color: var(--color-danger);
    }

    .workspace-actions-menu-item.is-danger:hover,
    .workspace-actions-menu :global(button.workspace-actions-menu-item.is-danger:hover) {
        background: color-mix(in srgb, var(--color-danger-soft) 90%, transparent);
        border-color: var(--theme-danger-border-bright);
    }

    .content-stage {
        display: flex;
        justify-content: center;
    }

    .content-stage-column {
        width: min(100%, 760px);
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    .content-page-preview {
        margin: 0;
        width: 100%;
        padding: 28px;
        border: 1px solid var(--theme-border-medium);
        border-radius: 28px;
        background: var(--theme-panel-ink);
        box-shadow: var(--shadow-lg);
        overflow: visible;
    }

    .content-guide-hero {
        display: grid;
        gap: 12px;
        padding-bottom: 24px;
        border-bottom: 1px solid var(--theme-border-medium);
        margin-bottom: 26px;
    }

    .content-guide-title {
        margin: 0;
        font-size: clamp(30px, 5vw, 54px);
        line-height: 1.05;
        color: var(--color-text-primary);
    }

    .content-guide-summary,
    .content-guide-meta {
        color: var(--theme-accent-cool-text-soft);
        line-height: 1.7;
    }

    .content-guide-summary {
        margin: 0;
        max-width: 60ch;
        font-size: 18px;
    }

    .content-guide-meta {
        font-size: 14px;
    }

    .content-block-list {
        display: flex;
        flex-direction: column;
        gap: 22px;
    }

    .content-block-row {
        display: block;
        padding: 0;
        background: transparent;
        border-top: 0;
        position: relative;
        cursor: pointer;
        border-radius: 14px;
        transition: background 0.15s ease, box-shadow 0.15s ease;
    }

    .content-block-row + .content-block-row {
        margin-top: 0;
    }

    .content-block-row.type-heading + .content-block-row.type-text {
        margin-top: 2px;
    }

    .content-block-row.type-text + .content-block-row.type-text {
        margin-top: 0;
    }

    .content-block-row.type-text + .content-block-row.type-heading,
    .content-block-row.type-image + .content-block-row.type-heading,
    .content-block-row.type-button + .content-block-row.type-heading,
    .content-block-row.type-collapsible + .content-block-row.type-heading,
    .content-block-row.type-table-of-contents + .content-block-row.type-heading {
        margin-top: 0;
    }

    .content-block-row.type-divider {
        margin-top: 0;
    }

    .content-block-row.type-divider + .content-block-row {
        margin-top: 0;
    }

    .content-block-row.type-text + .content-block-row.type-image,
    .content-block-row.type-image + .content-block-row.type-text,
    .content-block-row.type-image + .content-block-row.type-button,
    .content-block-row.type-button + .content-block-row.type-text,
    .content-block-row.type-table + .content-block-row.type-text {
        margin-top: 0;
    }

    .content-block-row:hover {
        background: var(--theme-panel-sheen-line);
    }

    .content-block-row.selected {
        background: var(--theme-accent-cool-fill-subtle);
        box-shadow: 0 0 0 1px var(--theme-accent-cool-border);
    }

    .content-block-row.type-image.selected {
        background: transparent;
        box-shadow: none;
    }

    .content-block-row.type-image,
    .content-block-row.type-image:hover,
    .content-block-row.type-image.selected {
        padding: 0;
        background: transparent;
        box-shadow: none;
        border-radius: 0;
    }

    .block-row-toolbar,
    .block-row-meta,
    .block-row-controls,
    .move-controls,
    .block-action-menu,
    .menu-trigger,
    .block-action-popover,
    .block-action-option {
        display: none;
    }

    .content-block-preview {
        color: var(--color-text-primary);
        font-size: 16px;
        line-height: 1.8;
        white-space: pre-wrap;
    }

    .inline-heading-editor,
    .inline-text-editor {
        width: 100%;
        display: block;
        padding: 0;
        border: 0;
        outline: 0;
        resize: none;
        overflow: hidden;
        background: transparent;
        color: inherit;
        font: inherit;
        line-height: inherit;
    }

    .inline-heading-editor::placeholder,
    .inline-text-editor::placeholder {
        color: var(--color-text-muted);
    }

    .inline-text-editor {
        min-height: 28px;
        font-size: 16px;
        line-height: 1.9;
        white-space: pre-wrap;
    }

    .inline-heading-editor {
        min-height: 44px;
        font-weight: 700;
    }

    .preview-heading {
        margin: 0;
        line-height: 1.2;
        color: var(--color-text-primary);
    }

    .preview-heading.level-1 {
        font-size: 40px;
    }

    .preview-heading.level-2 {
        font-size: 32px;
    }

    .preview-heading.level-3 {
        font-size: 24px;
    }

    .preview-heading.level-4 {
        font-size: 20px;
    }

    .content-block-preview > :first-child {
        margin-top: 0;
    }

    .content-block-preview > :last-child {
        margin-bottom: 0;
    }

    .content-block-row.type-divider hr {
        margin: 0;
        border: 0;
        border-top: 1px solid var(--theme-border-strong);
    }

    .rendered-rich-text {
        color: var(--color-text-primary);
    }

    .rendered-rich-text :global(p) {
        margin: 0;
        line-height: 1.9;
    }

    .rendered-rich-text :global(p + p) {
        margin-top: 6px;
    }

    .rendered-rich-text :global(.rich-list) {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        margin: 1px 0;
    }

    .rendered-rich-text :global(.rich-list.depth-2) {
        padding-left: 24px;
    }

    .rendered-rich-text :global(.rich-list.depth-3) {
        padding-left: 48px;
    }

    .rendered-rich-text :global(.rich-bullet) {
        flex: 0 0 auto;
        width: 12px;
        text-align: center;
        line-height: 1.85;
        font-size: 15px;
        color: var(--color-text-primary);
    }

    .rendered-rich-text :global(.rich-list-content) {
        min-width: 0;
        line-height: 1.85;
    }

    .rendered-rich-text :global(.rich-spacer) {
        height: 1.1em;
    }

    .rendered-rich-text :global(strong) {
        font-weight: 700;
        color: var(--color-text-primary);
    }

    .rendered-rich-text :global(a) {
        color: var(--theme-accent-cool-link);
        text-decoration: underline;
        text-underline-offset: 2px;
        word-break: break-word;
    }

    .rendered-rich-text :global(a:hover) {
        color: var(--theme-accent-cool-link-hover);
    }

    .sr-only-input {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }

    .image-upload-dropzone {
        width: 100%;
        min-height: 120px;
        display: grid;
        place-items: center;
        gap: 8px;
        padding: 20px 18px;
        border: 1.5px dashed var(--theme-accent-cool-border-medium);
        border-radius: 16px;
        background: var(--theme-panel-sheen-line);
        color: var(--color-text-primary);
        text-align: center;
        cursor: pointer;
        transition:
            border-color 180ms ease,
            background-color 180ms ease,
            transform 180ms ease;
    }

    .image-upload-dropzone strong {
        font-size: 15px;
        line-height: 1.4;
    }

    .image-upload-dropzone span {
        color: var(--color-text-muted);
        font-size: 13px;
        line-height: 1.5;
    }

    .image-upload-dropzone:hover:not(:disabled),
    .image-upload-dropzone.drag-active {
        border-color: var(--theme-accent-cool-border-brightest);
        background: var(--theme-accent-cool-fill-subtle);
        transform: translateY(-1px);
    }

    .image-upload-dropzone:disabled {
        cursor: wait;
        opacity: 0.8;
        transform: none;
    }

    .image-upload-preview-shell {
        display: grid;
        gap: 10px;
    }

    .image-upload-preview-shell > span {
        display: block;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--color-text-muted);
    }

    .image-upload-preview-card {
        border: 1px solid var(--theme-accent-cool-border-soft);
        border-radius: 16px;
        background: var(--theme-bg-soft);
        padding: 10px;
    }

    .image-upload-preview-card img {
        display: block;
        width: 100%;
        max-height: 260px;
        object-fit: contain;
        border-radius: 12px;
        background: var(--color-overlay);
    }

    .table-builder-shell {
        display: grid;
        gap: 16px;
        padding: 18px;
        border: 1px solid var(--theme-border-medium);
        border-radius: 22px;
        background:
            radial-gradient(circle at top left, var(--theme-accent-cool-fill-subtle), transparent 55%),
            var(--theme-bg-soft);
    }

    .table-builder-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 16px;
    }

    .table-builder-header span {
        display: block;
        margin-bottom: 6px;
        color: var(--theme-accent-cool-text);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
    }

    .table-builder-header strong {
        color: var(--color-text-primary);
        font-size: 16px;
        font-weight: 700;
        line-height: 1.35;
    }

    .table-builder-stats {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        gap: 8px;
    }

    .table-builder-stats span {
        margin: 0;
        padding: 7px 10px;
        border: 1px solid var(--theme-border-medium);
        border-radius: 999px;
        background: var(--theme-bg-medium);
        color: var(--theme-accent-cool-text-soft);
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0;
        text-transform: none;
    }

    .table-builder-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }

    .table-builder-actions :global(.btn) {
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .table-insert-picker {
        display: grid;
        grid-template-columns: repeat(8, minmax(0, 1fr));
        gap: 6px;
        max-width: 360px;
        padding: 12px;
        border: 1px solid var(--theme-border-medium);
        border-radius: 18px;
        background: var(--theme-panel-sheen-line);
    }

    .table-insert-cell {
        aspect-ratio: 1;
        border: 1px solid var(--theme-border-strong);
        border-radius: 6px;
        background: var(--theme-bg-soft);
        cursor: pointer;
        transition:
            background 140ms ease,
            border-color 140ms ease,
            transform 140ms ease;
    }

    .table-insert-cell:hover,
    .table-insert-cell.is-active {
        border-color: var(--theme-accent-cool-border-brightest);
        background: var(--theme-accent-cool-fill-soft);
        transform: translateY(-1px);
    }

    .table-insert-hint {
        margin: -6px 0 0;
        color: var(--theme-accent-cool-text-muted);
        line-height: 1.5;
    }

    .table-builder-footer small {
        margin: 0;
        color: var(--theme-accent-cool-text-muted);
        line-height: 1.55;
    }

    .preview-image-media {
        margin: 0;
        display: grid;
        gap: 8px;
    }

    .preview-image-media img {
        display: block;
        width: var(--image-width, 100%);
        max-width: 100%;
        max-height: 420px;
        object-fit: contain;
        border-radius: 12px;
    }

    .preview-image-media p,
    .preview-image-media span {
        margin: 0;
        color: var(--color-text-muted);
        font-size: 14px;
        line-height: 1.6;
    }

    .preview-table-wrap {
        overflow-x: auto;
        border: 1px solid var(--theme-border-medium);
        border-radius: 22px;
        background:
            linear-gradient(180deg, var(--theme-panel-sheen), var(--theme-bg-subtle)),
            var(--theme-panel-ink-soft);
        box-shadow: inset 0 1px 0 var(--theme-panel-topline);
    }

    .preview-table {
        width: 100%;
        min-width: 480px;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .preview-table.is-editing {
        min-width: 100%;
    }

    .preview-table th,
    .preview-table td {
        padding: 13px 15px;
        text-align: left;
        vertical-align: top;
        border-bottom: 1px solid var(--theme-border-medium);
        overflow-wrap: anywhere;
        word-break: break-word;
        hyphens: auto;
    }

    .preview-table th {
        color: var(--color-text-primary);
        font-size: 12px;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        background: var(--theme-panel-sheen-strong);
    }

    .preview-table td {
        color: color-mix(in oklab, var(--color-text-primary) 90%, transparent);
        line-height: 1.65;
    }

    .table-inline-input {
        width: 100%;
        min-width: 0;
        max-width: 100%;
        padding: 8px 10px;
        border: 1px solid var(--theme-border-medium);
        border-radius: 12px;
        background: var(--theme-bg-soft);
        color: var(--color-text-primary);
        font: inherit;
        line-height: 1.45;
        outline: none;
        overflow: hidden;
        text-overflow: ellipsis;
        transition:
            border-color 160ms ease,
            background 160ms ease,
            box-shadow 160ms ease;
    }

    .table-inline-input:focus {
        border-color: var(--theme-accent-cool-border-bright);
        background: var(--theme-bg-medium-strong);
        box-shadow: 0 0 0 3px var(--theme-focus-ring);
    }

    .table-inline-header-input {
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        background: var(--theme-bg-medium);
    }

    .table-empty-cell {
        display: block;
        color: color-mix(in oklab, var(--color-text-secondary) 65%, transparent);
        overflow-wrap: anywhere;
        word-break: break-word;
    }

    .preview-table tbody tr:nth-child(even) td {
        background: color-mix(in oklab, var(--theme-bg-subtle) 90%, transparent);
    }

    .preview-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .preview-toc {
        display: grid;
        gap: 12px;
        padding: 18px 20px;
        border: 1px solid var(--theme-border-medium);
        border-radius: 18px;
        background: var(--theme-panel-sheen-line);
        justify-items: start;
    }

    .preview-toc-title {
        color: var(--color-text-primary);
        font-size: 15px;
        font-weight: 700;
    }

    .preview-toc-list {
        display: grid;
        gap: 8px;
        width: 100%;
        justify-items: start;
    }

    .preview-toc-link {
        width: 100%;
        display: block;
        padding: 0;
        border: 0;
        appearance: none;
        background: transparent;
        color: color-mix(in oklab, var(--color-text-primary) 84%, transparent);
        font: inherit;
        text-align: left;
        text-decoration: none;
        line-height: 1.5;
        cursor: pointer;
        justify-self: start;
    }

    .preview-toc-link:hover {
        color: var(--theme-accent-cool-link);
    }

    .preview-toc-link.level-3 {
        padding-left: 18px;
    }

    .preview-toc-link.level-4 {
        padding-left: 36px;
    }

    .preview-toc-empty {
        margin: 0;
        color: color-mix(in oklab, var(--color-text-secondary) 82%, transparent);
    }

    .selected-block-toolbar {
        position: absolute;
        top: 50%;
        left: calc(100% + 18px);
        transform: translateY(-50%);
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 10px;
        border: 1px solid var(--theme-border-strong);
        border-radius: 18px;
        background: var(--theme-panel-ink-strong);
        box-shadow: var(--shadow-md);
        z-index: 8;
    }

    .selected-block-action {
        width: 42px;
        height: 42px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid var(--theme-border-strong);
        border-radius: 12px;
        background: var(--theme-bg-medium);
        color: var(--color-text-primary);
        cursor: pointer;
        transition: background 0.15s ease, border-color 0.15s ease, transform 0.15s ease;
    }

    .selected-block-action:hover:not(:disabled) {
        background: var(--theme-accent-cool-fill-soft);
        border-color: var(--theme-accent-cool-border-strong);
        transform: translateY(-1px);
    }

    .selected-block-action:disabled {
        opacity: 0.45;
        cursor: not-allowed;
    }

    .selected-block-action.danger:hover:not(:disabled) {
        background: var(--color-danger-soft);
        border-color: var(--theme-danger-border-bright);
    }

    .add-component-picker {
        position: relative;
        width: 100%;
    }

    .add-component-card {
        width: 100%;
        min-height: 72px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1.5px dashed var(--theme-border-bright);
        border-radius: 16px;
        background: var(--theme-bg-subtle);
        color: var(--color-text-primary);
        font: inherit;
        cursor: pointer;
        transition: border-color 0.15s ease, background 0.15s ease, transform 0.15s ease;
    }

    .add-component-card:hover {
        border-color: var(--color-accent);
        background: var(--theme-bg-medium);
        transform: translateY(-1px);
    }

    .add-component-card.is-empty {
        min-height: 72px;
    }

    .add-component-copy {
        font-size: 16px;
        font-weight: 600;
        letter-spacing: 0.01em;
    }

    .guides-layout {
        display: block;
    }

    .sidebar-card,
    .panel-card,
    .block-card {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
    }

    .sidebar-card,
    .panel-card {
        padding: 20px;
    }

    .list-toolbar,
    .section-heading,
    .list-card-top,
    .guide-list-meta,
    .guide-list-tags,
    .meta-actions,
    .share-actions,
    .block-card-header,
    .block-actions,
    .modal-actions {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .list-toolbar,
    .section-heading,
    .block-card-header {
        justify-content: space-between;
    }

    .list-toolbar-guides {
        align-items: flex-start;
        flex-wrap: wrap;
        row-gap: 10px;
    }

    .list-toolbar-copy {
        flex: 1 1 200px;
        min-width: 0;
    }

    .guide-toolbar-actions {
        margin-left: auto;
        display: inline-flex;
        align-items: center;
        justify-content: flex-end;
        gap: 12px;
        flex: 0 0 auto;
    }

    .panel-title,
    .section-heading h3 {
        margin: 0;
        font-size: 18px;
        color: var(--color-text-primary);
    }

    .panel-title {
        line-height: 1.08;
        text-wrap: balance;
    }

    .panel-subtitle,
    .section-heading p,
    .list-card p,
    .panel-subtitle {
        margin-top: 4px;
    }

    .panel-subtitle {
        margin-bottom: 0;
        line-height: 1.45;
        color: var(--color-text-muted);
    }

    .create-guide-button {
        flex: 0 0 auto;
        min-height: 42px;
        white-space: nowrap;
    }

    .guide-status-select {
        flex: 0 0 170px;
        min-width: 170px;
    }

    .list-stack,
    .editor-stack,
    .form-grid,
    .modal-form,
    .block-list {
        display: grid;
        gap: 14px;
    }

    .list-stack {
        margin-top: 16px;
    }

    .list-accordion {
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        background: var(--color-card);
        overflow: hidden;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
    }

    .list-accordion.expanded {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 1px var(--color-accent);
    }

    .list-card {
        width: 100%;
        text-align: left;
        padding: 16px;
        cursor: pointer;
        background: transparent;
        border: 0;
        transition: border-color 0.18s ease, transform 0.18s ease;
    }

    .list-card-shell {
        position: relative;
    }

    .block-picker {
        position: relative;
    }

    .block-picker-trigger {
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .list-card.active {
        transform: translateY(-1px);
    }

    .list-card strong {
        color: var(--color-text-primary);
        font-size: 15px;
    }

    .list-card-top {
        padding-right: min(64%, 580px);
    }

    .guide-list-meta,
    .guide-list-tags {
        margin-top: 10px;
        flex-wrap: wrap;
        color: var(--color-text-muted);
        font-size: 12px;
    }

    .mini-tag {
        padding: 4px 8px;
        border-radius: 999px;
        background: var(--theme-bg-medium-strong);
        color: var(--color-text-secondary);
    }

    .mini-tag.warn {
        background: var(--color-danger-soft);
        color: color-mix(in oklab, var(--color-danger) 82%, white 18%);
    }

    .list-card-detail {
        padding: 18px;
        border-top: 1px solid var(--color-border);
        background: var(--theme-bg-subtle);
    }

    .editor-stack {
        gap: 18px;
    }

    .inline-empty,
    .muted-state {
        display: grid;
        gap: 8px;
        justify-items: start;
    }

    .empty-state {
        color: var(--color-text-muted);
        font-size: 13px;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .summary-field {
        grid-column: 1 / -1;
    }

    label,
    .field-stack {
        display: grid;
        gap: 8px;
    }

    label span,
    .field-stack > span,
    .block-type {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: var(--color-text-muted);
    }

    input,
    textarea,
    :global(.custom-select .select-trigger) {
        width: 100%;
        background: var(--theme-underlay-ink);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        color: var(--color-text-primary);
        padding: 12px 14px;
        font: inherit;
    }

    input[type="range"] {
        padding: 0;
        background: transparent;
        border: 0;
        border-radius: 0;
    }

    textarea {
        resize: vertical;
        min-height: 90px;
    }

    :global(.custom-select) {
        width: 100%;
    }

    .meta-actions,
    .share-actions,
    .block-toolbar,
    .block-actions {
        flex-wrap: wrap;
    }

    .meta-actions {
        margin-top: 16px;
    }

    .share-box {
        margin-top: 18px;
        padding: 16px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--theme-panel-sheen-line);
        display: grid;
        gap: 12px;
    }

    .block-toolbar {
        margin-top: 18px;
    }

    .block-card {
        padding: 16px;
        display: grid;
        gap: 14px;
    }

    .block-preview {
        color: var(--color-text-secondary);
        line-height: 1.6;
        white-space: pre-wrap;
    }

    .preview-heading {
        color: var(--color-text-primary);
        font-weight: 700;
    }

    .preview-heading.level-1 { font-size: 28px; }
    .preview-heading.level-2 { font-size: 24px; }
    .preview-heading.level-3 { font-size: 20px; }
    .preview-heading.level-4 { font-size: 17px; }

    .preview-button-card {
        padding: 12px 14px;
        border-radius: var(--radius-md);
        background: var(--theme-bg-soft);
        border: 1px solid var(--color-border);
    }

    .preview-button-card {
        color: var(--color-text-primary);
        word-break: break-word;
    }

    details summary {
        cursor: pointer;
        font-weight: 600;
        color: var(--color-text-primary);
    }

    .assignee-select-shell {
        margin-top: 16px;
        display: grid;
        gap: 12px;
        position: relative;
    }

    .assignee-select-trigger,
    .assignee-option {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        background: var(--theme-underlay-ink);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        color: var(--color-text-primary);
        text-align: left;
        cursor: pointer;
        padding: 12px 14px;
    }

    .assignee-select-trigger {
        font: inherit;
    }

    .assignee-select-menu {
        display: grid;
        gap: 8px;
        padding: 10px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        background: var(--theme-overlay-ink);
        max-height: 260px;
        overflow-y: auto;
    }

    .assignee-option {
        padding: 10px 12px;
    }

    .assignee-option.is-selected {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 1px var(--color-accent);
    }

    .assignee-option-copy {
        min-width: 0;
    }

    .assignee-chip-list {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .assignee-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 10px;
        border-radius: 999px;
        border: 1px solid var(--color-border);
        background: var(--theme-bg-medium);
        color: var(--color-text-primary);
        cursor: pointer;
        font: inherit;
    }

    .assignee-option-copy strong {
        width: 100%;
    }

    .assignee-option-copy strong {
        display: block;
        color: var(--color-text-primary);
        overflow-wrap: anywhere;
    }

    .settings-panel {
        padding: 16px;
    }

    .settings-panel .section-heading p {
        font-size: 13px;
        line-height: 1.45;
    }

    .status-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 5px 10px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
    }

    .status-draft {
        background: var(--theme-bg-bright);
        color: var(--color-text-secondary);
    }

    .status-published {
        background: var(--color-success-soft);
        color: var(--color-success);
    }

    .status-unpublished {
        background: var(--color-warning-soft);
        color: var(--color-warning);
    }

    .status-archived {
        background: var(--color-danger-soft);
        color: var(--color-danger);
    }

    .icon-btn,
    .btn-small {
        min-height: 34px;
    }

    .icon-btn {
        width: 34px;
        border-radius: 10px;
        border: 1px solid var(--color-border);
        background: var(--theme-bg-soft);
        color: var(--color-text-primary);
        cursor: pointer;
    }

    .btn-small {
        padding: 8px 10px;
    }

    .two-column {
        display: grid;
        grid-template-columns: 1fr 180px;
        gap: 12px;
    }

    @media (max-width: 1100px) {
        .guides-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 840px) {
        .list-toolbar-guides {
            align-items: stretch;
        }

        .list-toolbar-copy {
            flex-basis: 100%;
        }

        .guide-toolbar-actions {
            width: 100%;
            flex-wrap: wrap;
            justify-content: stretch;
        }

        .guide-status-select {
            flex: 1 1 100%;
            min-width: 0;
        }

        .create-guide-button {
            margin-left: 0;
            flex: 1 1 100%;
            width: 100%;
            justify-content: center;
        }

        .workspace-topbar {
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }

        .workspace-topbar-left,
        .workspace-topbar-right {
            width: auto;
        }

        .workspace-topbar-left {
            align-items: center;
            justify-content: flex-start;
            flex: 1 1 auto;
            min-width: 0;
        }

        .workspace-topbar-right {
            flex-direction: row;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: nowrap;
            gap: 10px;
            flex: 0 0 auto;
        }

        .workspace-status {
            align-self: auto;
            flex: 0 0 auto;
        }

        .workspace-actions {
            display: none;
        }

        .workspace-actions-mobile {
            display: block;
            margin-left: auto;
        }

        .workspace-title-group p {
            white-space: normal;
            overflow: visible;
            text-overflow: clip;
            max-width: none;
        }
    }

    @media (max-width: 720px) {
        .content-workspace-canvas,
        .workspace-topbar,
        .content-stage-card,
        .sidebar-card,
        .panel-card {
            padding: 16px;
        }

        .list-card,
        .list-card-detail {
            padding: 14px;
        }

        .list-card-top {
            padding-right: 0;
        }

        .two-column {
            grid-template-columns: 1fr;
        }

        .block-card-header,
        .list-card-top,
        .list-toolbar,
        .section-heading,
        .workspace-topbar,
        .workspace-topbar-right,
        .workspace-actions,
        .content-stage-column,
        .content-block-list {
            gap: 16px;
        }

        .content-page-preview {
            padding: 20px 16px;
            border-radius: 22px;
        }

        .content-guide-title {
            font-size: clamp(24px, 10vw, 40px);
        }

        .content-guide-summary {
            font-size: 16px;
            max-width: none;
            line-height: 1.6;
        }

        .content-block-row {
            padding: 0;
        }

        .selected-block-toolbar {
            position: static;
            margin-top: 12px;
            transform: none;
            flex-direction: row;
            justify-content: flex-start;
        }

        .workspace-topbar {
            min-height: auto;
            gap: 12px;
        }

        .table-builder-header {
            flex-direction: column;
        }

        .table-builder-stats {
            justify-content: flex-start;
        }

        .table-insert-picker {
            max-width: 100%;
        }

        .block-toolbar .btn,
        .meta-actions :global(button),
        .workspace-back,
        .workspace-actions :global(button) {
            width: 100%;
        }

    }

    @media (max-width: 560px) {
        .content-workspace-canvas {
            padding: 12px 12px 72px;
        }

        .workspace-topbar,
        .sidebar-card,
        .panel-card {
            padding: 14px;
        }

        .content-page-preview {
            padding: 18px 14px;
            border-radius: 20px;
        }

        .workspace-topbar-left {
            align-items: center;
        }

        .workspace-actions {
            flex-direction: row;
        }

        .workspace-back {
            width: auto;
            flex: 0 0 auto;
            align-self: flex-start;
        }

        .workspace-title-group {
            flex: 1 1 auto;
        }

        .guide-toolbar-actions {
            gap: 10px;
        }

        .content-guide-hero {
            gap: 10px;
            padding-bottom: 20px;
            margin-bottom: 22px;
        }

        .content-guide-title {
            font-size: clamp(22px, 11vw, 34px);
        }

        .preview-image-media img {
            max-height: 320px;
        }
    }
</style>
