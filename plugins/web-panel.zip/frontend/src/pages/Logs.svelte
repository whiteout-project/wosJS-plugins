<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { formatTime, showToast } from '../lib/utils.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import Select from '../components/ui/Select.svelte';

    const PAGE_SIZE = 25;

    let logs = $state([]);
    let total = $state(0);
    let currentPage = $state(0);
    let isLoading = $state(true);
    let searchQuery = $state('');
    let filterType = $state('all');
    let expandedLogId = $state(null);

    let totalPages = $derived.by(() => Math.max(1, Math.ceil(total / PAGE_SIZE)));

    const TYPE_OPTIONS = [
        { value: 'all',   label: 'All Types' },
        { value: 'error', label: 'Error' },
        { value: 'warn',  label: 'Warning' },
        { value: 'info',  label: 'Info' },
    ];

    const TYPE_BADGE_CLASS = {
        error: 'badge-danger',
        warn:  'badge-warning',
        info:  'badge-info',
    };

    // Keys to show first; deferred keys (stack traces) show last
    const DETAIL_KEY_PRIORITY = ['error', 'error_message', 'function', 'action', 'process_id', 'processId'];
    const DETAIL_KEY_DEFER    = ['stack', 'stack_trace', 'error_stack'];

    let filteredLogs = $derived.by(() => {
        if (!searchQuery.trim()) return logs;
        const q = searchQuery.toLowerCase();
        return logs.filter(l =>
            (l.action || '').toLowerCase().includes(q) ||
            (l.extra_details || '').toLowerCase().includes(q) ||
            (l.action_type || '').toLowerCase().includes(q)
        );
    });

    async function loadPage(page, type) {
        isLoading = true;
        expandedLogId = null;
        try {
            const typeParam = type !== 'all' ? `&type=${encodeURIComponent(type)}` : '';
            const data = await apiFetch(`/api/logs?page=${page}&limit=${PAGE_SIZE}${typeParam}`);
            if (data) {
                if (Array.isArray(data)) {
                    // Legacy server format — raw array (server needs restart to use pagination)
                    logs = data;
                    total = data.length;
                    currentPage = 0;
                } else {
                    logs = data.logs ?? [];
                    total = data.total ?? 0;
                    currentPage = data.page ?? 0;
                }
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    function goToPage(page) {
        loadPage(page, filterType);
    }

    function onFilterChange(type) {
        filterType = type;
        loadPage(0, type);
    }

    function toggleExpand(logId) {
        expandedLogId = expandedLogId === logId ? null : logId;
    }

    function parseDetails(raw) {
        if (!raw) return null;
        try {
            const parsed = JSON.parse(raw);
            if (typeof parsed === 'object' && parsed !== null) return parsed;
        } catch {
            // Not JSON — return as raw string
        }
        return raw;
    }

    function sortedDetailKeys(obj) {
        const keys = Object.keys(obj);
        const priority = keys
            .filter(k => DETAIL_KEY_PRIORITY.includes(k))
            .sort((a, b) => DETAIL_KEY_PRIORITY.indexOf(a) - DETAIL_KEY_PRIORITY.indexOf(b));
        const deferred = keys.filter(k => DETAIL_KEY_DEFER.includes(k));
        const middle = keys
            .filter(k => !DETAIL_KEY_PRIORITY.includes(k) && !DETAIL_KEY_DEFER.includes(k))
            .sort();
        return [...priority, ...middle, ...deferred];
    }

    onMount(() => loadPage(0, 'all'));
</script>

<PageHeader label="System Logs" />

<div class="logs-toolbar">
    <div class="search-input">
        <Icon name="search" size={14} />
        <input type="text" bind:value={searchQuery} placeholder="Search current page..." />
    </div>
    <Select value={filterType} onchange={onFilterChange} options={TYPE_OPTIONS} />
</div>

{#if isLoading}
    <div class="skeleton" style="height: 300px;"></div>
{:else}
    <div class="table-container">
        <table class="data-table logs-table">
            <thead>
                <tr>
                    <th class="col-time">Time</th>
                    <th class="col-type">Type</th>
                    <th>Action</th>
                    <th class="col-expand"></th>
                </tr>
            </thead>
            <tbody>
                {#each filteredLogs as log (log.id ?? log.time)}
                    {@const details = parseDetails(log.extra_details)}
                    {@const isExpanded = expandedLogId === (log.id ?? log.time)}
                    {@const hasDetails = !!details}
                    <tr
                        class="log-row"
                        class:is-expanded={isExpanded}
                        class:has-details={hasDetails}
                        onclick={() => hasDetails && toggleExpand(log.id ?? log.time)}
                    >
                        <td class="col-time nowrap">{formatTime(log.time ?? log.timestamp)}</td>
                        <td class="col-type">
                            <span class="badge {TYPE_BADGE_CLASS[log.action_type] ?? 'badge-muted'}">
                                {log.action_type || '—'}
                            </span>
                        </td>
                        <td class="col-action">{log.action || '—'}</td>
                        <td class="col-expand">
                            {#if hasDetails}
                                <span class="expand-icon" class:rotated={isExpanded}>
                                    <Icon name="chevronDown" size={14} />
                                </span>
                            {/if}
                        </td>
                    </tr>
                    {#if isExpanded && hasDetails}
                        <tr class="detail-row">
                            <td colspan="4">
                                <div class="detail-panel">
                                    {#if typeof details === 'object'}
                                        <dl class="detail-list">
                                            {#each sortedDetailKeys(details) as key}
                                                {@const val = details[key]}
                                                {#if val !== null && val !== undefined && val !== ''}
                                                    <div class="detail-entry" class:is-stack={DETAIL_KEY_DEFER.includes(key)}>
                                                        <dt>{key}</dt>
                                                        <dd>
                                                            {#if DETAIL_KEY_DEFER.includes(key)}
                                                                <pre class="stack-trace">{String(val)}</pre>
                                                            {:else if typeof val === 'object'}
                                                                <pre class="json-value">{JSON.stringify(val, null, 2)}</pre>
                                                            {:else}
                                                                <span class="detail-value">{String(val)}</span>
                                                            {/if}
                                                        </dd>
                                                    </div>
                                                {/if}
                                            {/each}
                                        </dl>
                                    {:else}
                                        <pre class="raw-detail">{String(details)}</pre>
                                    {/if}
                                </div>
                            </td>
                        </tr>
                    {/if}
                {:else}
                    <tr>
                        <td colspan="4" class="empty-cell">
                            {searchQuery ? 'No matching logs on this page' : 'No logs'}
                        </td>
                    </tr>
                {/each}
            </tbody>
        </table>
    </div>

    {#if totalPages > 1}
        <div class="pagination">
            <button
                class="btn btn-sm"
                disabled={currentPage === 0}
                onclick={() => goToPage(currentPage - 1)}
            >
                <Icon name="chevron-left" size={14} /> Prev
            </button>
            <span class="page-info">
                Page <strong>{currentPage + 1}</strong> of <strong>{totalPages}</strong>
                <span class="total-count">({total} total)</span>
            </span>
            <button
                class="btn btn-sm"
                disabled={currentPage >= totalPages - 1}
                onclick={() => goToPage(currentPage + 1)}
            >
                Next <Icon name="chevron-right" size={14} />
            </button>
        </div>
    {:else}
        <div class="log-count">{total} log{total !== 1 ? 's' : ''}</div>
    {/if}
{/if}

<style>
    .logs-toolbar {
        display: flex;
        gap: 12px;
        margin-bottom: 16px;
        align-items: center;
    }

    .search-input {
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        padding: 0 12px;
        flex: 1;
        max-width: 320px;
        color: var(--color-text-muted);
    }

    .search-input input {
        border: none;
        background: none;
        padding: 8px 0;
        width: 100%;
    }

    .search-input input:focus {
        border-color: transparent;
        box-shadow: none;
        outline: none;
    }

    .search-input:focus-within {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    .logs-toolbar :global(.custom-select) {
        width: auto;
        min-width: 140px;
    }

    /* Table column widths */
    .logs-table .col-time   { width: 140px; white-space: nowrap; }
    .logs-table .col-type   { width: 90px; }
    .logs-table .col-expand { width: 36px; text-align: center; }

    /* Clickable rows */
    .log-row.has-details {
        cursor: pointer;
    }
    .log-row.has-details:hover :global(td) {
        background: var(--color-card-hover);
    }
    .log-row.is-expanded :global(td) {
        background: var(--color-secondary);
        border-bottom: none;
    }

    /* Expand chevron */
    .expand-icon {
        display: inline-flex;
        color: var(--color-text-muted);
        transition: transform 0.2s ease;
    }
    .expand-icon.rotated {
        transform: rotate(180deg);
    }

    /* Info badge (not in global) */
    :global(.badge-info) {
        background: rgba(59, 130, 246, 0.15);
        color: #60a5fa;
    }

    /* Detail expansion panel */
    .detail-row :global(td) {
        background: var(--color-secondary);
        padding: 0;
        border-top: none;
    }

    .detail-panel {
        padding: 12px 16px 16px 16px;
        border-top: 1px solid var(--color-border);
    }

    .detail-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin: 0;
    }

    .detail-entry {
        display: grid;
        grid-template-columns: 160px 1fr;
        gap: 8px;
        align-items: start;
    }

    .detail-entry dt {
        font-size: 11px;
        font-weight: 600;
        color: var(--color-text-muted);
        padding-top: 3px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        word-break: break-word;
    }

    .detail-entry dd {
        margin: 0;
        font-size: 13px;
        color: var(--color-text-secondary);
        word-break: break-word;
        min-width: 0;
    }

    .detail-value {
        display: block;
        line-height: 1.5;
    }

    .stack-trace,
    .json-value,
    .raw-detail {
        font-size: 11px;
        font-family: 'Consolas', 'Courier New', monospace;
        background: rgba(0, 0, 0, 0.2);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        padding: 8px 10px;
        margin: 0;
        white-space: pre-wrap;
        word-break: break-all;
        max-height: 200px;
        overflow-y: auto;
        color: var(--color-text-muted);
        line-height: 1.4;
    }

    /* Pagination */
    .pagination {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 16px;
        margin-top: 16px;
        padding: 8px 0;
    }

    .page-info {
        font-size: 14px;
        color: var(--color-text-secondary);
    }

    .total-count {
        color: var(--color-text-muted);
        font-size: 12px;
        margin-left: 4px;
    }

    .log-count {
        text-align: center;
        font-size: 13px;
        color: var(--color-text-muted);
        margin-top: 12px;
    }

    @media (max-width: 768px) {
        .logs-toolbar { flex-direction: column; }
        .search-input { max-width: 100%; }
        .logs-toolbar :global(.custom-select) { width: 100%; }
        .detail-entry { grid-template-columns: 1fr; }
        .detail-entry dt { padding-top: 0; }
        .logs-table .col-time { width: auto; }
    }
</style>
