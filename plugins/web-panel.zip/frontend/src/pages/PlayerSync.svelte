<script>
    import { onMount, untrack } from 'svelte';
    import { apiFetch as panelFetch } from '../lib/api.js';
    import { navigateTo, selectedGameType } from '../lib/stores.js';
    import { formatFurnaceLevel, getSettlementLevelLabel, formatTime, showToast } from '../lib/utils.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import Select from '../components/ui/Select.svelte';
    import PlayerAvatar from '../components/ui/PlayerAvatar.svelte';
    import Checkbox from '../components/ui/Checkbox.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import { PROCESS_STATUS } from '../lib/constants.js';

    const RUN_REASON_LABELS = {
        throttled: 'Waiting for the provider quota to reset.',
        busy: 'Waiting for another API request.',
        auth: 'Connection paused. Check the API key and test again.',
        permission: 'Waiting for administrator access to this alliance.',
        paused: 'Sync paused. Saved progress will resume when eligible.',
        unconfigured: 'Complete the connection setup to resume syncing.',
        unavailable: 'Player Sync is not loaded.',
        changed: 'The setup or roster changed. Start a fresh sync.',
        notFound: 'Player data is unavailable or the player left this bot alliance.',
        network: 'The API could not be reached. Stored player data was kept.',
        mapping: 'Check the response field mappings.',
        response: 'The provider response could not be used. Stored player data was kept.',
        stopped: 'Stopped by an administrator.'
    };

    let state = $state(null);
    let loading = $state(true);
    let busy = $state(false);
    let activeAction = $state('');
    let tab = $state('status');
    let failure = $state('');
    let draft = $state(null);
    let secret = $state('');
    let configText = $state('');
    let configFileInput = $state(null);
    let testId = $state('');
    let profile = $state(null);
    let scheduleDrafts = $state({});
    let memberModalOpen = $state(false);
    let memberControlsAvailable = $state(false);
    let memberPreview = $state(null);
    let memberConfirmOpen = $state(false);
    async function cancelMemberPreview() {
        if (memberPreview) await perform(`/members/confirm/${memberPreview.token}`, 'DELETE');
        memberPreview = null;
        memberConfirmOpen = false;
    }
    async function confirmMemberPreview() {
        if (await perform('/members/confirm', 'POST', { token: memberPreview.token })) {
            memberPreview = null;
            memberConfirmOpen = false;
        }
    }
    let memberAlliance = $state(null);
    let memberEnabled = $state('off');
    let memberHours = $state(24);
    let memberDelete = $state('off');
    function openMemberSettings(alliance) {
        failure = '';
        memberAlliance = alliance;
        memberEnabled = alliance.members?.enabled ? 'on' : 'off';
        memberHours = alliance.members?.hours || 24;
        memberDelete = alliance.members?.deleteNonMembers ? 'on' : 'off';
        memberModalOpen = true;
    }
    async function saveMemberSettings() {
        const result = await perform(`/alliances/${memberAlliance.id}/members`, 'PUT', {
            enabled: memberEnabled === 'on', hours: Number(memberHours), deleteNonMembers: memberDelete === 'on'
        });
        if (result) {
            memberModalOpen = false;
            if (result.memberPreview) {
                memberPreview = result.memberPreview;
                memberConfirmOpen = true;
            }
        }
    }
    const scheduleSnapshots = new Map();
    let importId = $state('');
    let destination = $state('');
    let guilds = $state([]);
    let guildId = $state('');
    let channels = $state([]);
    let channelId = $state('');
    let allianceName = $state('');
    let allianceState = $state('');
    let preview = $state(null);
    let confirmOpen = $state(false);
    let previewPage = $state(0);
    let expired = $state(false);
    let disposed = false;
    let expiryTimer;
    // App remounts this page per game; cleanup must keep the original confirmation context.
    const game = untrack(() => $selectedGameType);
    const apiFetch = (path, options = {}) => panelFetch(path, { ...options, gameType: game });
    let ready = $derived(!!(state?.enabled && state?.tested && state?.configured));
    let functionItems = $derived([
        ['status', 'Runs'],
        ...(state?.isOwner ? [['setup', 'Setup']] : []),
        ['alliances', 'Alliances & Schedule'],
        ['import', 'Import Alliance'],
        ['player', 'Player Details'],
        ['help', 'Help']
    ]);
    let mappingFields = $derived([
        ['id', 'Returned public ID (optional)'],
        ['name', 'Nickname'],
        ['level', getSettlementLevelLabel(game)],
        ['kingdom', 'State'],
        ['power', 'Power'],
        ['avatar', 'Picture URL']
    ]);
    let destinationOptions = $derived([
        { value: '', label: 'Choose a destination' },
        ...(state?.canManageAlliances ? [{ value: 'new', label: 'Create a new alliance' }] : []),
        ...(state?.alliances || []).map(alliance => ({ value: String(alliance.id), label: alliance.name }))
    ]);
    let guildOptions = $derived([
        { value: '', label: 'Choose a server' },
        ...guilds.map(guild => ({ value: guild.id, label: guild.name }))
    ]);
    let channelOptions = $derived([
        { value: '', label: 'Choose a channel' },
        ...channels.map(channel => ({ value: channel.id, label: '#' + channel.name }))
    ]);

    function selectFunction(value) {
        tab = value;
        if (value === 'import' && state?.canManageAlliances) loadGuilds();
    }

    function saveSchedule(allianceId) {
        const schedule = scheduleDrafts[allianceId];
        return perform(`/alliances/${allianceId}/schedule`, 'PUT', {
            enabled: schedule.enabled,
            hours: Number(schedule.hours)
        });
    }

    const validId = value =>
        /^\d{1,16}$/.test(String(value).trim()) && Number.isSafeInteger(Number(value)) && Number(value) > 0;
    const validHours = value => Number.isInteger(Number(value)) && Number(value) >= 1 && Number(value) <= 720;

    function updateState(result, reset = false) {
        if (disposed) return;
        if (state?.revision !== result?.revision) profile = null;
        state = result;
        if (reset && result?.installed && result.isOwner && !result.tested && tab === 'status') tab = 'setup';
        for (const alliance of result?.alliances || []) {
            const previous = scheduleSnapshots.get(alliance.id);
            const draft = scheduleDrafts[alliance.id];
            if (!draft) scheduleDrafts[alliance.id] = { enabled: alliance.enabled, hours: alliance.hours };
            else {
                if (previous?.enabled === draft.enabled) draft.enabled = alliance.enabled;
                if (previous?.hours === Number(draft.hours)) draft.hours = alliance.hours;
            }
            scheduleSnapshots.set(alliance.id, { enabled: alliance.enabled, hours: alliance.hours });
        }
        if (reset || !draft)
            draft = structuredClone(
                result?.profile || {
                    base_url: '',
                    player_path: 'players/{id}',
                    auth_header: 'X-Api-Key',
                    per_minute: 30,
                    per_day: 1000,
                    fields: {
                        id: '',
                        name: 'player.nick_name',
                        level: game === 'ks' ? 'player.town_center_level' : 'player.furnace_level',
                        kingdom: 'player.kid',
                        power: 'player.power',
                        avatar: 'player.avatar_url'
                    }
                }
            );
    }

    async function refresh(reset = false) {
        try {
            const result = await apiFetch('/api/player-sync/status');
            const memberCapability = result?.capabilities?.memberSync
                ? await apiFetch('/api/player-sync/members/capability').catch(() => null)
                : null;
            if (!disposed) memberControlsAvailable = !!memberCapability?.available;
            updateState(result || { installed: false }, reset);
        } catch (error) {
            if (!state) state = { installed: false };
            if (!disposed) failure = error.message;
        } finally {
            if (!disposed) loading = false;
        }
    }

    async function perform(path, method = 'POST', body, reset = false) {
        if (busy) return null;
        busy = true;
        activeAction = `${method} ${path}`;
        failure = '';
        try {
            const result = await apiFetch('/api/player-sync' + path, { method, body });
            if (!result) throw new Error('You no longer have access to this action.');
            if (disposed) {
                if (result.memberPreview)
                    await apiFetch(`/api/player-sync/members/confirm/${result.memberPreview.token}`, { method: 'DELETE' }).catch(() => {});
                if (path === '/import/preview' && result.token)
                    await apiFetch(`/api/player-sync/import/${result.token}`, { method: 'DELETE' }).catch(() => {});
                return null;
            }
            if (result.installed !== undefined) updateState(result, reset);
            else await refresh();
            return result;
        } catch (error) {
            if (!disposed) {
                failure = error.message;
                showToast(error.message, 'error');
                await refresh();
            }
            return null;
        } finally {
            if (!disposed) {
                busy = false;
                activeAction = '';
            }
        }
    }

    async function savePart(part) {
        const base = state.profile || draft;
        const result = await perform('/profile', 'PUT', { profile: { ...base, ...part } });
        if (result?.profile) for (const key of Object.keys(part)) draft[key] = structuredClone(result.profile[key]);
        return result;
    }

    async function saveKey() {
        const value = secret;
        secret = '';
        await perform('/key', 'PUT', { key: value });
    }

    async function importFile(event) {
        const file = event.currentTarget.files?.[0];
        event.currentTarget.value = '';
        if (!file) return;
        if (file.size > 65536 || !file.name.toLowerCase().endsWith('.json')) {
            failure = 'Choose a JSON file up to 64 KiB.';
            return;
        }
        configText = await file.text();
    }

    async function importSetup() {
        if (new TextEncoder().encode(configText).length > 65536) {
            failure = 'Setup files must be 64 KiB or smaller.';
            return;
        }
        const result = await perform('/profile', 'PUT', { profile: configText }, true);
        if (result) {
            configText = '';
            showToast(
                result.keyCleared
                    ? 'Setup imported. The old provider key was cleared.'
                    : 'Setup imported. Test the connection before enabling it.',
                'success'
            );
        }
    }

    function download(name, data) {
        const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
        const link = document.createElement('a');
        link.href = url;
        link.download = name;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 0);
    }

    async function exportSetup() {
        const result = await perform('/profile', 'GET');
        if (result) download(`player-sync-${game}.json`, result.profile);
    }

    async function inspectPlayer(test = false) {
        profile = null;
        const result = test
            ? await perform('/test', 'POST', { fid: testId })
            : await perform(`/players/${encodeURIComponent(testId)}`, 'GET');
        if (result) profile = test ? result.profile : result;
    }

    async function sync(allianceId = null) {
        const result = await perform('/runs', 'POST', { allianceIds: allianceId == null ? null : [allianceId] });
        if (result)
            showToast(
                `${result.processIds.length} sync run(s) queued; ${result.skipped} already queued, running or empty.`,
                'success'
            );
    }

    async function loadGuilds() {
        try {
            const result = await apiFetch('/api/guilds');
            if (!disposed) guilds = Array.isArray(result) ? result : [];
        } catch {
            if (!disposed) guilds = [];
        }
    }

    async function loadChannels() {
        channels = [];
        channelId = '';
        if (!guildId) return;
        const selected = guildId;
        try {
            const result = await apiFetch(`/api/guilds/${encodeURIComponent(selected)}/channels`);
            if (!disposed && guildId === selected) {
                channels = Array.isArray(result) ? result : [];
            }
        } catch (error) {
            if (!disposed) failure = error.message;
        }
    }

    async function previewImport() {
        const target =
            destination === 'new'
                ? { newAlliance: { name: allianceName, state: allianceState, channelId } }
                : { allianceId: Number(destination) };
        const result = await perform('/import/preview', 'POST', { fid: importId, target });
        if (!result) return;
        preview = result;
        previewPage = 0;
        expired = false;
        confirmOpen = true;
        clearTimeout(expiryTimer);
        expiryTimer = setTimeout(
            () => {
                expired = true;
            },
            Math.max(0, result.expiresAt - Date.now())
        );
    }

    async function cancelPreview() {
        if (busy) return;
        const token = preview?.token;
        confirmOpen = false;
        preview = null;
        clearTimeout(expiryTimer);
        if (token) {
            try {
                await apiFetch(`/api/player-sync/import/${token}`, { method: 'DELETE' });
            } catch (error) {
                if (!disposed) failure = error.message;
            }
        }
    }

    async function confirmImport() {
        const result = await perform('/import/confirm', 'POST', { token: preview?.token });
        if (result) {
            confirmOpen = false;
            preview = null;
            clearTimeout(expiryTimer);
            if (memberPreview?.token && activeAction !== 'POST /members/confirm')
                apiFetch(`/api/player-sync/members/confirm/${memberPreview.token}`, { method: 'DELETE' }).catch(() => {});
            showToast(
                `Added ${result.added}; already here ${result.existing}; registered elsewhere ${result.conflicts}; invalid ${result.invalid}.`,
                'success'
            );
        }
    }

    onMount(() => {
        refresh(true);
        const timer = setInterval(() => {
            if (!busy && document.visibilityState !== 'hidden') refresh();
        }, 10000);
        return () => {
            disposed = true;
            secret = '';
            clearInterval(timer);
            clearTimeout(expiryTimer);
            if (preview?.token && activeAction !== 'POST /import/confirm')
                apiFetch(`/api/player-sync/import/${preview.token}`, { method: 'DELETE' }).catch(() => {});
        };
    });
</script>

<PageHeader label="Player Sync">
    Connect your own player-data API to restore player profiles. WOS and Kingshot have separate settings and keys.
</PageHeader>

<div class="toolbar">
    <button class="btn btn-sm" onclick={() => navigateTo('alliances')}>
        <Icon name="chevron-left" size={14} /> Back to Alliances
    </button>
    <button class="btn btn-sm" onclick={() => refresh()} disabled={busy}>
        <Icon name="refresh" size={14} /> Refresh Status
    </button>
</div>

{#if loading}
    <div class="skeleton" style="height: 240px;"></div>
{:else if !state?.installed}
    <div class="form-card">
        <h3>Player Sync is not available</h3>
        <p>The plugin is not installed or loaded. The rest of the web panel still works.</p>
        {#if failure}<p class="error" role="alert">{failure}</p>{/if}
    </div>
{:else}
    <section class="form-card summary" aria-label="Player Sync status">
        <div>
            <span class="muted">Connection</span>
            <strong>{state.enabled ? 'Enabled' : 'Disabled'} · {state.provider || 'Not configured'}</strong>
        </div>
        <div>
            <span class="muted">Setup</span>
            <strong>{state.keyPresent ? 'Key saved' : 'No key'} · {state.tested ? 'Tested' : 'Test required'}</strong>
        </div>
        <div>
            <span class="muted">Requests today</span>
            <strong>{state.usage.used} / {state.limits?.perDay || '—'}</strong>
        </div>
        <div>
            <span class="muted">Pending change reports</span>
            <strong>{state.pendingReports}</strong>
        </div>
        {#if state.usage.retryAt}
            <p class="notice">
                API cooldown until {formatTime(new Date(state.usage.retryAt).toISOString())}.
                Saved sync progress will resume.
            </p>
        {/if}
        {#if state.error}
            <p class="notice">The provider rejected the connection. Check the API key and test again.</p>
        {/if}
    </section>

    <nav class="tabs" aria-label="Player Sync functions">
        {#each functionItems as item (item[0])}
            <button
                class="btn btn-sm"
                class:btn-primary={tab === item[0]}
                aria-pressed={tab === item[0]}
                onclick={() => selectFunction(item[0])}
                disabled={busy}
            >
                {item[1]}
            </button>
        {/each}
    </nav>

    {#if failure}
        <div class="notice error" role="alert">{failure}</div>
    {/if}
    {#if busy}
        <div class="notice" role="status">
            Working… API requests can take up to 100 seconds each.
            Existing player records are kept if a request fails.
        </div>
    {/if}

    {#if tab === 'setup' && state.isOwner && draft}
        <section class="form-card">
            <div class="section-header">
                <Icon name="settings" size={18} />
                <h3>Connect a provider</h3>
            </div>
            <p>
                Choose an example, add your key, test one player, then enable the connection.
                Custom connections and JSON import are under Advanced Setup.
                These providers are independent services, not WOSLand partners.
            </p>
            <div class="toolbar">
                <button class="btn btn-primary" disabled={busy} onclick={() => perform('/example', 'POST', undefined, true)}>
                    Use {game === 'ks' ? 'MightPulse' : 'WhiteoutStats'} Example
                </button>
                <a
                    class="btn"
                    href={game === 'ks' ? 'https://api.mightpulse.com/' : 'https://api.whiteoutstats.com/'}
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    Get an API Key
                </a>
            </div>

            <fieldset disabled={busy}>
                <legend>API Key</legend>
                <p>
                    Keys are never shown or included in setup exports. Enter the complete value, including
                    <code>Bearer </code> when required. Keep database backups private.
                </p>
                <label>
                    Replace key
                    <input
                        type="password"
                        bind:value={secret}
                        autocomplete="new-password"
                        maxlength="500"
                        placeholder={state.keyPresent ? 'A key is saved; enter a replacement' : 'Enter your API key'}
                    />
                </label>
                <div class="toolbar">
                    <LoadingButton class="btn" loading={activeAction === 'PUT /key'} disabled={busy || !secret.trim()} onclick={saveKey}>
                        Save Key
                    </LoadingButton>
                    <button class="btn btn-danger" onclick={() => perform('/key', 'DELETE')} disabled={!state.keyPresent}>
                        Remove Key
                    </button>
                </div>
            </fieldset>

            <fieldset disabled={busy}>
                <legend>Test and Enable</legend>
                <label>
                    Public player ID
                    <input type="text" bind:value={testId} inputmode="numeric" maxlength="16" />
                </label>
                <div class="toolbar">
                    <LoadingButton class="btn" loading={activeAction === 'POST /test'} disabled={busy || !state.configured || !validId(testId)} onclick={() => inspectPlayer(true)}>
                        Test One Player
                    </LoadingButton>
                    <button class="btn btn-primary" onclick={() => perform('/settings', 'PUT', { enabled: !state.enabled })} disabled={!state.enabled && !state.tested}>
                        {state.enabled ? 'Disable Connection' : 'Enable Connection'}
                    </button>
                </div>
                <p>A test changes no player records. Changing the connection, mappings, limits or key requires another test before enabling.</p>
            </fieldset>

            <details class="advanced-setup">
                <summary>Advanced Setup</summary>
                <fieldset disabled={busy}>
                    <legend>Connection</legend>
                    <label>
                        HTTPS base URL
                        <input type="text" bind:value={draft.base_url} placeholder="https://api.example.com/v1" maxlength="500" />
                    </label>
                    <label>
                        Player path
                        <input type="text" bind:value={draft.player_path} placeholder={'players/{id}'} maxlength="1000" />
                    </label>
                    <label>
                        Authentication header
                        <input type="text" bind:value={draft.auth_header} placeholder="X-Api-Key" maxlength="60" />
                    </label>
                    <button class="btn" onclick={() => savePart({ base_url: draft.base_url, player_path: draft.player_path, auth_header: draft.auth_header })}>
                        Save Connection
                    </button>
                </fieldset>

                <fieldset disabled={busy}>
                    <legend>Field Mappings</legend>
                    <p>Use dotted paths, such as <code>player.nick_name</code>, or numeric array indexes. Empty paths are skipped.</p>
                    <div class="form-grid">
                        {#each mappingFields as field (field[0])}
                            <label>
                                {field[1]}
                                <input type="text" bind:value={draft.fields[field[0]]} maxlength="200" />
                            </label>
                        {/each}
                    </div>
                    <button class="btn" onclick={() => savePart({ fields: draft.fields })}>Save Mappings</button>
                </fieldset>

                <fieldset disabled={busy}>
                    <legend>Request Limits</legend>
                    <div class="form-grid">
                        <label>
                            Per minute
                            <input type="number" min="1" max="600" bind:value={draft.per_minute} />
                        </label>
                        <label>
                            Per day
                            <input type="number" min="1" max="1000000" bind:value={draft.per_day} />
                        </label>
                    </div>
                    <button class="btn" onclick={() => savePart({ per_minute: Number(draft.per_minute), per_day: Number(draft.per_day) })}>
                        Save Limits
                    </button>
                </fieldset>

                <fieldset disabled={busy}>
                    <legend>Import / Export Setup</legend>
                    <p>
                        Setup files never carry the saved API key. Changing provider hosts clears the old key.
                        The optional <code>alliance</code> mapping enables roster imports.
                    </p>
                    <label>
                        Paste JSON
                        <textarea rows="7" bind:value={configText} placeholder={'{"base_url":"https://api.example.com/v1", ...}'}></textarea>
                    </label>
                    <div class="toolbar">
                        <input bind:this={configFileInput} type="file" accept=".json,application/json" aria-label="JSON setup file" onchange={importFile} hidden />
                        <button class="btn" onclick={() => configFileInput?.click()}>Choose JSON File</button>
                        <span class="muted">JSON · up to 64 KiB</span>
                    </div>
                    <div class="toolbar">
                        <button class="btn" onclick={importSetup} disabled={!configText.trim()}>Import Setup</button>
                        <button class="btn" onclick={exportSetup} disabled={!state.profile}>
                            <Icon name="download" size={14} /> Export Setup
                        </button>
                    </div>
                </fieldset>

            </details>
        </section>
    {:else if tab === 'alliances'}
        <section class="form-card">
            <div class="section-header">
                <Icon name="alliances" size={18} />
                <h3>Alliances & Schedule</h3>
            </div>
            <p>
                Automatic syncing starts only when enabled for an alliance. Default: every 24 hours.
                Only actual changes are posted in its configured Discord channel.
            </p>
            <LoadingButton class="btn btn-primary" loading={activeAction === 'POST /runs'} disabled={busy || !ready} onclick={() => sync()}>
                Sync All Accessible Alliances
            </LoadingButton>
            <div class="alliance-schedules">
                {#each state.alliances as alliance (alliance.id)}
                    <fieldset disabled={busy}>
                        <legend>{alliance.name}</legend>
                        <p>
                            {alliance.playerCount} players · State {alliance.state ?? '—'} ·
                            {alliance.channelId ? `Channel ${alliance.channelId}` : 'No reporting channel'} ·
                            {alliance.deferred} deferred profiles
                        </p>
                        <div class="schedule-controls">
                            <Checkbox label="Automatic sync" bind:checked={scheduleDrafts[alliance.id].enabled} disabled={busy || (!ready && !scheduleDrafts[alliance.id].enabled)} />
                            <label>
                                Interval (hours)
                                <input type="number" min="1" max="720" bind:value={scheduleDrafts[alliance.id].hours} />
                            </label>
                            <button class="btn" onclick={() => saveSchedule(alliance.id)} disabled={(scheduleDrafts[alliance.id].enabled && !ready) || !validHours(scheduleDrafts[alliance.id].hours)}>Save Schedule</button>
                            <button class="btn" onclick={() => sync(alliance.id)} disabled={!ready}>Sync Now</button>
                            {#if memberControlsAvailable}<button class="btn" onclick={() => openMemberSettings(alliance)}>Member Sync: {alliance.members?.enabled ? 'On' : 'Off'}</button>{/if}
                        </div>
                        <p class="muted">
                            Next profile sync: {alliance.enabled && alliance.nextAt ? formatTime(new Date(alliance.nextAt).toISOString()) : 'Off'}
                        </p>
                        {#if alliance.members?.enabled}
                            <p class="muted">Member sync: every {alliance.members.hours}h · Delete non-members: {alliance.members.deleteNonMembers ? 'On' : 'Off'} · Source: [{alliance.members.source?.tag}] {alliance.members.source?.state}</p>
                            <p class="muted">Next member sync: {alliance.members.nextAt ? formatTime(new Date(alliance.members.nextAt).toISOString()) : 'Waiting'}</p>
                        {/if}
                    </fieldset>
                {/each}
            </div>
        </section>
    {:else if tab === 'import'}
        <section class="form-card">
            <div class="section-header">
                <Icon name="download" size={18} />
                <h3>Import Alliance from a Player ID</h3>
            </div>
            <p>
                Fetch a provider roster using one member's public chief/governor ID.
                A preview is required before adding anyone. Existing assignments are kept.
            </p>
            <fieldset disabled={busy || !ready}>
                <label>
                    Seed player ID
                    <input type="text" bind:value={importId} inputmode="numeric" maxlength="16" />
                </label>
                <label>
                    Destination
                    <Select bind:value={destination} disabled={busy || !ready} options={destinationOptions} />
                </label>
                {#if destination === 'new'}
                    <label>
                        Server
                        <Select
                            bind:value={guildId}
                            disabled={busy || !ready}
                            options={guildOptions}
                            onchange={value => { guildId = value; loadChannels(); }}
                        />
                    </label>
                    <label>
                        Discord channel
                        <Select bind:value={channelId} disabled={busy || !ready} options={channelOptions} />
                    </label>
                    <label>
                        New name (optional)
                        <input type="text" bind:value={allianceName} maxlength="50" placeholder="Use the provider's alliance name" />
                    </label>
                    <label>
                        New state (optional)
                        <input type="text" bind:value={allianceState} inputmode="numeric" placeholder="Use the seed player's state" />
                    </label>
                {/if}
                <LoadingButton
                    class="btn btn-primary"
                    loading={activeAction === 'POST /import/preview'}
                    disabled={busy || !ready || !validId(importId) || !destination || (destination === 'new' && (!channelId || (allianceState.trim() !== '' && !validId(allianceState))))}
                    onclick={previewImport}
                >
                    Fetch Preview
                </LoadingButton>
            </fieldset>
        </section>
    {:else if tab === 'player'}
        <section class="form-card">
            <div class="section-header">
                <Icon name="players" size={18} />
                <h3>Player Details</h3>
            </div>
            <label>
                Registered player ID
                <input type="text" bind:value={testId} inputmode="numeric" maxlength="16" />
            </label>
            <button class="btn" onclick={() => inspectPlayer()} disabled={busy || !validId(testId)}>View Stored Profile</button>
        </section>
    {:else if tab === 'help'}
        <section class="form-card">
            <div class="section-header">
                <Icon name="guides" size={18} />
                <h3>Setup Guide</h3>
            </div>
            <ol>
                <li>Get your own API key from a provider.</li>
                <li>Choose the game in the panel's game selector.</li>
                <li>Open Setup and use the game example, import JSON, or edit the connection and mappings.</li>
                <li>Enter the key under API Key.</li>
                <li>Test a known public player ID and verify the returned fields.</li>
                <li>Enable Connection, then choose alliance schedules or Sync Now.</li>
            </ol>
            <p>
                <a href="https://api.whiteoutstats.com/" target="_blank" rel="noopener noreferrer">WhiteoutStats (WOS)</a> ·
                <a href="https://api.mightpulse.com/" target="_blank" rel="noopener noreferrer">MightPulse (KS)</a>
            </p>
            <p>These services are independent of WOSLand. Responses can be cached for up to an hour. API state replaces existing player overrides; transferred players remain registered. Pictures update silently.</p>
            <p>Rate limits pause sync without losing progress. Missing fields and API failures keep existing values. Setup exports omit keys, but database backups contain them and must stay private.</p>
            <p>If the plugin is unloaded, its controls become unavailable and normal bot features continue. Newly installed slash commands require a bot restart. See the Player Sync plugin README for custom alliance mappings and troubleshooting.</p>
        </section>
    {:else}
        <section class="form-card">
            <div class="section-header">
                <Icon name="processes" size={18} />
                <h3>Recent Runs</h3>
            </div>
            <div class="toolbar">
                <LoadingButton class="btn btn-primary" loading={activeAction === 'POST /runs'} disabled={busy || !ready} onclick={() => sync()}>
                    Sync All Accessible Alliances
                </LoadingButton>
            </div>
            {#if !state.runs.length}
                <p>No sync runs yet. Complete setup, then enable a schedule or run a manual sync.</p>
            {/if}
            {#each state.runs as run (run.id)}
                <div class="run">
                    <div>
                        <strong>#{run.id} · {state.alliances.find(alliance => alliance.id === run.allianceId)?.name || run.allianceId}</strong>
                        <p>
                            <span class="badge badge-{PROCESS_STATUS.COLORS[run.status] || 'muted'}">
                                {PROCESS_STATUS.LABELS[run.status] || run.status}
                            </span>
                            {run.done} checked · {run.failed} failed · {run.pending} pending
                        </p>
                        {#if run.kind === 'members'}
                            <p>Alliance member sync
                                {#if run.members} · {run.members.added} added · {run.members.removed} removed · {run.members.conflicts} registered elsewhere{/if}
                            </p>
                            {#if run.members?.removalSkipped}<p>Removal skipped: the provider did not verify a complete, fresh roster. Existing players were kept.</p>{/if}
                        {/if}
                        {#if run.reason}
                            <p>
                                {RUN_REASON_LABELS[run.reason] || 'Check the connection status before starting another sync.'}
                                {run.retryAt ? ` — retry after ${formatTime(new Date(run.retryAt).toISOString())}` : ''}
                            </p>
                        {/if}
                    </div>
                    {#if ['queued', 'active'].includes(run.status)}
                        <button class="btn btn-sm btn-danger" onclick={() => perform(`/runs/${run.id}`, 'DELETE')} disabled={busy}>Stop</button>
                    {/if}
                </div>
            {/each}
        </section>
    {/if}

    {#if profile && (tab === 'player' || tab === 'setup')}
        <section class="form-card profile">
            <div class="avatar"><PlayerAvatar src={profile.image_url} /></div>
            <div class="profile-copy">
                <h3>{profile.nickname || `ID ${profile.fid}`}</h3>
                <p>ID {profile.fid} · State {profile.state_override ?? profile.state ?? '—'}</p>
                <p>{getSettlementLevelLabel(game)}: {formatFurnaceLevel(profile.furnace_level, game)} · Power: {profile.power?.toLocaleString() ?? '—'}</p>
                <p>Last successful sync: {formatTime(profile.profile_synced_at)}</p>
            </div>
        </section>
    {/if}
{/if}

<Modal bind:isOpen={memberConfirmOpen} title="Confirm Member Sync Source" dismissible={!busy} onclose={cancelMemberPreview}>
    {#if memberPreview}
        <p>Enable member sync for <strong>{memberPreview.allianceName}</strong> using <strong>[{memberPreview.source.tag}] · State {memberPreview.source.state}</strong>?</p>
        <p class="muted">Identified using player ID {memberPreview.seed}.</p>
        <p>Every {memberPreview.hours} hours · Delete non-members: {memberPreview.deleteNonMembers ? 'On' : 'Off'}</p>
        {#if memberPreview.deleteNonMembers}<p>Players missing from this alliance will be deleted, including their bot history.</p>{/if}
        <p>This source stays fixed. Confirm only if this is the intended in-game alliance. This confirmation expires in five minutes.</p>
        {#if failure}<p role="alert" class="error">{failure}</p>{/if}
        <div class="modal-actions">
            <button class="btn" disabled={busy} onclick={cancelMemberPreview}>Cancel</button>
            <LoadingButton class="btn btn-primary" loading={busy} onclick={confirmMemberPreview}>Enable Member Sync</LoadingButton>
        </div>
    {/if}
</Modal>

<Modal bind:isOpen={memberModalOpen} title="Alliance Member Sync" dismissible={!busy}>
    <p>{memberAlliance?.name}</p>
    <p>Add missing members on a separate schedule. Review the in-game alliance before enabling it for the first time.</p>
    {#if memberAlliance?.members?.source}<p>Source: [{memberAlliance.members.source.tag}] · State {memberAlliance.members.source.state}</p>{/if}
    <label>Member sync
        <Select bind:value={memberEnabled} disabled={busy} options={[{ value: 'off', label: 'Disabled' }, { value: 'on', label: 'Enabled' }]} />
    </label>
    <label>Interval (hours)
        <input type="number" min="1" max="720" bind:value={memberHours} disabled={busy} />
    </label>
    <label>Delete non-members
        <Select bind:value={memberDelete} disabled={busy} options={[{ value: 'off', label: 'Disabled' }, { value: 'on', label: 'Enabled' }]} />
    </label>
    <p>Deletion is off by default. Enabling it deletes players absent from a verified roster, including their bot history. Incomplete rosters keep existing players.</p>
    {#if failure}<p role="alert" class="error">{failure}</p>{/if}
    <div class="modal-actions">
        <button class="btn" disabled={busy} onclick={() => memberModalOpen = false}>Cancel</button>
        <LoadingButton class="btn btn-primary" loading={busy} disabled={!validHours(memberHours) || (memberEnabled === 'on' && !ready)} onclick={saveMemberSettings}>Save</LoadingButton>
    </div>
</Modal>

<Modal bind:isOpen={confirmOpen} title="Confirm Alliance Import" wide dismissible={!busy} onclose={cancelPreview}>
    {#if preview}
        <p>Source: <strong>[{preview.source.tag}] {preview.source.name}</strong> · State {preview.source.state}</p>
        <p>Destination: <strong>{preview.destination.newAlliance?.name || state?.alliances.find(alliance => alliance.id === preview.destination.allianceId)?.name}</strong></p>
        {#if preview.destination.newAlliance}
            <p>State {preview.destination.newAlliance.state} · Discord channel {preview.destination.newAlliance.channelId}</p>
        {/if}
        <p>
            {preview.players.filter(player => player.status === 'add').length} addable ·
            {preview.players.filter(player => player.status === 'existing').length} already here ·
            {preview.players.filter(player => player.status === 'conflict').length} registered elsewhere ·
            {preview.invalid} invalid/duplicate entries.
        </p>
        <p class="notice">
            Only missing players will be added. No existing assignments will move.
            This exact preview expires at {formatTime(new Date(preview.expiresAt).toISOString())}.
        </p>
        <div class="preview-list">
            {#each preview.players.slice(previewPage * 20, (previewPage + 1) * 20) as player (player.fid)}
                <div>
                    {player.nickname || '—'} · ID {player.fid}
                    <span>{player.status === 'add' ? 'Addable' : player.status === 'existing' ? 'Already here' : 'Registered elsewhere'}</span>
                </div>
            {/each}
        </div>
        <div class="toolbar">
            {#if preview.players.length > 20}
            <button class="btn btn-sm" onclick={() => previewPage--} disabled={previewPage === 0}>
                <Icon name="chevron-left" size={14} /> Previous
            </button>
            <span>{previewPage + 1}/{Math.ceil(preview.players.length / 20)}</span>
            <button class="btn btn-sm" onclick={() => previewPage++} disabled={(previewPage + 1) * 20 >= preview.players.length}>
                Next <Icon name="chevron-right" size={14} />
            </button>
            {/if}
            <button class="btn btn-sm" onclick={() => download('alliance-import-preview.json', preview)}>
                <Icon name="download" size={14} /> Download Preview
            </button>
        </div>
        {#if failure}<p role="alert" class="error">{failure}</p>{/if}
        <div class="modal-actions">
            <button class="btn" onclick={cancelPreview} disabled={busy}>Cancel Import</button>
            <LoadingButton class="btn btn-primary" loading={activeAction === 'POST /import/confirm'} disabled={busy || expired || !state?.installed || !ready} onclick={confirmImport}>
                Confirm Import
            </LoadingButton>
        </div>
        {#if expired}<p class="error">This preview expired. Cancel and fetch a new one.</p>{/if}
    {/if}
</Modal>

<style>
    .section-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
        padding-bottom: 12px;
        border-bottom: 1px solid var(--color-border);
        color: var(--color-text-muted);
    }

    .section-header h3 {
        margin: 0;
    }

    .advanced-setup {
        margin-top: 22px;
    }

    .advanced-setup summary {
        cursor: pointer;
        padding: 12px 0;
        color: var(--color-text-primary);
        font-weight: 600;
    }

    p,
    li {
        color: var(--color-text-secondary);
        line-height: 1.6;
        overflow-wrap: anywhere;
    }

    .toolbar,
    .tabs {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 10px;
        margin: 14px 0;
    }

    .tabs .btn {
        width: auto;
    }

    .summary {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 16px;
    }

    .summary strong,
    .muted {
        display: block;
        overflow-wrap: anywhere;
    }

    .muted {
        font-size: 12px;
        color: var(--color-text-secondary);
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 16px;
    }

    fieldset {
        min-width: 0;
        margin-top: 22px;
        padding: 18px;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
    }

    legend {
        color: var(--color-text-primary);
        font-weight: 600;
        padding: 0 8px;
    }

    label {
        display: grid;
        gap: 8px;
        margin-bottom: 16px;
        color: var(--color-text-secondary);
        font-size: 13px;
    }

    input,
    textarea {
        min-width: 0;
        max-width: 100%;
    }

    textarea {
        resize: vertical;
        font-family: var(--font-mono);
    }

    .notice {
        padding: 14px;
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-md);
        margin: 12px 0;
    }

    .error {
        color: var(--status-danger);
    }

    .schedule-controls {
        display: flex;
        flex-wrap: wrap;
        align-items: end;
        gap: 16px;
    }

    .schedule-controls label {
        margin: 0;
    }

    .schedule-controls :global(.checkboxRoot) {
        min-height: 42px;
    }

    .run {
        display: flex;
        align-items: start;
        justify-content: space-between;
        gap: 16px;
        padding: 16px 0;
        border-bottom: 1px solid var(--color-border);
    }

    .profile {
        display: flex;
        gap: 12px;
        align-items: center;
    }

    .profile-copy { min-width: 0; overflow-wrap: anywhere; }

    .avatar {
        width: 48px;
        height: 48px;
        flex-shrink: 0;
        border-radius: var(--radius-md);
        overflow: hidden;
        background: var(--color-secondary);
        display: grid;
        place-items: center;
    }

    .preview-list {
        max-height: 360px;
        overflow: auto;
    }

    .preview-list > div {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        padding: 8px;
        border-bottom: 1px solid var(--color-border);
        overflow-wrap: anywhere;
    }

    @media (max-width: 640px) {
        .summary,
        .form-grid {
            grid-template-columns: 1fr;
        }
        .profile {
            align-items: start;
        }
        .schedule-controls {
            display: grid;
        }
        .modal-actions {
            flex-wrap: wrap;
        }
    }
</style>
