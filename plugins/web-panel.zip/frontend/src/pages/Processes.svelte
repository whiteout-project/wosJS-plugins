<script>
    import { onMount, onDestroy } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { formatTime, getGameBadgeLabel, showToast } from '../lib/utils.js';
    import { PROCESS_STATUS } from '../lib/constants.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';
    import Icon from '../components/ui/Icon.svelte';

    let processes = $state([]);
    let isLoading = $state(true);
    let pollingTimer = null;

    // Delete confirmation
    let confirmDeleteOpen = $state(false);
    let deleteProcessId = $state(null);

    let sortedProcesses = $derived(() => {
        const queuedByPriority = processes
            .filter(p => p.status === 'queued')
            .sort((a, b) => a.priority - b.priority || new Date(a.created_at) - new Date(b.created_at));
        const nextInQueueId = queuedByPriority[0]?.id ?? null;

        return [...processes].sort((a, b) => {
            const orderA = PROCESS_STATUS.ORDER[a.status] ?? 5;
            const orderB = PROCESS_STATUS.ORDER[b.status] ?? 5;
            if (orderA !== orderB) return orderA - orderB;

            if (a.status === 'queued') {
                if (a.id === nextInQueueId) return -1;
                if (b.id === nextInQueueId) return 1;
                return a.priority - b.priority || new Date(a.created_at) - new Date(b.created_at);
            }

            return new Date(b.created_at) - new Date(a.created_at);
        });
    });

    onMount(() => loadProcesses());
    onDestroy(stopPolling);

    async function loadProcesses() {
        try {
            const data = await apiFetch('/api/processes');
            if (data) processes = data;
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }

        startPollingIfNeeded();
    }

    function startPollingIfNeeded() {
        stopPolling();
        const hasActive = processes.some(p => p.status === 'active' || p.status === 'queued');
        if (hasActive) {
            pollingTimer = setInterval(loadProcesses, 5000);
        }
    }

    function stopPolling() {
        if (pollingTimer) {
            clearInterval(pollingTimer);
            pollingTimer = null;
        }
    }

    async function deleteProcess(processId) {
        deleteProcessId = processId;
        confirmDeleteOpen = true;
    }

    async function confirmDeleteProcess() {
        try {
            await apiFetch(`/api/processes/${deleteProcessId}`, { method: 'DELETE' });
            showToast('Process deleted', 'success');
            await loadProcesses();
        } catch (error) {
            showToast(error.message, 'error');
        }
    }

    function getProgressPercent(process) {
        if (process.status === 'completed') return 100;
        return process.progressPercent || 0;
    }

    function getStatusColor(status) {
        return PROCESS_STATUS.COLORS[status] || 'muted';
    }

    function getStatusLabel(process) {
        const queuedByPriority = processes
            .filter(p => p.status === 'queued')
            .sort((a, b) => a.priority - b.priority || new Date(a.created_at) - new Date(b.created_at));
        const nextInQueueId = queuedByPriority[0]?.id ?? null;

        if (process.status === 'queued' && process.id === nextInQueueId) return 'Next in Queue';
        return PROCESS_STATUS.LABELS[process.status] || process.status;
    }
</script>

<PageHeader label="Processes" />

{#if isLoading}
    <div class="skeleton" style="height: 200px;"></div>
{:else}
    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Progress</th>
                    <th>ID</th>
                    <th>Game</th>
                    <th>Action</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {#each sortedProcesses() as process (process.id)}
                    {@const percent = getProgressPercent(process)}
                    {@const offset = 100 - percent}
                    {@const statusColor = getStatusColor(process.status)}
                    <tr>
                        <td>
                            <div class="progress-ring" class:active={process.status === 'active'}>
                                <svg viewBox="0 0 36 36">
                                    <circle class="ring-bg" cx="18" cy="18" r="15.9" />
                                    <circle
                                        class="ring-fill ring-{statusColor}"
                                        cx="18" cy="18" r="15.9"
                                        stroke-dasharray="100"
                                        stroke-dashoffset={offset}
                                        transform="rotate(-90 18 18)"
                                    />
                                </svg>
                                <span class="ring-text">{percent}%</span>
                            </div>
                        </td>
                        <td>{process.id}</td>
                        <td>
                            <span class="badge badge-muted">{process.game_label || getGameBadgeLabel(process.game_type)}</span>
                        </td>
                        <td>{process.action || ''}</td>
                        <td>
                            <span class="badge badge-{statusColor}">
                                {getStatusLabel(process)}
                            </span>
                        </td>
                        <td>{formatTime(process.created_at)}</td>
                        <td>
                            {#if process.status !== 'active'}
                                <button class="btn btn-sm btn-danger" onclick={() => deleteProcess(process.id)}>
                                    <Icon name="delete" size={14} /> Delete
                                </button>
                            {/if}
                        </td>
                    </tr>
                {:else}
                    <tr>
                        <td colspan="7" class="empty-cell">No processes</td>
                    </tr>
                {/each}
            </tbody>
        </table>
    </div>
{/if}

<ConfirmDialog
    bind:isOpen={confirmDeleteOpen}
    title="Delete Process"
    message={`Delete process #${deleteProcessId}?`}
    confirmLabel="Delete"
    variant="danger"
    onconfirm={confirmDeleteProcess}
/>

<style>
    .progress-ring {
        width: 44px;
        height: 44px;
        position: relative;
    }

    .progress-ring svg {
        width: 100%;
        height: 100%;
    }

    .ring-bg {
        fill: none;
        stroke: var(--color-border);
        stroke-width: 2.5;
    }

    .ring-fill {
        fill: none;
        stroke-width: 2.5;
        stroke-linecap: round;
        transition: stroke-dashoffset 0.5s ease;
    }

    .ring-success { stroke: var(--color-success); }
    .ring-warning { stroke: var(--color-warning); }
    .ring-danger { stroke: var(--color-danger); }
    .ring-muted { stroke: var(--color-text-muted); }
    .ring-purple { stroke: var(--color-purple); }

    .ring-text {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
    }

    .progress-ring.active .ring-fill {
        animation: pulse-ring 2s ease-in-out infinite;
    }

    @keyframes pulse-ring {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }
</style>
