<script>
    import { onMount } from 'svelte';
    import { apiFetch } from '../lib/api.js';
    import { formatTime, showToast, hasPerm } from '../lib/utils.js';
    import { PERMS } from '../lib/constants.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import ConfirmDialog from '../components/ui/ConfirmDialog.svelte';
    import Modal from '../components/ui/Modal.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';

    const STATUS_ORDER = ['active', 'expired', 'invalid'];
    const STATUS_BADGE_CLASS = { active: 'badge-success', expired: 'badge-danger', invalid: 'badge-warning' };

    let codes = $state([]);
    let alliances = $state([]);
    let isLoading = $state(true);
    let newCode = $state('');
    let isAdding = $state(false);
    let showAddCodeModal = $state(false);

    // Redeem modal
    let showRedeemModal = $state(false);
    let redeemCode = $state('');
    let redeemAllianceIds = $state([]);
    let isRedeeming = $state(false);

    // Delete confirm dialog
    let confirmDeleteOpen = $state(false);
    let deleteCodeValue = $state('');

    // Mobile detail modal
    let mobileDetailCode = $state(null);
    let showMobileDetailModal = $state(false);

    const canManageAlliances = hasPerm(PERMS.ALLIANCE_MANAGEMENT, PERMS.FULL_ACCESS);

    onMount(() => loadGiftCodes());

    async function loadGiftCodes() {
        isLoading = true;
        try {
            const [codesData, alliancesData] = await Promise.all([
                apiFetch('/api/giftcodes'),
                canManageAlliances ? apiFetch('/api/alliances') : Promise.resolve([]),
            ]);
            if (codesData) codes = codesData;
            if (alliancesData) alliances = alliancesData;
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    }

    async function addCode(event) {
        event?.preventDefault?.();
        if (!newCode.trim()) return;
        isAdding = true;
        try {
            await apiFetch('/api/giftcodes', { method: 'POST', body: { code: newCode.trim(), isVip: false } });
            newCode = '';
            showAddCodeModal = false;
            await loadGiftCodes();
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isAdding = false;
        }
    }

    async function updateStatus(codeValue, newStatus) {
        try {
            await apiFetch(`/api/giftcodes/${encodeURIComponent(codeValue)}/status`, { method: 'PATCH', body: { status: newStatus } });
        } catch (error) {
            showToast(error.message, 'error');
            await loadGiftCodes();
        }
    }

    function openAddCodeModal() {
        newCode = '';
        showAddCodeModal = true;
    }

    async function cycleStatus(codeObj) {
        const nextStatus = STATUS_ORDER[(STATUS_ORDER.indexOf(codeObj.status) + 1) % STATUS_ORDER.length];
        codes = codes.map(c => c.gift_code === codeObj.gift_code ? { ...c, status: nextStatus } : c);
        if (mobileDetailCode?.gift_code === codeObj.gift_code) {
            mobileDetailCode = { ...mobileDetailCode, status: nextStatus };
        }
        await updateStatus(codeObj.gift_code, nextStatus);
    }

    function openRedeemModal(codeObj) {
        redeemCode = codeObj.gift_code;
        redeemAllianceIds = [];
        showRedeemModal = true;
    }

    function toggleAllianceSelection(allianceId) {
        const id = String(allianceId);
        redeemAllianceIds = redeemAllianceIds.includes(id)
            ? redeemAllianceIds.filter(x => x !== id)
            : [...redeemAllianceIds, id];
    }

    async function submitRedeem() {
        if (redeemAllianceIds.length === 0) return;
        isRedeeming = true;
        let successCount = 0;
        const errors = [];
        for (const allianceId of redeemAllianceIds) {
            try {
                await apiFetch(`/api/giftcodes/${encodeURIComponent(redeemCode)}/redeem`, {
                    method: 'POST',
                    body: { allianceId: parseInt(allianceId, 10) },
                });
                successCount++;
            } catch (error) {
                errors.push(error.message);
            }
        }
        isRedeeming = false;
        showRedeemModal = false;
        showMobileDetailModal = false;
        if (successCount > 0) {
            showToast(`Redeem started for ${successCount} alliance${successCount > 1 ? 's' : ''}`, 'success');
        }
        for (const msg of errors) {
            showToast(msg, 'error');
        }
    }

    function openMobileDetail(codeObj) {
        mobileDetailCode = codeObj;
        redeemAllianceIds = [];
        showMobileDetailModal = true;
    }

    async function deleteCode(codeValue) {
        deleteCodeValue = codeValue;
        confirmDeleteOpen = true;
    }

    async function confirmDelete() {
        try {
            await apiFetch(`/api/giftcodes/${encodeURIComponent(deleteCodeValue)}`, { method: 'DELETE' });
            if (mobileDetailCode?.gift_code === deleteCodeValue) {
                showMobileDetailModal = false;
                mobileDetailCode = null;
            }
            await loadGiftCodes();
        } catch (error) {
            showToast(error.message, 'error');
        }
    }
</script>

<PageHeader label="Gift Codes" />

<div class="action-bar">
    <LoadingButton type="button" class="btn btn-primary" loading={isAdding} onclick={openAddCodeModal}>
        <Icon name="plus" size={14} /> Add Code
    </LoadingButton>
</div>

{#if isLoading}
    <div class="skeleton" style="height: 200px;"></div>
{:else}
    <div class="table-container">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Status</th>
                    <th class="mobile-hide">Source</th>
                    <th class="mobile-hide">Added</th>
                    <th class="actions-cell mobile-hide">Actions</th>
                </tr>
            </thead>
            <tbody>
                {#each codes as code (code.gift_code)}
                    <tr class="code-row" onclick={() => openMobileDetail(code)}>
                        <td class="mono">{code.gift_code || ''}</td>
                        <td>
                            <button
                                class="badge-btn {STATUS_BADGE_CLASS[code.status] ?? 'badge-muted'}"
                                onclick={(e) => { e.stopPropagation(); cycleStatus(code); }}
                            >
                                {code.status ?? 'unknown'}
                            </button>
                        </td>
                        <td class="mobile-hide">{code.source || '-'}</td>
                        <td class="mobile-hide">{formatTime(code.date)}</td>
                        <td class="actions-cell mobile-hide">
                            {#if alliances.length > 0}
                                <button
                                    class="btn btn-sm"
                                    disabled={code.status !== 'active'}
                                    onclick={(e) => { e.stopPropagation(); openRedeemModal(code); }}
                                >
                                    Redeem
                                </button>
                            {/if}
                            <button
                                class="btn btn-sm btn-danger"
                                onclick={(e) => { e.stopPropagation(); deleteCode(code.gift_code); }}
                            >
                                <Icon name="delete" size={14} /> Delete
                            </button>
                        </td>
                    </tr>
                {:else}
                    <tr>
                        <td colspan="5" class="empty-cell">No gift codes</td>
                    </tr>
                {/each}
            </tbody>
        </table>
    </div>
{/if}

<Modal bind:isOpen={showAddCodeModal} title="Add Gift Code">
    <form class="giftcode-add-form" onsubmit={addCode}>
        <label class="field-group">
            <span class="field-label">Gift code</span>
            <input
                type="text"
                bind:value={newCode}
                placeholder="Enter gift code"
                maxlength="50"
                required
            />
        </label>
        <div class="modal-actions">
            <button class="btn btn-sm" type="button" onclick={() => showAddCodeModal = false} disabled={isAdding}>Cancel</button>
            <LoadingButton type="submit" class="btn btn-sm btn-primary" loading={isAdding}>
                <Icon name="plus" size={14} /> Add Code
            </LoadingButton>
        </div>
    </form>
</Modal>

<!-- Redeem alliance selection modal -->
<Modal bind:isOpen={showRedeemModal} title="Redeem Gift Code">
    <p class="redeem-desc">Select alliances to redeem <strong class="mono">{redeemCode}</strong> for:</p>
    <div class="alliance-checklist">
        {#each alliances as alliance (alliance.id)}
            <label class="alliance-check-item">
                <input
                    type="checkbox"
                    checked={redeemAllianceIds.includes(String(alliance.id))}
                    onchange={() => toggleAllianceSelection(alliance.id)}
                />
                <span>{alliance.name || 'Alliance #' + alliance.priority}</span>
            </label>
        {/each}
    </div>
    <div class="modal-actions">
        <button class="btn btn-sm" onclick={() => showRedeemModal = false}>Cancel</button>
        <LoadingButton class="btn btn-sm btn-primary" disabled={redeemAllianceIds.length === 0} loading={isRedeeming} onclick={submitRedeem}>
            Redeem ({redeemAllianceIds.length})
        </LoadingButton>
    </div>
</Modal>

<!-- Mobile detail modal -->
<Modal bind:isOpen={showMobileDetailModal} title={mobileDetailCode?.gift_code ?? 'Gift Code'}>
    {#if mobileDetailCode}
        <div class="mobile-detail-content">
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Status</span>
                <button
                    class="badge-btn {STATUS_BADGE_CLASS[mobileDetailCode.status] ?? 'badge-muted'}"
                    onclick={() => cycleStatus(mobileDetailCode)}
                >
                    {mobileDetailCode.status ?? 'unknown'}
                </button>
            </div>
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Source</span>
                <span>{mobileDetailCode.source || '-'}</span>
            </div>
            <div class="mobile-detail-row">
                <span class="mobile-detail-label">Added</span>
                <span>{formatTime(mobileDetailCode.date)}</span>
            </div>
            {#if alliances.length > 0}
                <div class="mobile-detail-row detail-row-vertical">
                    <span class="mobile-detail-label">Redeem for Alliances</span>
                    <div class="alliance-checklist">
                        {#each alliances as alliance (alliance.id)}
                            <label class="alliance-check-item" class:is-disabled={mobileDetailCode.status !== 'active'}>
                                <input
                                    type="checkbox"
                                    disabled={mobileDetailCode.status !== 'active'}
                                    checked={redeemAllianceIds.includes(String(alliance.id))}
                                    onchange={() => toggleAllianceSelection(alliance.id)}
                                />
                                <span>{alliance.name || 'Alliance #' + alliance.priority}</span>
                            </label>
                        {/each}
                    </div>
                </div>
            {/if}
        </div>
        <div class="mobile-detail-actions">
            {#if alliances.length > 0}
                <LoadingButton
                    class="btn btn-sm btn-primary"
                    disabled={redeemAllianceIds.length === 0 || mobileDetailCode.status !== 'active'}
                    loading={isRedeeming}
                    onclick={() => { redeemCode = mobileDetailCode.gift_code; submitRedeem(); }}
                >
                    Redeem ({redeemAllianceIds.length})
                </LoadingButton>
            {/if}
            <button
                class="btn btn-sm btn-danger"
                onclick={() => { showMobileDetailModal = false; deleteCode(mobileDetailCode.gift_code); }}
            >
                <Icon name="delete" size={14} /> Delete
            </button>
        </div>
    {/if}
</Modal>

<!-- Delete confirmation dialog -->
<ConfirmDialog
    bind:isOpen={confirmDeleteOpen}
    title="Delete Gift Code"
    message={`Delete gift code "${deleteCodeValue}"?`}
    confirmLabel="Delete"
    variant="danger"
    onconfirm={confirmDelete}
/>

<style>
    .badge-btn {
        display: inline-flex;
        align-items: center;
        padding: 3px 12px;
        border-radius: 99px;
        font-size: 11px;
        font-weight: 600;
        border: none;
        cursor: pointer;
        font-family: inherit;
        transition: filter 0.15s ease;
        text-transform: capitalize;
    }
    .badge-btn:hover { filter: brightness(1.2); }
    .badge-success { background: var(--color-success-soft); color: var(--color-success); }
    .badge-danger  { background: var(--color-danger-soft);  color: var(--color-danger); }
    .badge-warning { background: var(--color-warning-soft); color: var(--color-warning); }
    .badge-muted   { background: rgba(255,255,255,0.05);    color: var(--color-text-muted); }

    .mobile-detail-content {
        display: flex;
        flex-direction: column;
        gap: 0;
    }
    .mobile-detail-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 0;
        border-bottom: 1px solid var(--color-border);
        gap: 12px;
    }
    .mobile-detail-row:last-child { border-bottom: none; }
    .detail-row-vertical {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }
    .detail-row-vertical :global(.custom-select) { width: 100%; }
    .mobile-detail-label {
        font-size: 13px;
        color: var(--color-text-muted);
        font-weight: 500;
        flex-shrink: 0;
    }
    .mobile-detail-actions {
        display: flex;
        gap: 8px;
        margin-top: 16px;
        justify-content: flex-end;
    }

    .giftcode-add-form {
        display: grid;
        gap: 16px;
    }

    .field-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .field-label {
        color: var(--color-text-primary);
        font-size: 13px;
        font-weight: 600;
    }

    .redeem-desc {
        font-size: 14px;
        color: var(--color-text-secondary);
        margin-bottom: 12px;
    }
    .alliance-checklist {
        display: flex;
        flex-direction: column;
        gap: 2px;
        max-height: 220px;
        overflow-y: auto;
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        padding: 4px;
    }
    .alliance-check-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 10px;
        border-radius: var(--radius-sm);
        cursor: pointer;
        font-size: 13px;
        color: var(--color-text-secondary);
        transition: background 0.1s ease;
    }
    .alliance-check-item:hover:not(.is-disabled) {
        background: var(--color-accent-soft);
        color: var(--color-text-primary);
    }
    .alliance-check-item.is-disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    .alliance-check-item input[type="checkbox"] {
        flex-shrink: 0;
    }
    .modal-actions {
        display: flex;
        gap: 8px;
        margin-top: 16px;
        justify-content: flex-end;
    }

    @media (max-width: 768px) {
        .mobile-hide { display: none; }
        .code-row { cursor: pointer; }
        .code-row:active { background: var(--color-accent-soft); }
    }
</style>
