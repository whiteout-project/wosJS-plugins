<script>
    import { onMount } from 'svelte';
    import { apiFetch, getBasePath } from '../lib/api.js';
    import { showToast } from '../lib/utils.js';
    import { currentUser, publicConfig } from '../lib/stores.js';
    import { hasPerm } from '../lib/utils.js';
    import { PERMS } from '../lib/constants.js';
    import PageHeader from '../components/ui/PageHeader.svelte';
    import LoadingButton from '../components/ui/LoadingButton.svelte';
    import Icon from '../components/ui/Icon.svelte';
    import Select from '../components/ui/Select.svelte';
    import Checkbox from '../components/ui/Checkbox.svelte';

    let settings = $state(null);
    let featureAccess = $state({});
    let isLoading = $state(true);
    let isSavingGeneral = $state(false);
    let isSavingFeatures = $state(false);

    let panelAccessLevel = $state('everyone');
    let guestPublicToolsEnabled = $state(false);
    let isSavingAccessSettings = $state(false);
    let hasAccessSettingsApi = $state(true);
    let panelTheme = $state('dark-blue-premium');
    let isSavingThemeSettings = $state(false);
    let hasThemeSettingsApi = $state(true);
    let isRestartingBot = $state(false);

    let hasFullAccess = $derived($currentUser?.isOwner || hasPerm(PERMS.FULL_ACCESS));
    let isOwner = $derived(!!$currentUser?.isOwner);

    const FEATURE_KEYS = ['privateNotifications', 'calculators', 'inspect'];

    // Must match FEATURE_ACCESS bit flags in src/functions/utility/checkAccess.js
    const FEATURE_ACCESS_NUM = { EVERYONE: 1, ADMINS_ONLY: 2, BY_CHANNEL: 4, NO_ONE: 8 };

    const ACCESS_NUM_TO_STRING = {
        1: 'everyone',
        2: 'admins_only',
        4: 'whitelist',
        8: 'disabled'
    };

    const ACCESS_STRING_TO_NUM = {
        everyone:    FEATURE_ACCESS_NUM.EVERYONE,
        admins_only: FEATURE_ACCESS_NUM.ADMINS_ONLY,
        whitelist:   FEATURE_ACCESS_NUM.BY_CHANNEL,
        disabled:    FEATURE_ACCESS_NUM.NO_ONE
    };

    const FEATURE_ACCESS_OPTIONS = [
        { value: 'everyone',    label: 'Everyone' },
        { value: 'admins_only', label: 'Admins Only' },
        { value: 'whitelist',   label: 'Whitelist (channels)' },
        { value: 'disabled',    label: 'Disabled' }
    ];

    const PANEL_ACCESS_OPTIONS = [
        { value: 'everyone',    label: 'Everyone' },
        { value: 'bot_users',   label: 'Bot Users Only' },
        { value: 'admins_only', label: 'Admins Only' },
        { value: 'owner_only',  label: 'Owner Only' },
    ];

    const THEME_OPTIONS = [
        { value: 'dark-blue-premium', label: 'Dark Blue' },
        { value: 'black-premium', label: 'Black' },
        { value: 'dark-gold-premium', label: 'Dark Gold' },
    ];

    const SETTING_INFO = {
        auto_delete: { label: 'Auto Delete', desc: 'Automatically delete inactive players during refresh' },
        auto_remove_transferred_players: { label: 'Auto Remove State Transfers', desc: 'Automatically remove players when a refresh detects that they transferred to a different state' },
        auto_update: { label: 'Auto Update', desc: 'Check for and apply bot updates on startup' },
        notif_auto_clean: { label: 'Notification Auto Clean', desc: 'Automatically remove expired notifications' },
    };

    const FEATURE_INFO = {
        privateNotifications: { label: 'Private Notifications', desc: 'Allow users to create personal notifications' },
        calculators: { label: 'Calculators', desc: 'Building upgrade calculator tool access' },
        inspect: { label: 'Inspect', desc: 'Player inspection command access' },
    };

    onMount(async () => {
        try {
            const data = await apiFetch('/api/settings');
            if (!data) return;

            settings = data;

            try {
                featureAccess = typeof data.feature_access === 'string'
                    ? JSON.parse(data.feature_access)
                    : (data.feature_access || {});
            } catch {
                featureAccess = {};
            }

            try {
                const [panelAccess, guestPublicTools] = await Promise.all([
                    apiFetch('/api/settings/panel-access'),
                    apiFetch('/api/settings/guest-public-tools'),
                ]);

                if (panelAccess?.accessLevel) panelAccessLevel = panelAccess.accessLevel;
                if (typeof guestPublicTools?.enabled === 'boolean') guestPublicToolsEnabled = guestPublicTools.enabled;
                hasAccessSettingsApi = true;
            } catch (error) {
                hasAccessSettingsApi = false;
                console.warn('[Web Panel] Access settings API unavailable:', error.message);
            }

            try {
                const themeSettings = await apiFetch('/api/settings/theme');
                if (themeSettings?.theme) panelTheme = themeSettings.theme;
                hasThemeSettingsApi = true;
            } catch (error) {
                hasThemeSettingsApi = false;
                console.warn('[Web Panel] Theme settings API unavailable:', error.message);
            }
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isLoading = false;
        }
    });

    async function saveGeneralSettings({ showSuccessToast = true } = {}) {
        isSavingGeneral = true;
        try {
            await apiFetch('/api/settings', {
                method: 'PATCH',
                body: {
                    autoDelete: settings.auto_delete,
                    autoRemoveTransferredPlayers: settings.auto_remove_transferred_players,
                    autoUpdate: settings.auto_update,
                    notifAutoClean: settings.notif_auto_clean,
                    notifAutoCleanFreq: settings.notif_auto_clean_freq || 3600,
                },
            });
            if (showSuccessToast) {
                showToast('Settings saved', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
            throw error;
        } finally {
            isSavingGeneral = false;
        }
    }

    async function saveFeatureAccess() {
        isSavingFeatures = true;
        try {
            await apiFetch('/api/settings/feature-access', { method: 'PUT', body: { featureAccess } });
            showToast('Feature access saved', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isSavingFeatures = false;
        }
    }

    async function saveAccessSettings() {
        isSavingAccessSettings = true;
        try {
            await Promise.all([
                apiFetch('/api/settings/panel-access', { method: 'POST', body: { accessLevel: panelAccessLevel } }),
                apiFetch('/api/settings/guest-public-tools', { method: 'POST', body: { enabled: guestPublicToolsEnabled } }),
            ]);
            showToast('Access settings saved', 'success');
        } catch (error) {
            showToast(error.message, 'error');
        } finally {
            isSavingAccessSettings = false;
        }
    }

    async function saveThemeSettings({ showSuccessToast = true } = {}) {
        isSavingThemeSettings = true;
        try {
            await apiFetch('/api/settings/theme', {
                method: 'POST',
                body: { theme: panelTheme },
            });
            publicConfig.update((config) => ({ ...config, theme: panelTheme }));
            if (showSuccessToast) {
                showToast('Theme settings saved', 'success');
            }
        } catch (error) {
            showToast(error.message, 'error');
            throw error;
        } finally {
            isSavingThemeSettings = false;
        }
    }

    async function saveGeneralSection() {
        try {
            if (isOwner && hasThemeSettingsApi) {
                await saveThemeSettings({ showSuccessToast: false });
            }
            await saveGeneralSettings({ showSuccessToast: false });
            showToast('Settings saved', 'success');
        } catch {
            // Individual save helpers already surfaced the error toast.
        }
    }

    async function restartBot() {
        isRestartingBot = true;
        try {
            await apiFetch('/api/settings/restart', { method: 'POST' });
            showToast('Restart requested', 'success');
            void waitForBotToReturn();
        } catch (error) {
            showToast(error.message, 'error');
            isRestartingBot = false;
        }
    }

    async function waitForBotToReturn() {
        const basePath = getBasePath();
        const restartGraceMs = 1800;
        const pollIntervalMs = 2000;
        const timeoutMs = 120000;
        const startedAt = Date.now();

        await new Promise((resolve) => setTimeout(resolve, restartGraceMs));

        while (Date.now() - startedAt < timeoutMs) {
            try {
                const response = await fetch(`${basePath}/api/public-config`, {
                    cache: 'no-store',
                    credentials: 'same-origin',
                });

                if (response.ok) {
                    window.location.reload();
                    return;
                }
            } catch {
                // The bot is still restarting; keep polling.
            }

            await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
        }

        isRestartingBot = false;
        showToast('The bot is taking longer than expected to come back. Refresh the page in a moment.', 'error');
    }

    function getFeatureAccessValue(key) {
        const stored = featureAccess[key]?.access;
        if (stored === undefined || stored === null) return 'everyone';
        // Convert numeric flag to string option value
        if (typeof stored === 'number') return ACCESS_NUM_TO_STRING[stored] ?? 'everyone';
        // Legacy string value (fallback)
        return stored;
    }

    function setFeatureAccessValue(key, strValue) {
        if (!featureAccess[key]) featureAccess[key] = {};
        featureAccess[key].access = ACCESS_STRING_TO_NUM[strValue] ?? FEATURE_ACCESS_NUM.EVERYONE;
    }
</script>

<PageHeader label="Settings" />

{#if isLoading}
    <div class="skeleton" style="height: 300px;"></div>
{:else if settings}
    <div class="settings-section">
        <div class="section-header">
            <Icon name="settings" size={18} />
            <h3>General</h3>
        </div>
        <div class="settings-grid">
            {#each Object.entries(SETTING_INFO) as [key, info]}
                <label class="toggle-row">
                    <div class="toggle-info">
                        <span class="toggle-label">{info.label}</span>
                        <span class="toggle-desc">{info.desc}</span>
                    </div>
                    <Checkbox bind:checked={settings[key]} ariaLabel={info.label} />
                </label>
            {/each}
            <label class="toggle-row">
                <div class="toggle-info">
                    <span class="toggle-label">Clean Frequency</span>
                    <span class="toggle-desc">How often to check for expired notifications (in seconds)</span>
                </div>
                <input type="number" bind:value={settings.notif_auto_clean_freq} min="60" />
            </label>
            {#if isOwner && hasThemeSettingsApi}
                <div class="feature-row">
                    <div class="toggle-info">
                        <span class="toggle-label">Theme</span>
                        <span class="toggle-desc">Choose which theme the web panel loads for everyone. This is served by the backend at runtime, so it also works behind the production central proxy.</span>
                    </div>
                    <Select
                        value={panelTheme}
                        onchange={(val) => panelTheme = val}
                        options={THEME_OPTIONS}
                    />
                </div>
            {/if}
            {#if isOwner}
                <div class="feature-row action-row">
                    <div class="toggle-info">
                        <span class="toggle-label">Restart Bot</span>
                        <span class="toggle-desc">Restart the bot using the built-in restart flow. The panel may disconnect for a short moment while the process comes back up.</span>
                    </div>
                    <LoadingButton class="btn btn-danger btn-sm restart-btn" loading={isRestartingBot} onclick={restartBot}>
                        <Icon name="refresh" size={14} /> Restart
                    </LoadingButton>
                </div>
            {/if}
        </div>
        <LoadingButton class="btn btn-primary save-btn" loading={isSavingGeneral || isSavingThemeSettings} onclick={saveGeneralSection}>
            Save General Settings
        </LoadingButton>
    </div>

    <div class="settings-section">
        <div class="section-header">
            <Icon name="shield" size={18} />
            <h3>Feature Access</h3>
        </div>
        <div class="feature-grid">
            {#each FEATURE_KEYS as key}
                <div class="feature-row">
                    <div class="toggle-info">
                        <span class="toggle-label">{FEATURE_INFO[key]?.label || key}</span>
                        <span class="toggle-desc">{FEATURE_INFO[key]?.desc || ''}</span>
                    </div>
                    <Select
                        value={getFeatureAccessValue(key)}
                        onchange={(val) => setFeatureAccessValue(key, val)}
                        options={FEATURE_ACCESS_OPTIONS}
                    />
                </div>
            {/each}
        </div>
        <LoadingButton class="btn btn-primary save-btn" loading={isSavingFeatures} onclick={saveFeatureAccess}>
            Save Feature Access
        </LoadingButton>
    </div>

    {#if hasFullAccess && hasAccessSettingsApi}
    <div class="settings-section">
        <div class="section-header">
            <Icon name="lock" size={18} />
            <h3>Access</h3>
        </div>
        <p class="section-desc">Control who can access the web panel and which public access shortcuts are allowed.</p>
        <div class="feature-grid">
            <div class="feature-row access-panel-row">
                <div class="toggle-info">
                    <span class="toggle-label">Who can access the panel?</span>
                    <span class="toggle-desc">
                        Everyone — any Discord user who logs in via OAuth2 can access the panel.<br>
                        Bot Users — only users who have previously used the bot in Discord.<br>
                        Admins Only — only users added as bot admins.<br>
                        Owner Only — only the bot owner.
                    </span>
                </div>
                <Select
                    value={panelAccessLevel}
                    onchange={(val) => panelAccessLevel = val}
                    options={PANEL_ACCESS_OPTIONS}
                />
            </div>
            <label class="toggle-row">
                <div class="toggle-info">
                    <span class="toggle-label">Allow guest access to public calculators</span>
                    <span class="toggle-desc">Lets users open public calculators without Discord login. Admin and management features still require login.</span>
                </div>
                <Checkbox bind:checked={guestPublicToolsEnabled} ariaLabel="Allow guest access to public calculators" />
            </label>
        </div>
        <LoadingButton class="btn btn-primary save-btn" loading={isSavingAccessSettings} onclick={saveAccessSettings}>
            Save Access Settings
        </LoadingButton>
    </div>
    {/if}
{/if}

<style>
    .settings-section {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 24px;
        margin-bottom: 20px;
    }

    .section-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
        padding-bottom: 12px;
        border-bottom: 1px solid var(--color-border);
        color: var(--color-text-muted);
    }

    .section-header h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: var(--color-text-primary);
    }

    .settings-grid,
    .feature-grid {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .toggle-row,
    .feature-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 16px;
        font-size: 14px;
        color: var(--color-text-secondary);
        cursor: pointer;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--color-secondary);
        transition: background 0.15s ease;
        gap: 16px;
    }

    .toggle-row:hover,
    .feature-row:hover {
        border-color: var(--color-border-accent);
    }

    .toggle-info {
        display: flex;
        flex-direction: column;
        gap: 2px;
        min-width: 0;
    }

    .toggle-label {
        font-size: 14px;
        font-weight: 500;
        color: var(--color-text-primary);
    }

    .toggle-desc {
        font-size: 12px;
        color: var(--color-text-muted);
    }

    .toggle-row input[type="number"] {
        width: 100px;
    }

    .feature-row :global(.custom-select) {
        width: auto;
        min-width: 130px;
    }

    .access-panel-row {
        align-items: flex-start;
        padding: 16px;
    }

    .action-row {
        align-items: center;
    }

    :global(.restart-btn) {
        min-width: 112px;
        justify-content: center;
    }

    .access-panel-row .toggle-info {
        gap: 8px;
    }

    .access-panel-row .toggle-label {
        font-size: 15px;
    }

    .access-panel-row .toggle-desc {
        line-height: 1.6;
    }

    .access-panel-row :global(.custom-select) {
        width: 220px;
        min-width: 220px;
        align-self: center;
    }

    :global(.save-btn) {
        margin-top: 20px;
    }

    .section-desc {
        font-size: 13px;
        color: var(--color-text-muted);
        margin: -10px 0 16px;
    }

    @media (max-width: 768px) {
        .settings-section {
            padding: 18px;
        }

        .toggle-row,
        .feature-row {
            align-items: flex-start;
            flex-direction: column;
            padding: 14px;
            gap: 12px;
        }

        .toggle-row input[type="number"] {
            width: 100%;
        }

        .feature-row :global(.custom-select),
        .access-panel-row :global(.custom-select) {
            width: 100%;
            min-width: 0;
            align-self: stretch;
        }

        .toggle-row :global(.checkbox-root) {
            align-self: flex-end;
        }
    }
</style>
