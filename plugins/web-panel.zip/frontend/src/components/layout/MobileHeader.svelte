<script>
    import { botInfo, mobileMenuOpen } from '../../lib/stores.js';

    function toggleMenu() {
        mobileMenuOpen.update(v => !v);
    }
</script>

<div class="mobile-header">
    <button class="hamburger" onclick={toggleMenu} aria-label="Toggle menu">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
    </button>
    <span class="mobile-title">{$botInfo.name || 'Bot'}</span>
</div>

<style>
    .mobile-header {
        display: none;
        position: fixed;
        top: 10px;
        left: 12px;
        right: 12px;
        height: 58px;
        background: color-mix(in oklab, var(--color-primary) 86%, black);
        border: 1px solid var(--theme-border-medium);
        border-radius: 22px;
        box-shadow: var(--shadow-md), var(--shadow-inset);
        backdrop-filter: blur(16px);
        align-items: center;
        padding: 0 14px;
        gap: 12px;
        z-index: 80;
    }

    .hamburger {
        background: var(--theme-bg-soft);
        border: 1px solid var(--theme-border-soft);
        color: var(--color-text-primary);
        cursor: pointer;
        padding: 6px;
        border-radius: 999px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition:
            transform 150ms var(--ease-out),
            border-color 150ms var(--ease-out),
            background-color 150ms var(--ease-out);
    }

    .hamburger:hover {
        background: var(--theme-bg-bright);
        border-color: var(--theme-border-strong);
        transform: translateY(-1px);
    }

    .mobile-title {
        font-size: 15px;
        font-weight: 700;
        letter-spacing: 0.02em;
        color: var(--color-text-primary);
    }

    @media (max-width: 768px) {
        .mobile-header {
            display: flex;
        }
    }
</style>
