<script>
    import { botInfo, mobileMenuOpen } from '../../lib/stores.js';

    function toggleMenu() {
        mobileMenuOpen.update(v => !v);
    }
</script>

<div class="mobile-header">
    <button class="hamburger" onclick={toggleMenu} aria-label="Toggle menu">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
    </button>
    <span class="mobile-title">{$botInfo.name || 'Bot'}</span>
</div>

<style>
    .mobile-header {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        height: 56px;
        background: var(--color-primary);
        border-bottom: 1px solid var(--color-border);
        align-items: center;
        padding: 0 16px;
        gap: 12px;
        z-index: 80;
    }

    .hamburger {
        background: none;
        border: none;
        color: var(--color-text-primary);
        cursor: pointer;
        padding: 6px;
        border-radius: var(--radius-sm);
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.15s ease;
    }

    .hamburger:hover {
        background: var(--color-secondary);
    }

    .mobile-title {
        font-size: 16px;
        font-weight: 600;
        color: var(--color-text-primary);
    }

    @media (max-width: 768px) {
        .mobile-header {
            display: flex;
        }
    }
</style>
