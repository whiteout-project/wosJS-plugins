<script>
    import { currentUser, botInfo, currentPage, sidebarCollapsed, mobileMenuOpen, navigateTo, publicConfig, selectedGameType } from '../../lib/stores.js';
    import { getBasePath } from '../../lib/api.js';
    import { canAccessPage } from '../../lib/utils.js';
    import { NAV_ITEMS } from '../../lib/constants.js';
    import Icon from '../ui/Icon.svelte';
    import Select from '../ui/Select.svelte';

    const basePath = getBasePath();

    let filteredNavItems = $derived(NAV_ITEMS.filter(item => canAccessPage(item.perms, item.page)));
    let gameOptions = $derived([
        { value: 'wos', label: 'Whiteout Survival' },
        { value: 'ks', label: 'Kingshot' },
    ].filter(option => ($publicConfig?.enabledGames || ['wos']).includes(option.value)));

    function handleNav(page) {
        navigateTo(page);
        mobileMenuOpen.set(false);
    }

    function toggleCollapse() {
        sidebarCollapsed.update(v => !v);
    }

    function expandIfCollapsed() {
        if ($sidebarCollapsed) sidebarCollapsed.set(false);
    }

    async function handleLogout() {
        if ($currentUser?.isGuest) {
            currentUser.set(null);
            navigateTo('dashboard');
            return;
        }

        await fetch(basePath + '/auth/logout', { method: 'POST' });
        currentUser.set(null);
        window.location.href = basePath + '/auth/login';
    }
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div
    class="sidebar-overlay"
    class:visible={$mobileMenuOpen}
    onclick={() => mobileMenuOpen.set(false)}
></div>

<nav
    class="sidebar"
    class:collapsed={$sidebarCollapsed}
    class:open={$mobileMenuOpen}
>
    <div class="sidebar-header">
        <!-- svelte-ignore a11y_click_events_have_key_events -->
        <!-- svelte-ignore a11y_no_static_element_interactions -->
        <div class="sidebar-brand" onclick={expandIfCollapsed}>
            <div class="brand-icon">{$botInfo.name?.charAt(0).toUpperCase() || 'B'}</div>
            <a
                class="brand-text bmac-link"
                href="https://buymeacoffee.com/wosland"
                target="_blank"
                rel="noopener noreferrer"
                title="Support us on Buy Me a Coffee"
                onclick={(e) => e.stopPropagation()}
            >
                <span class="support-badge">
                    <span class="support-badge-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M7 9H16.5V12.5C16.5 15.5376 14.0376 18 11 18C7.96243 18 5.5 15.5376 5.5 12.5V10.5C5.5 9.67157 6.17157 9 7 9Z" />
                            <path d="M16.5 10H18C19.3807 10 20.5 11.1193 20.5 12.5C20.5 13.8807 19.3807 15 18 15H16.5" />
                            <path d="M8.5 5.5V7.5" />
                            <path d="M11.5 4.5V7.5" />
                            <path d="M14.5 5.5V7.5" />
                        </svg>
                    </span>
                    <span class="support-badge-copy">
                        <span class="support-badge-label">Support</span>
                        <span class="support-badge-meta">Buy me a coffee</span>
                    </span>
                </span>
            </a>
        </div>
        <button class="sidebar-collapse-btn" onclick={toggleCollapse} title={$sidebarCollapsed ? 'Expand' : 'Collapse'}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="chevron-icon">
                <path d="M10 12L6 8l4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
    </div>

    <div class="nav-section">
        {#if $publicConfig?.gameMode === 'both'}
            <div class="game-context-panel">
                <span class="game-context-label">Game</span>
                <Select
                    class="game-context-select"
                    value={$selectedGameType}
                    options={gameOptions}
                    onchange={(value) => selectedGameType.set(value)}
                />
            </div>
        {/if}
        {#each filteredNavItems as item}
            <button
                class="nav-item"
                class:active={$currentPage === item.page}
                onclick={() => handleNav(item.page)}
                title={$sidebarCollapsed ? item.label : ''}
            >
                <span class="icon">
                    <Icon name={item.icon} size={20} />
                </span>
                <span class="nav-label">{item.label}</span>
            </button>
        {/each}
    </div>

    <div class="sidebar-footer">
        <div class="user-section">
            {#if $currentUser?.isGuest}
                <div class="user-avatar">G</div>
            {:else if $currentUser?.avatar}
                <img class="user-avatar-img" src={$currentUser.avatar} alt="" />
            {:else}
                <div class="user-avatar">
                    {($currentUser?.username || '?')[0].toUpperCase()}
                </div>
            {/if}
            <div class="user-info">
                <span class="user-name">{$currentUser?.isGuest ? 'Guest' : ($currentUser?.username || 'Admin')}</span>
            </div>
            <button class="logout-btn" onclick={handleLogout} title={$currentUser?.isGuest ? 'Exit guest mode' : 'Logout'}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M6 14H3.33A1.33 1.33 0 012 12.67V3.33A1.33 1.33 0 013.33 2H6M10.67 11.33L14 8l-3.33-3.33M14 8H6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>
    </div>
</nav>

<style>
    .sidebar-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: var(--color-overlay);
        z-index: 90;
        opacity: 0;
        backdrop-filter: blur(10px);
        transition: opacity 0.22s var(--ease-out);
    }

    .sidebar-overlay.visible {
        display: block;
        opacity: 1;
    }

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: var(--spacing-sidebar);
        background:
            linear-gradient(180deg, var(--theme-panel-sheen), transparent 18%),
            color-mix(in oklab, var(--color-primary) 95%, black);
        border-right: 1px solid var(--color-border);
        display: flex;
        flex-direction: column;
        z-index: 100;
        box-shadow: inset -1px 0 0 var(--theme-panel-sheen-soft);
        transition: width 0.3s var(--ease-out), transform 0.3s var(--ease-drawer);
        overflow: hidden;
    }

    .sidebar.collapsed {
        width: var(--spacing-sidebar-collapsed);
    }

    .sidebar.collapsed .brand-text,
    .sidebar.collapsed .nav-label,
    .sidebar.collapsed .sidebar-collapse-btn {
        opacity: 0;
        pointer-events: none;
    }

    .sidebar.collapsed .sidebar-brand {
        cursor: pointer;
    }

    .sidebar-header {
        padding: 20px 18px 18px;
        border-bottom: 1px solid var(--color-border-subtle);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
    }

    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 0;
    }

    .brand-icon {
        width: 42px;
        height: 42px;
        border-radius: 16px;
        background:
            radial-gradient(circle at 28% 28%, var(--theme-panel-topline-bright), transparent 44%),
            linear-gradient(145deg, rgba(229, 233, 242, 0.96), rgba(188, 196, 212, 0.9));
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid var(--theme-border-medium);
        box-shadow: var(--shadow-glow);
        font-weight: 800;
        font-size: 16px;
        flex-shrink: 0;
        color: var(--color-text-inverse);
    }

    .brand-text {
        overflow: hidden;
        transition: opacity 0.2s ease;
        flex-shrink: 1;
        min-width: 0;
    }

    .bmac-link {
        display: flex;
        align-items: center;
        text-decoration: none;
    }

    .support-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        min-height: 34px;
        padding: 6px 12px 6px 8px;
        border-radius: 999px;
        border: 1px solid var(--theme-border-medium);
        background:
            linear-gradient(180deg, var(--theme-panel-sheen-strong), var(--theme-panel-sheen-line)),
            color-mix(in oklab, var(--color-panel-elevated) 92%, black);
        box-shadow:
            inset 0 1px 0 var(--theme-panel-topline),
            0 10px 20px rgba(0, 0, 0, 0.18);
        transition:
            transform 160ms var(--ease-out),
            border-color 160ms var(--ease-out),
            background-color 160ms var(--ease-out),
            box-shadow 160ms var(--ease-out);
    }

    .bmac-link:hover .support-badge {
        border-color: var(--theme-border-stronger);
        background:
            linear-gradient(180deg, var(--theme-panel-sheen-hover), var(--theme-bg-soft-strong)),
            color-mix(in oklab, var(--color-panel-elevated) 96%, black);
        box-shadow:
            inset 0 1px 0 var(--theme-panel-topline-strong),
            0 16px 26px rgba(0, 0, 0, 0.22);
    }

    .support-badge-icon {
        width: 24px;
        height: 24px;
        flex-shrink: 0;
        display: grid;
        place-items: center;
        border-radius: 999px;
        background:
            linear-gradient(180deg, var(--theme-bg-bright), var(--theme-panel-sheen-line)),
            color-mix(in oklab, var(--color-panel) 92%, black);
        box-shadow:
            inset 0 1px 0 var(--theme-panel-topline-bright),
            0 0 0 1px var(--theme-border-medium);
    }

    .support-badge-icon svg {
        width: 14px;
        height: 14px;
        stroke: var(--color-accent-strong);
        stroke-width: 1.8;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    .support-badge-copy {
        display: flex;
        flex-direction: column;
        min-width: 0;
        line-height: 1.05;
    }

    .support-badge-label {
        color: var(--color-text-primary);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }

    .support-badge-meta {
        color: var(--color-text-muted);
        font-size: 10px;
        font-weight: 600;
        white-space: nowrap;
    }

    .sidebar-collapse-btn {
        background: var(--theme-bg-subtle);
        border: 1px solid var(--color-border-subtle);
        color: var(--color-text-muted);
        cursor: pointer;
        padding: 6px;
        border-radius: 999px;
        font-size: 12px;
        transition:
            transform 160ms var(--ease-out),
            border-color 160ms var(--ease-out),
            background-color 160ms var(--ease-out),
            color 160ms var(--ease-out);
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .sidebar-collapse-btn:hover {
        color: var(--color-text-primary);
        background: var(--theme-bg-medium-strong);
        border-color: var(--theme-border-medium);
        transform: translateY(-1px);
    }

    .chevron-icon {
        transition: transform 0.3s var(--ease-out);
    }

    .sidebar.collapsed .chevron-icon {
        transform: rotate(180deg);
    }

    .nav-section {
        flex: 1;
        padding: 16px 10px;
        overflow-y: auto;
        overflow-x: hidden;
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .game-context-panel {
        display: flex;
        flex-direction: column;
        gap: 6px;
        padding: 0 4px 8px;
    }

    .game-context-label {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--color-text-muted);
        padding-left: 2px;
    }

    .nav-section :global(.game-context-select) {
        width: 100%;
        min-width: 0;
    }

    .nav-section :global(.custom-select) {
        width: 100%;
    }

    .nav-section :global(.select-trigger) {
        width: 100%;
    }

    .nav-section :global(.select-dropdown) {
        z-index: 140;
    }

    .sidebar.collapsed .game-context-panel {
        display: none;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 12px;
        min-height: 46px;
        padding: 0 14px;
        border: 1px solid transparent;
        background: transparent;
        color: var(--color-text-secondary);
        border-radius: 16px;
        cursor: pointer;
        font-size: 14px;
        font-family: inherit;
        white-space: nowrap;
        transition:
            transform 150ms var(--ease-out),
            border-color 150ms var(--ease-out),
            background-color 150ms var(--ease-out),
            color 150ms var(--ease-out),
            box-shadow 150ms var(--ease-out);
        width: 100%;
        text-align: left;
    }

    .nav-item:hover {
        color: var(--color-text-primary);
        background: var(--theme-bg-soft-strong);
        border-color: var(--theme-panel-topline);
        transform: translateX(2px);
    }

    .nav-item.active {
        color: var(--color-accent-strong);
        background:
            linear-gradient(90deg, var(--color-accent-soft), var(--theme-bg-subtle));
        border-color: var(--theme-accent-border);
        box-shadow: inset 0 1px 0 var(--theme-panel-topline);
    }

    .nav-item .icon {
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        color: var(--color-text-muted);
        transition: color 150ms var(--ease-out);
    }

    .nav-item:hover .icon,
    .nav-item.active .icon {
        color: currentColor;
    }

    .nav-label {
        transition: opacity 0.2s ease;
    }

    .sidebar-footer {
        padding: 14px 12px 16px;
        border-top: 1px solid var(--color-border-subtle);
    }

    .user-section {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px;
        border-radius: 18px;
        background: var(--theme-bg-subtle);
        border: 1px solid var(--color-border-subtle);
        transition:
            background-color 160ms var(--ease-out),
            border-color 160ms var(--ease-out);
    }

    .user-section:hover {
        background: var(--theme-bg-soft-strong);
        border-color: var(--theme-border-soft);
    }

    .user-avatar {
        width: 34px;
        height: 34px;
        border-radius: 12px;
        background: color-mix(in oklab, var(--color-surface) 90%, black);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 13px;
        color: var(--color-accent-strong);
        flex-shrink: 0;
        border: 1px solid var(--theme-border-soft);
    }

    .user-avatar-img {
        width: 32px;
        height: 32px;
        min-width: 32px;
        min-height: 32px;
        max-width: 32px;
        max-height: 32px;
        border-radius: 12px;
        display: block;
        flex: 0 0 32px;
        aspect-ratio: 1;
        object-fit: cover;
    }

    .user-info {
        display: flex;
        flex-direction: column;
        min-width: 0;
        flex: 1;
        transition: opacity 0.2s ease;
    }

    .user-name {
        font-size: 13px;
        font-weight: 600;
        color: var(--color-text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .logout-btn {
        background: transparent;
        border: 1px solid transparent;
        color: var(--color-text-muted);
        padding: 6px;
        border-radius: 999px;
        cursor: pointer;
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        transition:
            transform 150ms var(--ease-out),
            border-color 150ms var(--ease-out),
            background-color 150ms var(--ease-out),
            color 150ms var(--ease-out);
    }

    .logout-btn:hover {
        color: var(--color-danger);
        background: var(--color-danger-soft);
        border-color: var(--theme-danger-border);
        transform: translateY(-1px);
    }

    .sidebar.collapsed .user-info {
        opacity: 0;
        pointer-events: none;
    }

    @media (max-width: 768px) {
        .sidebar {
            transform: translateX(-100%);
            width: var(--spacing-sidebar);
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar.collapsed {
            width: var(--spacing-sidebar);
        }

        .sidebar-collapse-btn {
            display: none;
        }
    }
</style>
