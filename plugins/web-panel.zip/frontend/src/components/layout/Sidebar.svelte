<script>
    import { currentUser, botInfo, currentPage, sidebarCollapsed, mobileMenuOpen, navigateTo } from '../../lib/stores.js';
    import { getBasePath } from '../../lib/api.js';
    import { canAccessPage } from '../../lib/utils.js';
    import { NAV_ITEMS } from '../../lib/constants.js';
    import Icon from '../ui/Icon.svelte';

    const basePath = getBasePath();

    let filteredNavItems = $derived(NAV_ITEMS.filter(item => canAccessPage(item.perms, item.page)));

    function handleNav(page) {
        navigateTo(page);
        mobileMenuOpen.set(false);
    }

    function toggleCollapse() {
        sidebarCollapsed.update(v => !v);
    }

    function expandIfCollapsed() {
        if ($sidebarCollapsed) sidebarCollapsed.set(false);
    }

    async function handleLogout() {
        if ($currentUser?.isGuest) {
            currentUser.set(null);
            navigateTo('dashboard');
            return;
        }

        await fetch(basePath + '/auth/logout', { method: 'POST' });
        currentUser.set(null);
        window.location.href = basePath + '/auth/login';
    }
</script>

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div
    class="sidebar-overlay"
    class:visible={$mobileMenuOpen}
    onclick={() => mobileMenuOpen.set(false)}
></div>

<nav
    class="sidebar"
    class:collapsed={$sidebarCollapsed}
    class:open={$mobileMenuOpen}
>
    <div class="sidebar-header">
        <!-- svelte-ignore a11y_click_events_have_key_events -->
        <!-- svelte-ignore a11y_no_static_element_interactions -->
        <div class="sidebar-brand" onclick={expandIfCollapsed}>
            <div class="brand-icon">{$botInfo.name?.charAt(0).toUpperCase() || 'B'}</div>
            <a
                class="brand-text bmac-link"
                href="https://buymeacoffee.com/wosland"
                target="_blank"
                rel="noopener noreferrer"
                title="Support us on Buy Me a Coffee"
                onclick={(e) => e.stopPropagation()}
            >
                <img
                    src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png"
                    alt="Buy Me A Coffee"
                    class="bmac-img"
                />
            </a>
        </div>
        <button class="sidebar-collapse-btn" onclick={toggleCollapse} title={$sidebarCollapsed ? 'Expand' : 'Collapse'}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" class="chevron-icon">
                <path d="M10 12L6 8l4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
    </div>

    <div class="nav-section">
        {#each filteredNavItems as item}
            <button
                class="nav-item"
                class:active={$currentPage === item.page}
                onclick={() => handleNav(item.page)}
                title={$sidebarCollapsed ? item.label : ''}
            >
                <span class="icon">
                    <Icon name={item.icon} size={20} />
                </span>
                <span class="nav-label">{item.label}</span>
            </button>
        {/each}
    </div>

    <div class="sidebar-footer">
        <div class="user-section">
            {#if $currentUser?.isGuest}
                <div class="user-avatar">G</div>
            {:else if $currentUser?.avatar}
                <img class="user-avatar-img" src={$currentUser.avatar} alt="" />
            {:else}
                <div class="user-avatar">
                    {($currentUser?.username || '?')[0].toUpperCase()}
                </div>
            {/if}
            <div class="user-info">
                <span class="user-name">{$currentUser?.isGuest ? 'Guest' : ($currentUser?.username || 'Admin')}</span>
            </div>
            <button class="logout-btn" onclick={handleLogout} title={$currentUser?.isGuest ? 'Exit guest mode' : 'Logout'}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M6 14H3.33A1.33 1.33 0 012 12.67V3.33A1.33 1.33 0 013.33 2H6M10.67 11.33L14 8l-3.33-3.33M14 8H6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>
    </div>
</nav>

<style>
    .sidebar-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.6);
        z-index: 90;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .sidebar-overlay.visible {
        display: block;
        opacity: 1;
    }

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: var(--spacing-sidebar);
        background: var(--color-primary);
        border-right: 1px solid var(--color-border);
        display: flex;
        flex-direction: column;
        z-index: 100;
        transition: width 0.3s var(--ease-out), transform 0.3s var(--ease-out);
        overflow: hidden;
    }

    .sidebar.collapsed {
        width: var(--spacing-sidebar-collapsed);
    }

    .sidebar.collapsed .brand-text,
    .sidebar.collapsed .nav-label,
    .sidebar.collapsed .sidebar-collapse-btn {
        opacity: 0;
        pointer-events: none;
    }

    .sidebar.collapsed .sidebar-brand {
        cursor: pointer;
    }

    .sidebar-header {
        padding: 20px 16px;
        border-bottom: 1px solid var(--color-border);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
    }

    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 0;
    }

    .brand-icon {
        width: 36px;
        height: 36px;
        border-radius: var(--radius-md);
        background: linear-gradient(135deg, var(--color-accent), var(--color-purple));
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 16px;
        flex-shrink: 0;
        color: white;
    }

    .brand-text {
        overflow: hidden;
        transition: opacity 0.2s ease;
        flex-shrink: 1;
        min-width: 0;
    }

    .bmac-link {
        display: flex;
        align-items: center;
        text-decoration: none;
    }

    .bmac-img {
        height: 30px;
        width: auto;
        display: block;
        border-radius: 6px;
    }

    .sidebar-collapse-btn {
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        padding: 6px;
        border-radius: var(--radius-sm);
        font-size: 12px;
        transition: all 0.2s ease;
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .sidebar-collapse-btn:hover {
        color: var(--color-text-primary);
        background: var(--color-secondary);
    }

    .chevron-icon {
        transition: transform 0.3s var(--ease-out);
    }

    .sidebar.collapsed .chevron-icon {
        transform: rotate(180deg);
    }

    .nav-section {
        flex: 1;
        padding: 12px 8px;
        overflow-y: auto;
        overflow-x: hidden;
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 12px;
        border: none;
        background: none;
        color: var(--color-text-secondary);
        border-radius: var(--radius-md);
        cursor: pointer;
        font-size: 14px;
        font-family: inherit;
        white-space: nowrap;
        transition: all 0.15s ease;
        width: 100%;
        text-align: left;
    }

    .nav-item:hover {
        color: var(--color-text-primary);
        background: var(--color-secondary);
    }

    .nav-item.active {
        color: var(--color-accent);
        background: var(--color-accent-soft);
    }

    .nav-item .icon {
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        color: var(--color-text-muted);
        transition: color 0.15s ease;
    }

    .nav-item:hover .icon,
    .nav-item.active .icon {
        color: currentColor;
    }

    .nav-label {
        transition: opacity 0.2s ease;
    }

    .sidebar-footer {
        padding: 12px;
        border-top: 1px solid var(--color-border);
    }

    .user-section {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px;
        border-radius: var(--radius-md);
        transition: background 0.15s ease;
    }

    .user-section:hover {
        background: var(--color-secondary);
    }

    .user-avatar {
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        background: var(--color-surface);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 13px;
        color: var(--color-accent);
        flex-shrink: 0;
    }

    .user-avatar-img {
        width: 32px;
        height: 32px;
        border-radius: var(--radius-sm);
        flex-shrink: 0;
        object-fit: cover;
    }

    .user-info {
        display: flex;
        flex-direction: column;
        min-width: 0;
        flex: 1;
        transition: opacity 0.2s ease;
    }

    .user-name {
        font-size: 13px;
        font-weight: 500;
        color: var(--color-text-primary);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .logout-btn {
        background: none;
        border: none;
        color: var(--color-text-muted);
        padding: 6px;
        border-radius: var(--radius-sm);
        cursor: pointer;
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s ease;
    }

    .logout-btn:hover {
        color: var(--color-danger);
        background: var(--color-danger-soft);
    }

    .sidebar.collapsed .user-info {
        opacity: 0;
        pointer-events: none;
    }

    @media (max-width: 768px) {
        .sidebar {
            transform: translateX(-100%);
            width: var(--spacing-sidebar);
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar.collapsed {
            width: var(--spacing-sidebar);
        }

        .sidebar-collapse-btn {
            display: none;
        }
    }
</style>
