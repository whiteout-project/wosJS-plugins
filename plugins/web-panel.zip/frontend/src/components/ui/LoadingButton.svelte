<script>
    import Icon from './Icon.svelte';

    /**
     * Button with loading state — disables and shows spinner during async ops.
     * @type {{ loading?: boolean, disabled?: boolean, class?: string, type?: string, onclick?: (e: Event) => void, children: any }}
     */
    let {
        loading = false,
        disabled = false,
        class: className = 'btn',
        type = 'button',
        onclick,
        children,
    } = $props();
</script>

<button
    {type}
    class={className}
    disabled={loading || disabled}
    onclick={onclick}
>
    {#if loading}
        <span class="loading-spinner" aria-hidden="true">
            <Icon name="loader" size={14} />
        </span>
    {/if}
    {@render children()}
</button>

<style>
    button {
        position: relative;
    }

    .loading-spinner {
        display: inline-flex;
        animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>
