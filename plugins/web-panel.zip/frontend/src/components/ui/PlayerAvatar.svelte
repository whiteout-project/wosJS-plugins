<script>
    import { safePlayerImage } from '../../lib/playerProfile.js';
    let { src = null, alt = '', fallback = '#', fallbackLabel = 'No player picture' } = $props();
    let failedUrl = $state(null);
    let safeSrc = $derived(safePlayerImage(src));
</script>

{#if safeSrc && safeSrc !== failedUrl}
    <img src={safeSrc} {alt} loading="lazy" referrerpolicy="no-referrer" onerror={() => { failedUrl = safeSrc; }} />
{:else}
    <span aria-label={fallbackLabel}>{fallback}</span>
{/if}

<style>
    img { display: block; width: 100%; height: 100%; object-fit: cover; }
</style>
