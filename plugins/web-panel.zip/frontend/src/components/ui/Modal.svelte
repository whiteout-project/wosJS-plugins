<script>
    /**
     * @type {{ isOpen: boolean, title: string, wide?: boolean, onclose?: () => void }}
     */
    let { isOpen = $bindable(false), title = '', wide = false, children, onclose } = $props();

    /** Portal action: moves the element to document.body so it escapes scrolling containers */
    function portal(node) {
        document.body.appendChild(node);
        return {
            destroy() {
                node.remove();
            }
        };
    }

    function handleClose() {
        isOpen = false;
        onclose?.();
    }

    function handleOverlayClick(event) {
        if (event.target === event.currentTarget) {
            handleClose();
        }
    }

    function handleKeydown(event) {
        if (event.key === 'Escape') {
            handleClose();
        }
    }
</script>

<svelte:window onkeydown={handleKeydown} />

{#if isOpen}
    <!-- svelte-ignore a11y_click_events_have_key_events -->
    <!-- svelte-ignore a11y_no_static_element_interactions -->
    <div class="modal-overlay" use:portal onclick={handleOverlayClick}>
        <div class="modal" class:modal-wide={wide} role="dialog" aria-modal="true" aria-label={title}>
            <div class="modal-header">
                <h3>{title}</h3>
                <button class="modal-close" onclick={handleClose} aria-label="Close">&times;</button>
            </div>
            <div class="modal-body">
                {@render children()}
            </div>
        </div>
    </div>
{/if}

<style>
    :global(.modal-overlay) {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.85);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        padding: 24px;
        animation: fadeOverlay 0.2s ease both;
    }

    :global(.modal-overlay .modal) {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        width: 100%;
        max-width: 480px;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: var(--shadow-lg);
        animation: scaleIn 0.25s var(--ease-spring) both;
    }

    :global(.modal-overlay .modal-header) {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 24px 16px;
        border-bottom: 1px solid var(--color-border);
    }

    :global(.modal-overlay .modal-header h3) {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: var(--color-text-primary);
    }

    :global(.modal-overlay .modal-close) {
        background: none;
        border: none;
        color: var(--color-text-muted);
        font-size: 22px;
        cursor: pointer;
        padding: 0 4px;
        line-height: 1;
        border-radius: var(--radius-sm);
        transition: color 0.15s ease;
    }

    :global(.modal-overlay .modal-close:hover) {
        color: var(--color-text-primary);
    }

    :global(.modal-overlay .modal-wide) {
        max-width: 600px;
    }

    :global(.modal-overlay .modal-body) {
        padding: 20px 24px 24px;
    }

    @keyframes -global-fadeOverlay {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes -global-scaleIn {
        from {
            opacity: 0;
            transform: scale(0.95) translateY(8px);
        }
        to {
            opacity: 1;
            transform: none;
        }
    }

    @media (max-width: 768px) {
        :global(.modal-overlay) {
            padding: 12px;
        }

        :global(.modal-overlay .modal) {
            max-height: calc(100vh - 80px);
        }

        :global(.modal-overlay .modal-header) {
            padding: 16px 16px 12px;
        }

        :global(.modal-overlay .modal-body) {
            padding: 12px 16px 16px;
        }
    }
</style>
