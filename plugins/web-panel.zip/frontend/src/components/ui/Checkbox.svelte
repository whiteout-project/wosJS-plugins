<script>
    let {
        checked = $bindable(false),
        label = '',
        id = '',
        name = '',
        value = '',
        disabled = false,
        ariaLabel = '',
        onchange = null,
        class: className = ''
    } = $props();

    const fallbackId = `checkbox-${Math.random().toString(36).slice(2, 10)}`;
    const inputId = $derived(id || fallbackId);
    const accessibleLabel = $derived(label || ariaLabel || 'Checkbox');
</script>

<label class={`checkboxRoot ${className}`.trim()} for={inputId} aria-disabled={disabled}>
    <input
        class="checkboxInput"
        type="checkbox"
        id={inputId}
        bind:checked
        {name}
        {value}
        {disabled}
        aria-label={accessibleLabel}
        onchange={onchange}
    />

    <span class="checkboxBox" aria-hidden="true">
        <svg class="checkboxIcon" viewBox="0 0 16 16" fill="none">
            <path d="M3.5 8.2L6.6 11.3L12.8 4.8" />
        </svg>
    </span>

    {#if label}
        <span class="checkboxLabel">{label}</span>
    {/if}
</label>

<style>
    .checkboxRoot {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        width: fit-content;
        color: var(--color-text-secondary, #aeb6c8);
        font-size: 13px;
        font-weight: 600;
        line-height: 1.25;
        cursor: pointer;
        user-select: none;
    }

    .checkboxInput {
        position: absolute;
        opacity: 0;
        width: 1px;
        height: 1px;
        pointer-events: none;
    }

    .checkboxBox {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 21px;
        height: 21px;
        flex: 0 0 21px;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 6px;
        background:
            linear-gradient(180deg, rgba(255, 255, 255, 0.06), rgba(255, 255, 255, 0.025)),
            color-mix(in oklab, var(--color-panel-muted, #1e2230) 88%, black);
        color: var(--color-text-inverse, #0f1218);
        box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.06),
            0 1px 0 rgba(0, 0, 0, 0.16);
        transition:
            background-color 140ms ease,
            border-color 140ms ease,
            box-shadow 140ms ease,
            transform 140ms ease;
    }

    .checkboxIcon {
        width: 14px;
        height: 14px;
        opacity: 0;
        transform: scale(0.8);
        transition:
            opacity 120ms ease,
            transform 120ms ease;
    }

    .checkboxIcon path {
        stroke: currentColor;
        stroke-width: 2.5;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    .checkboxLabel {
        color: inherit;
        transition: color 140ms ease;
    }

    .checkboxRoot:hover .checkboxBox {
        border-color: rgba(255, 255, 255, 0.26);
        background:
            linear-gradient(180deg, rgba(255, 255, 255, 0.08), rgba(255, 255, 255, 0.03)),
            color-mix(in oklab, var(--color-panel-elevated, #2a3142) 88%, black);
    }

    .checkboxInput:checked + .checkboxBox {
        border-color: rgba(255, 255, 255, 0.2);
        background:
            linear-gradient(180deg, color-mix(in oklab, var(--color-accent, #cfd7e6) 96%, white 4%), color-mix(in oklab, var(--color-accent-strong, #f4f7ff) 86%, var(--color-accent, #cfd7e6) 14%));
        box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.28),
            0 0 0 1px rgba(207, 215, 230, 0.14),
            0 8px 18px rgba(0, 0, 0, 0.16);
        transform: scale(1.02);
    }

    .checkboxInput:checked + .checkboxBox .checkboxIcon {
        opacity: 1;
        transform: scale(1);
    }

    .checkboxInput:checked ~ .checkboxLabel {
        color: var(--color-text-primary, #f4f7ff);
    }

    .checkboxInput:focus-visible + .checkboxBox {
        outline: 2px solid color-mix(in srgb, var(--color-accent, #7c9cff) 70%, white 10%);
        outline-offset: 3px;
    }

    .checkboxRoot[aria-disabled="true"] {
        cursor: not-allowed;
        opacity: 0.55;
    }

    .checkboxRoot[aria-disabled="true"]:hover .checkboxBox {
        border-color: rgba(255, 255, 255, 0.18);
        background: rgba(255, 255, 255, 0.05);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08);
        transform: none;
    }
</style>
