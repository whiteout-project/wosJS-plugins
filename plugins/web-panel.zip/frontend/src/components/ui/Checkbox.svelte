<script>
    let {
        checked = $bindable(false),
        label = '',
        id = '',
        name = '',
        value = '',
        disabled = false,
        ariaLabel = '',
        onchange = null,
        class: className = ''
    } = $props();

    const fallbackId = `checkbox-${Math.random().toString(36).slice(2, 10)}`;
    const inputId = $derived(id || fallbackId);
    const accessibleLabel = $derived(label || ariaLabel || 'Checkbox');
</script>

<label class={`checkboxRoot ${className}`.trim()} for={inputId} aria-disabled={disabled}>
    <input
        class="checkboxInput"
        type="checkbox"
        id={inputId}
        bind:checked
        {name}
        {value}
        {disabled}
        aria-label={accessibleLabel}
        onchange={onchange}
    />

    <span class="checkboxBox" aria-hidden="true">
        <svg class="checkboxIcon" viewBox="0 0 16 16" fill="none">
            <path d="M3.5 8.2L6.6 11.3L12.8 4.8" />
        </svg>
    </span>

    {#if label}
        <span class="checkboxLabel">{label}</span>
    {/if}
</label>

<style>
    .checkboxRoot {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        width: fit-content;
        color: var(--color-text-secondary, #aeb6c8);
        font-size: 13px;
        font-weight: 600;
        line-height: 1.25;
        cursor: pointer;
        user-select: none;
    }

    .checkboxInput {
        position: absolute;
        opacity: 0;
        width: 1px;
        height: 1px;
        pointer-events: none;
    }

    .checkboxBox {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 22px;
        height: 22px;
        flex: 0 0 22px;
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 6px;
        background: rgba(255, 255, 255, 0.05);
        color: #fff;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08);
        transition:
            background-color 140ms ease,
            border-color 140ms ease,
            box-shadow 140ms ease,
            transform 140ms ease;
    }

    .checkboxIcon {
        width: 15px;
        height: 15px;
        opacity: 0;
        transform: scale(0.82);
        transition:
            opacity 120ms ease,
            transform 120ms ease;
    }

    .checkboxIcon path {
        stroke: currentColor;
        stroke-width: 2.2;
        stroke-linecap: round;
        stroke-linejoin: round;
    }

    .checkboxLabel {
        color: inherit;
        transition: color 140ms ease;
    }

    .checkboxRoot:hover .checkboxBox {
        border-color: var(--color-accent, #7c9cff);
        background: rgba(255, 255, 255, 0.08);
    }

    .checkboxInput:checked + .checkboxBox {
        border-color: var(--color-accent, #7c9cff);
        background: var(--color-accent, #7c9cff);
        box-shadow:
            0 0 0 1px color-mix(in srgb, var(--color-accent, #7c9cff) 40%, transparent),
            0 0 18px color-mix(in srgb, var(--color-accent, #7c9cff) 35%, transparent);
        transform: scale(1.03);
    }

    .checkboxInput:checked + .checkboxBox .checkboxIcon {
        opacity: 1;
        transform: scale(1);
    }

    .checkboxInput:checked ~ .checkboxLabel {
        color: var(--color-text-primary, #f4f7ff);
    }

    .checkboxInput:focus-visible + .checkboxBox {
        outline: 2px solid color-mix(in srgb, var(--color-accent, #7c9cff) 70%, white 10%);
        outline-offset: 3px;
    }

    .checkboxRoot[aria-disabled="true"] {
        cursor: not-allowed;
        opacity: 0.55;
    }

    .checkboxRoot[aria-disabled="true"]:hover .checkboxBox {
        border-color: rgba(255, 255, 255, 0.18);
        background: rgba(255, 255, 255, 0.05);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08);
        transform: none;
    }
</style>
