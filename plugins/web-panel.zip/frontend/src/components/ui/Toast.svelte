<script>
    import { toasts } from '../../lib/stores.js';
    import { dismissToast } from '../../lib/utils.js';
    import Icon from './Icon.svelte';

    const ICONS = { success: 'check', error: 'x', info: 'info' };
</script>

{#if $toasts.length > 0}
    <div class="toast-container">
        {#each $toasts as toast (toast.id)}
            <button class="toast toast-{toast.type}" onclick={() => dismissToast(toast.id)}>
                <span class="toast-icon">
                    <Icon name={ICONS[toast.type] || ICONS.info} size={14} />
                </span>
                <span class="toast-message">{toast.message}</span>
            </button>
        {/each}
    </div>
{/if}

<style>
    .toast-container {
        position: fixed;
        top: 22px;
        right: 22px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 10px;
        max-width: 420px;
        pointer-events: none;
    }

    .toast {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 16px;
        border-radius: 18px;
        border: 1px solid var(--color-border);
        background: var(--theme-glass-fill);
        color: var(--color-text-primary);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        animation: slideUp 0.3s var(--ease-out) both;
        backdrop-filter: blur(18px);
        box-shadow: var(--shadow-md), var(--shadow-inset);
        width: 100%;
        text-align: left;
        pointer-events: auto;
        transition:
            transform 160ms var(--ease-out),
            border-color 160ms var(--ease-out),
            background-color 160ms var(--ease-out);
    }

    .toast:hover {
        transform: translateY(-1px);
    }

    .toast-success { border-color: var(--theme-success-border-strong); }
    .toast-error { border-color: var(--theme-danger-border-strong); }
    .toast-info { border-color: var(--theme-accent-border); }

    .toast-icon {
        width: 28px;
        height: 28px;
        flex-shrink: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 999px;
        background: var(--theme-bg-medium-strong);
    }

    .toast-success .toast-icon { color: var(--color-success); }
    .toast-error .toast-icon { color: var(--color-danger); }
    .toast-info .toast-icon { color: var(--color-accent-strong); }

    .toast-message {
        flex: 1;
        line-height: 1.55;
        color: var(--color-text-secondary);
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(12px);
        }
        to {
            opacity: 1;
            transform: none;
        }
    }

    @media (max-width: 768px) {
        .toast-container {
            left: 16px;
            right: 16px;
            top: auto;
            bottom: 16px;
            max-width: none;
        }
    }
</style>
