<script>
    import { toasts } from '../../lib/stores.js';
    import { dismissToast } from '../../lib/utils.js';

    const ICONS = { success: '✓', error: '✗', info: 'ℹ' };
</script>

{#if $toasts.length > 0}
    <div class="toast-container">
        {#each $toasts as toast (toast.id)}
            <button class="toast toast-{toast.type}" onclick={() => dismissToast(toast.id)}>
                <span class="toast-icon">{ICONS[toast.type] || ICONS.info}</span>
                <span class="toast-message">{toast.message}</span>
            </button>
        {/each}
    </div>
{/if}

<style>
    .toast-container {
        position: fixed;
        top: 24px;
        right: 24px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 8px;
        max-width: 400px;
        pointer-events: none;
    }

    .toast {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 16px;
        border-radius: var(--radius-md);
        border: 1px solid var(--color-border);
        background: var(--color-card);
        color: var(--color-text-primary);
        font-size: 14px;
        font-family: inherit;
        cursor: pointer;
        animation: slideUp 0.3s var(--ease-out) both;
        backdrop-filter: blur(12px);
        box-shadow: var(--shadow-md);
        width: 100%;
        text-align: left;
        pointer-events: auto;
    }

    .toast-success { border-color: var(--color-success); }
    .toast-error { border-color: var(--color-danger); }
    .toast-info { border-color: var(--color-accent); }

    .toast-icon {
        font-size: 16px;
        flex-shrink: 0;
    }

    .toast-success .toast-icon { color: var(--color-success); }
    .toast-error .toast-icon { color: var(--color-danger); }
    .toast-info .toast-icon { color: var(--color-accent); }

    .toast-message {
        flex: 1;
        line-height: 1.4;
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(12px);
        }
        to {
            opacity: 1;
            transform: none;
        }
    }

    @media (max-width: 768px) {
        .toast-container {
            left: 16px;
            right: 16px;
            bottom: 16px;
            max-width: none;
        }
    }
</style>
