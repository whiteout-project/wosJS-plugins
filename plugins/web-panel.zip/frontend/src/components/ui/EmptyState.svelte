<script>
    import Icon from './Icon.svelte';

    let { icon = 'info', title = 'Nothing here', message = '', children } = $props();
</script>

<div class="empty-state">
    <div class="empty-icon-wrap">
        <Icon name={icon} size={32} />
    </div>
    <h3 class="empty-title">{title}</h3>
    {#if message}
        <p class="empty-message">{message}</p>
    {/if}
    {#if children}
        <div class="empty-actions">
            {@render children()}
        </div>
    {/if}
</div>

<style>
    .empty-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 48px 24px;
        text-align: center;
    }

    .empty-icon-wrap {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: var(--color-secondary);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--color-text-muted);
        margin-bottom: 16px;
    }

    .empty-title {
        margin: 0 0 6px;
        font-size: 16px;
        font-weight: 600;
        color: var(--color-text-primary);
    }

    .empty-message {
        margin: 0;
        font-size: 13px;
        color: var(--color-text-muted);
        max-width: 300px;
    }

    .empty-actions {
        margin-top: 16px;
    }
</style>
