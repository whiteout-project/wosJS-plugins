<script>
    /**
     * Confirmation dialog — replaces native confirm().
     * @type {{ isOpen: boolean, title?: string, message?: string, confirmLabel?: string, cancelLabel?: string, variant?: 'danger'|'primary', onconfirm?: () => void, oncancel?: () => void }}
     */
    let {
        isOpen = $bindable(false),
        title = 'Confirm',
        message = 'Are you sure?',
        confirmLabel = 'Confirm',
        cancelLabel = 'Cancel',
        variant = 'danger',
        onconfirm,
        oncancel,
    } = $props();

    /** Portal action: moves the element to document.body */
    function portal(node) {
        document.body.appendChild(node);
        return {
            destroy() {
                node.remove();
            }
        };
    }

    function handleConfirm() {
        isOpen = false;
        onconfirm?.();
    }

    function handleCancel() {
        isOpen = false;
        oncancel?.();
    }

    function handleOverlayClick(event) {
        if (event.target === event.currentTarget) handleCancel();
    }

    function handleKeydown(event) {
        if (event.key === 'Escape') handleCancel();
    }
</script>

<svelte:window onkeydown={isOpen ? handleKeydown : undefined} />

{#if isOpen}
    <!-- svelte-ignore a11y_click_events_have_key_events -->
    <!-- svelte-ignore a11y_no_static_element_interactions -->
    <div class="confirm-overlay" use:portal onclick={handleOverlayClick}>
        <div class="confirm-dialog" role="alertdialog" aria-modal="true" aria-label={title}>
            <div class="confirm-header">
                <h3>{title}</h3>
            </div>
            <div class="confirm-body">
                <p>{message}</p>
            </div>
            <div class="confirm-actions">
                <button class="btn" onclick={handleCancel}>{cancelLabel}</button>
                <button class="btn btn-{variant}" onclick={handleConfirm}>{confirmLabel}</button>
            </div>
        </div>
    </div>
{/if}

<style>
    :global(.confirm-overlay) {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.85);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1100;
        padding: 24px;
        animation: fadeOverlay 0.15s ease both;
    }

    :global(.confirm-overlay .confirm-dialog) {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        width: 100%;
        max-width: 400px;
        box-shadow: var(--shadow-lg);
        animation: scaleIn 0.2s var(--ease-spring) both;
    }

    :global(.confirm-overlay .confirm-header) {
        padding: 20px 24px 0;
    }

    :global(.confirm-overlay .confirm-header h3) {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: var(--color-text-primary);
    }

    :global(.confirm-overlay .confirm-body) {
        padding: 12px 24px 0;
    }

    :global(.confirm-overlay .confirm-body p) {
        margin: 0;
        font-size: 14px;
        color: var(--color-text-secondary);
        line-height: 1.5;
    }

    :global(.confirm-overlay .confirm-actions) {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
        padding: 20px 24px;
    }

    @keyframes -global-fadeOverlay {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes -global-scaleIn {
        from { opacity: 0; transform: scale(0.95) translateY(8px); }
        to { opacity: 1; transform: none; }
    }
</style>
