<script>
    import Icon from './Icon.svelte';

    let {
        value = $bindable(''),
        options = [],
        disabled = false,
        onchange,
        placeholder = '',
        class: className = ''
    } = $props();

    let isOpen = $state(false);
    let triggerEl = $state(null);
    let dropdownEl = $state(null);
    let focusedIndex = $state(-1);
    let listboxId = $state(`select-listbox-${Math.random().toString(36).slice(2, 8)}`);
    let dropdownStyle = $state('');

    let selectedLabel = $derived(() => {
        const found = options.find(o => String(o.value) === String(value));
        return found ? found.label : placeholder || '';
    });

    function portal(node) {
        document.body.appendChild(node);
        return { destroy() { node.remove(); } };
    }

    function computeDropdownPosition() {
        if (!triggerEl) return;
        const rect = triggerEl.getBoundingClientRect();
        const VIEWPORT_MARGIN = 8;
        const DROPDOWN_GAP = 4;
        const MIN_DROPDOWN_HEIGHT = 96;

        const spaceBelow = window.innerHeight - rect.bottom - VIEWPORT_MARGIN - DROPDOWN_GAP;
        const spaceAbove = rect.top - VIEWPORT_MARGIN - DROPDOWN_GAP;
        const shouldOpenDownward = spaceBelow >= MIN_DROPDOWN_HEIGHT || spaceBelow >= spaceAbove;

        if (shouldOpenDownward) {
            const maxHeight = Math.max(MIN_DROPDOWN_HEIGHT, Math.floor(spaceBelow));
            dropdownStyle = [
                `top: ${rect.bottom + DROPDOWN_GAP}px`,
                `left: ${rect.left}px`,
                `width: ${rect.width}px`,
                `max-height: ${maxHeight}px`
            ].join('; ');
            return;
        }

        const maxHeight = Math.max(MIN_DROPDOWN_HEIGHT, Math.floor(spaceAbove));
        dropdownStyle = [
            `bottom: ${window.innerHeight - rect.top + DROPDOWN_GAP}px`,
            `left: ${rect.left}px`,
            `width: ${rect.width}px`,
            `max-height: ${maxHeight}px`
        ].join('; ');
    }

    function toggle() {
        if (disabled) return;
        if (isOpen) {
            close();
        } else {
            open();
        }
    }

    function open() {
        isOpen = true;
        focusedIndex = options.findIndex(o => String(o.value) === String(value));
        if (focusedIndex < 0) focusedIndex = 0;
        requestAnimationFrame(computeDropdownPosition);
    }

    function close() {
        isOpen = false;
        focusedIndex = -1;
    }

    function select(opt) {
        value = opt.value;
        if (onchange) onchange(opt.value);
        close();
        triggerEl?.focus();
    }

    function handleKeydown(e) {
        if (disabled) return;

        if (!isOpen) {
            if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
                e.preventDefault();
                open();
            }
            return;
        }

        switch (e.key) {
            case 'ArrowDown':
                e.preventDefault();
                focusedIndex = Math.min(focusedIndex + 1, options.length - 1);
                scrollToFocused();
                break;
            case 'ArrowUp':
                e.preventDefault();
                focusedIndex = Math.max(focusedIndex - 1, 0);
                scrollToFocused();
                break;
            case 'Enter':
            case ' ':
                e.preventDefault();
                if (focusedIndex >= 0 && focusedIndex < options.length) {
                    select(options[focusedIndex]);
                }
                break;
            case 'Escape':
            case 'Tab':
                e.preventDefault();
                close();
                triggerEl?.focus();
                break;
            case 'Home':
                e.preventDefault();
                focusedIndex = 0;
                scrollToFocused();
                break;
            case 'End':
                e.preventDefault();
                focusedIndex = options.length - 1;
                scrollToFocused();
                break;
        }
    }

    function scrollToFocused() {
        requestAnimationFrame(() => {
            const item = dropdownEl?.querySelector(`[data-index="${focusedIndex}"]`);
            item?.scrollIntoView({ block: 'nearest' });
        });
    }

    function handleClickOutside(e) {
        if (isOpen && triggerEl && !triggerEl.contains(e.target) && dropdownEl && !dropdownEl.contains(e.target)) {
            close();
        }
    }

    $effect(() => {
        if (isOpen) {
            document.addEventListener('click', handleClickOutside, true);
            window.addEventListener('resize', computeDropdownPosition);
            window.addEventListener('scroll', computeDropdownPosition, true);
            return () => {
                document.removeEventListener('click', handleClickOutside, true);
                window.removeEventListener('resize', computeDropdownPosition);
                window.removeEventListener('scroll', computeDropdownPosition, true);
            };
        }
    });
</script>

<div class="custom-select {className}" class:is-open={isOpen} class:is-disabled={disabled}>
    <button
        bind:this={triggerEl}
        type="button"
        class="select-trigger"
        onclick={toggle}
        onkeydown={handleKeydown}
        {disabled}
        role="combobox"
        aria-expanded={isOpen}
        aria-haspopup="listbox"
        aria-controls={listboxId}
    >
        <span class="select-value" class:is-placeholder={!value && placeholder}>
            {selectedLabel()}
        </span>
        <span class="select-chevron">
            <Icon name="chevronDown" size={14} />
        </span>
    </button>

    {#if isOpen}
        <div
            use:portal
            bind:this={dropdownEl}
            class="select-dropdown"
            style={dropdownStyle}
            role="listbox"
            id={listboxId}
        >
            {#each options as opt, i (opt.value)}
                <button
                    type="button"
                    class="select-option"
                    class:is-selected={String(opt.value) === String(value)}
                    class:is-focused={i === focusedIndex}
                    data-index={i}
                    role="option"
                    aria-selected={String(opt.value) === String(value)}
                    onclick={() => select(opt)}
                    onmouseenter={() => focusedIndex = i}
                >
                    {opt.label}
                    {#if String(opt.value) === String(value)}
                        <Icon name="check" size={14} />
                    {/if}
                </button>
            {/each}
        </div>
    {/if}
</div>

<style>
    .custom-select {
        position: relative;
        display: inline-flex;
        min-width: 130px;
    }

    .select-trigger {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        width: 100%;
        padding: 8px 12px;
        font-size: 14px;
        font-family: inherit;
        line-height: 1.5;
        color: var(--color-text-primary);
        background: var(--color-secondary);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-sm);
        cursor: pointer;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
        text-align: left;
        outline: none;
    }

    .select-trigger:hover:not(:disabled) {
        border-color: var(--color-border-accent);
    }

    .select-trigger:focus-visible {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    .is-open .select-trigger {
        border-color: var(--color-accent);
        box-shadow: 0 0 0 3px var(--color-accent-soft);
    }

    .is-disabled .select-trigger {
        opacity: 0.5;
        cursor: not-allowed;
    }

    .select-value {
        flex: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .select-value.is-placeholder {
        color: var(--color-text-muted);
    }

    .select-chevron {
        display: flex;
        align-items: center;
        color: var(--color-text-secondary);
        transition: transform 0.2s ease;
        flex-shrink: 0;
    }

    .is-open .select-chevron {
        transform: rotate(180deg);
    }

    .select-dropdown {
        position: fixed;
        z-index: 9999;
        max-height: 220px;
        overflow-y: auto;
        background: var(--color-card);
        border: 1px solid var(--color-border-accent);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg), 0 0 0 1px rgba(0, 0, 0, 0.1);
        padding: 4px;
        animation: selectSlideIn 0.15s ease;
    }

    @keyframes selectSlideIn {
        from {
            opacity: 0;
            transform: translateY(-4px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .select-option {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        width: 100%;
        padding: 7px 10px;
        font-size: 13px;
        font-family: inherit;
        line-height: 1.4;
        color: var(--color-text-secondary);
        background: transparent;
        border: none;
        border-radius: var(--radius-sm);
        cursor: pointer;
        text-align: left;
        transition: background 0.1s ease, color 0.1s ease;
        outline: none;
    }

    .select-option:hover,
    .select-option.is-focused {
        background: var(--color-accent-soft);
        color: var(--color-text-primary);
    }

    .select-option.is-selected {
        color: var(--color-accent);
        font-weight: 500;
    }

    .select-option.is-selected:hover,
    .select-option.is-selected.is-focused {
        background: var(--color-accent-soft);
    }

    /* Scrollbar styling */
    .select-dropdown::-webkit-scrollbar {
        width: 6px;
    }
    .select-dropdown::-webkit-scrollbar-track {
        background: transparent;
    }
    .select-dropdown::-webkit-scrollbar-thumb {
        background: var(--color-border);
        border-radius: 3px;
    }
    .select-dropdown::-webkit-scrollbar-thumb:hover {
        background: var(--color-text-muted);
    }
</style>
