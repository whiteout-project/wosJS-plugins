<script>
    import Icon from './Icon.svelte';

    let { label = '', value = '', colorClass = '', icon = '' } = $props();
</script>

<div class="stat-card">
    <div class="stat-header">
        {#if icon}
            <Icon name={icon} size={16} />
        {/if}
        <span class="label">{label}</span>
    </div>
    <div class="value {colorClass}">{value}</div>
</div>

<style>
    .stat-card {
        background: var(--color-card);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 20px 24px;
        transition: all 0.2s ease;
        display: flex;
        flex-direction: column;
    }

    .stat-card:hover {
        border-color: var(--color-border-accent);
        box-shadow: var(--shadow-glow);
        transform: translateY(-2px);
    }

    .stat-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 10px;
        min-height: 20px;
        color: var(--color-text-muted);
    }

    .label {
        font-size: 12px;
        font-weight: 500;
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        white-space: nowrap;
    }

    .value {
        font-size: 28px;
        font-weight: 700;
        color: var(--color-text-primary);
        line-height: 1.2;
    }

    .value.accent { color: var(--color-accent); }
    .value.success { color: var(--color-success); }
    .value.warning { color: var(--color-warning); }
    .value.danger { color: var(--color-danger); }
    .value.purple { color: var(--color-purple); }
</style>
