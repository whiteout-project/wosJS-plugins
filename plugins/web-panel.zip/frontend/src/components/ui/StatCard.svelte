<script>
    import Icon from './Icon.svelte';

    let { label = '', value = '', colorClass = '', icon = '' } = $props();
</script>

<div class="stat-card">
    <div class="stat-header">
        {#if icon}
            <Icon name={icon} size={16} />
        {/if}
        <span class="label">{label}</span>
    </div>
    <div class="value {colorClass}">{value}</div>
</div>

<style>
    .stat-card {
        background:
            linear-gradient(180deg, var(--theme-panel-sheen-soft), transparent 36%),
            var(--theme-panel-fill);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-lg);
        padding: 20px 22px 22px;
        transition:
            transform 180ms var(--ease-out),
            border-color 180ms var(--ease-out),
            box-shadow 180ms var(--ease-out),
            background-color 180ms var(--ease-out);
        display: flex;
        flex-direction: column;
        min-width: 0;
        box-shadow: var(--shadow-panel), var(--shadow-inset);
    }

    .stat-card:hover {
        border-color: var(--theme-accent-border);
        box-shadow: var(--shadow-glow);
        transform: translateY(-2px);
    }

    .stat-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 14px;
        min-height: 20px;
        min-width: 0;
        color: var(--color-text-muted);
    }

    .label {
        display: block;
        min-width: 0;
        font-size: 12px;
        font-weight: 700;
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.08em;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .value {
        font-size: clamp(28px, 3vw, 38px);
        font-weight: 800;
        color: var(--color-text-primary);
        line-height: 1;
        letter-spacing: -0.04em;
    }

    .value.accent { color: var(--color-accent-strong); }
    .value.success { color: var(--color-success); }
    .value.warning { color: var(--color-warning); }
    .value.danger { color: var(--color-danger); }
    .value.purple { color: var(--color-purple); }
</style>
