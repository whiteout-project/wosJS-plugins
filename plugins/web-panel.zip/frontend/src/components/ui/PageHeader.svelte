<script>
    let { label = '', children } = $props();
</script>

<div class="page-header">
    <h2>{label}</h2>
    {#if children}
        <div class="desc">
            {@render children()}
        </div>
    {/if}
</div>

<style>
    .page-header {
        margin-bottom: 28px;
        padding: 4px 0 18px;
        border-bottom: 1px solid var(--color-border-subtle);
        display: grid;
        gap: 8px;
    }

    .page-header h2 {
        font-size: clamp(28px, 3vw, 40px);
        font-weight: 700;
        color: var(--color-text-primary);
        margin: 0;
        letter-spacing: -0.04em;
        line-height: 1;
    }

    .desc {
        font-size: 14px;
        color: var(--color-text-secondary);
        max-width: 64ch;
        line-height: 1.65;
    }
</style>
