<script>
    let { label = '', children } = $props();
</script>

<div class="page-header">
    <h2>{label}</h2>
    {#if children}
        <div class="desc">
            {@render children()}
        </div>
    {/if}
</div>

<style>
    .page-header {
        margin-bottom: 28px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--color-border);
    }

    .page-header h2 {
        font-size: 24px;
        font-weight: 700;
        color: var(--color-text-primary);
        margin: 0 0 4px;
        letter-spacing: -0.3px;
    }

    .desc {
        font-size: 14px;
        color: var(--color-text-muted);
    }
</style>
