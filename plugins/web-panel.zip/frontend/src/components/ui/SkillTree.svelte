<script>
    import { onMount, tick } from 'svelte';

    let {
        tiers = [],
        selectedNodeId = '',
        selectedTierId = '',
        dimmedNodeIds = new Set(),
        hideNodeLabels = true,
        onselect = () => {},
    } = $props();

    let treeWrapper = $state(null);
    let treeCanvas = $state(null);
    let svgSize = $state({ width: 0, height: 0 });
    let connectorPaths = $state([]);
    let measureFrame = 0;
    let failedNodeImages = $state({});

    const nodeElements = new Map();

    let measureKey = $derived(
        tiers
            .map((tier) => `${tier.id}:${tier.nodes.map((node) => `${node.id}:${node.level}/${node.maxLevel}`).join(',')}`)
            .join('|')
    );

    function registerNode(node, nodeId) {
        nodeElements.set(nodeId, node);
        scheduleMeasure();

        return {
            destroy() {
                nodeElements.delete(nodeId);
                scheduleMeasure();
            },
        };
    }

    function getNodePoint(nodeId, canvasRect, edge) {
        const element = nodeElements.get(nodeId);
        if (!element) return null;

        const rect = element.getBoundingClientRect();
        return {
            x: Math.round(rect.left - canvasRect.left + rect.width / 2),
            y: Math.round(edge === 'top' ? rect.top - canvasRect.top : rect.bottom - canvasRect.top),
        };
    }

    function buildConnectionPath(parentTier, childTier, canvasRect) {
        const parentPoints = parentTier.nodes
            .map((node) => getNodePoint(node.id, canvasRect, 'bottom'))
            .filter(Boolean);
        const childPoints = childTier.nodes
            .map((node) => getNodePoint(node.id, canvasRect, 'top'))
            .filter(Boolean);

        if (!parentPoints.length || !childPoints.length) return '';

        const parentY = Math.max(...parentPoints.map((point) => point.y));
        const childY = Math.min(...childPoints.map((point) => point.y));
        const parentDropY = parentY + 28;
        const childRiseY = childY - 28;
        const busY = Math.round((parentDropY + childRiseY) / 2);
        const allX = [...parentPoints, ...childPoints].map((point) => point.x);
        const minX = Math.min(...allX);
        const maxX = Math.max(...allX);
        const segments = [];

        if (parentPoints.length === 1 && childPoints.length === 1 && Math.abs(parentPoints[0].x - childPoints[0].x) <= 2) {
            return `M ${parentPoints[0].x} ${parentPoints[0].y} L ${childPoints[0].x} ${childPoints[0].y}`;
        }

        for (const point of parentPoints) {
            segments.push(`M ${point.x} ${point.y} L ${point.x} ${busY}`);
        }

        segments.push(`M ${minX} ${busY} L ${maxX} ${busY}`);

        for (const point of childPoints) {
            segments.push(`M ${point.x} ${busY} L ${point.x} ${point.y}`);
        }

        return segments.join(' ');
    }

    async function measureConnectors() {
        if (!treeCanvas) return;

        await tick();
        if (!treeCanvas?.isConnected) return;

        const canvasRect = treeCanvas.getBoundingClientRect();
        svgSize = {
            width: Math.ceil(canvasRect.width),
            height: Math.ceil(canvasRect.height),
        };

        const paths = [];
        for (let index = 0; index < tiers.length - 1; index += 1) {
            const d = buildConnectionPath(tiers[index], tiers[index + 1], canvasRect);
            if (d) paths.push({ id: `${tiers[index].id}-${tiers[index + 1].id}`, d });
        }

        connectorPaths = paths;
    }

    function scheduleMeasure() {
        if (typeof requestAnimationFrame !== 'function') return;
        cancelAnimationFrame(measureFrame);
        measureFrame = requestAnimationFrame(() => {
            measureConnectors();
        });
    }

    function handleSelect(tier, node, event) {
        event?.currentTarget?.blur?.();
        onselect({ tier, node });
    }

    function hasUsableNodeImage(node) {
        return Boolean(node?.imageSrc) && !failedNodeImages[node.id];
    }

    function handleNodeImageError(nodeId) {
        failedNodeImages = {
            ...failedNodeImages,
            [nodeId]: true,
        };
    }

    $effect(() => {
        measureKey;
        selectedNodeId;
        selectedTierId;
        scheduleMeasure();
    });

    onMount(() => {
        scheduleMeasure();

        const resizeObserver = new ResizeObserver(scheduleMeasure);
        if (treeWrapper) resizeObserver.observe(treeWrapper);
        if (treeCanvas) resizeObserver.observe(treeCanvas);

        window.addEventListener('resize', scheduleMeasure);

        return () => {
            resizeObserver.disconnect();
            window.removeEventListener('resize', scheduleMeasure);
            cancelAnimationFrame(measureFrame);
        };
    });
</script>

<div class="skill-tree" bind:this={treeWrapper}>
    <div class="skill-tree-canvas" bind:this={treeCanvas}>
        <svg
            class="connector-svg"
            width={svgSize.width}
            height={svgSize.height}
            viewBox={`0 0 ${svgSize.width} ${svgSize.height}`}
            aria-hidden="true"
        >
            {#each connectorPaths as path (path.id)}
                <path class="connector-path connector-path-shadow" d={path.d} />
                <path class="connector-path" d={path.d} />
            {/each}
        </svg>

        <div class="skill-tree-content">
            {#each tiers as tier (tier.id)}
                <section class="skill-tier" class:selected-tier={selectedTierId === tier.id}>
                    <div
                        class="node-row"
                        class:node-row-5={tier.nodes.length === 5}
                        class:node-row-4={tier.nodes.length === 4}
                        class:node-row-1={tier.nodes.length === 1}
                    >
                        {#each tier.nodes as node (node.id)}
                            <div class="skill-node-wrap" class:labels-hidden={hideNodeLabels}>
                                <button
                                    type="button"
                                    class="skill-node"
                                    class:selected={selectedNodeId === node.id}
                                    class:locked={node.locked}
                                    class:dimmed={dimmedNodeIds?.has?.(node.id)}
                                    class:skill-image-mode={node.imageMode === 'full' && hasUsableNodeImage(node)}
                                    onclick={(event) => handleSelect(tier, node, event)}
                                    aria-label={`${node.name}, level ${node.level} of ${node.maxLevel}`}
                                >
                                    <span
                                        class="node-circle"
                                        class:has-full-image={node.imageMode === 'full' && hasUsableNodeImage(node)}
                                        use:registerNode={node.id}
                                    >
                                        {#if node.imageMode === 'full' && hasUsableNodeImage(node)}
                                            <img
                                                class="node-full-image"
                                                src={node.imageSrc}
                                                alt={node.name}
                                                draggable="false"
                                                onerror={() => handleNodeImageError(node.id)}
                                            />
                                        {:else}
                                            <span
                                                class="node-short"
                                                class:has-gear-image={node.imageMode === 'gear' && hasUsableNodeImage(node)}
                                            >
                                                {#if node.imageMode === 'gear' && hasUsableNodeImage(node)}
                                                    <img
                                                        class="node-gear-image"
                                                        src={node.imageSrc}
                                                        alt={node.name}
                                                        draggable="false"
                                                        onerror={() => handleNodeImageError(node.id)}
                                                    />
                                                {:else}
                                                    {node.short}
                                                {/if}
                                            </span>
                                        {/if}
                                    </span>
                                </button>
                                <span class="node-progress">{node.level}/{node.maxLevel}</span>

                                {#if !hideNodeLabels}
                                    <div class="node-label">
                                        <span class="node-name">{node.name}</span>
                                        {#if node.stat}
                                            <span class="node-stat">{node.stat}</span>
                                        {:else}
                                            <span class="node-stat">Core</span>
                                        {/if}
                                    </div>
                                {/if}
                            </div>
                        {/each}
                    </div>
                </section>
            {/each}
        </div>
    </div>
</div>

<style>
    .skill-tree {
        --tree-node-size: 72px;
        --tree-node-inner-size: 52px;
        --tree-bg: var(--color-secondary);
        position: relative;
        overflow: hidden;
        border: 1px solid var(--color-border);
        border-radius: 8px;
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.025), rgba(255, 255, 255, 0.01));
    }

    .skill-tree-canvas {
        position: relative;
        width: 100%;
        min-width: 0;
        padding: 18px 18px 28px;
    }

    .connector-svg {
        position: absolute;
        inset: 0;
        z-index: 1;
        pointer-events: none;
        overflow: visible;
    }

    .connector-path {
        fill: none;
        stroke: var(--color-accent);
        stroke-width: 3;
        stroke-linecap: round;
        stroke-linejoin: round;
        opacity: 0.68;
    }

    .connector-path-shadow {
        stroke: rgba(0, 0, 0, 0.45);
        stroke-width: 7;
        opacity: 0.75;
    }

    .skill-tree-content {
        position: relative;
        z-index: 2;
        display: flex;
        flex-direction: column;
        gap: 72px;
    }

    .skill-tier {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0;
    }

    .node-row {
        width: 100%;
        display: grid;
        align-items: start;
        justify-items: center;
        column-gap: 18px;
        row-gap: 18px;
    }

    .node-row-5 {
        grid-template-columns: repeat(5, minmax(0, 1fr));
    }

    .node-row-4 {
        grid-template-columns: repeat(4, minmax(0, 1fr));
        max-width: 620px;
    }

    .node-row-1 {
        grid-template-columns: minmax(112px, 150px);
        justify-content: center;
        max-width: 220px;
    }

    .skill-node-wrap {
        width: 100%;
        max-width: 124px;
        min-height: calc(var(--tree-node-size) + 52px);
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        isolation: isolate;
    }

    .skill-node-wrap.labels-hidden {
        min-height: calc(var(--tree-node-size) + 16px);
    }

    .skill-node {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        border: 0;
        background: transparent;
        color: inherit;
        padding: 0;
        cursor: pointer;
        z-index: 2;
    }

    .node-circle {
        width: var(--tree-node-size);
        height: var(--tree-node-size);
        border-radius: 999px;
        border: 3px solid rgba(255, 255, 255, 0.18);
        background:
            radial-gradient(circle at 32% 24%, rgba(255, 255, 255, 0.22), transparent 34%),
            linear-gradient(180deg, rgba(29, 36, 68, 0.98), rgba(14, 18, 36, 0.98));
        display: grid;
        place-items: center;
        box-shadow: inset 0 0 0 4px rgba(255, 255, 255, 0.04), 0 12px 22px rgba(0, 0, 0, 0.22);
        transition: transform 0.16s ease, border-color 0.16s ease, box-shadow 0.16s ease;
    }

    .node-circle.has-full-image {
        border: none;
        background: transparent;
        box-shadow: none;
    }

    .node-short {
        width: var(--tree-node-inner-size);
        height: var(--tree-node-inner-size);
        border-radius: 999px;
        display: grid;
        place-items: center;
        background: radial-gradient(circle at 35% 30%, #ffffff, #d5f2ff 30%, #79e0d1 65%, #2f6fb0 100%);
        color: #0f1d35;
        font-size: 12px;
        font-weight: 800;
        letter-spacing: 0;
        box-shadow: inset 0 -8px 16px rgba(0, 0, 0, 0.2);
    }

    .node-short.has-gear-image {
        position: relative;
        width: 100%;
        height: 100%;
        overflow: visible;
        background: transparent;
        box-shadow: none;
    }

    .node-full-image,
    .node-gear-image {
        display: block;
        user-select: none;
        pointer-events: none;
    }

    .node-full-image {
        width: 100%;
        height: 100%;
        object-fit: contain;
        filter: drop-shadow(0 8px 16px rgba(0, 0, 0, 0.28));
    }

    .node-gear-image {
        position: absolute;
        top: 50%;
        left: 50%;
        width: calc(var(--tree-node-inner-size) * 2);
        height: calc(var(--tree-node-inner-size) * 2);
        transform: translate(-50%, -50%);
        object-fit: contain;
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.22));
    }

    .skill-node:hover .node-circle,
    .skill-node.selected .node-circle {
        transform: translateY(-2px) scale(1.03);
        border-color: rgba(255, 255, 255, 0.56);
        box-shadow: 0 0 0 3px rgba(99, 139, 255, 0.14), 0 14px 26px rgba(0, 0, 0, 0.28);
    }

    .skill-node:hover .node-circle.has-full-image,
    .skill-node.selected .node-circle.has-full-image {
        border-color: transparent;
        box-shadow: none;
        filter: drop-shadow(0 0 0 rgba(0, 0, 0, 0)) drop-shadow(0 14px 24px rgba(24, 71, 171, 0.18));
    }

    .skill-node.selected .node-short {
        background: radial-gradient(circle at 30% 30%, #ffffff, #d7e5ff 35%, #8bb2ff 72%, #456dca 100%);
        color: #12203f;
    }

    .skill-node.selected .node-short.has-gear-image {
        background: transparent;
        color: inherit;
    }

    .skill-node.locked {
        opacity: 0.58;
    }

    .skill-node.dimmed,
    .skill-node-wrap:has(.skill-node.dimmed) .node-label {
        opacity: 0.36;
    }

    .node-progress {
        position: relative;
        z-index: 3;
        margin-top: -8px;
        min-width: 44px;
        padding: 2px 8px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 999px;
        background: rgba(8, 10, 18, 0.86);
        color: var(--color-text-primary);
        font-size: 11px;
        font-weight: 700;
        font-variant-numeric: tabular-nums;
    }

    .node-label {
        min-height: 52px;
        margin-top: 6px;
        padding: 4px 6px;
        border-radius: 6px;
        background: color-mix(in srgb, var(--tree-bg) 88%, transparent);
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: center;
        gap: 3px;
    }

    .node-name {
        color: var(--color-text-primary);
        font-size: 12px;
        font-weight: 700;
        line-height: 1.2;
        text-wrap: balance;
    }

    .node-stat {
        color: var(--color-text-secondary);
        font-size: 10px;
        line-height: 1.2;
        text-transform: uppercase;
    }

    @media (max-width: 640px) {
        .skill-tree {
            --tree-node-size: 50px;
            --tree-node-inner-size: 36px;
        }

        .skill-tree-canvas {
            min-width: 0;
            padding: 14px 8px 22px;
        }

        .skill-tree-content {
            gap: 68px;
        }

        .node-row {
            column-gap: 4px;
        }

        .node-row-5 {
            grid-template-columns: repeat(5, minmax(0, 1fr));
        }

        .node-row-4 {
            grid-template-columns: repeat(4, minmax(0, 1fr));
        }

        .skill-node-wrap {
            max-width: 72px;
        }

        .skill-node.skill-image-mode {
            min-width: 58px;
        }

        .skill-node.skill-image-mode .node-circle.has-full-image {
            width: 58px;
            height: 58px;
        }

        .node-short {
            font-size: 9px;
        }

        .node-gear-image {
            width: 42px;
            height: 42px;
        }

        .node-name {
            font-size: 10px;
            line-height: 1.15;
        }

        .node-stat {
            font-size: 8px;
        }

        .node-progress {
            min-width: 38px;
            padding: 1px 6px;
            font-size: 10px;
        }

    }
</style>
