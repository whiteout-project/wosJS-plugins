<script>
    import { onMount } from 'svelte';
    import { currentUser, botInfo, currentPage } from './lib/stores.js';
    import { getBasePath } from './lib/api.js';

    import Sidebar from './components/layout/Sidebar.svelte';
    import MobileHeader from './components/layout/MobileHeader.svelte';
    import Toast from './components/ui/Toast.svelte';
    import Login from './pages/Login.svelte';
    import Dashboard from './pages/Dashboard.svelte';
    import Alliances from './pages/Alliances.svelte';
    import Notifications from './pages/Notifications.svelte';
    import Processes from './pages/Processes.svelte';
    import GiftCodes from './pages/GiftCodes.svelte';
    import Settings from './pages/Settings.svelte';
    import Logs from './pages/Logs.svelte';
    import Calculators from './pages/Calculators.svelte';

    let isLoading = $state(true);
    let authCheckInFlight = false;
    const STARTUP_FETCH_TIMEOUT_MS = 8000;

    const pageComponents = {
        dashboard: Dashboard,
        alliances: Alliances,
        notifications: Notifications,
        processes: Processes,
        giftcodes: GiftCodes,
        calculators: Calculators,
        settings: Settings,
        logs: Logs,
    };

    async function fetchWithTimeout(url, options = {}, timeoutMs = STARTUP_FETCH_TIMEOUT_MS) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
        try {
            return await fetch(url, {
                ...options,
                signal: controller.signal,
            });
        } finally {
            clearTimeout(timeoutId);
        }
    }

    async function loadSession({ includeBotInfo = false } = {}) {
        if (authCheckInFlight) return;
        authCheckInFlight = true;
        try {
            const basePath = getBasePath();
            const userPromise = fetchWithTimeout(basePath + '/auth/me', {
                cache: 'no-store',
                credentials: 'same-origin',
            });
            const botPromise = includeBotInfo
                ? fetchWithTimeout(basePath + '/api/botinfo', {
                    cache: 'no-store',
                    credentials: 'same-origin',
                })
                : Promise.resolve(null);

            const [userResult, botResult] = await Promise.allSettled([userPromise, botPromise]);
            const userResponse = userResult.status === 'fulfilled' ? userResult.value : null;
            const botResponse = botResult.status === 'fulfilled' ? botResult.value : null;

            if (includeBotInfo && botResponse?.ok) {
                const info = await botResponse.json().catch(() => null);
                if (info) {
                    botInfo.set(info);
                    document.title = `${info.name} Panel`;
                }
            }

            if (!userResponse?.ok) {
                currentUser.set(null);
                isLoading = false;
                return;
            }

            const userJson = await userResponse.json().catch(() => null);
            if (!userJson) {
                currentUser.set(null);
                isLoading = false;
                return;
            }

            currentUser.set(userJson);
            try {
                sessionStorage.removeItem('webpanel_oauth_pending');
                sessionStorage.removeItem('webpanel_oauth_started_at');
                if (window.location.search.includes('oauth=complete')) {
                    const nextUrl = window.location.pathname + window.location.hash;
                    window.history.replaceState({}, '', nextUrl || '/');
                }
            } catch {
                // best-effort only
            }
        } catch {
            // Auth failed — will show login
            currentUser.set(null);
        } finally {
            authCheckInFlight = false;
            isLoading = false;
        }
    }

    function shouldRetryPendingOAuth() {
        try {
            const pending = sessionStorage.getItem('webpanel_oauth_pending');
            if (pending !== '1') return false;

            const startedAt = Number(sessionStorage.getItem('webpanel_oauth_started_at') || 0);
            if (!startedAt) return true;

            const ageMs = Date.now() - startedAt;
            if (ageMs > 5 * 60 * 1000) {
                sessionStorage.removeItem('webpanel_oauth_pending');
                sessionStorage.removeItem('webpanel_oauth_started_at');
                return false;
            }

            return true;
        } catch {
            return false;
        }
    }

    function handleAuthResume() {
        if (document.visibilityState === 'hidden') return;
        if ($currentUser) return;
        if (!shouldRetryPendingOAuth() && !window.location.search.includes('oauth=complete')) return;
        loadSession();
    }

    onMount(() => {
        loadSession({ includeBotInfo: true });

        const resumeHandlers = [
            ['visibilitychange', handleAuthResume, document],
            ['focus', handleAuthResume, window],
            ['pageshow', handleAuthResume, window],
        ];

        for (const [eventName, handler, target] of resumeHandlers) {
            target.addEventListener(eventName, handler);
        }

        let pendingPoll = null;
        if (shouldRetryPendingOAuth()) {
            pendingPoll = setInterval(() => {
                if ($currentUser) return;
                loadSession();
            }, 1500);
        }

        return () => {
            for (const [eventName, handler, target] of resumeHandlers) {
                target.removeEventListener(eventName, handler);
            }
            if (pendingPoll) clearInterval(pendingPoll);
        };
    });
</script>

{#if isLoading}
    <div class="loading-screen">
        <div class="loading-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-dot"></div>
        </div>
        <div class="loading-text">Loading panel...</div>
    </div>
{:else if !$currentUser}
    <Login />
{:else}
    <a href="#main-content" class="skip-link">Skip to main content</a>
    <div class="layout">
        <MobileHeader />
        <Sidebar />
        <main id="main-content" class="main-content">
            {#key $currentPage}
                {@const PageComponent = pageComponents[$currentPage] || Dashboard}
                <div class="animate-fade-in">
                    <PageComponent />
                </div>
            {/key}
        </main>
    </div>
{/if}

<Toast />

<style>
    .skip-link {
        position: absolute;
        top: -100%;
        left: 16px;
        z-index: 9999;
        background: var(--color-accent);
        color: white;
        padding: 8px 16px;
        border-radius: var(--radius-md);
        font-size: 14px;
        font-weight: 500;
        text-decoration: none;
        transition: top 0.2s ease;
    }

    .skip-link:focus {
        top: 16px;
    }

    .loading-screen {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        gap: 14px;
        min-height: 100vh;
        background: var(--color-base);
    }

    .loading-spinner {
        width: 48px;
        height: 48px;
        position: relative;
    }

    .spinner-ring {
        width: 100%;
        height: 100%;
        border: 3px solid var(--color-border);
        border-top-color: var(--color-accent);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }

    .spinner-dot {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 8px;
        height: 8px;
        margin: -4px 0 0 -4px;
        background: var(--color-accent);
        border-radius: 50%;
        animation: pulse-glow 1.5s ease-in-out infinite;
    }

    .loading-text {
        color: var(--color-text-secondary);
        font-size: 14px;
        font-weight: 500;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    .layout {
        display: flex;
        min-height: 100vh;
        overflow-x: hidden;
    }

    .main-content {
        flex: 1;
        padding: 20px 32px 32px;
        margin-left: var(--spacing-sidebar);
        height: 100vh;
        overflow-y: auto;
        overflow-x: hidden;
        transition: margin-left 0.3s var(--ease-out);
    }

    @media (max-width: 768px) {
        .main-content {
            margin-left: 0;
            padding: 16px;
            padding-top: 72px;
        }
    }

    :global(.sidebar-collapsed) .main-content {
        margin-left: var(--spacing-sidebar-collapsed);
    }
</style>
