<script>
    import { onMount } from 'svelte';
    import { currentUser, botInfo, currentPage } from './lib/stores.js';
    import { getBasePath } from './lib/api.js';

    import Sidebar from './components/layout/Sidebar.svelte';
    import MobileHeader from './components/layout/MobileHeader.svelte';
    import Toast from './components/ui/Toast.svelte';
    import Login from './pages/Login.svelte';
    import Dashboard from './pages/Dashboard.svelte';
    import Alliances from './pages/Alliances.svelte';
    import Notifications from './pages/Notifications.svelte';
    import Processes from './pages/Processes.svelte';
    import GiftCodes from './pages/GiftCodes.svelte';
    import Settings from './pages/Settings.svelte';
    import Logs from './pages/Logs.svelte';
    import Calculators from './pages/Calculators.svelte';

    let isLoading = $state(true);

    const pageComponents = {
        dashboard: Dashboard,
        alliances: Alliances,
        notifications: Notifications,
        processes: Processes,
        giftcodes: GiftCodes,
        calculators: Calculators,
        settings: Settings,
        logs: Logs,
    };

    onMount(async () => {
        try {
            const basePath = getBasePath();
            const [userResponse, botResponse] = await Promise.all([
                fetch(basePath + '/auth/me'),
                fetch(basePath + '/api/botinfo'),
            ]);

            if (botResponse.ok) {
                const info = await botResponse.json();
                botInfo.set(info);
                document.title = `${info.name} Panel`;
            }

            if (!userResponse.ok) {
                isLoading = false;
                return;
            }

            currentUser.set(await userResponse.json());
        } catch {
            // Auth failed — will show login
        }
        isLoading = false;
    });
</script>

{#if isLoading}
    <div class="loading-screen">
        <div class="loading-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-dot"></div>
        </div>
    </div>
{:else if !$currentUser}
    <Login />
{:else}
    <a href="#main-content" class="skip-link">Skip to main content</a>
    <div class="layout">
        <MobileHeader />
        <Sidebar />
        <main id="main-content" class="main-content">
            {#key $currentPage}
                {@const PageComponent = pageComponents[$currentPage] || Dashboard}
                <div class="animate-fade-in">
                    <PageComponent />
                </div>
            {/key}
        </main>
    </div>
{/if}

<Toast />

<style>
    .skip-link {
        position: absolute;
        top: -100%;
        left: 16px;
        z-index: 9999;
        background: var(--color-accent);
        color: white;
        padding: 8px 16px;
        border-radius: var(--radius-md);
        font-size: 14px;
        font-weight: 500;
        text-decoration: none;
        transition: top 0.2s ease;
    }

    .skip-link:focus {
        top: 16px;
    }

    .loading-screen {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        background: var(--color-base);
    }

    .loading-spinner {
        width: 48px;
        height: 48px;
        position: relative;
    }

    .spinner-ring {
        width: 100%;
        height: 100%;
        border: 3px solid var(--color-border);
        border-top-color: var(--color-accent);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }

    .spinner-dot {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 8px;
        height: 8px;
        margin: -4px 0 0 -4px;
        background: var(--color-accent);
        border-radius: 50%;
        animation: pulse-glow 1.5s ease-in-out infinite;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    .layout {
        display: flex;
        min-height: 100vh;
        overflow-x: hidden;
    }

    .main-content {
        flex: 1;
        padding: 20px 32px 32px;
        margin-left: var(--spacing-sidebar);
        height: 100vh;
        overflow-y: auto;
        overflow-x: hidden;
        transition: margin-left 0.3s var(--ease-out);
    }

    @media (max-width: 768px) {
        .main-content {
            margin-left: 0;
            padding: 16px;
            padding-top: 72px;
        }
    }

    :global(.sidebar-collapsed) .main-content {
        margin-left: var(--spacing-sidebar-collapsed);
    }
</style>
