<script>
    import { onMount } from 'svelte';
    import { currentUser, botInfo, currentPage, publicConfig, navigateTo, immersivePage, sidebarCollapsed } from './lib/stores.js';
    import { getBasePath } from './lib/api.js';

    import Sidebar from './components/layout/Sidebar.svelte';
    import MobileHeader from './components/layout/MobileHeader.svelte';
    import Toast from './components/ui/Toast.svelte';
    import Login from './pages/Login.svelte';
    import Dashboard from './pages/Dashboard.svelte';
    import Alliances from './pages/Alliances.svelte';
    import Notifications from './pages/Notifications.svelte';
    import Processes from './pages/Processes.svelte';
    import GiftCodes from './pages/GiftCodes.svelte';
    import Guides from './pages/Guides.svelte';
    import Reservations from './pages/Reservations.svelte';
    import ManageAdmins from './pages/ManageAdmins.svelte';
    import Settings from './pages/Settings.svelte';
    import Logs from './pages/Logs.svelte';
    import Calculators from './pages/Calculators.svelte';
    import ReservationPublicPage from './pages/ReservationPublicPage.svelte';
    import GuidePublicPage from './pages/GuidePublicPage.svelte';

    let isLoading = $state(true);
    let authCheckInFlight = false;
    const STARTUP_FETCH_TIMEOUT_MS = 8000;

    const pageComponents = {
        dashboard: Dashboard,
        alliances: Alliances,
        notifications: Notifications,
        processes: Processes,
        giftcodes: GiftCodes,
        guides: Guides,
        reservations: Reservations,
        admins: ManageAdmins,
        calculators: Calculators,
        settings: Settings,
        logs: Logs,
    };

    function getPublicReservationSlug() {
        if (typeof window === 'undefined') return null;
        const basePath = getBasePath();
        const pathname = window.location.pathname;
        const normalizedBase = basePath && pathname.startsWith(basePath)
            ? pathname.slice(basePath.length) || '/'
            : pathname;
        const match = normalizedBase.match(/^\/r\/positions\/([^/]+)\/?$/);
        return match ? decodeURIComponent(match[1]) : null;
    }

    function getPublicGuideSlug() {
        if (typeof window === 'undefined') return null;
        const basePath = getBasePath();
        const pathname = window.location.pathname;
        const normalizedBase = basePath && pathname.startsWith(basePath)
            ? pathname.slice(basePath.length) || '/'
            : pathname;
        const match = normalizedBase.match(/^\/g\/([^/]+)\/?$/);
        return match ? decodeURIComponent(match[1]) : null;
    }

    const publicReservationSlug = getPublicReservationSlug();
    const publicGuideSlug = getPublicGuideSlug();

    function readStoredTheme() {
        if (typeof window === 'undefined') return 'dark-blue-premium';
        try {
            return window.localStorage.getItem('panel-theme') || 'dark-blue-premium';
        } catch {
            return 'dark-blue-premium';
        }
    }

    function writeStoredTheme(theme) {
        if (typeof window === 'undefined') return;
        try {
            window.localStorage.setItem('panel-theme', theme || 'dark-blue-premium');
        } catch {
            // Ignore storage failures
        }
    }

    function applyTheme(theme) {
        if (typeof document === 'undefined') return;
        const resolvedTheme = theme || 'dark-blue-premium';
        document.documentElement.dataset.panelTheme = resolvedTheme;
        writeStoredTheme(resolvedTheme);
    }

    async function loadPublicConfig() {
        try {
            const basePath = getBasePath();
            const response = await fetchWithTimeout(basePath + '/api/public-config', {
                cache: 'no-store',
                credentials: 'same-origin',
            });
            if (!response?.ok) return;

            const config = await response.json().catch(() => null);
            if (!config) return;

            publicConfig.set({
                guestPublicToolsEnabled: !!config.guestPublicToolsEnabled,
                calculatorsPublic: !!config.calculatorsPublic,
                theme: config.theme || 'dark-blue-premium',
            });
            applyTheme(config.theme);
        } catch {
            applyTheme(readStoredTheme());
        }
    }

    applyTheme(readStoredTheme());

    function buildGuestUser() {
        return {
            userId: null,
            username: 'Guest',
            avatar: null,
            permissions: 0,
            isOwner: false,
            isAdmin: false,
            isGuest: true,
            publicFeatures: { calculators: true },
            language: 'en',
        };
    }

    function canEnterGuestMode() {
        return !!($publicConfig?.guestPublicToolsEnabled && $publicConfig?.calculatorsPublic);
    }

    function enterGuestMode() {
        if (!canEnterGuestMode()) return;
        currentUser.set(buildGuestUser());
        navigateTo('calculators');
    }

    async function fetchWithTimeout(url, options = {}, timeoutMs = STARTUP_FETCH_TIMEOUT_MS) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
        try {
            return await fetch(url, {
                ...options,
                signal: controller.signal,
            });
        } finally {
            clearTimeout(timeoutId);
        }
    }

    async function loadSession({ includeBotInfo = false } = {}) {
        if (authCheckInFlight) return;
        authCheckInFlight = true;
        try {
            const basePath = getBasePath();
            const userPromise = fetchWithTimeout(basePath + '/auth/me', {
                cache: 'no-store',
                credentials: 'same-origin',
            });
            const botPromise = includeBotInfo
                ? fetchWithTimeout(basePath + '/api/botinfo', {
                    cache: 'no-store',
                    credentials: 'same-origin',
                })
                : Promise.resolve(null);

            const [userResult, botResult, publicConfigResult] = await Promise.allSettled([
                userPromise,
                botPromise,
                Promise.resolve(null),
            ]);
            const userResponse = userResult.status === 'fulfilled' ? userResult.value : null;
            const botResponse = botResult.status === 'fulfilled' ? botResult.value : null;

            if (includeBotInfo && botResponse?.ok) {
                const info = await botResponse.json().catch(() => null);
                if (info) {
                    botInfo.set(info);
                    document.title = `${info.name} Panel`;
                }
            }

            if (!userResponse?.ok) {
                currentUser.set(null);
                isLoading = false;
                return;
            }

            const userJson = await userResponse.json().catch(() => null);
            if (!userJson) {
                currentUser.set(null);
                isLoading = false;
                return;
            }

            currentUser.set(userJson);
            try {
                sessionStorage.removeItem('webpanel_oauth_pending');
                sessionStorage.removeItem('webpanel_oauth_started_at');
                if (window.location.search.includes('oauth=complete')) {
                    const nextUrl = window.location.pathname + window.location.hash;
                    window.history.replaceState({}, '', nextUrl || '/');
                }
            } catch {
                // best-effort only
            }
        } catch {
            // Auth failed — will show login
            currentUser.set(null);
        } finally {
            authCheckInFlight = false;
            isLoading = false;
        }
    }

    function shouldRetryPendingOAuth() {
        try {
            const pending = sessionStorage.getItem('webpanel_oauth_pending');
            if (pending !== '1') return false;

            const startedAt = Number(sessionStorage.getItem('webpanel_oauth_started_at') || 0);
            if (!startedAt) return true;

            const ageMs = Date.now() - startedAt;
            if (ageMs > 5 * 60 * 1000) {
                sessionStorage.removeItem('webpanel_oauth_pending');
                sessionStorage.removeItem('webpanel_oauth_started_at');
                return false;
            }

            return true;
        } catch {
            return false;
        }
    }

    function handleAuthResume() {
        if (document.visibilityState === 'hidden') return;
        if ($currentUser) return;
        if (!shouldRetryPendingOAuth() && !window.location.search.includes('oauth=complete')) return;
        loadSession();
    }

    onMount(() => {
        applyTheme($publicConfig?.theme || 'dark-blue-premium');
        void loadPublicConfig();

        if (publicReservationSlug || publicGuideSlug) {
            isLoading = false;
            return;
        }

        loadSession({ includeBotInfo: true });

        const resumeHandlers = [
            ['visibilitychange', handleAuthResume, document],
            ['focus', handleAuthResume, window],
            ['pageshow', handleAuthResume, window],
        ];

        for (const [eventName, handler, target] of resumeHandlers) {
            target.addEventListener(eventName, handler);
        }

        let pendingPoll = null;
        if (shouldRetryPendingOAuth()) {
            pendingPoll = setInterval(() => {
                if ($currentUser) return;
                loadSession();
            }, 1500);
        }

        return () => {
            for (const [eventName, handler, target] of resumeHandlers) {
                target.removeEventListener(eventName, handler);
            }
            if (pendingPoll) clearInterval(pendingPoll);
        };
    });

    $effect(() => {
        if ($currentUser?.isGuest && $currentPage !== 'calculators') {
            navigateTo('calculators');
        }
    });

    $effect(() => {
        applyTheme($publicConfig?.theme || 'dark-blue-premium');
    });
</script>

{#if publicReservationSlug}
    <ReservationPublicPage slug={publicReservationSlug} />
{:else if publicGuideSlug}
    <GuidePublicPage slug={publicGuideSlug} />
{:else if isLoading}
    <div class="loading-screen">
        <div class="loading-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-dot"></div>
        </div>
        <div class="loading-text">Loading panel...</div>
    </div>
{:else if !$currentUser}
    <Login onContinueAsGuest={enterGuestMode} />
{:else}
    <a href="#main-content" class="skip-link">Skip to main content</a>
    {#if $immersivePage && $currentPage === 'guides'}
        <main id="main-content" class="immersive-main">
            {#key `${$currentPage}:${$immersivePage}`}
                {@const PageComponent = pageComponents[$currentPage] || Dashboard}
                <div class="animate-fade-in immersive-page-shell">
                    <PageComponent />
                </div>
            {/key}
        </main>
    {:else}
        <div class="layout" class:sidebar-is-collapsed={$sidebarCollapsed}>
            <MobileHeader />
            <Sidebar />
            <main id="main-content" class="main-content" class:sidebar-is-collapsed={$sidebarCollapsed}>
                {#key $currentPage}
                    {@const PageComponent = pageComponents[$currentPage] || Dashboard}
                    <div class="animate-fade-in">
                        <PageComponent />
                    </div>
                {/key}
            </main>
        </div>
    {/if}
{/if}

<Toast />

<style>
    .skip-link {
        position: absolute;
        top: -100%;
        left: 16px;
        z-index: 9999;
        background: var(--color-accent);
        color: var(--color-accent-ink);
        padding: 10px 16px;
        border-radius: var(--radius-pill);
        font-size: 14px;
        font-weight: 700;
        text-decoration: none;
        transition: top 0.2s var(--ease-out);
    }

    .skip-link:focus {
        top: 16px;
    }

    .loading-screen {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        gap: 18px;
        min-height: 100dvh;
        background:
            radial-gradient(circle at 50% 0%, var(--theme-ambient-canvas-top), transparent 28%),
            linear-gradient(180deg, var(--color-canvas-2), var(--color-canvas));
    }

    .loading-spinner {
        width: 64px;
        height: 64px;
        position: relative;
    }

    .spinner-ring {
        width: 100%;
        height: 100%;
        border: 2px solid var(--theme-border-medium);
        border-top-color: var(--color-accent);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }

    .spinner-dot {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 10px;
        height: 10px;
        margin: -5px 0 0 -5px;
        background: var(--color-accent);
        border-radius: 50%;
        animation: pulse-glow 1.5s ease-in-out infinite;
    }

    .loading-text {
        color: var(--color-text-secondary);
        font-size: 13px;
        font-weight: 600;
        letter-spacing: 0.12em;
        text-transform: uppercase;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    .layout {
        display: flex;
        min-height: 100dvh;
        overflow-x: hidden;
    }

    .main-content {
        flex: 1;
        padding: 24px 32px 0;
        margin-left: var(--spacing-sidebar);
        height: 100dvh;
        box-sizing: border-box;
        overflow-y: auto;
        overflow-x: hidden;
        transition: margin-left 0.3s var(--ease-out);
    }

    .layout.sidebar-is-collapsed .main-content {
        margin-left: var(--spacing-sidebar-collapsed);
        padding-left: 40px;
        padding-right: 40px;
    }

    .immersive-main {
        min-height: 100dvh;
        background:
            radial-gradient(circle at 50% 0%, var(--theme-ambient-canvas-left), transparent 30%),
            linear-gradient(180deg, var(--color-canvas-2), var(--color-canvas));
    }

    .immersive-page-shell {
        min-height: 100dvh;
    }

    @media (max-width: 768px) {
        .main-content {
            margin-left: 0;
            padding: 16px;
            padding-top: 80px;
        }

        .immersive-main {
            min-height: 100dvh;
        }
    }

</style>
