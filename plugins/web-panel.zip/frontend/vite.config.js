import { defineConfig } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import tailwindcss from '@tailwindcss/vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * Vite plugin that wipes only the assets/ output directory before each build,
 * leaving other files in public/ (app.js, icons/, style.css) untouched.
 */
function cleanAssetsPlugin() {
    return {
        name: 'clean-assets',
        buildStart() {
            const assetsDir = path.resolve(__dirname, '../public/assets');
            if (fs.existsSync(assetsDir)) {
                fs.rmSync(assetsDir, { recursive: true, force: true });
            }
        }
    };
}

export default defineConfig({
    base: './',
    plugins: [
        tailwindcss(),
        svelte(),
        cleanAssetsPlugin()
    ],
    build: {
        outDir: '../public',
        emptyOutDir: false,
        assetsDir: 'assets',
        rollupOptions: {
            input: 'index.html'
        }
    },
    server: {
        proxy: {
            '/auth': 'http://localhost:3000',
            '/api': 'http://localhost:3000'
        }
    }
});
