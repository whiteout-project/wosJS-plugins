import test from 'node:test';
import assert from 'node:assert/strict';
import { isValidNotificationPattern, parseUtcTrigger } from '../src/lib/notificationTime.js';

test('parses an exact UTC trigger', () => {
    assert.equal(parseUtcTrigger('2028', '02', '29', '14', '30'), 1835447400);
});

test('rejects rolled-over and out-of-range dates', () => {
    assert.equal(parseUtcTrigger('2027', '02', '29', '14', '30'), null);
    assert.equal(parseUtcTrigger('2027', '13', '01', '14', '30'), null);
    assert.equal(parseUtcTrigger('2027', '12', '01', '24', '00'), null);
});

test('validates notification patterns without silent or duplicate sends', () => {
    assert.equal(isValidNotificationPattern('5,15,time'), true);
    assert.equal(isValidNotificationPattern('time,5'), true);
    assert.equal(isValidNotificationPattern('abc'), false);
    assert.equal(isValidNotificationPattern('0,time'), false);
    assert.equal(isValidNotificationPattern('5,5,time'), false);
});
