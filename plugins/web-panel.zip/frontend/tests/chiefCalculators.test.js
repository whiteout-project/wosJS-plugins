import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

import {
    calculateLegendaryStageCost,
    flattenGearStages,
    loadCalculatorData,
    parseCharmCost,
    parseGearCost,
} from '../src/lib/calculators/calculatorData.js';
import { calculateCharmUpgrade } from '../src/lib/calculators/chiefCharmCalculator.js';
import { calculateGearUpgrade, calculateMultipleGearUpgrades } from '../src/lib/calculators/chiefGearCalculator.js';

const repoRoot = path.resolve(process.cwd(), '..');
const jsonPath = path.join(repoRoot, 'data', 'chief_Gear_Charm.json');
const rawData = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
const data = loadCalculatorData(rawData);

test('gear flatten count equals 46', () => {
    assert.equal(flattenGearStages(rawData).length, 46);
});

test('charm level entry count equals 17', () => {
    assert.equal(data.charmLevels.length, 17);
});

test('same current and target gear stage returns zero materials', () => {
    const result = calculateGearUpgrade(
        data,
        { quality: 'green', tier: 1, star: 0 },
        { quality: 'green', tier: 1, star: 0 },
        6
    );

    assert.deepEqual(result.materialsPerItem, {
        hardenedAlloy: 0,
        polishingSolution: 0,
        designPlan: 0,
        lunarAmber: 0,
    });
});

test('one normal gear upgrade is calculated correctly', () => {
    const result = calculateGearUpgrade(
        data,
        { quality: 'green', tier: 1, star: 0 },
        { quality: 'green', tier: 1, star: 1 },
        1
    );

    assert.deepEqual(result.materialsPerItem, {
        hardenedAlloy: 3800,
        polishingSolution: 40,
        designPlan: 0,
        lunarAmber: 0,
    });
});

test('multiple gear upgrades accumulate stage costs', () => {
    const result = calculateGearUpgrade(
        data,
        { quality: 'green', tier: 1, star: 0 },
        { quality: 'blue', tier: 1, star: 1 },
        1
    );

    assert.deepEqual(result.materialsPerItem, {
        hardenedAlloy: 20500,
        polishingSolution: 205,
        designPlan: 0,
        lunarAmber: 0,
    });
});

test('cross-quality gear upgrade includes design plans', () => {
    const result = calculateGearUpgrade(
        data,
        { quality: 'blue', tier: 1, star: 1 },
        { quality: 'purple', tier: 1, star: 1 },
        1
    );

    assert.deepEqual(result.materialsPerItem, {
        hardenedAlloy: 0,
        polishingSolution: 0,
        designPlan: 225,
        lunarAmber: 0,
    });
});

test('upgrade into red legendary gear is calculated correctly', () => {
    const result = calculateGearUpgrade(
        data,
        { quality: 'gold', tier: 2, star: 3 },
        { quality: 'red', tier: 1, star: 0 },
        1
    );

    assert.deepEqual(result.materialsPerItem, {
        hardenedAlloy: 224000,
        polishingSolution: 2280,
        designPlan: 380,
        lunarAmber: 10,
    });
    assert.equal(result.deploymentCapacity.increasePerItem, 40);
});

test('red compressed steps aggregate correctly', () => {
    const firstRedStage = data.gearStages.find((stage) => stage.quality === 'red' && stage.tier === 1 && stage.star === 0);
    assert.deepEqual(calculateLegendaryStageCost(firstRedStage.source, data), {
        hardenedAlloy: 50000,
        polishingSolution: 530,
        designPlan: 85,
        lunarAmber: 10,
    });
});

test('gear count 1 versus 6 scales totals', () => {
    const single = calculateGearUpgrade(
        data,
        { quality: 'red', tier: 1, star: 0 },
        { quality: 'red', tier: 1, star: 1 },
        1
    );
    const full = calculateGearUpgrade(
        data,
        { quality: 'red', tier: 1, star: 0 },
        { quality: 'red', tier: 1, star: 1 },
        6
    );

    assert.equal(full.materialsTotal.hardenedAlloy, single.materialsTotal.hardenedAlloy * 6);
    assert.equal(full.power.increaseTotal, single.power.increaseTotal * 6);
});

test('multiple configured gear pieces aggregate totals correctly', () => {
    const result = calculateMultipleGearUpgrades(data, [
        {
            slotId: 'hat',
            current: { quality: 'green', tier: 1, star: 0 },
            target: { quality: 'green', tier: 1, star: 1 },
        },
        {
            slotId: 'clock',
            current: { quality: 'blue', tier: 1, star: 1 },
            target: { quality: 'purple', tier: 1, star: 1 },
        },
        {
            slotId: 'coat',
            current: { quality: 'green', tier: 1, star: 0 },
            target: { quality: 'green', tier: 1, star: 0 },
        },
    ]);

    assert.equal(result.configuredCount, 2);
    assert.deepEqual(result.materialsTotal, {
        hardenedAlloy: 3800,
        polishingSolution: 40,
        designPlan: 225,
        lunarAmber: 0,
    });
});

test('charm level 0 to level 1 works', () => {
    const result = calculateCharmUpgrade(data, 0, 1, 1);
    assert.deepEqual(result.materialsPerCharm, {
        charmDesign: 5,
        charmGuide: 5,
        charmSecret: 0,
    });
});

test('charm level 5 to level 8 works', () => {
    const result = calculateCharmUpgrade(data, 5, 8, 1);
    assert.deepEqual(result.materialsPerCharm, {
        charmDesign: 1100,
        charmGuide: 460,
        charmSecret: 0,
    });
});

test('charm level 0 to level 16 works', () => {
    const result = calculateCharmUpgrade(data, 0, 16, 1);
    assert.ok(result.materialsPerCharm.charmDesign > 0);
    assert.ok(result.materialsPerCharm.charmGuide > 0);
    assert.ok(result.materialsPerCharm.charmSecret > 0);
    assert.equal(result.targetLevel, 16);
});

test('charm count 1 versus 18 scales totals', () => {
    const single = calculateCharmUpgrade(data, 0, 4, 1);
    const full = calculateCharmUpgrade(data, 0, 4, 18);

    assert.equal(full.materialsTotal.charmDesign, single.materialsTotal.charmDesign * 18);
    assert.equal(full.power.increaseTotal, single.power.increaseTotal * 18);
});

test('reverse gear upgrades are rejected', () => {
    assert.throws(
        () => calculateGearUpgrade(
            data,
            { quality: 'purple', tier: 1, star: 0 },
            { quality: 'green', tier: 1, star: 1 },
            1
        ),
        /Target gear stage cannot be lower/
    );
});

test('reverse charm upgrades are rejected', () => {
    assert.throws(() => calculateCharmUpgrade(data, 8, 5, 1), /Target charm level cannot be lower/);
});

test('invalid counts and missing stages are rejected', () => {
    assert.throws(
        () => calculateGearUpgrade(
            data,
            { quality: 'green', tier: 1, star: 0 },
            { quality: 'green', tier: 1, star: 1 },
            0
        ),
        /Gear item count must be at least 1/
    );

    assert.throws(
        () => calculateGearUpgrade(
            data,
            { quality: 'green', tier: 9, star: 9 },
            { quality: 'green', tier: 1, star: 1 },
            1
        ),
        /Current gear stage does not exist/
    );

    assert.throws(() => calculateCharmUpgrade(data, 0, 1, 0), /Charm count must be at least 1/);
});

test('malformed material arrays and red steps are rejected', () => {
    assert.throws(
        () => parseGearCost(data, [1, 2, 3]),
        /invalid length/
    );
    assert.throws(
        () => parseCharmCost(data, [1, 2]),
        /invalid length/
    );
    assert.throws(
        () => calculateLegendaryStageCost({ steps: [[3, 1, 2, 3]] }, data),
        /malformed step data/
    );
});
