const crypto = require('crypto');
const pluginDb = require('./pluginDb');

const LOGIN_TOKEN_EXPIRY_MS = 5 * 60 * 1000;
const JWT_EXPIRY = '30d';
const DISCORD_API_BASE = 'https://discord.com/api/v10';

const pendingTokens = new Map();

// Clean up expired pending tokens every 10 minutes
setInterval(() => {
    const now = Date.now();
    for (const [token, entry] of pendingTokens) {
        if (now > entry.expiresAt) pendingTokens.delete(token);
    }
}, 10 * 60 * 1000).unref();

/**
 * Generate a one-time login token for a Discord user.
 * @param {string} userId - Discord user ID
 * @returns {string} The login token
 */
function generateLoginToken(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    pendingTokens.set(token, {
        userId,
        expiresAt: Date.now() + LOGIN_TOKEN_EXPIRY_MS
    });
    return token;
}

/**
 * Validate a login token. Tokens remain valid until their 5-minute expiry
 * to survive localtunnel interstitial double-requests.
 * @param {string} token - The login token to validate
 * @returns {string|null} The Discord user ID if valid, null otherwise
 */
function validateLoginToken(token) {
    const entry = pendingTokens.get(token);
    if (!entry) return null;

    if (Date.now() > entry.expiresAt) {
        pendingTokens.delete(token);
        return null;
    }

    return entry.userId;
}

/**
 * Persistent JWT secret — survives bot restarts so user sessions stay valid.
 */
let JWT_SECRET = pluginDb.get('jwt_secret');
if (!JWT_SECRET) {
    JWT_SECRET = crypto.randomBytes(48).toString('hex');
    pluginDb.set('jwt_secret', JWT_SECRET);
}

// ── OAuth2 ───────────────────────────────────────────────────────────────────

const pendingOAuthStates = new Map();
const OAUTH_STATE_EXPIRY_MS = 5 * 60 * 1000;

/**
 * Generate a one-time OAuth2 state token for CSRF protection.
 * @returns {string} The state token
 */
function generateOAuth2State() {
    const state = crypto.randomBytes(32).toString('hex');
    pendingOAuthStates.set(state, { expiresAt: Date.now() + OAUTH_STATE_EXPIRY_MS });
    return state;
}

/**
 * Validate and consume an OAuth2 state token.
 * @param {string} state
 * @returns {boolean}
 */
function validateOAuth2State(state) {
    const entry = pendingOAuthStates.get(state);
    if (!entry) return false;
    pendingOAuthStates.delete(state);
    return Date.now() <= entry.expiresAt;
}

// Clean up expired OAuth2 states every 10 minutes
setInterval(() => {
    const now = Date.now();
    for (const [state, entry] of pendingOAuthStates) {
        if (now > entry.expiresAt) pendingOAuthStates.delete(state);
    }
}, 10 * 60 * 1000).unref();

function getClientSecret() {
    return pluginDb.get('discord_client_secret') || null;
}

function setClientSecret(secret) {
    pluginDb.set('discord_client_secret', secret);
}

function isOAuth2Configured() {
    return !!getClientSecret();
}

/**
 * Build the Discord OAuth2 authorization URL.
 * @param {string} clientId - Bot application ID
 * @param {string} redirectUri - Callback URL
 * @param {string} [state] - CSRF state parameter
 * @returns {string}
 */
function buildOAuth2Url(clientId, redirectUri, state) {
    const params = new URLSearchParams({
        client_id: clientId,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: 'identify guilds'
    });
    if (state) params.set('state', state);
    return `https://discord.com/oauth2/authorize?${params}`;
}

/**
 * Exchange an OAuth2 authorization code for an access token.
 * @param {string} code
 * @param {string} clientId
 * @param {string} clientSecret
 * @param {string} redirectUri
 * @returns {Promise<{access_token: string, token_type: string}|null>}
 */
async function exchangeCode(code, clientId, clientSecret, redirectUri) {
    const response = await fetch(`${DISCORD_API_BASE}/oauth2/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            client_id: clientId,
            client_secret: clientSecret,
            grant_type: 'authorization_code',
            code,
            redirect_uri: redirectUri
        })
    });

    if (!response.ok) {
        const errorText = await response.text().catch(() => '');
        console.warn(`[Web Panel OAuth2] Token exchange failed (${response.status}): ${errorText.slice(0, 300)}`);
        return null;
    }
    return response.json();
}

/**
 * Fetch the authenticated Discord user's profile.
 * @param {string} accessToken
 * @returns {Promise<{id: string, username: string, avatar: string|null}|null>}
 */
async function fetchDiscordUser(accessToken) {
    const response = await fetch(`${DISCORD_API_BASE}/users/@me`, {
        headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!response.ok) return null;
    return response.json();
}

/**
 * Fetch the guilds the authenticated user belongs to.
 * Requires the `guilds` OAuth2 scope.
 * @param {string} accessToken
 * @returns {Promise<Array<{id: string, name: string, icon: string|null, owner: boolean, permissions: string}>|null>}
 */
async function fetchUserGuilds(accessToken) {
    const response = await fetch(`${DISCORD_API_BASE}/users/@me/guilds`, {
        headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!response.ok) return null;
    return response.json();
}

module.exports = {
    generateLoginToken,
    validateLoginToken,
    JWT_SECRET,
    JWT_EXPIRY,
    getClientSecret,
    setClientSecret,
    isOAuth2Configured,
    buildOAuth2Url,
    exchangeCode,
    fetchDiscordUser,
    fetchUserGuilds,
    generateOAuth2State,
    validateOAuth2State
};
