const { spawn, execFileSync, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');

// ─────────────────────────────────────────────────────────────────────────────
// Tunnel Manager
// Tries in order: PUBLIC_URL env > cloudflared quick tunnel > localtunnel
// ─────────────────────────────────────────────────────────────────────────────

const BIN_DIR = path.join(__dirname, 'bin');
const CLOUDFLARED_DOWNLOAD_BASE = 'https://github.com/cloudflare/cloudflared/releases/latest/download';

let tunnelProcess = null;
let tunnelUrl = null;
let tunnelType = null;
let localtunnelInstance = null;

/**
 * Get the cloudflared binary filename for the current platform.
 * @returns {{ filename: string, url: string } | null}
 */
function getCloudflaredInfo() {
    const platform = process.platform;
    const arch = process.arch;

    const matrix = {
        'win32-x64': 'cloudflared-windows-amd64.exe',
        'win32-arm64': 'cloudflared-windows-amd64.exe',
        'linux-x64': 'cloudflared-linux-amd64',
        'linux-arm64': 'cloudflared-linux-arm64',
        'linux-arm': 'cloudflared-linux-arm',
        'darwin-x64': 'cloudflared-darwin-amd64.tgz',
        'darwin-arm64': 'cloudflared-darwin-arm64.tgz'
    };

    const key = `${platform}-${arch}`;
    const filename = matrix[key];
    if (!filename) return null;

    return {
        filename,
        url: `${CLOUDFLARED_DOWNLOAD_BASE}/${filename}`
    };
}

/**
 * Check if cloudflared is available on PATH.
 * @returns {string|null} Path to cloudflared binary, or null
 */
function findCloudflaredOnPath() {
    try {
        const cmd = process.platform === 'win32' ? 'where' : 'which';
        const result = execFileSync(cmd, ['cloudflared'], { encoding: 'utf8', timeout: 5000 });
        const binPath = result.trim().split('\n')[0].trim();
        if (binPath && fs.existsSync(binPath)) return binPath;
    } catch {
        // Not on PATH
    }
    return null;
}

/**
 * Get path to local cloudflared binary (in bin/ folder).
 * @returns {string|null}
 */
function findLocalCloudflared() {
    const info = getCloudflaredInfo();
    if (!info) return null;

    const localBin = path.join(BIN_DIR, info.filename);
    if (fs.existsSync(localBin)) return localBin;
    return null;
}

/**
 * Download a file from a URL with redirect following.
 * @param {string} url
 * @param {string} destPath
 * @returns {Promise<void>}
 */
function downloadFile(url, destPath, redirectCount = 0) {
    if (redirectCount > 5) return Promise.reject(new Error('Too many redirects'));

    return new Promise((resolve, reject) => {
        const protocol = url.startsWith('https') ? https : require('http');
        protocol.get(url, { headers: { 'User-Agent': 'wosJS-bot' } }, (response) => {
            if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
                return downloadFile(response.headers.location, destPath, redirectCount + 1).then(resolve, reject);
            }
            if (response.statusCode !== 200) {
                return reject(new Error(`Download failed: HTTP ${response.statusCode}`));
            }

            const fileStream = fs.createWriteStream(destPath);
            response.pipe(fileStream);
            fileStream.on('finish', () => fileStream.close(resolve));
            fileStream.on('error', (error) => {
                fs.unlink(destPath, () => {});
                reject(error);
            });
        }).on('error', reject);
    });
}

/**
 * Auto-download cloudflared binary if not present.
 * @returns {Promise<string|null>} Path to binary, or null on failure
 */
async function autoDownloadCloudflared() {
    const info = getCloudflaredInfo();
    if (!info) {
        console.log('[Tunnel] Unsupported platform for cloudflared auto-download');
        return null;
    }

    const destPath = path.join(BIN_DIR, info.filename);

    if (fs.existsSync(destPath)) return destPath;

    console.log(`[Tunnel] Downloading cloudflared for ${process.platform}-${process.arch}...`);

    try {
        if (!fs.existsSync(BIN_DIR)) fs.mkdirSync(BIN_DIR, { recursive: true });

        await downloadFile(info.url, destPath);

        if (process.platform !== 'win32') {
            fs.chmodSync(destPath, 0o755);
        }

        // macOS comes as .tgz - extract it
        if (info.filename.endsWith('.tgz')) {
            execSync(`tar -xzf "${destPath}" -C "${BIN_DIR}"`, { timeout: 30000 });
            const extractedPath = path.join(BIN_DIR, 'cloudflared');
            if (fs.existsSync(extractedPath)) {
                fs.chmodSync(extractedPath, 0o755);
                fs.unlinkSync(destPath);
                return extractedPath;
            }
        }

        console.log('[Tunnel] cloudflared downloaded successfully');
        return destPath;
    } catch (error) {
        console.error('[Tunnel] Failed to download cloudflared:', error.message);
        if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
        return null;
    }
}

/**
 * Start a cloudflared quick tunnel.
 * @param {string} binPath - Path to cloudflared binary
 * @param {number} port - Local port to tunnel
 * @returns {Promise<string>} The public tunnel URL
 */
function startCloudflaredTunnel(binPath, port) {
    return new Promise((resolve, reject) => {
        const args = ['tunnel', '--url', `http://localhost:${port}`, '--no-autoupdate'];
        const child = spawn(binPath, args, {
            stdio: ['ignore', 'pipe', 'pipe'],
            windowsHide: true
        });

        tunnelProcess = child;
        let resolved = false;
        let stderr = '';

        const timeout = setTimeout(() => {
            if (!resolved) {
                resolved = true;
                reject(new Error('cloudflared tunnel timed out after 30 seconds'));
            }
        }, 30000);

        child.stderr.on('data', (chunk) => {
            const text = chunk.toString();
            stderr += text;

            // cloudflared prints the URL to stderr
            const urlMatch = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);
            if (urlMatch && !resolved) {
                resolved = true;
                clearTimeout(timeout);
                resolve(urlMatch[0]);
            }
        });

        child.stdout.on('data', (chunk) => {
            const text = chunk.toString();
            const urlMatch = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);
            if (urlMatch && !resolved) {
                resolved = true;
                clearTimeout(timeout);
                resolve(urlMatch[0]);
            }
        });

        child.on('error', (error) => {
            clearTimeout(timeout);
            if (!resolved) {
                resolved = true;
                reject(error);
            }
        });

        child.on('close', (code) => {
            clearTimeout(timeout);
            tunnelProcess = null;
            if (!resolved) {
                resolved = true;
                reject(new Error(`cloudflared exited with code ${code}: ${stderr.slice(-200)}`));
            } else {
                // Tunnel closed after it was running
                console.log('[Tunnel] cloudflared process exited');
                tunnelUrl = null;
                tunnelType = null;
            }
        });
    });
}

/**
 * Start a localtunnel as fallback.
 * @param {number} port
 * @returns {Promise<string>} Tunnel URL
 */
async function startLocaltunnel(port) {
    const localtunnel = require('localtunnel');
    const tunnel = await localtunnel({ port });

    localtunnelInstance = tunnel;

    tunnel.on('close', () => {
        localtunnelInstance = null;
        if (tunnelType === 'localtunnel') {
            tunnelUrl = null;
            tunnelType = null;
            console.log('[Tunnel] localtunnel closed');
        }
    });

    tunnel.on('error', (error) => {
        console.error('[Tunnel] localtunnel error:', error.message);
        localtunnelInstance = null;
        if (tunnelType === 'localtunnel') {
            tunnelUrl = null;
            tunnelType = null;
        }
    });

    return tunnel.url;
}

/**
 * Open a public tunnel to the given local port.
 * Priority: PUBLIC_URL env > cloudflared > localtunnel
 * @param {number} port - Local server port
 * @returns {Promise<{ url: string, type: string } | null>}
 */
async function openTunnel(port) {
    // 1. Check for PUBLIC_URL env var (hosted platforms)
    const publicUrl = process.env.PUBLIC_URL;
    if (publicUrl) {
        tunnelUrl = publicUrl.replace(/\/$/, '');
        tunnelType = 'env';
        console.log(`[Tunnel] Using PUBLIC_URL: ${tunnelUrl}`);
        return { url: tunnelUrl, type: tunnelType };
    }

    // 2. Try cloudflared
    try {
        const binPath = findCloudflaredOnPath() || findLocalCloudflared() || await autoDownloadCloudflared();
        if (binPath) {
            const url = await startCloudflaredTunnel(binPath, port);
            tunnelUrl = url;
            tunnelType = 'cloudflared';
            return { url, type: 'cloudflared' };
        }
    } catch (error) {
        console.error('[Tunnel] cloudflared failed:', error.message);
        closeTunnel();
    }

    // 3. Fall back to localtunnel
    try {
        console.log('[Tunnel] Falling back to localtunnel...');
        const url = await startLocaltunnel(port);
        tunnelUrl = url;
        tunnelType = 'localtunnel';
        console.log(`[Tunnel] localtunnel: ${url}`);
        return { url, type: 'localtunnel' };
    } catch (error) {
        console.error('[Tunnel] localtunnel failed:', error.message);
    }

    console.log('[Tunnel] No tunnel available -- direct IP access only');
    return null;
}

/**
 * Close any active tunnel.
 */
function closeTunnel() {
    if (tunnelProcess) {
        tunnelProcess.kill();
        tunnelProcess = null;
    }
    if (localtunnelInstance) {
        localtunnelInstance.close();
        localtunnelInstance = null;
    }
    tunnelUrl = null;
    tunnelType = null;
}

/**
 * Get the current tunnel URL, or null if no tunnel is active.
 */
function getTunnelUrl() {
    return tunnelUrl;
}

/**
 * Get the current tunnel type: 'env', 'cloudflared', 'localtunnel', or null.
 */
function getTunnelType() {
    return tunnelType;
}

module.exports = {
    openTunnel,
    closeTunnel,
    getTunnelUrl,
    getTunnelType
};
