/**
 * WOS Land Central Proxy Client
 *
 * Handles bot registration, heartbeats, and URL management with the
 * central proxy at wosland.com.  Config is persisted in the plugin database.
 */

const crypto = require('crypto');
const pluginDb = require('./pluginDb');
const { isOAuth2Configured } = require('./auth');

const CENTRAL_PROXY_URL = (process.env.CENTRAL_PROXY_URL || 'https://wosland.com').replace(/\/+$/, '');
const HEARTBEAT_INTERVAL_MS = 60 * 1000;
const BOT_NAME_REGEX = /^[a-z0-9][a-z0-9-]{1,28}[a-z0-9]$/;
const REQUEST_TIMEOUT_MS = 10_000;
const CONNECTION_MODE_WS = 'ws';
const CONNECTION_MODE_LEGACY = 'legacy';
const LEGACY_MODE_ENABLED = process.env.WEB_PANEL_ENABLE_LEGACY === '1';

let heartbeatTimer = null;

// ── Config persistence (via plugin database) ────────────────────────────────

const DB_PREFIX = 'wosland_';

function looksLikeLegacyApiKey(apiKey) {
    return typeof apiKey === 'string' && /^[a-f0-9]{64}$/i.test(apiKey);
}

function normalizeMode(mode) {
    return mode === CONNECTION_MODE_WS || mode === CONNECTION_MODE_LEGACY ? mode : null;
}

function hasStoredLegacyConfig() {
    const persistedMode = normalizeMode(pluginDb.get(`${DB_PREFIX}mode`));
    const apiKey = pluginDb.get(`${DB_PREFIX}api_key`);
    return persistedMode === CONNECTION_MODE_LEGACY || looksLikeLegacyApiKey(apiKey);
}

function isCentralHostedPublicUrl(publicUrl) {
    return typeof publicUrl === 'string' && publicUrl.startsWith(`${CENTRAL_PROXY_URL}/bots/`);
}

function shouldPreferWsMode(apiKey, publicUrl, persistedMode) {
    if (isOAuth2Configured()) {
        return false;
    }

    if (persistedMode === CONNECTION_MODE_WS) {
        return true;
    }

    if (persistedMode === CONNECTION_MODE_LEGACY) {
        return isCentralHostedPublicUrl(publicUrl);
    }

    if (isCentralHostedPublicUrl(publicUrl)) {
        return true;
    }

    return !looksLikeLegacyApiKey(apiKey);
}

function inferConnectionMode(apiKey, publicUrl) {
    const persistedMode = normalizeMode(pluginDb.get(`${DB_PREFIX}mode`));

    if (!LEGACY_MODE_ENABLED) {
        if (persistedMode === CONNECTION_MODE_LEGACY || looksLikeLegacyApiKey(apiKey)) {
            return null;
        }

        return apiKey ? CONNECTION_MODE_WS : null;
    }

    if (shouldPreferWsMode(apiKey, publicUrl, persistedMode)) {
        return CONNECTION_MODE_WS;
    }

    if (persistedMode) return persistedMode;

    if (looksLikeLegacyApiKey(apiKey)) {
        return CONNECTION_MODE_LEGACY;
    }

    // Older installs may predate explicit mode persistence. When the key does not
    // look like a legacy self-generated token, prefer WS so tunnel failures do not
    // incorrectly block the panel's primary connection path.
    return CONNECTION_MODE_WS;
}

function loadConfig() {
    const botName = pluginDb.get(`${DB_PREFIX}bot_name`);
    const apiKey = pluginDb.get(`${DB_PREFIX}api_key`);
    const publicUrl = pluginDb.get(`${DB_PREFIX}public_url`);
    const mode = inferConnectionMode(apiKey, publicUrl);
    if (!botName || !apiKey) return null;
    return { botName, apiKey, publicUrl, mode };
}

function saveConfig(data) {
    pluginDb.set(`${DB_PREFIX}bot_name`, data.botName);
    pluginDb.set(`${DB_PREFIX}api_key`, data.apiKey);
    if (data.publicUrl) pluginDb.set(`${DB_PREFIX}public_url`, data.publicUrl);
    const mode = normalizeMode(data.mode);
    if (mode) {
        pluginDb.set(`${DB_PREFIX}mode`, mode);
    }
}

function deleteConfig() {
    pluginDb.remove(`${DB_PREFIX}bot_name`);
    pluginDb.remove(`${DB_PREFIX}api_key`);
    pluginDb.remove(`${DB_PREFIX}public_url`);
    pluginDb.remove(`${DB_PREFIX}mode`);
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function generateApiKey() {
    return crypto.randomBytes(32).toString('hex');
}

function isValidBotName(name) {
    return typeof name === 'string' && BOT_NAME_REGEX.test(name);
}

/**
 * Make an authenticated request to the central proxy.
 * @param {string} endpoint - API path (e.g. '/api/register')
 * @param {'POST'|'DELETE'} method
 * @param {object} body
 * @param {string} apiKey
 * @returns {Promise<{status: number, data: object}>}
 */
async function proxyRequest(endpoint, method, body, apiKey) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    try {
        const response = await fetch(`${CENTRAL_PROXY_URL}${endpoint}`, {
            method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify(body),
            signal: controller.signal
        });

        const data = await response.json();
        return { status: response.status, data };
    } finally {
        clearTimeout(timeout);
    }
}

// ── WS Claim (no URL required) ────────────────────────────────────────────────────────────────

/**
 * Claim a panel name via the WebSocket path.
 * Unlike register(), no URL is needed — the bot connects outbound via WS.
 * Stores the returned botToken as the API key for subsequent WS authentication.
 *
 * @param {string} botName - The desired panel slug
 * @param {string} [displayName] - Human-friendly display name
 * @returns {Promise<{ok: boolean, panelUrl?: string, error?: string}>}
 */
async function claimName(botName, displayName) {
    if (!isValidBotName(botName)) {
        return { ok: false, error: 'Invalid name. Use 3-30 lowercase letters, numbers, and hyphens.' };
    }

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

        const response = await fetch(`${CENTRAL_PROXY_URL}/api/claim`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ botName, displayName: displayName || botName }),
            signal: controller.signal
        });
        clearTimeout(timeout);

        const data = await response.json();

        if (response.status === 201 && data.ok) {
            // Store botToken as the API key — used for WS authentication
            saveConfig({
                botName,
                apiKey: data.botToken,
                publicUrl: data.panelUrl,
                mode: CONNECTION_MODE_WS
            });
            console.log(`[WOS Land] Claimed "${botName}" → ${data.panelUrl}`);
            return { ok: true, panelUrl: data.panelUrl };
        }

        return { ok: false, error: data.error || `Claim failed (HTTP ${response.status})` };
    } catch (error) {
        const message = error.name === 'AbortError'
            ? 'Connection to wosland.com timed out'
            : error.message;
        return { ok: false, error: message };
    }
}

// ── WS Hub Upgrade ────────────────────────────────────────────────────────────────────────────

/**
 * Upgrade from HTTP proxy mode to WebSocket hub mode.
 * The existing API key proves ownership of the bot name.
 * On success, the central server rotates the key and clears the URL — the bot
 * then connects outbound via WebSocket using the new botToken.
 *
 * @returns {Promise<{ok: boolean, panelUrl?: string, error?: string}>}
 */
async function upgradeToWsHub() {
    const config = loadConfig();
    if (!config) return { ok: false, error: 'Not configured' };

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

        const response = await fetch(`${CENTRAL_PROXY_URL}/api/upgrade-to-ws`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ botName: config.botName, apiKey: config.apiKey }),
            signal: controller.signal
        });
        clearTimeout(timeout);

        const data = await response.json();

        if (response.ok && data.ok) {
            // Rotate to new botToken and persist — old HTTP proxy credentials are now invalid
            saveConfig({
                botName: config.botName,
                apiKey: data.botToken,
                publicUrl: data.panelUrl,
                mode: CONNECTION_MODE_WS
            });
            stopHeartbeat();
            console.log(`[WOS Land] Upgraded "${config.botName}" to WS hub mode → ${data.panelUrl}`);
            return { ok: true, panelUrl: data.panelUrl };
        }

        return { ok: false, error: data.error || `Upgrade failed (HTTP ${response.status})` };
    } catch (error) {
        const message = error.name === 'AbortError'
            ? 'Connection to wosland.com timed out'
            : error.message;
        return { ok: false, error: message };
    }
}

async function ensurePreferredConnectionMode() {
    const config = loadConfig();
    if (!config) {
        return { ok: false, action: 'unconfigured', error: 'Not configured' };
    }

    if (config.mode === CONNECTION_MODE_WS) {
        return { ok: true, action: 'ws', panelUrl: config.publicUrl || null };
    }

    if (!LEGACY_MODE_ENABLED && hasStoredLegacyConfig()) {
        console.log(`[WOS Land] Attempting automatic legacy-to-WS migration for "${config.botName}"...`);
        const result = await upgradeToWsHub();
        if (result.ok) {
            return { ok: true, action: 'migrated', panelUrl: result.panelUrl || null };
        }

        return {
            ok: false,
            action: 'migration_failed',
            error: result.error || 'Automatic migration failed'
        };
    }

    return {
        ok: true,
        action: config.mode || 'configured',
        panelUrl: config.publicUrl || null
    };
}

// ── Availability Check ───────────────────────────────────────────────────────────────
async function checkAvailability(botName) {
    if (!isValidBotName(botName)) {
        return { available: false, error: 'Invalid name format' };
    }

    // If this name is already ours, it's "available" to us
    const existing = loadConfig();
    if (existing?.botName === botName) {
        return { available: true };
    }

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

        const response = await fetch(`${CENTRAL_PROXY_URL}/api/check/${encodeURIComponent(botName)}`, {
            signal: controller.signal
        });
        clearTimeout(timeout);

        if (!response.ok) {
            return { available: false, error: `Server error (${response.status})` };
        }

        const data = await response.json();
        return { available: data.available };
    } catch (error) {
        console.error('[CentralProxy] checkAvailability failed:', error.message);
        return { available: false, error: 'Could not reach wosland.com' };
    }
}

// ── Registration ─────────────────────────────────────────────────────────────

/**
 * Register or re-register the bot with the central proxy.
 * On first call for a new name, generates an API key and persists it.
 * On subsequent calls (same name, existing key), updates the URL.
 *
 * @param {string} botName - Lowercase slug (3-30 chars, alphanumeric + dashes)
 * @param {string} botUrl  - Bot web panel URL (tunnel or http://ip:port)
 * @param {string} [displayName] - Human-friendly name
 * @returns {Promise<{ok: boolean, publicUrl?: string, error?: string}>}
 */
async function register(botName, botUrl, displayName) {
    if (!isValidBotName(botName)) {
        return { ok: false, error: 'Invalid name. Use 3-30 lowercase letters, numbers, and hyphens.' };
    }

    const existing = loadConfig();
    const isNewName = !existing || existing.botName !== botName;
    const apiKey = isNewName ? generateApiKey() : existing.apiKey;

    try {
        const { status, data } = await proxyRequest('/api/register', 'POST', {
            botName,
            url: botUrl,
            displayName: displayName || botName
        }, apiKey);

        if (status === 200 || status === 201) {
            saveConfig({
                botName,
                apiKey,
                publicUrl: data.publicUrl,
                mode: CONNECTION_MODE_LEGACY
            });
            console.log(`[WOS Land] Registered as ${botName} → ${data.publicUrl}`);
            return { ok: true, publicUrl: data.publicUrl };
        }

        return { ok: false, error: data.error || `Registration failed (HTTP ${status})` };
    } catch (error) {
        const message = error.name === 'AbortError'
            ? 'Connection to wosland.com timed out'
            : error.message;
        return { ok: false, error: message };
    }
}

/**
 * Re-register using stored config (called on bot restart to update URL).
 * @param {string} botUrl - Current bot web panel URL
 * @returns {Promise<{ok: boolean, error?: string}>}
 */
async function reRegister(botUrl) {
    const config = loadConfig();
    if (!config) return { ok: false, error: 'Not configured' };

    try {
        const { status, data } = await proxyRequest('/api/register', 'POST', {
            botName: config.botName,
            url: botUrl
        }, config.apiKey);

        if (status === 200 || status === 201) {
            saveConfig({ ...config, publicUrl: data.publicUrl, mode: CONNECTION_MODE_LEGACY });
            console.log(`[WOS Land] Re-registered ${config.botName} → ${data.publicUrl}`);
            return { ok: true };
        }

        console.error(`[WOS Land] Re-registration failed: ${data.error}`);
        return { ok: false, error: data.error };
    } catch (error) {
        console.error('[WOS Land] Re-registration failed:', error.message);
        return { ok: false, error: error.message };
    }
}

// ── Heartbeat ────────────────────────────────────────────────────────────────

async function sendHeartbeat() {
    const config = loadConfig();
    if (!config) return;

    try {
        await proxyRequest('/api/heartbeat', 'POST', {
            botName: config.botName
        }, config.apiKey);
    } catch (error) {
        console.error('[WOS Land] Heartbeat failed:', error.message);
    }
}

function startHeartbeat() {
    stopHeartbeat();
    sendHeartbeat();
    heartbeatTimer = setInterval(sendHeartbeat, HEARTBEAT_INTERVAL_MS);
}

function stopHeartbeat() {
    if (heartbeatTimer) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
    }
}

// ── Unregister ───────────────────────────────────────────────────────────────

async function unregister() {
    const config = loadConfig();
    if (!config) return;

    stopHeartbeat();

    try {
        await proxyRequest('/api/unregister', 'DELETE', {
            botName: config.botName
        }, config.apiKey);
    } catch {
        // Best effort — server will timeout the bot anyway
    }

    deleteConfig();
    console.log('[WOS Land] Unregistered');
}

// ── Accessors ────────────────────────────────────────────────────────────────

function getPublicUrl() {
    return loadConfig()?.publicUrl || null;
}

function getBotName() {
    return loadConfig()?.botName || null;
}

function isConfigured() {
    const config = loadConfig();
    return !!(config?.botName && config?.apiKey);
}

/** Returns the stored API key (used for WS authentication). */
function getApiKey() {
    return loadConfig()?.apiKey || null;
}

/**
 * Returns true if the bot has claimed a name and has a stored API key,
 * meaning it can authenticate a WebSocket connection to the central hub.
 */
function isWsConfigured() {
    return loadConfig()?.mode === CONNECTION_MODE_WS;
}

function isLegacyConfigured() {
    return loadConfig()?.mode === CONNECTION_MODE_LEGACY;
}

function isLegacyModeEnabled() {
    return LEGACY_MODE_ENABLED;
}

/**
 * Check if the WOS Land central proxy is reachable.
 * @returns {Promise<boolean>}
 */
async function isProxyHealthy() {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

        const response = await fetch(`${CENTRAL_PROXY_URL}/api/health`, {
            signal: controller.signal
        });
        clearTimeout(timeout);

        return response.ok;
    } catch {
        return false;
    }
}

module.exports = {
    register,
    reRegister,
    claimName,
    upgradeToWsHub,
    unregister,
    checkAvailability,
    isProxyHealthy,
    startHeartbeat,
    stopHeartbeat,
    getPublicUrl,
    getBotName,
    getApiKey,
    isConfigured,
    isWsConfigured,
    isLegacyConfigured,
    hasStoredLegacyConfig,
    isLegacyModeEnabled,
    ensurePreferredConnectionMode,
    isValidBotName,
    CENTRAL_PROXY_URL
};
