/**
 * WOS Land Central Proxy Client
 *
 * Handles bot registration, heartbeats, and URL management with the
 * central proxy at wosland.com.  Config is persisted in the plugin database.
 */

const crypto = require('crypto');
const pluginDb = require('./pluginDb');

const CENTRAL_PROXY_URL = (process.env.CENTRAL_PROXY_URL || 'https://wosland.com').replace(/\/+$/, '');
const HEARTBEAT_INTERVAL_MS = 60 * 1000;
const BOT_NAME_REGEX = /^[a-z0-9][a-z0-9-]{1,28}[a-z0-9]$/;
const REQUEST_TIMEOUT_MS = 10_000;

let heartbeatTimer = null;

// ── Config persistence (via plugin database) ────────────────────────────────

const DB_PREFIX = 'wosland_';

function loadConfig() {
    const botName = pluginDb.get(`${DB_PREFIX}bot_name`);
    const apiKey = pluginDb.get(`${DB_PREFIX}api_key`);
    const publicUrl = pluginDb.get(`${DB_PREFIX}public_url`);
    if (!botName || !apiKey) return null;
    return { botName, apiKey, publicUrl };
}

function saveConfig(data) {
    pluginDb.set(`${DB_PREFIX}bot_name`, data.botName);
    pluginDb.set(`${DB_PREFIX}api_key`, data.apiKey);
    if (data.publicUrl) pluginDb.set(`${DB_PREFIX}public_url`, data.publicUrl);
}

function deleteConfig() {
    pluginDb.remove(`${DB_PREFIX}bot_name`);
    pluginDb.remove(`${DB_PREFIX}api_key`);
    pluginDb.remove(`${DB_PREFIX}public_url`);
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function generateApiKey() {
    return crypto.randomBytes(32).toString('hex');
}

function isValidBotName(name) {
    return typeof name === 'string' && BOT_NAME_REGEX.test(name);
}

/**
 * Make an authenticated request to the central proxy.
 * @param {string} endpoint - API path (e.g. '/api/register')
 * @param {'POST'|'DELETE'} method
 * @param {object} body
 * @param {string} apiKey
 * @returns {Promise<{status: number, data: object}>}
 */
async function proxyRequest(endpoint, method, body, apiKey) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    try {
        const response = await fetch(`${CENTRAL_PROXY_URL}${endpoint}`, {
            method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify(body),
            signal: controller.signal
        });

        const data = await response.json();
        return { status: response.status, data };
    } finally {
        clearTimeout(timeout);
    }
}

// ── Availability Check ───────────────────────────────────────────────────────

/**
 * Check if a bot name is available on the central proxy.
 * @param {string} botName
 * @returns {Promise<{available: boolean, error?: string}>}
 */
async function checkAvailability(botName) {
    if (!isValidBotName(botName)) {
        return { available: false, error: 'Invalid name format' };
    }

    // If this name is already ours, it's "available" to us
    const existing = loadConfig();
    if (existing?.botName === botName) {
        return { available: true };
    }

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

        const response = await fetch(`${CENTRAL_PROXY_URL}/api/check/${encodeURIComponent(botName)}`, {
            signal: controller.signal
        });
        clearTimeout(timeout);

        if (!response.ok) {
            return { available: false, error: `Server error (${response.status})` };
        }

        const data = await response.json();
        return { available: data.available };
    } catch (error) {
        console.error('[CentralProxy] checkAvailability failed:', error.message);
        return { available: false, error: 'Could not reach wosland.com' };
    }
}

// ── Registration ─────────────────────────────────────────────────────────────

/**
 * Register or re-register the bot with the central proxy.
 * On first call for a new name, generates an API key and persists it.
 * On subsequent calls (same name, existing key), updates the URL.
 *
 * @param {string} botName - Lowercase slug (3-30 chars, alphanumeric + dashes)
 * @param {string} botUrl  - Bot web panel URL (tunnel or http://ip:port)
 * @param {string} [displayName] - Human-friendly name
 * @returns {Promise<{ok: boolean, publicUrl?: string, error?: string}>}
 */
async function register(botName, botUrl, displayName) {
    if (!isValidBotName(botName)) {
        return { ok: false, error: 'Invalid name. Use 3-30 lowercase letters, numbers, and hyphens.' };
    }

    const existing = loadConfig();
    const isNewName = !existing || existing.botName !== botName;
    const apiKey = isNewName ? generateApiKey() : existing.apiKey;

    try {
        const { status, data } = await proxyRequest('/api/register', 'POST', {
            botName,
            url: botUrl,
            displayName: displayName || botName
        }, apiKey);

        if (status === 200 || status === 201) {
            saveConfig({ botName, apiKey, publicUrl: data.publicUrl });
            console.log(`[WOS Land] Registered as ${botName} → ${data.publicUrl}`);
            return { ok: true, publicUrl: data.publicUrl };
        }

        return { ok: false, error: data.error || `Registration failed (HTTP ${status})` };
    } catch (error) {
        const message = error.name === 'AbortError'
            ? 'Connection to wosland.com timed out'
            : error.message;
        return { ok: false, error: message };
    }
}

/**
 * Re-register using stored config (called on bot restart to update URL).
 * @param {string} botUrl - Current bot web panel URL
 * @returns {Promise<{ok: boolean, error?: string}>}
 */
async function reRegister(botUrl) {
    const config = loadConfig();
    if (!config) return { ok: false, error: 'Not configured' };

    try {
        const { status, data } = await proxyRequest('/api/register', 'POST', {
            botName: config.botName,
            url: botUrl
        }, config.apiKey);

        if (status === 200 || status === 201) {
            saveConfig({ ...config, publicUrl: data.publicUrl });
            console.log(`[WOS Land] Re-registered ${config.botName} → ${data.publicUrl}`);
            return { ok: true };
        }

        console.error(`[WOS Land] Re-registration failed: ${data.error}`);
        return { ok: false, error: data.error };
    } catch (error) {
        console.error('[WOS Land] Re-registration failed:', error.message);
        return { ok: false, error: error.message };
    }
}

// ── Heartbeat ────────────────────────────────────────────────────────────────

async function sendHeartbeat() {
    const config = loadConfig();
    if (!config) return;

    try {
        await proxyRequest('/api/heartbeat', 'POST', {
            botName: config.botName
        }, config.apiKey);
    } catch (error) {
        console.error('[WOS Land] Heartbeat failed:', error.message);
    }
}

function startHeartbeat() {
    stopHeartbeat();
    sendHeartbeat();
    heartbeatTimer = setInterval(sendHeartbeat, HEARTBEAT_INTERVAL_MS);
}

function stopHeartbeat() {
    if (heartbeatTimer) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
    }
}

// ── Unregister ───────────────────────────────────────────────────────────────

async function unregister() {
    const config = loadConfig();
    if (!config) return;

    stopHeartbeat();

    try {
        await proxyRequest('/api/unregister', 'DELETE', {
            botName: config.botName
        }, config.apiKey);
    } catch {
        // Best effort — server will timeout the bot anyway
    }

    deleteConfig();
    console.log('[WOS Land] Unregistered');
}

// ── Accessors ────────────────────────────────────────────────────────────────

function getPublicUrl() {
    return loadConfig()?.publicUrl || null;
}

function getBotName() {
    return loadConfig()?.botName || null;
}

function isConfigured() {
    const config = loadConfig();
    return !!(config?.botName && config?.apiKey);
}

/**
 * Check if the WOS Land central proxy is reachable.
 * @returns {Promise<boolean>}
 */
async function isProxyHealthy() {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

        const response = await fetch(`${CENTRAL_PROXY_URL}/api/health`, {
            signal: controller.signal
        });
        clearTimeout(timeout);

        return response.ok;
    } catch {
        return false;
    }
}

module.exports = {
    register,
    reRegister,
    unregister,
    checkAvailability,
    isProxyHealthy,
    startHeartbeat,
    stopHeartbeat,
    getPublicUrl,
    getBotName,
    isConfigured,
    isValidBotName,
    CENTRAL_PROXY_URL
};
