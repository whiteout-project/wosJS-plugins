const { SlashCommandBuilder, MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { generateLoginToken, isOAuth2Configured } = require('../auth');
const { getRunningPort, getPublicAddress, getTunnelUrl, getBasePath } = require('../server');
const { adminQueries, userQueries } = require('../../../src/functions/utility/database');
const centralProxy = require('../centralProxy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('webpanel')
        .setDescription('Get a login link for the web admin panel'),

    async execute(interaction) {
        const adminData = adminQueries.getAdmin(interaction.user.id);
        if (!adminData) {
            const userData = userQueries.getUser(interaction.user.id);
            if (!userData) {
                return interaction.reply({
                    content: 'You need to register first. Please use `/panel` to get started.',
                    flags: MessageFlags.Ephemeral
                });
            }
        }

        const port = getRunningPort();
        if (!port) {
            return interaction.reply({
                content: 'The web panel server is not currently running.',
                flags: MessageFlags.Ephemeral
            });
        }

        const isSetUp = centralProxy.isConfigured() && isOAuth2Configured();

        // ── Fully configured → show permanent base URL ─────────────────
        if (isSetUp) {
            const publicUrl = centralProxy.getPublicUrl();

            return interaction.reply({
                content: `**Web Panel**\nOpen the dashboard:\n${publicUrl}\n\n-# You'll be redirected to log in with Discord if needed.`,
                flags: MessageFlags.Ephemeral
            });
        }

        // ── Not configured — build a fallback token link ─────────────────
        const tunnelUrl = getTunnelUrl();
        const basePath = getBasePath();
        const baseUrl = tunnelUrl || `http://${getPublicAddress() || 'localhost'}:${port}`;
        const token = generateLoginToken(interaction.user.id);
        const tokenLink = `${baseUrl}${basePath}/auth/login?token=${token}`;

        // ── Non-owner / non-admin → token link only ──────────────────────
        if (!adminData || !adminData.is_owner) {
            return interaction.reply({
                content: `**Web Panel Login**\nClick the link below (expires in 5 minutes):\n${tokenLink}\n\n-# Ask the bot owner to run \`/webpanel\` to set up a permanent URL.`,
                flags: MessageFlags.Ephemeral
            });
        }

        // ── Owner → setup wizard + token fallback ────────────────────────
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`wp_setup_start_${interaction.user.id}`)
                .setLabel('Set Up Web Panel')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('🌐')
        );

        await interaction.reply({
            content: `# Welcome to the Web Panel!\nSet up a **permanent URL** with Discord login so you and your users can access the panel anytime. Click the button below to get started.\n-# Or use this temporary link (expires in 5 min): [link](${tokenLink})`,
            components: [row],
            flags: MessageFlags.Ephemeral
        });
    }
};
