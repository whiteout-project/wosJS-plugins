const { getEffectivePlayerState } = require('../../src/functions/Players/playerDisplay');
const { SyncError } = require('./profile');

/** Namespaced persistence on the core connection; callers own profile/checkpoint transactions. */
function createStore(db, now = Date.now) {
    db.exec(`
        CREATE TABLE IF NOT EXISTS plugin_player_sync_config (
            game_type TEXT PRIMARY KEY, profile TEXT, secret TEXT NOT NULL DEFAULT '', revision INTEGER NOT NULL DEFAULT 0,
            tested_revision INTEGER, enabled INTEGER NOT NULL DEFAULT 0, last_error TEXT
        );
        CREATE TABLE IF NOT EXISTS plugin_player_sync_quota (
            bucket TEXT PRIMARY KEY, day TEXT NOT NULL, used INTEGER NOT NULL, minute INTEGER NOT NULL,
            minute_used INTEGER NOT NULL, next_at INTEGER NOT NULL DEFAULT 0, blocked_until INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS plugin_player_sync_schedule (
            game_type TEXT NOT NULL, alliance_id INTEGER NOT NULL REFERENCES alliance(id) ON DELETE CASCADE,
            enabled INTEGER NOT NULL DEFAULT 0, hours INTEGER NOT NULL DEFAULT 24, next_at INTEGER NOT NULL DEFAULT 0, created_by TEXT,
            PRIMARY KEY (game_type, alliance_id)
        );
        CREATE TABLE IF NOT EXISTS plugin_player_sync_import (
            token TEXT PRIMARY KEY, user_id TEXT NOT NULL, game_type TEXT NOT NULL, revision INTEGER NOT NULL,
            expires_at INTEGER NOT NULL, snapshot TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS plugin_player_sync_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT, game_type TEXT NOT NULL, alliance_id INTEGER NOT NULL,
            fid TEXT NOT NULL, nickname TEXT, changes TEXT NOT NULL, created_at TEXT NOT NULL,
            sent_at TEXT, message_id TEXT, run_id TEXT NOT NULL,
            UNIQUE (game_type, fid, run_id)
        );
        CREATE TABLE IF NOT EXISTS plugin_player_sync_runs (
            process_id INTEGER PRIMARY KEY, game_type TEXT NOT NULL, alliance_id INTEGER NOT NULL,
            created_by TEXT NOT NULL, scheduled INTEGER NOT NULL DEFAULT 0, revision INTEGER NOT NULL,
            result TEXT, updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS plugin_player_sync_deferred (
            game_type TEXT NOT NULL, fid TEXT NOT NULL, reason TEXT NOT NULL, updated_at INTEGER NOT NULL,
            PRIMARY KEY (game_type, fid)
        );
        CREATE TABLE IF NOT EXISTS plugin_player_sync_catchup (
            game_type TEXT NOT NULL, fid TEXT NOT NULL, PRIMARY KEY (game_type,fid)
        );
    `);
    if (!db.pragma('table_info(plugin_player_sync_schedule)').some(column => column.name === 'created_by')) {
        db.exec('ALTER TABLE plugin_player_sync_schedule ADD COLUMN created_by TEXT');
    }

    function config(game) {
        const row = db.prepare('SELECT * FROM plugin_player_sync_config WHERE game_type = ?').get(game);
        if (!row)
            return {
                game_type: game,
                profile: null,
                secret: '',
                revision: 0,
                enabled: false,
                tested_revision: null,
                last_error: null
            };
        try {
            return { ...row, profile: row.profile ? JSON.parse(row.profile) : null, enabled: !!row.enabled };
        } catch {
            throw new SyncError(
                'storage',
                'The saved Player Sync setup could not be read. Restore it from a private backup.'
            );
        }
    }

    function changeConfig(game, patch) {
        const old = config(game);
        const next = { ...old, ...patch };
        db.prepare(
            `INSERT INTO plugin_player_sync_config (game_type,profile,secret,revision,tested_revision,enabled,last_error)
            VALUES (?,?,?,?,?,?,?) ON CONFLICT(game_type) DO UPDATE SET profile=excluded.profile, secret=excluded.secret,
            revision=excluded.revision, tested_revision=excluded.tested_revision, enabled=excluded.enabled,last_error=excluded.last_error`
        ).run(
            game,
            next.profile ? JSON.stringify(next.profile) : null,
            next.secret,
            next.revision,
            next.tested_revision ?? null,
            next.enabled ? 1 : 0,
            next.last_error ?? null
        );
        return next;
    }

    function quota(bucket) {
        return db.prepare('SELECT * FROM plugin_player_sync_quota WHERE bucket=?').get(bucket);
    }
    const migrateQuota = db.transaction((bucket, legacyBucket) => {
        if (bucket === legacyBucket) return;
        const old = quota(legacyBucket);
        if (!old) return;
        const current = quota(bucket);
        const day = new Date(now()).toISOString().slice(0, 10);
        const minute = Math.floor(now() / 60000);
        const rows = [old, current].filter(Boolean);
        db.prepare(
            `INSERT OR REPLACE INTO plugin_player_sync_quota (bucket,day,used,minute,minute_used,next_at,blocked_until)
            VALUES (?,?,?,?,?,?,?)`
        ).run(
            bucket,
            day,
            rows.reduce((sum, row) => sum + (row.day === day ? row.used : 0), 0),
            minute,
            rows.reduce((sum, row) => sum + (row.minute === minute ? row.minute_used : 0), 0),
            Math.max(...rows.map(row => row.next_at)),
            Math.max(...rows.map(row => row.blocked_until))
        );
        db.prepare('DELETE FROM plugin_player_sync_quota WHERE bucket=?').run(legacyBucket);
    });
    const reserve = db.transaction((bucket, minuteLimit, dayLimit) => {
        const at = now();
        const day = new Date(at).toISOString().slice(0, 10);
        const minute = Math.floor(at / 60000);
        const previous = quota(bucket);
        const row = previous || { day, used: 0, minute, minute_used: 0, next_at: 0, blocked_until: 0 };
        if (row.day !== day) {
            row.day = day;
            row.used = 0;
        }
        if (row.minute !== minute) {
            row.minute = minute;
            row.minute_used = 0;
        }
        let retryAt = Math.max(row.next_at, row.blocked_until);
        if (row.used >= dayLimit) retryAt = Math.max(retryAt, Date.parse(day + 'T00:00:00Z') + 86400000);
        if (row.minute_used >= minuteLimit) retryAt = Math.max(retryAt, (minute + 1) * 60000);
        if (retryAt > at) return retryAt;
        db.prepare(
            `INSERT INTO plugin_player_sync_quota (bucket,day,used,minute,minute_used,next_at,blocked_until)
            VALUES (?,?,?,?,?,?,?) ON CONFLICT(bucket) DO UPDATE SET day=excluded.day,used=excluded.used,
            minute=excluded.minute,minute_used=excluded.minute_used,next_at=excluded.next_at,blocked_until=excluded.blocked_until`
        ).run(
            bucket,
            day,
            row.used + 1,
            minute,
            row.minute_used + 1,
            Math.ceil(at + 60000 / minuteLimit),
            row.blocked_until
        );
        return null;
    });
    function blockQuota(bucket, until) {
        db.prepare('UPDATE plugin_player_sync_quota SET blocked_until=MAX(blocked_until,?) WHERE bucket=?').run(
            until,
            bucket
        );
    }

    function player(fid, game) {
        return db.prepare('SELECT * FROM players WHERE game_type=? AND fid=?').get(game, fid);
    }

    function apply(profile, game, allianceId, runId, notify = true) {
        const before = player(profile.fid, game);
        const alliance = db.prepare('SELECT * FROM alliance WHERE id=? AND game_type=?').get(allianceId, game);
        if (!before || !alliance || before.alliance_id !== Number(allianceId))
            return { changed: [], stateChanged: false };
        const changed = [];
        const at = new Date(now()).toISOString();
        const values = {};
        for (const key of ['nickname', 'furnace_level', 'state', 'image_url', 'power']) {
            if (profile[key] === undefined || before[key] === profile[key]) continue;
            values[key] = profile[key];
            if (key !== 'image_url' && key !== 'state')
                changed.push({ field: key, old: before[key] ?? null, value: profile[key] });
        }
        const effectiveBefore = getEffectivePlayerState(before, alliance.state);
        if (profile.state !== undefined)
            values.state_override = Number(alliance.state) === profile.state ? null : profile.state;
        const effectiveAfter = getEffectivePlayerState({ ...before, ...values }, alliance.state);
        const stateChanged = effectiveAfter !== effectiveBefore;
        if (stateChanged) {
            values.state_search_blocked_for = null;
            db.prepare('INSERT OR IGNORE INTO plugin_player_sync_catchup (game_type,fid) VALUES (?,?)').run(
                game,
                profile.fid
            );
            changed.push({ field: 'state', old: effectiveBefore, value: effectiveAfter });
        }
        values.profile_synced_at = at;
        // The caller wraps profile, history, outbox and process checkpoint in one transaction.
        db.prepare(
            `UPDATE players SET ${Object.keys(values)
                .map(key => `${key}=?`)
                .join(',')}
            WHERE game_type=? AND fid=? AND alliance_id=?`
        ).run(...Object.values(values), game, profile.fid, allianceId);
        for (const change of changed) {
            if (change.field === 'nickname')
                db.prepare(
                    `INSERT INTO nickname_changes (game_type,fid,old_nickname,new_nickname,change_date) VALUES (?,?,?,?,?)`
                ).run(game, profile.fid, change.old, change.value, at);
            if (change.field === 'furnace_level')
                db.prepare(
                    `INSERT INTO furnace_changes (game_type,fid,old_furnace_lv,new_furnace_lv,change_date) VALUES (?,?,?,?,?)`
                ).run(game, profile.fid, change.old, change.value, at);
        }
        if (notify && changed.length)
            db.prepare(
                `INSERT OR IGNORE INTO plugin_player_sync_reports
            (game_type,alliance_id,fid,nickname,changes,created_at,run_id) VALUES (?,?,?,?,?,?,?)`
            ).run(
                game,
                allianceId,
                profile.fid,
                profile.nickname || before.nickname || null,
                JSON.stringify(changed),
                at,
                String(runId)
            );
        db.prepare('DELETE FROM plugin_player_sync_deferred WHERE game_type=? AND fid=?').run(game, profile.fid);
        return { changed, stateChanged };
    }

    function deferred(fid, game, reason) {
        db.prepare(
            `INSERT INTO plugin_player_sync_deferred (game_type,fid,reason,updated_at) VALUES (?,?,?,?)
            ON CONFLICT(game_type,fid) DO UPDATE SET reason=excluded.reason,updated_at=excluded.updated_at`
        ).run(game, fid, reason, now());
    }
    return { config, changeConfig, quota, migrateQuota, reserve, blockQuota, player, apply, deferred };
}
module.exports = { createStore };
