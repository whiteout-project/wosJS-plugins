const { start } = require('../runtime');

module.exports = function (client) {
    return start(client);
};
