const { SyncError, extract, whole, playerId, readPlayer } = require('./profile');
const { randomBytes } = require('node:crypto');

/** Roster reconciliation shares the provider transport, permissions and process queue with profile sync. */
function createMemberSync({
    db,
    core,
    store,
    authorize,
    connection,
    lookupPlayer,
    fetchPayload,
    unchanged,
    now,
    enqueue
}) {
    const get = (game, allianceId) =>
        db
            .prepare('SELECT * FROM plugin_player_sync_members WHERE game_type=? AND alliance_id=?')
            .get(game, allianceId);
    function stopPending(game, allianceId) {
        for (const row of db
            .prepare(
                `SELECT p.id,p.progress FROM processes p JOIN plugin_player_sync_runs r ON r.process_id=p.id
            WHERE r.kind='members' AND r.game_type=? AND r.alliance_id=? AND p.status IN ('active','queued')`
            )
            .all(game, allianceId)) {
            const progress = JSON.parse(row.progress);
            progress.pending = [];
            progress.playerSync = { reason: 'stopped', retryAt: null };
            db.prepare("UPDATE processes SET status='completed',progress=? WHERE id=?").run(
                JSON.stringify(progress),
                row.id
            );
            db.prepare(
                "UPDATE plugin_player_sync_runs SET result='stopped',updated_at=? WHERE process_id=?"
            ).run(now(), row.id);
        }
    }
    function settings(game, allianceId) {
        const row = get(game, allianceId);
        return {
            enabled: !!row?.enabled,
            hours: row?.hours || 24,
            deleteNonMembers: !!row?.delete_missing,
            source: row?.source ? JSON.parse(row.source) : null,
            nextAt: row?.next_at || null,
            result: row?.result || null
        };
    }
    function check(context, allianceId, revision) {
        const auth = authorize(context, false, allianceId);
        const row = get(auth.game, allianceId);
        if (!row?.enabled || row.revision !== revision)
            throw new SyncError('changed', 'Member sync settings changed.');
        if (
            row.delete_missing &&
            !core.hasPermission(auth.admin, core.permissions.PLAYER_MANAGEMENT, core.permissions.FULL_ACCESS)
        )
            throw new SyncError(
                'permission',
                'Player management permission is required to remove non-members.'
            );
        return row;
    }
    const fingerprint = (game, allianceId) =>
        JSON.stringify(
            db
                .prepare('SELECT id,name,state,channel_id FROM alliance WHERE game_type=? AND id=?')
                .get(game, allianceId)
        );
    async function setSchedule(context, allianceId, options, approval = null) {
        const { game, admin } = authorize(context, false, allianceId);
        if (
            typeof options.enabled !== 'boolean' ||
            typeof options.deleteNonMembers !== 'boolean' ||
            !Number.isInteger(options.hours) ||
            options.hours < 1 ||
            options.hours > 720
        )
            throw new SyncError('invalid', 'Choose on/off settings and an interval from 1 to 720 hours.');
        if (
            options.deleteNonMembers &&
            !core.hasPermission(admin, core.permissions.PLAYER_MANAGEMENT, core.permissions.FULL_ACCESS)
        )
            throw new SyncError(
                'permission',
                'Player management permission is required to remove non-members.'
            );
        const old = get(game, allianceId);
        let sourceSeed = approval?.seed || null;
        let source = approval?.source || (old?.source ? JSON.parse(old.source) : null);
        const destination = fingerprint(game, allianceId);
        if (options.enabled) {
            const config = connection(game);
            const mapping = config.profile.alliance;
            if (!mapping) throw new SyncError('mapping', 'Configure the alliance roster endpoint first.');
            if (!source) {
                const seed = db
                    .prepare(
                        'SELECT fid FROM players WHERE game_type=? AND alliance_id=? AND exist<3 ORDER BY fid LIMIT 1'
                    )
                    .get(game, allianceId);
                if (!seed)
                    throw new SyncError(
                        'invalid',
                        'Add a member of the in-game alliance before enabling member sync.'
                    );
                sourceSeed = String(seed.fid);
                const answer = await lookupPlayer({
                    gameType: game,
                    fid: seed.fid,
                    checkAccess: () => authorize(context, false, allianceId)
                });
                const state = whole(extract(answer.payload, mapping.state_field), 1);
                const tag = extract(answer.payload, mapping.tag_field);
                if (
                    !state ||
                    typeof tag !== 'string' ||
                    !tag.trim() ||
                    tag.length > 30 ||
                    /[\x00-\x1f]/.test(tag)
                )
                    throw new SyncError(
                        'mapping',
                        'The existing member has no usable alliance tag and state.'
                    );
                source = { state, tag };
                const observedAllianceId = whole(answer.payload?.player?.alliance?.aid, 1);
                if (observedAllianceId) source.aid = observedAllianceId;
            }
            unchanged(game, config.revision, null, config.epoch);
            if (
                approval &&
                (approval.revision !== config.revision ||
                    approval.memberRevision !== (old?.revision || 0) ||
                    approval.destination !== destination)
            )
                throw new SyncError(
                    'expired',
                    'The source or settings changed. Open member sync settings again.'
                );
            if (!old?.source && !approval) {
                authorize(context, false, allianceId);
                if (
                    store.player(sourceSeed, game)?.alliance_id !== Number(allianceId) ||
                    destination !== fingerprint(game, allianceId)
                )
                    throw new SyncError('changed', 'The source member or destination changed. Try again.');
                db.prepare('DELETE FROM plugin_player_sync_member_confirm WHERE expires_at<=?').run(now());
                if (
                    db
                        .prepare('SELECT COUNT(*) n FROM plugin_player_sync_member_confirm WHERE user_id=?')
                        .get(String(context.userId)).n >= 3
                )
                    throw new SyncError('busy', 'Cancel an earlier member sync confirmation first.');
                const token = randomBytes(24).toString('hex');
                const snapshot = {
                    allianceId: Number(allianceId),
                    source,
                    seed: sourceSeed,
                    options: { enabled: options.enabled, hours: options.hours, deleteNonMembers: options.deleteNonMembers },
                    revision: config.revision,
                    memberRevision: old?.revision || 0,
                    destination
                };
                db.prepare('INSERT INTO plugin_player_sync_member_confirm VALUES (?,?,?,?,?)').run(
                    token,
                    String(context.userId),
                    game,
                    now() + 300000,
                    JSON.stringify(snapshot)
                );
                return {
                    memberPreview: {
                        token,
                        source,
                        seed: sourceSeed,
                        allianceName: JSON.parse(destination).name,
                        hours: options.hours,
                        deleteNonMembers: options.deleteNonMembers
                    }
                };
            }
        }
        const current = authorize(context, false, allianceId);
        if (sourceSeed && store.player(sourceSeed, game)?.alliance_id !== Number(allianceId))
            throw new SyncError('changed', 'The source member left this bot alliance. Try again.');
        if (
            options.deleteNonMembers &&
            !core.hasPermission(
                current.admin,
                core.permissions.PLAYER_MANAGEMENT,
                core.permissions.FULL_ACCESS
            )
        )
            throw new SyncError(
                'permission',
                'Player management permission is required to remove non-members.'
            );
        // A late API response must not overwrite a newer settings submission.
        if ((get(game, allianceId)?.revision ?? 0) !== (old?.revision ?? 0))
            throw new SyncError('changed', 'Member sync settings changed.');
        if (
            !approval &&
            old &&
            old.enabled === +options.enabled &&
            old.hours === options.hours &&
            old.delete_missing === +options.deleteNonMembers &&
            old.created_by === String(context.userId)
        )
            return {};
        db.transaction(() => {
            if (approval) {
                const consumed = db
                    .prepare(
                        'DELETE FROM plugin_player_sync_member_confirm WHERE token=? AND user_id=? AND game_type=? AND expires_at>?'
                    )
                    .run(approval.token, String(context.userId), game, now());
                if (!consumed.changes)
                    throw new SyncError('expired', 'This confirmation expired or was already used.');
            }
            db.prepare(
                "DELETE FROM plugin_player_sync_member_confirm WHERE game_type=? AND json_extract(snapshot,'$.allianceId')=?"
            ).run(game, allianceId);
            stopPending(game, allianceId);
            db.prepare(
                `INSERT INTO plugin_player_sync_members (game_type,alliance_id,enabled,hours,delete_missing,source,revision,next_at,created_by)
            VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(game_type,alliance_id) DO UPDATE SET enabled=excluded.enabled,hours=excluded.hours,
            delete_missing=excluded.delete_missing,source=excluded.source,revision=excluded.revision,next_at=excluded.next_at,created_by=excluded.created_by,result=NULL`
            ).run(
                game,
                allianceId,
                +options.enabled,
                options.hours,
                +options.deleteNonMembers,
                source ? JSON.stringify(source) : null,
                (old?.revision || 0) + 1,
                now(),
                String(context.userId)
            );
        })();
        return {};
    }
    async function confirm(context, token) {
        const { game } = authorize(context);
        if (typeof token !== 'string' || !/^[a-f0-9]{48}$/.test(token))
            throw new SyncError('expired', 'Choose a current member sync confirmation.');
        const row = db
            .prepare(
                'SELECT * FROM plugin_player_sync_member_confirm WHERE token=? AND user_id=? AND game_type=? AND expires_at>?'
            )
            .get(token, String(context.userId), game, now());
        if (!row) throw new SyncError('expired', 'This confirmation expired or was already used.');
        const snapshot = JSON.parse(row.snapshot);
        await setSchedule(context, snapshot.allianceId, snapshot.options, { ...snapshot, token });
    }
    function cancel(context, token) {
        const { game } = authorize(context);
        if (typeof token !== 'string' || !/^[a-f0-9]{48}$/.test(token))
            throw new SyncError('expired', 'Choose a current member sync confirmation.');
        db.prepare(
            'DELETE FROM plugin_player_sync_member_confirm WHERE token=? AND user_id=? AND game_type=?'
        ).run(token, String(context.userId), game);
        return { cancelled: true };
    }
    async function tick() {
        db.prepare('DELETE FROM plugin_player_sync_member_confirm WHERE expires_at<=?').run(now());
        // Release obsolete jobs even when the next scheduled scan is still hours away.
        for (const run of db
            .prepare(
                `SELECT r.* FROM plugin_player_sync_runs r JOIN processes p ON p.id=r.process_id
            WHERE r.kind='members' AND p.status IN ('queued','active')`
            )
            .all()) {
            try {
                check(
                    { gameType: run.game_type, userId: run.created_by },
                    run.alliance_id,
                    run.member_revision
                );
                if (run.revision !== store.config(run.game_type).revision)
                    stopPending(run.game_type, run.alliance_id);
            } catch (error) {
                if (['unavailable', 'game'].includes(error.code)) continue;
                if (!['permission', 'changed'].includes(error.code)) throw error;
                stopPending(run.game_type, run.alliance_id);
                if (error.code === 'permission')
                    db.prepare(
                        'UPDATE plugin_player_sync_members SET enabled=0,revision=revision+1,result=? WHERE game_type=? AND alliance_id=?'
                    ).run('permission', run.game_type, run.alliance_id);
            }
        }
        for (const row of db
            .prepare(
                'SELECT * FROM plugin_player_sync_members WHERE enabled=1 AND next_at<=? ORDER BY next_at'
            )
            .all(now())) {
            const context = { gameType: row.game_type, userId: row.created_by };
            try {
                check(context, row.alliance_id, row.revision);
            } catch (error) {
                if (error.code === 'permission')
                    db.transaction(() => {
                        stopPending(row.game_type, row.alliance_id);
                        db.prepare(
                            'UPDATE plugin_player_sync_members SET enabled=0,revision=revision+1,result=? WHERE game_type=? AND alliance_id=?'
                        ).run('permission', row.game_type, row.alliance_id);
                    })();
                continue;
            }
            try {
                connection(row.game_type);
            } catch {
                continue;
            }
            const alliance = db
                .prepare('SELECT * FROM alliance WHERE game_type=? AND id=?')
                .get(row.game_type, row.alliance_id);
            const id = await enqueue(row.game_type, alliance, row.created_by, true, row.revision);
            if (id)
                db.prepare(
                    'UPDATE plugin_player_sync_members SET next_at=? WHERE game_type=? AND alliance_id=? AND revision=?'
                ).run(now() + row.hours * 3600000, row.game_type, row.alliance_id, row.revision);
        }
    }
    async function execute(run, processId) {
        const context = { gameType: run.game_type, userId: run.created_by };
        const row = check(context, run.alliance_id, run.member_revision);
        const config = connection(run.game_type);
        const mapping = config.profile.alliance;
        if (!mapping || !row.source) throw new SyncError('mapping', 'Configure an alliance source first.');
        const source = JSON.parse(row.source);
        const alliance = db
            .prepare('SELECT * FROM alliance WHERE game_type=? AND id=?')
            .get(run.game_type, run.alliance_id);
        const before = db
            .prepare('SELECT fid FROM players WHERE game_type=? AND alliance_id=?')
            .all(run.game_type, run.alliance_id)
            .map(p => String(p.fid));
        const response = await fetchPayload(run.game_type, mapping.path, source, {
            processId,
            checkAccess: () => check(context, run.alliance_id, run.member_revision)
        });
        unchanged(run.game_type, config.revision, null, config.epoch);
        check(context, run.alliance_id, run.member_revision);
        if ((await core.preemption(processId)).shouldStop) return;
        const raw = extract(response.payload, mapping.members_path);
        if (response.payload?.ok === false || !Array.isArray(raw) || !raw.length || raw.length > 2000)
            throw new SyncError('mapping', 'The provider did not return a usable alliance roster.');
        const info = response.payload?.alliance;
        if (
            (info?.kid != null && whole(info.kid, 1) !== source.state) ||
            (info?.abbr != null && info.abbr !== source.tag) ||
            (source.aid && info?.aid != null && whole(info.aid, 1) !== source.aid)
        )
            throw new SyncError('mapping', 'The provider returned a different alliance.');
        const profiles = new Map();
        let invalid = 0;
        for (const entry of raw) {
            try {
                const fid = playerId(extract(entry, mapping.fields.id));
                if (profiles.has(fid)) {
                    invalid++;
                    continue;
                }
                profiles.set(fid, readPlayer(entry, mapping.fields, fid));
            } catch {
                invalid++;
            }
        }
        if (!profiles.size) throw new SyncError('mapping', 'The roster has no usable public IDs.');
        // A count match is required for deletion; partial, invalid or paginated rosters only add members.
        const count = whole(extract(response.payload, mapping.count_field || 'alliance.count'), 1);
        const pagination = response.payload?.pagination;
        const identityMatches =
            whole(info?.kid, 1) === source.state &&
            info?.abbr === source.tag &&
            (!source.aid || whole(info?.aid, 1) === source.aid);
        const complete =
            !invalid &&
            identityMatches &&
            count === raw.length &&
            (response.payload?.fresh === true || response.payload?.fresh?.roster === true) &&
            !response.payload?.partial &&
            !response.payload?.truncated &&
            !response.payload?.next &&
            !response.payload?.next_cursor &&
            !response.payload?.next_page &&
            !response.payload?.has_more &&
            !pagination?.has_more &&
            !pagination?.next &&
            !pagination?.next_cursor &&
            !pagination?.next_page &&
            !(pagination?.total_pages > 1);
        const result = db.transaction(() => {
            check(context, run.alliance_id, run.member_revision);
            unchanged(run.game_type, config.revision, null, config.epoch);
            const process = db.prepare('SELECT status,progress FROM processes WHERE id=?').get(processId);
            if (process?.status !== 'active') throw new SyncError('paused', 'Member sync paused.');
            const currentAlliance = db
                .prepare('SELECT * FROM alliance WHERE game_type=? AND id=?')
                .get(run.game_type, run.alliance_id);
            if (!currentAlliance || currentAlliance.state !== alliance.state)
                throw new SyncError('changed', 'The destination alliance changed.');
            let added = 0,
                removed = 0,
                conflicts = 0;
            for (const profile of profiles.values()) {
                const existing = store.player(profile.fid, run.game_type);
                if (existing) {
                    if (existing.alliance_id !== run.alliance_id) conflicts++;
                    continue;
                }
                core.addPlayer(
                    profile.fid,
                    currentAlliance.state,
                    run.alliance_id,
                    String(run.created_by),
                    run.game_type
                );
                store.apply(profile, run.game_type, run.alliance_id, `members:${processId}`, false);
                added++;
            }
            if (row.delete_missing && complete)
                for (const fid of before) {
                    if (
                        profiles.has(fid) ||
                        store.player(fid, run.game_type)?.alliance_id !== run.alliance_id
                    )
                        continue;
                    core.deletePlayer(fid, run.game_type);
                    for (const table of ['deferred', 'catchup', 'reports'])
                        db.prepare(`DELETE FROM plugin_player_sync_${table} WHERE game_type=? AND fid=?`).run(
                            run.game_type,
                            fid
                        );
                    removed++;
                }
            const summary = {
                added,
                removed,
                conflicts,
                invalid,
                removalSkipped: !!row.delete_missing && !complete
            };
            const progress = JSON.parse(process.progress);
            progress.done.push(...progress.pending);
            progress.pending = [];
            progress.playerSync = { reason: null, retryAt: null, members: summary };
            db.prepare('UPDATE processes SET progress=? WHERE id=?').run(JSON.stringify(progress), processId);
            db.prepare(
                'UPDATE plugin_player_sync_members SET result=? WHERE game_type=? AND alliance_id=?'
            ).run(JSON.stringify(summary), run.game_type, run.alliance_id);
            return summary;
        })();
        return result;
    }
    return { settings, setSchedule, confirm, cancel, tick, execute, check };
}
module.exports = { createMemberSync };
