const net = require('net');
const { FURNACE_LEVEL_MAPPING } = require('../../src/functions/Players/furnaceReadable');

class SyncError extends Error {
    constructor(code, message, retryAt = null) {
        super(message);
        this.name = 'SyncError';
        this.code = code;
        this.retryAt = retryAt;
    }
}
const fail = message => {
    throw new SyncError('invalid', message);
};
const FIELDS = ['id', 'name', 'level', 'kingdom', 'power', 'avatar'];
const block = new net.BlockList();
const blockV6 = new net.BlockList();
for (const [address, prefix] of [
    ['0.0.0.0', 8],
    ['10.0.0.0', 8],
    ['100.64.0.0', 10],
    ['127.0.0.0', 8],
    ['169.254.0.0', 16],
    ['172.16.0.0', 12],
    ['192.0.0.0', 24],
    ['192.0.2.0', 24],
    ['192.88.99.0', 24],
    ['192.168.0.0', 16],
    ['198.18.0.0', 15],
    ['198.51.100.0', 24],
    ['203.0.113.0', 24],
    ['224.0.0.0', 4],
    ['240.0.0.0', 4]
])
    block.addSubnet(address, prefix, 'ipv4');
for (const [address, prefix] of [
    ['::', 128],
    ['::1', 128],
    ['::ffff:0:0', 96],
    ['64:ff9b::', 96],
    ['64:ff9b:1::', 48],
    ['100::', 64],
    ['2001::', 23],
    ['2001:db8::', 32],
    ['2002::', 16],
    ['fc00::', 7],
    ['fe80::', 10],
    ['ff00::', 8]
])
    blockV6.addSubnet(address, prefix, 'ipv6');
const globalV6 = new net.BlockList();
globalV6.addSubnet('2000::', 3, 'ipv6');

function isPublicAddress(address) {
    const family = net.isIP(address);
    return family === 4
        ? !block.check(address, 'ipv4')
        : family === 6 && globalV6.check(address, 'ipv6') && !blockV6.check(address, 'ipv6');
}
function publicUrl(value) {
    let url;
    try {
        url = new URL(value);
    } catch {
        fail('Enter a valid HTTPS URL.');
    }
    if (url.protocol !== 'https:' || url.username || url.password || url.hash)
        fail('Use HTTPS without embedded credentials or a fragment.');
    const host = url.hostname
        .replace(/^\[|\]$/g, '')
        .replace(/\.$/, '')
        .toLowerCase();
    if (
        (net.isIP(host) && !isPublicAddress(host)) ||
        (!net.isIP(host) && (!host.includes('.') || /\.(localhost|local|internal|home|invalid|test)$/.test(host)))
    )
        fail('Only public API hosts are supported.');
    return url;
}
function pathMapping(value) {
    if (typeof value !== 'string' || value.length > 200) fail('Field paths must be text, up to 200 characters.');
    if (
        value &&
        value
            .split('.')
            .some(part => !/^[\w-]+$/.test(part) || ['__proto__', 'prototype', 'constructor'].includes(part))
    )
        fail('Use dotted field names or numeric array indexes.');
    return value;
}
function mappings(raw, requireId = false) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) fail('Fields must be a JSON object.');
    const result = Object.fromEntries(FIELDS.map(field => [field, pathMapping(raw[field] ?? '')]));
    if (/(^|\.)uid$/i.test(result.id)) fail('Map the public chief/governor ID, not the internal uid.');
    if (requireId && !result.id) fail('Alliance member fields need a public ID mapping.');
    return result;
}
function endpoint(value, placeholders) {
    if (
        typeof value !== 'string' ||
        value.length > 1000 ||
        !value ||
        /^\s|[\r\n\\#]|^[a-z]+:|^\/\//i.test(value) ||
        value.includes('..') ||
        !placeholders.some(p => value.includes(`{${p}}`))
    )
        fail('The endpoint needs its ID placeholders and must be relative to the base URL.');
    const tokens = value.match(/\{[^}]*\}/g) || [];
    if (tokens.some(token => !placeholders.includes(token.slice(1, -1)))) fail('Unsupported endpoint placeholder.');
    const query = new URLSearchParams(value.split('?')[1] || '');
    if ([...query.keys()].some(key => /^(api[-_]?key|access[-_]?token|token|secret|authorization)$/i.test(key)))
        fail('Enter credentials under API Key, not in the URL.');
    return value;
}
function normalizeProfile(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) fail('Import the complete JSON setup object.');
    if (Buffer.byteLength(JSON.stringify(raw)) > 65536) fail('Setup files must be 64 KiB or smaller.');
    const url = publicUrl(raw.base_url);
    if (url.search) fail('Put query parameters in the endpoint, not the base URL.');
    const header = raw.auth_header ?? 'X-Api-Key';
    if (
        typeof header !== 'string' ||
        !/^[!#$%&'*+.^_`|~0-9A-Za-z-]{1,60}$/.test(header) ||
        /^(host|connection|content-length|cookie|set-cookie|transfer-encoding|accept-encoding|te|trailer|upgrade|expect|proxy-.*|sec-.*|x-forwarded-.*)$/i.test(
            header
        )
    )
        fail('Choose a valid authentication header, such as X-Api-Key or Authorization.');
    const result = {
        base_url: url.href.replace(/\/$/, ''),
        player_path: endpoint(raw.player_path, ['id', 'fid']),
        auth_header: header,
        per_minute: raw.per_minute ?? 30,
        per_day: raw.per_day ?? 1000,
        fields: mappings(raw.fields)
    };
    if (
        !Number.isInteger(result.per_minute) ||
        result.per_minute < 1 ||
        result.per_minute > 600 ||
        !Number.isInteger(result.per_day) ||
        result.per_day < 1 ||
        result.per_day > 1000000
    )
        fail('Limits must be whole numbers: 1–600 per minute and 1–1,000,000 per day.');
    if (!FIELDS.slice(1).some(field => result.fields[field])) fail('Map at least one player field.');
    if (raw.alliance != null) {
        const a = raw.alliance;
        if (typeof a !== 'object' || Array.isArray(a)) fail('Alliance mappings must be a JSON object.');
        result.alliance = {
            path: endpoint(a.path, ['state', 'tag']),
            state_field: pathMapping(a.state_field),
            tag_field: pathMapping(a.tag_field),
            name_field: pathMapping(a.name_field || ''),
            members_path: pathMapping(a.members_path),
            fields: mappings(a.fields, true)
        };
        if (!result.alliance.state_field || !result.alliance.tag_field || !result.alliance.members_path)
            fail('Alliance imports need state, tag and member-list mappings.');
    }
    return result;
}
function extract(payload, path) {
    if (!path) return undefined;
    let node = payload;
    for (const part of path.split('.')) {
        if (!node || typeof node !== 'object' || !Object.hasOwn(node, part)) return undefined;
        node = node[part];
    }
    return node;
}
function whole(value, min = 0) {
    if (!['number', 'string'].includes(typeof value) || String(value).trim() === '') return undefined;
    const number = Number(value);
    return Number.isSafeInteger(number) && number >= min ? number : undefined;
}
function playerId(value) {
    const id = whole(value, 1);
    if (id == null) fail('Player IDs must be positive whole numbers.');
    return String(id);
}
function level(value) {
    const number = whole(value, 1);
    if (number != null) return number;
    if (typeof value !== 'string') return undefined;
    const compact = value
        .toUpperCase()
        .replace(/^TG/, 'FC')
        .replace(/[^A-Z0-9]/g, '');
    for (const [raw, label] of Object.entries(FURNACE_LEVEL_MAPPING))
        if (label.replace(/[^A-Z0-9]/g, '') === compact) return Number(raw);
    return /^LEVEL\d+$/.test(compact) ? whole(compact.slice(5), 1) : undefined;
}
function power(value) {
    const number = whole(value);
    if (number != null) return number;
    if (typeof value !== 'string') return undefined;
    const match = value.trim().match(/^(\d+(?:\.\d+)?)\s*([KMBT])$/i);
    return match ? whole(Number(match[1]) * { K: 1e3, M: 1e6, B: 1e9, T: 1e12 }[match[2].toUpperCase()]) : undefined;
}
function imageUrl(value) {
    if (typeof value !== 'string' || value.length > 2048) return undefined;
    try {
        return publicUrl(value).href;
    } catch {
        return undefined;
    }
}
function readPlayer(payload, fields, requestedId) {
    const mappedId = extract(payload, fields.id);
    if (fields.id && (mappedId == null || playerId(mappedId) !== playerId(requestedId)))
        throw new SyncError('mapping', 'The returned public player ID does not match the requested player.');
    const result = { fid: playerId(requestedId) };
    const name = extract(payload, fields.name);
    if (typeof name === 'string' && name.trim() && name.length <= 128 && !/[\x00-\x1f\x7f]/.test(name))
        result.nickname = name.trim();
    const values = {
        furnace_level: level(extract(payload, fields.level)),
        state: whole(extract(payload, fields.kingdom), 1),
        power: power(extract(payload, fields.power)),
        image_url: imageUrl(extract(payload, fields.avatar))
    };
    for (const [key, value] of Object.entries(values)) if (value !== undefined) result[key] = value;
    return result;
}
function buildUrl(profile, path, values) {
    const rendered = path.replace(/\{(\w+)\}/g, (_, key) => {
        if (values[key] == null) fail('Missing endpoint value.');
        return encodeURIComponent(String(values[key]));
    });
    const url = publicUrl(`${profile.base_url.replace(/\/+$/, '')}/${rendered.replace(/^\/+/, '')}`);
    if (url.origin !== new URL(profile.base_url).origin) fail('Endpoints must use the configured API host.');
    return url.href;
}
function preset(game) {
    const ks = game === 'ks';
    const fields = {
        id: ks ? 'governor_id' : 'chief_id',
        name: 'nick_name',
        level: ks ? 'town_center_level' : 'furnace_level',
        kingdom: 'kid',
        power: 'power',
        avatar: 'avatar_url'
    };
    return normalizeProfile({
        base_url: ks ? 'https://api.mightpulse.com/v1' : 'https://api.whiteoutstats.com/v1',
        player_path: `players/{id}?include=base&id_type=${ks ? 'governor_id' : 'chief_id'}`,
        auth_header: 'X-Api-Key',
        per_minute: 60,
        per_day: 5000,
        fields: Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, `player.${value}`])),
        alliance: {
            path: 'alliances/{state}/{tag}?include=info,roster',
            state_field: 'player.kid',
            tag_field: 'player.alliance.abbr',
            name_field: 'player.alliance.name',
            members_path: 'members',
            fields
        }
    });
}
module.exports = {
    SyncError,
    normalizeProfile,
    extract,
    readPlayer,
    buildUrl,
    playerId,
    whole,
    preset,
    isPublicAddress,
    publicUrl,
    imageUrl
};
