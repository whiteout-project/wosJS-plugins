const { PermissionFlagsBits, ChannelType } = require('discord.js');
const { createService } = require('./service');
const { createDiscordUI } = require('./discord');
const { SyncError } = require('./profile');
const { registerPlayerSyncIntegration } = require('../../src/functions/Players/playerSyncIntegration');
const { db, adminQueries, allianceQueries, playerQueries } = require('../../src/functions/utility/database');
const {
    getAlliancesForUserByGame,
    getUserInfo,
    hasPermission
} = require('../../src/functions/utility/commonFunctions');
const { PERMISSIONS } = require('../../src/functions/Settings/admin/permissions');
const { getEmojiMapForUser, getComponentEmoji } = require('../../src/functions/utility/emojis');
const { getActiveGameTypes } = require('../../src/functions/utility/gameRuntime');
const { createProcessRecord, getProcessById } = require('../../src/functions/Processes/createProcesses');
const { queueManager } = require('../../src/functions/Processes/queueManager');
const { processExecutor } = require('../../src/functions/Processes/executeProcesses');
const { queueMissedCodes } = require('../../src/functions/GiftCode/stateSearch');

/** Registers the shared service and Discord handlers; returns the plugin lifecycle cleanup. */
function start(client, options = {}) {
    const core = {
        permissions: PERMISSIONS,
        hasPermission,
        enabledGames: getActiveGameTypes,
        getAdmin: id => adminQueries.getAdmin(id),
        reportStrings: alliance => {
            const admin = adminQueries.getAdminById(alliance.created_by);
            return getUserInfo(admin?.user_id || '').lang?.plugins?.['player-sync'];
        },
        accessibleAlliances: (admin, game) =>
            getAlliancesForUserByGame(
                admin,
                game,
                hasPermission(admin, PERMISSIONS.ALLIANCE_MANAGEMENT)
                    ? PERMISSIONS.ALLIANCE_MANAGEMENT
                    : PERMISSIONS.PLAYER_MANAGEMENT
            ),
        createProcessRecord,
        getProcess: getProcessById,
        manageQueue: info => queueManager.manageQueue(info),
        startNext: () => queueManager.startNextProcess(),
        preemption: id => processExecutor.checkForPreemption(id),
        queueMissedCodes,
        addPlayer: (...args) => playerQueries.addPlayer(...args),
        async validateChannel(userId, channelId) {
            if (!/^\d{16,22}$/.test(String(channelId)))
                throw new SyncError('invalid', 'Select a valid Discord text channel.');
            const channel = await client.channels.fetch(channelId, { force: true }).catch(() => null);
            if (!channel || channel.type !== ChannelType.GuildText)
                throw new SyncError('channel', 'Choose an accessible server text channel.');
            const member = await channel.guild.members.fetch({ user: String(userId), force: true }).catch(() => null);
            const me = await channel.guild.members.fetchMe({ force: true }).catch(() => null);
            const needed = [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.EmbedLinks
            ];
            if (
                !member ||
                !channel.permissionsFor(member)?.has(PermissionFlagsBits.ViewChannel) ||
                !channel.permissionsFor(me)?.has(needed)
            ) {
                throw new SyncError(
                    'channel',
                    'You and the bot need access to the channel; the bot also needs Send Messages and Embed Links.'
                );
            }
            return { id: channel.id, guildId: channel.guildId };
        },
        createAlliance(input, admin, game, channel) {
            const max = db.prepare('SELECT COALESCE(MAX(priority),0) n FROM alliance WHERE game_type=?').get(game).n;
            if (max >= 99999) throw new SyncError('invalid', 'No alliance priority is available.');
            const result = allianceQueries.addAlliance(
                max + 1,
                input.name,
                channel.guildId,
                channel.id,
                0,
                1,
                admin.id,
                game,
                input.state
            );
            const id = Number(result.lastInsertRowid);
            let assigned;
            try {
                assigned = JSON.parse(admin.alliances || '[]');
            } catch {
                assigned = [];
            }
            if (!Array.isArray(assigned)) assigned = [];
            adminQueries.updateAdminAlliances(JSON.stringify([...new Set([...assigned, id])]), admin.user_id);
            return id;
        }
    };
    const service = createService({ db, client, core, ...options });
    const ui = createDiscordUI(service, {
        getUserInfo,
        enabledGames: getActiveGameTypes,
        getEmoji: (userId, key) => getComponentEmoji(getEmojiMapForUser(userId), key)
    });
    service.openDiscord = ui.show;
    const unregister = registerPlayerSyncIntegration(service);
    client.on('interactionCreate', ui.listener);
    let timer;
    const ready = () => {
        if (timer) return;
        timer = setInterval(
            () => service.tick().catch(() => console.warn('[Player Sync] Background work deferred.')),
            60000
        );
        timer.unref?.();
        service.tick().catch(() => console.warn('[Player Sync] Startup work deferred.'));
    };
    client.on('clientReady', ready);
    if (client.isReady()) ready();
    return () => {
        unregister();
        client.off('interactionCreate', ui.listener);
        client.off('clientReady', ready);
        clearInterval(timer);
        service.stop();
    };
}
module.exports = { start };
