const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { getPlayerSyncIntegration } = require('../../../src/functions/Players/playerSyncIntegration');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('playersync')
        .setDescription('Sync player profiles, configure an API, or import an alliance.')
        .setDescriptionLocalizations({ fr: 'Synchroniser les joueurs, configurer une API ou importer une alliance.' }),

    async execute(interaction) {
        const service = getPlayerSyncIntegration();
        if (!service?.openDiscord)
            return interaction.reply({ content: 'Player Sync is not available.', flags: MessageFlags.Ephemeral });
        await service.openDiscord(interaction);
    }
};
