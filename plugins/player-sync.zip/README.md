# Player Sync

Restore player nicknames, state, pictures, furnace/town-center levels and power through an API connection you control. [WhiteoutStats](https://api.whiteoutstats.com/) and [MightPulse](https://api.mightpulse.com/) are independent services. WOSLand does not operate or endorse them. Their availability, account quotas and terms belong to them.

## Requirements

- Bot core v1.0.53 or later and Node.js 22 or later are required.
- Place this folder at `plugins/player-sync/` and load it through the plugin manager. No additional dependencies or installation scripts are needed.
- Browser controls require web-panel v1.1.22 or later. An older panel continues working without these controls.
- Restart after installing to register `/playersync` with Discord. **Alliances → Player Sync** and **Players → Player Sync** are available while the plugin is loaded, according to your permissions.
- Only bot owners manage shared provider settings, keys and limits. Alliance/player administrators manage syncs and imports for accessible alliances. Creating an alliance additionally requires alliance-management permission.
- In the reporting channel, the bot needs View Channel, Send Messages and Embed Links.

## Setup in Discord or the web panel

1. Get your own provider API key: WhiteoutStats for WOS or MightPulse for Kingshot.
2. Open **Alliances → Player Sync → Setup**, **Players → Player Sync**, or `/playersync`. Select the correct game first. Inactive games are hidden; WOS and Kingshot have separate connections and keys.
3. Choose **Use Game Example**. For custom providers or the matching JSON in `examples/`, open **Advanced Setup**: paste or upload JSON up to 64 KiB, or edit the connection and field mappings.
4. Open **API Key** and enter the complete authentication-header value. Include `Bearer ` if required by your provider's `Authorization` header. Discord uses a private modal; the panel uses a password field. Keys are never prefilled, returned or exported. **Database backups contain keys: keep them private.**
5. Use **Test One Player** with a known public chief/governor ID. Verify the mapped values. Tests consume quota but do not change registered players.
6. Enable the connection. Automatic syncing remains off until enabled separately for an alliance.
7. Under **Alliances & Schedule**, enable the desired alliances. The default interval is 24 hours; supported intervals are 1–720 hours. **Sync Now** queues one alliance or all accessible alliances.

Connection settings, field mappings, limits and the key can be edited separately. Any change disables the connection until a successful test. Changing the API origin clears the previous key to prevent sending it to a different provider.

## Updates and scheduling

Only valid mapped fields update records. Missing fields, blank names, invalid levels/states and unsafe pictures preserve stored values. Pictures update silently. Nickname, level, effective-state and power changes are grouped in the alliance's existing channel. Unchanged runs, progress and failures stay in management screens. Missing channels or failed announcements do not undo profile updates; undelivered reports and progress between message parts are saved for another attempt.

**The API state replaces a manual override.** If it matches the alliance state, the override is cleared; otherwise it becomes the redemption override. Changing the effective state releases an exhausted state-search block and queues recorded, still-active missed gift codes through the existing retry mechanism. Gift-code state searches themselves do not call this API.

Transferred players remain in their bot alliance. Assignments, Discord links, redemption history and unrelated metadata are preserved. Newly added players use the same connection; if enrichment is unavailable or throttled, their IDs are still added and the lookup is reported as deferred. A later alliance sync can enrich them.

Tests, lookups, imports and syncs share quota for the same API origin and key, including across both games and equivalent API-key/Bearer headers. When a credential is shared, the stricter configured limits apply. Daily budgets reset at UTC midnight; provider reset/cooldown headers can extend waits. Requests are paced; expected limits pause work with saved progress. Higher-priority additions, redemptions and state searches run first for the same game.

Disabling/unloading pauses jobs while ordinary bot features continue. Revoked administrator access prevents their queued jobs from running. Schedules whose administrator loses access are disabled until an authorized administrator enables them again. Stored profile information remains available after unloading.

## Import an alliance

1. Open **Import Alliance** and select an existing destination or **Create a new alliance**.
2. For a new alliance, choose an accessible Discord text channel. Optionally enter a name (up to 50 characters) and positive state; omitted values use the source alliance. The next priority is assigned, and the creator receives access.
3. Enter one member's public chief/governor ID. The provider must supply the seed player's state/tag and a roster endpoint. The example configurations include those mappings.
4. Review source, destination, returned players, addable IDs, existing members, conflicts and invalid entries. Discord includes the full JSON preview; the panel provides pages and a download.
5. Confirm using the same account within five minutes. Confirmation is bound to this exact roster, game, provider revision and destination. Configuration/destination changes require a fresh preview. Cancelled, expired or already used confirmations cannot add players.

Only players shown as addable in the preview can be added. Players in another bot alliance are skipped, never moved. If someone shown as already registered is removed before confirmation, fetch a fresh preview; the old confirmation cannot re-add them. No absent members are removed and no existing roster is replaced. Entries without usable public IDs are skipped; internal `uid` values are not public player IDs. Roster profile fields are applied directly without per-member requests. Import failure rolls back all insertions, including a newly created alliance and administrator assignment.

## Custom JSON

The basic format matches Python v2.2.0:

```json
{
  "base_url": "https://api.example.com/v1",
  "player_path": "players/{fid}",
  "auth_header": "X-Api-Key",
  "per_minute": 60,
  "per_day": 5000,
  "fields": {
    "name": "player.nick_name",
    "level": "player.furnace_level",
    "kingdom": "player.kid",
    "power": "player.power",
    "avatar": "player.avatar_url"
  }
}
```

`{id}` and `{fid}` represent the requested public ID. Dotted paths support numeric array indexes, such as `data.players.0.nick_name`. Mappings are data, never executable code. Numeric levels and `FC 3`/`TG 3` labels are supported, as are whole-number power values and `1.2M` notation. Optional `fields.id` checks the response's public ID against the request.

For roster imports, add an `alliance` object as shown in the examples. Its `path` accepts `{state}` and `{tag}`. `state_field`, `tag_field` and `name_field` refer to the seed response; `members_path` selects the roster array. `alliance.fields` paths are relative to each member and must include a public-ID mapping. Basic Python configurations without this extension still support player syncing.

Use public HTTPS endpoints. Private/local addresses, embedded credentials, unsafe authentication headers and cross-origin redirects are rejected. Each request validates and pins DNS results, has a 100-second deadline including DNS, and accepts at most 2 MiB. Setup files are limited to 64 KiB. Keys belong only in API Key, never in URLs or JSON exports.

## Troubleshooting

| Symptom | Action |
| --- | --- |
| Button missing | Load the plugin with a core containing this integration. Browser controls also need the accompanying panel update. |
| Slash command missing | Restart after installation to register `/playersync`. |
| Cannot enable | Save configuration/key, successfully test one player, then enable. Changes require another test. |
| Key rejected | Check account status, header and complete key value. HTTP 401/403 pauses the connection; correct it and test again. |
| No usable data | Check public-ID type, endpoint and field paths. For imports, add roster mappings or use the example. |
| Values look old | Providers can cache data for up to an hour. A successful sync means a usable response, not guaranteed live game data. |
| Waiting for quota | Check Requests Today and cooldown time. Tests/previews count too. Jobs retain progress and resume when eligible. |
| Job remains queued | Check connection state and administrator access. Higher-priority work runs first. |
| No announcement | Only actual changes are posted. Check channel permissions; pending reports retry later. |
| Preview expired/changed | Fetch a new preview. It lasts five minutes and cannot be transferred between users, games or destinations. |

Provider API formats and availability can change independently of this plugin.

## Reference

Configuration and setup behavior were informed by the Python bot's [v2.2.0 Player Sync implementation](https://github.com/whiteout-project/bot/blob/v2.2.0/cogs/alliance_api_sync.py) and provider documentation. This JavaScript implementation is independently written; no Python source was copied.
