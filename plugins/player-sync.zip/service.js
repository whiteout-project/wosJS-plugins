const crypto = require('crypto');
const { EmbedBuilder, escapeMarkdown } = require('discord.js');
const { createStore } = require('./store');
const {
    SyncError,
    normalizeProfile,
    readPlayer,
    buildUrl,
    extract,
    playerId,
    whole,
    preset,
    publicUrl
} = require('./profile');
const { requestJson } = require('./transport');
const { getFurnaceReadable } = require('../../src/functions/Players/furnaceReadable');
const defaultStrings = require('./locales/en.json').plugins['player-sync'];

/** Shared authorization and sync engine used by Discord, the panel, and queued processes. */
function createService({ db, client, core, request = requestJson, now = Date.now, sleep = wait }) {
    const { permissions: PERMISSIONS, hasPermission } = core;
    const store = createStore(db, now);
    const controllers = new Map();
    const epochs = new Map();
    const creating = new Set();
    const waking = new Map();
    let stopped = false;
    let ticking = false;
    let flushing = false;
    const hash = value => crypto.createHash('sha256').update(value).digest('hex');
    const gameFrom = value => {
        if (!['wos', 'ks'].includes(value) || !core.enabledGames().includes(value))
            throw new SyncError('game', 'This game is not enabled.');
        return value;
    };

    function authorize(context, owner = false, allianceId = null) {
        if (stopped) throw new SyncError('unavailable', 'Player Sync is not loaded.');
        const game = gameFrom(context.gameType);
        const admin = core.getAdmin(String(context.userId));
        if (
            !hasPermission(
                admin,
                PERMISSIONS.ALLIANCE_MANAGEMENT,
                PERMISSIONS.PLAYER_MANAGEMENT,
                PERMISSIONS.FULL_ACCESS
            ) ||
            (owner && !admin.is_owner)
        )
            throw new SyncError('permission', 'You do not have permission for this action.');
        const alliances = core.accessibleAlliances(admin, game);
        if (allianceId != null && !alliances.some(alliance => alliance.id === Number(allianceId)))
            throw new SyncError('permission', 'You do not have access to this alliance.');
        return { game, admin, alliances };
    }

    function bucket(config) {
        const credential =
            config.profile.auth_header.toLowerCase() === 'authorization'
                ? config.secret.replace(/^Bearer\s+/i, '')
                : config.secret;
        // Keep the former X-Api-Key identity; equivalent Bearer/custom headers share its quota.
        return hash(`${new URL(config.profile.base_url).origin}\nx-api-key\n${credential}`);
    }

    function migrateQuota(config) {
        if (config.profile && config.secret)
            store.migrateQuota(
                bucket(config),
                hash(
                    `${new URL(config.profile.base_url).origin}\n${config.profile.auth_header.toLowerCase()}\n${config.secret}`
                )
            );
    }

    function limits(config) {
        const shared = db
            .prepare('SELECT game_type FROM plugin_player_sync_config')
            .all()
            .map(row => store.config(row.game_type))
            .filter(other => other.profile && bucket(other) === bucket(config));
        return {
            minute: Math.min(...shared.map(other => other.profile.per_minute)),
            day: Math.min(...shared.map(other => other.profile.per_day))
        };
    }

    function connection(game, allowDisabled = false) {
        if (stopped) throw new SyncError('unavailable', 'Player Sync is not loaded.');
        const config = store.config(game);
        if (
            !config.profile ||
            !config.secret ||
            (!allowDisabled && (!config.enabled || config.tested_revision !== config.revision))
        ) {
            throw new SyncError(
                'unconfigured',
                'Import or edit a setup, add an API key, test one player, then enable the connection.'
            );
        }
        migrateQuota(config);
        return { ...config, epoch: epochs.get(game) || 0 };
    }

    function unchanged(game, revision, signal, epoch) {
        if (stopped || signal?.aborted || (epoch != null && epoch !== (epochs.get(game) || 0)))
            throw new SyncError('paused', 'Player Sync was paused.');
        if (store.config(game).revision !== revision)
            throw new SyncError('changed', 'The API setup changed. Test the new setup before continuing.');
    }

    function wake(at) {
        if (stopped || waking.has(at)) return;
        const timer = setTimeout(
            () => {
                waking.delete(at);
                tick().catch(() => {});
            },
            Math.max(1, Math.min(2147483647, at - now()))
        );
        timer.unref?.();
        waking.set(at, timer);
    }

    function publicProfile(row) {
        return {
            fid: String(row.fid),
            nickname: row.nickname ?? null,
            furnace_level: row.furnace_level ?? null,
            state: row.state ?? null,
            state_override: row.state_override ?? null,
            image_url: row.image_url ?? null,
            power: row.power ?? null,
            profile_synced_at: row.profile_synced_at ?? null,
            alliance_id: row.alliance_id,
            game_type: row.game_type
        };
    }

    function runs(game, alliances) {
        const ids = new Set(alliances.map(alliance => alliance.id));
        return db
            .prepare(
                `SELECT r.*,p.status,p.progress FROM plugin_player_sync_runs r JOIN processes p ON p.id=r.process_id
            WHERE r.game_type=? ORDER BY r.process_id DESC LIMIT 200`
            )
            .all(game)
            .filter(row => ids.has(row.alliance_id))
            .slice(0, 30)
            .map(row => {
                const progress = JSON.parse(row.progress);
                return {
                    id: row.process_id,
                    allianceId: row.alliance_id,
                    status: row.status,
                    pending: progress.pending?.length || 0,
                    done: progress.done?.length || 0,
                    failed: progress.failed?.length || 0,
                    reason: progress.playerSync?.reason || null,
                    retryAt: progress.playerSync?.retryAt || null,
                    result: row.result,
                    updatedAt: row.updated_at
                };
            });
    }

    function status(context) {
        const { game, admin, alliances } = authorize(context);
        const config = store.config(game);
        const usage = config.profile && config.secret ? store.quota(bucket(config)) : null;
        const day = new Date(now()).toISOString().slice(0, 10);
        return {
            installed: true,
            gameType: game,
            isOwner: !!admin.is_owner,
            canManageAlliances: hasPermission(admin, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS),
            configured: !!(config.profile && config.secret),
            tested: config.tested_revision === config.revision && !!config.profile,
            enabled: config.enabled,
            keyPresent: !!config.secret,
            profile: admin.is_owner ? config.profile : null,
            revision: config.revision,
            provider: config.profile ? new URL(config.profile.base_url).hostname : null,
            error: config.last_error,
            limits: config.profile ? { perMinute: config.profile.per_minute, perDay: config.profile.per_day } : null,
            usage: {
                used: usage?.day === day ? usage.used : 0,
                retryAt: usage?.blocked_until > now() ? usage.blocked_until : null
            },
            alliances: alliances.map(alliance => {
                const schedule = db
                    .prepare('SELECT * FROM plugin_player_sync_schedule WHERE game_type=? AND alliance_id=?')
                    .get(game, alliance.id);
                return {
                    id: alliance.id,
                    name: alliance.name,
                    state: alliance.state,
                    channelId: alliance.channel_id,
                    enabled: !!schedule?.enabled,
                    hours: schedule?.hours || 24,
                    nextAt: schedule?.next_at || null,
                    playerCount: db
                        .prepare('SELECT COUNT(*) n FROM players WHERE game_type=? AND alliance_id=? AND exist<3')
                        .get(game, alliance.id).n,
                    deferred: db
                        .prepare(
                            `SELECT COUNT(*) n FROM plugin_player_sync_deferred d JOIN players p ON p.game_type=d.game_type AND p.fid=d.fid
                        WHERE p.game_type=? AND p.alliance_id=?`
                        )
                        .get(game, alliance.id).n
                };
            }),
            runs: runs(game, alliances),
            pendingReports: db
                .prepare(
                    'SELECT alliance_id,COUNT(*) n FROM plugin_player_sync_reports WHERE game_type=? AND sent_at IS NULL GROUP BY alliance_id'
                )
                .all(game)
                .filter(row => alliances.some(alliance => alliance.id === row.alliance_id))
                .reduce((sum, row) => sum + row.n, 0)
        };
    }

    function abortGame(game) {
        epochs.set(game, (epochs.get(game) || 0) + 1);
        for (const [controller, info] of controllers) if (info.game === game) controller.abort();
    }

    function invalidate(game) {
        abortGame(game);
        db.prepare('DELETE FROM plugin_player_sync_import WHERE game_type=?').run(game);
        for (const row of db
            .prepare(
                `SELECT p.id,p.progress FROM processes p JOIN plugin_player_sync_runs r ON r.process_id=p.id
            WHERE r.game_type=? AND p.status IN ('queued','active')`
            )
            .all(game)) {
            const progress = JSON.parse(row.progress);
            progress.pending = [];
            progress.playerSync = { ...progress.playerSync, reason: 'changed' };
            db.prepare("UPDATE processes SET status='completed',progress=? WHERE id=?").run(
                JSON.stringify(progress),
                row.id
            );
            db.prepare('UPDATE plugin_player_sync_runs SET result=?,updated_at=? WHERE process_id=?').run(
                'changed',
                now(),
                row.id
            );
        }
    }

    function saveProfile(context, input) {
        const { game } = authorize(context, true);
        let raw = input;
        if (typeof input === 'string') {
            if (Buffer.byteLength(input) > 65536)
                throw new SyncError('invalid', 'Setup files must be 64 KiB or smaller.');
            try {
                raw = JSON.parse(input);
            } catch {
                throw new SyncError('invalid', 'Paste or upload a valid JSON setup object.');
            }
        }
        const profile = normalizeProfile(raw);
        const old = store.config(game);
        if (JSON.stringify(profile) === JSON.stringify(old.profile)) return { ...status(context), keyCleared: false };
        const changedHost = old.profile && new URL(old.profile.base_url).origin !== new URL(profile.base_url).origin;
        db.transaction(() => {
            invalidate(game);
            store.changeConfig(game, {
                profile,
                revision: old.revision + 1,
                tested_revision: null,
                enabled: false,
                secret: changedHost ? '' : old.secret,
                last_error: null
            });
        })();
        return { ...status(context), keyCleared: !!changedHost };
    }

    function saveKey(context, key) {
        const { game } = authorize(context, true);
        if (typeof key !== 'string' || key.length > 500 || /[^\x20-\x7e]/.test(key))
            throw new SyncError('invalid', 'Enter an API key of up to 500 characters without newlines.');
        const old = store.config(game);
        if (key.trim() === old.secret) return status(context);
        db.transaction(() => {
            invalidate(game);
            store.changeConfig(game, {
                secret: key.trim(),
                revision: old.revision + 1,
                tested_revision: null,
                enabled: false,
                last_error: null
            });
        })();
        return status(context);
    }

    function setEnabled(context, enabled) {
        const { game } = authorize(context, true);
        if (typeof enabled !== 'boolean') throw new SyncError('invalid', 'Choose whether the connection is enabled.');
        const config = store.config(game);
        if (enabled && (!config.profile || !config.secret || config.tested_revision !== config.revision))
            throw new SyncError('unconfigured', 'Test the current setup successfully before enabling it.');
        store.changeConfig(game, { enabled });
        if (!enabled) abortGame(game);
        else wake(now() + 1);
        return status(context);
    }

    async function fetchPayload(game, path, values, { allowDisabled = false, processId = null, checkAccess } = {}) {
        const config = connection(game, allowDisabled);
        if (controllers.size >= 3)
            throw new SyncError('busy', 'Three API requests are already running. Try again shortly.', now() + 5000);
        const controller = new AbortController();
        controllers.set(controller, { game, processId });
        const id = bucket(config);
        let address = buildUrl(config.profile, path, values);
        let redirects = 0;
        const preemptionTimer =
            processId == null
                ? null
                : setInterval(async () => {
                      try {
                          if ((await core.getProcess(processId))?.status !== 'active') controller.abort();
                      } catch {
                          controller.abort();
                      }
                  }, 1000);
        preemptionTimer?.unref?.();
        try {
            for (let attempt = 0; attempt < 3; attempt++) {
                checkAccess?.();
                unchanged(game, config.revision, controller.signal, config.epoch);
                const budget = limits(config);
                for (;;) {
                    checkAccess?.();
                    const retryAt = store.reserve(id, budget.minute, budget.day);
                    if (!retryAt) break;
                    if (retryAt - now() > 10000) {
                        wake(retryAt);
                        throw new SyncError(
                            'throttled',
                            'The API request allowance is exhausted or cooling down.',
                            retryAt
                        );
                    }
                    await sleep(retryAt - now(), controller.signal);
                    unchanged(game, config.revision, controller.signal, config.epoch);
                }
                let answer;
                try {
                    answer = await request(address, { [config.profile.auth_header]: config.secret }, controller.signal);
                } catch (error) {
                    if (!(error instanceof SyncError) || error.code === 'network') {
                        if (attempt < 2) {
                            await sleep(1000 * 2 ** (attempt + 1), controller.signal);
                            continue;
                        }
                        throw new SyncError('network', 'The API could not be reached after three attempts.');
                    }
                    throw error;
                }
                unchanged(game, config.revision, controller.signal, config.epoch);
                const headers = answer.headers || {};
                for (const kind of ['minute', 'day']) {
                    if (String(headers[`x-ratelimit-remaining-${kind}`]) === '0') {
                        const reset = Number(headers[`x-ratelimit-reset-${kind}`]) * 1000;
                        if (Number.isFinite(reset) && reset > now()) {
                            store.blockQuota(id, reset);
                            wake(reset);
                        }
                    }
                }
                if ([301, 302, 303, 307, 308].includes(answer.status)) {
                    let next;
                    try {
                        next = publicUrl(new URL(headers.location, address).href);
                    } catch {
                        throw new SyncError('invalid', 'Invalid API redirect.');
                    }
                    if (++redirects > 3 || next.origin !== new URL(config.profile.base_url).origin)
                        throw new SyncError('invalid', 'The API redirected to another host.');
                    address = next.href;
                    attempt--;
                    continue;
                }
                if (answer.status === 429) {
                    const value = String(headers['retry-after'] ?? '').trim();
                    const parsed = /^\d+(?:\.\d+)?$/.test(value)
                        ? now() + Number(value) * 1000
                        : /^[A-Za-z]/.test(value)
                          ? Date.parse(value)
                          : NaN;
                    const quota = store.quota(id);
                    const retryAt = Math.max(
                        Number.isFinite(parsed) ? parsed : now() + 60000,
                        now() + 1,
                        quota?.next_at || 0,
                        quota?.blocked_until || 0
                    );
                    store.blockQuota(id, retryAt);
                    wake(retryAt);
                    throw new SyncError('throttled', 'The API asked the bot to wait.', retryAt);
                }
                if (answer.status === 401 || answer.status === 403) {
                    store.changeConfig(game, { enabled: false, tested_revision: null, last_error: 'auth' });
                    abortGame(game);
                    throw new SyncError(
                        'auth',
                        'The API rejected the key. Check the key and permissions, then test again.'
                    );
                }
                if ((answer.status >= 500 || answer.status === 0) && attempt < 2) {
                    await sleep(1000 * 2 ** (attempt + 1), controller.signal);
                    continue;
                }
                if (answer.status === 404)
                    throw new SyncError('notFound', 'The provider has no data for this player or alliance.');
                if (answer.status !== 200)
                    throw new SyncError(
                        'response',
                        'The API did not return usable data. Check the connection and try again.'
                    );
                if (!answer.payload || typeof answer.payload !== 'object' || answer.payload.ok === false)
                    throw new SyncError(
                        'mapping',
                        'The response contains no usable player data. Check the endpoint and field mappings.'
                    );
                checkAccess?.();
                return { payload: answer.payload, config };
            }
        } finally {
            clearInterval(preemptionTimer);
            controllers.delete(controller);
        }
    }

    async function lookupPlayer({ gameType, fid, allowDisabled = false, processId = null, checkAccess }) {
        const game = gameFrom(gameType);
        const id = playerId(fid);
        const config = connection(game, allowDisabled);
        const answer = await fetchPayload(
            game,
            config.profile.player_path,
            { id, fid: id },
            { allowDisabled, processId, checkAccess }
        );
        const profile = readPlayer(answer.payload, answer.config.profile.fields, id);
        if (Object.keys(profile).length === 1)
            throw new SyncError('mapping', 'None of the mapped fields contains usable player data.');
        return { profile, payload: answer.payload, revision: answer.config.revision, epoch: answer.config.epoch };
    }

    async function test(context, fid) {
        const { game } = authorize(context, true);
        const answer = await lookupPlayer({
            gameType: game,
            fid,
            allowDisabled: true,
            checkAccess: () => authorize(context, true)
        });
        authorize(context, true);
        unchanged(game, answer.revision, null, answer.epoch);
        store.changeConfig(game, { tested_revision: answer.revision, last_error: null });
        return { profile: answer.profile, tested: true };
    }

    function details(context, fid) {
        const { game } = authorize(context);
        const row = store.player(playerId(fid), game);
        if (!row) throw new SyncError('notFound', 'This player is not registered in the bot.');
        authorize(context, false, row.alliance_id);
        return publicProfile(row);
    }

    async function flushCatchups() {
        for (const row of db.prepare('SELECT * FROM plugin_player_sync_catchup LIMIT 200').all()) {
            if (stopped) return;
            if (store.player(row.fid, row.game_type)) await core.queueMissedCodes(row.fid, row.game_type);
            if (stopped) return;
            db.prepare('DELETE FROM plugin_player_sync_catchup WHERE game_type=? AND fid=?').run(
                row.game_type,
                row.fid
            );
        }
        if (!stopped) await core.startNext();
    }

    async function enrichPlayer({ fid, gameType, allianceId }) {
        try {
            const answer = await lookupPlayer({ gameType, fid });
            unchanged(gameType, answer.revision, null, answer.epoch);
            db.transaction(() =>
                store.apply(answer.profile, gameType, allianceId, `add:${crypto.randomUUID()}`, false)
            )();
            await flushCatchups().catch(() => {});
            return { deferred: false };
        } catch (error) {
            if (!stopped) store.deferred(fid, gameType, error instanceof SyncError ? error.code : 'response');
            return { deferred: true, reason: error instanceof SyncError ? error.code : 'response' };
        }
    }

    async function enqueue(game, alliance, userId, scheduled = false) {
        if (stopped) return null;
        const key = `${game}:${alliance.id}`;
        if (creating.has(key)) return null;
        creating.add(key);
        try {
            if (
                db
                    .prepare(
                        "SELECT id FROM processes WHERE action='player_sync' AND CAST(target AS INTEGER)=? AND status IN ('queued','active')"
                    )
                    .get(alliance.id)
            )
                return null;
            const fids = db
                .prepare(
                    'SELECT fid FROM players WHERE game_type=? AND alliance_id=? AND exist<3 ORDER BY profile_synced_at IS NOT NULL,profile_synced_at,fid'
                )
                .all(game, alliance.id)
                .map(row => String(row.fid));
            if (!fids.length) return null;
            const created = db.transaction(() => {
                const result = core.createProcessRecord({
                    admin_id: userId,
                    alliance_id: alliance.id,
                    player_ids: fids.join(','),
                    action: 'player_sync',
                    game_type: game
                });
                db.prepare(
                    `INSERT INTO plugin_player_sync_runs (process_id,game_type,alliance_id,created_by,scheduled,revision,updated_at) VALUES (?,?,?,?,?,?,?)`
                ).run(
                    result.process_id,
                    game,
                    alliance.id,
                    userId,
                    scheduled ? 1 : 0,
                    store.config(game).revision,
                    now()
                );
                return result;
            })();
            if (!stopped) await core.manageQueue(created);
            return created.process_id;
        } finally {
            creating.delete(key);
        }
    }

    async function syncNow(context, allianceIds = null) {
        const { game, alliances } = authorize(context);
        connection(game);
        if (
            allianceIds != null &&
            (!Array.isArray(allianceIds) ||
                !allianceIds.length ||
                allianceIds.some(id => !alliances.some(alliance => alliance.id === Number(id))))
        )
            throw new SyncError('permission', 'Choose only alliances you can manage.');
        const selected = allianceIds
            ? alliances.filter(alliance => allianceIds.map(Number).includes(alliance.id))
            : alliances;
        const processIds = [];
        for (const alliance of selected) {
            authorize(context, false, alliance.id);
            const id = await enqueue(game, alliance, String(context.userId));
            if (id) processIds.push(id);
        }
        return { processIds, skipped: selected.length - processIds.length };
    }

    function setSchedule(context, allianceId, options) {
        const { game } = authorize(context, false, allianceId);
        const hours = options.hours;
        if (typeof options.enabled !== 'boolean' || !Number.isInteger(hours) || hours < 1 || hours > 720)
            throw new SyncError('invalid', 'Choose an interval from 1 to 720 hours and an on/off setting.');
        if (options.enabled) connection(game);
        db.prepare(
            `INSERT INTO plugin_player_sync_schedule (game_type,alliance_id,enabled,hours,next_at,created_by) VALUES (?,?,?,?,?,?)
            ON CONFLICT(game_type,alliance_id) DO UPDATE SET enabled=excluded.enabled,hours=excluded.hours,next_at=excluded.next_at,created_by=excluded.created_by`
        ).run(game, Number(allianceId), options.enabled ? 1 : 0, hours, now(), String(context.userId));
        wake(now() + 1);
        return status(context);
    }

    function canRunProcess(process) {
        if (stopped) return false;
        const run = db.prepare('SELECT * FROM plugin_player_sync_runs WHERE process_id=?').get(process.id);
        if (!run || !core.enabledGames().includes(run.game_type)) return false;
        const config = store.config(run.game_type);
        try {
            authorize({ userId: run.created_by, gameType: run.game_type }, false, run.alliance_id);
        } catch {
            return false;
        }
        return !!(
            config.enabled &&
            config.profile &&
            config.secret &&
            config.tested_revision === config.revision &&
            run.revision === config.revision &&
            !(process.progress?.playerSync?.retryAt > now())
        );
    }

    function pause(processId, reason, retryAt = null) {
        const current = db.prepare('SELECT status,progress FROM processes WHERE id=?').get(processId);
        if (!current || !['active', 'queued'].includes(current.status)) return;
        const progress = JSON.parse(current.progress);
        progress.playerSync = { ...progress.playerSync, reason, retryAt };
        db.prepare("UPDATE processes SET status='queued',progress=? WHERE id=?").run(
            JSON.stringify(progress),
            processId
        );
        db.prepare('UPDATE plugin_player_sync_runs SET result=?,updated_at=? WHERE process_id=?').run(
            reason,
            now(),
            processId
        );
        if (retryAt) wake(retryAt);
    }

    function cancelRun(context, processId) {
        const run = db.prepare('SELECT * FROM plugin_player_sync_runs WHERE process_id=?').get(Number(processId));
        if (!run || run.game_type !== context.gameType) throw new SyncError('notFound', 'Sync run not found.');
        authorize(context, false, run.alliance_id);
        const current = db.prepare('SELECT status FROM processes WHERE id=?').get(run.process_id);
        if (!current || !['queued', 'active'].includes(current.status)) return { stopped: false };
        for (const [controller, info] of controllers) if (info.processId === run.process_id) controller.abort();
        const row = db.prepare('SELECT progress FROM processes WHERE id=?').get(run.process_id);
        const progress = JSON.parse(row.progress);
        progress.pending = [];
        progress.playerSync = { reason: 'stopped' };
        db.prepare("UPDATE processes SET status='completed',progress=? WHERE id=?").run(
            JSON.stringify(progress),
            run.process_id
        );
        db.prepare('UPDATE plugin_player_sync_runs SET result=?,updated_at=? WHERE process_id=?').run(
            'stopped',
            now(),
            run.process_id
        );
        return { stopped: true };
    }

    async function executeProcess(processId) {
        const run = db.prepare('SELECT * FROM plugin_player_sync_runs WHERE process_id=?').get(processId);
        if (!run) {
            pause(processId, 'unavailable');
            return;
        }
        const game = run.game_type;
        while (!stopped) {
            const process = await core.getProcess(processId);
            if (!process || process.status !== 'active') return;
            if ((await core.preemption(processId)).shouldStop) return;
            if (!canRunProcess(process)) {
                pause(processId, 'unconfigured');
                return;
            }
            try {
                authorize({ userId: run.created_by, gameType: game }, false, run.alliance_id);
            } catch {
                pause(processId, 'permission');
                return;
            }
            const fid = process.progress.pending?.[0];
            if (!fid) break;
            const belongsToRun = () => {
                const player = store.player(fid, game);
                return player && player.alliance_id === run.alliance_id && player.exist < 3;
            };
            let answer;
            let failure = null;
            try {
                if (!belongsToRun()) throw new SyncError('notFound');
                answer = await lookupPlayer({
                    gameType: game,
                    fid,
                    processId,
                    checkAccess: () => {
                        authorize({ userId: run.created_by, gameType: game }, false, run.alliance_id);
                        if (!belongsToRun()) throw new SyncError('notFound');
                    }
                });
            } catch (error) {
                const code = error instanceof SyncError ? error.code : 'response';
                if (
                    [
                        'throttled',
                        'busy',
                        'auth',
                        'paused',
                        'permission',
                        'unconfigured',
                        'unavailable',
                        'changed'
                    ].includes(code)
                ) {
                    pause(processId, code, error.retryAt);
                    return;
                }
                failure = code;
            }
            if (stopped) {
                pause(processId, 'paused');
                return;
            }
            if ((await core.preemption(processId)).shouldStop) return;
            try {
                authorize({ userId: run.created_by, gameType: game }, false, run.alliance_id);
            } catch {
                pause(processId, 'permission');
                return;
            }
            if (!belongsToRun()) {
                answer = null;
                failure = 'notFound';
            }
            if (answer) {
                try {
                    unchanged(game, answer.revision, null, answer.epoch);
                } catch (error) {
                    pause(processId, error.code);
                    return;
                }
            }
            db.transaction(() => {
                const current = db.prepare('SELECT status,progress FROM processes WHERE id=?').get(processId);
                if (current.status !== 'active') return;
                const progress = JSON.parse(current.progress);
                if (answer) {
                    unchanged(game, answer.revision, null, answer.epoch);
                    store.apply(answer.profile, game, run.alliance_id, processId);
                } else if (belongsToRun()) store.deferred(fid, game, failure);
                progress.pending = progress.pending.filter(id => String(id) !== String(fid));
                progress[failure ? 'failed' : 'done'].push(fid);
                progress.playerSync = { reason: failure, retryAt: null };
                db.prepare('UPDATE processes SET progress=? WHERE id=?').run(JSON.stringify(progress), processId);
                db.prepare('UPDATE plugin_player_sync_runs SET result=?,updated_at=? WHERE process_id=?').run(
                    failure,
                    now(),
                    processId
                );
            })();
            await flushCatchups().catch(() => {});
        }
        if (stopped) {
            pause(processId, 'paused');
            return;
        }
        db.prepare('UPDATE plugin_player_sync_runs SET result=?,updated_at=? WHERE process_id=?').run(
            'finished',
            now(),
            processId
        );
        await flushReports();
    }

    function ensurePreviewSlot(userId) {
        db.prepare('DELETE FROM plugin_player_sync_import WHERE expires_at<=?').run(now());
        if (db.prepare('SELECT COUNT(*) n FROM plugin_player_sync_import WHERE user_id=?').get(String(userId)).n >= 3)
            throw new SyncError('busy', 'Cancel an earlier import preview before opening another.');
    }

    async function previewImport(context, input) {
        const { game, admin } = authorize(context);
        ensurePreviewSlot(context.userId);
        const config = connection(game);
        const mapping = config.profile.alliance;
        if (!mapping)
            throw new SyncError(
                'mapping',
                'Add the optional alliance endpoint and roster mappings, or use the example setup for this game.'
            );
        const target = input.target;
        if (!target || typeof target !== 'object')
            throw new SyncError('invalid', 'Choose an existing or new destination alliance.');
        let destination;
        if (target.allianceId != null) {
            const { alliances } = authorize(context, false, target.allianceId);
            const alliance = alliances.find(row => row.id === Number(target.allianceId));
            destination = {
                allianceId: alliance.id,
                fingerprint: hash(
                    JSON.stringify([alliance.id, alliance.name, alliance.state, alliance.guide_id, alliance.channel_id])
                )
            };
        } else {
            if (!hasPermission(admin, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS))
                throw new SyncError('permission', 'Alliance management permission is required to create an alliance.');
            if (!target.newAlliance || typeof target.newAlliance.channelId !== 'string')
                throw new SyncError('invalid', 'Select a Discord channel for the new alliance.');
            if (target.newAlliance.name != null && typeof target.newAlliance.name !== 'string')
                throw new SyncError('invalid', 'Enter the new alliance name as text.');
            const name = target.newAlliance.name?.trim();
            const requestedState = target.newAlliance.state;
            if (
                (name && (name.length > 50 || /[\x00-\x1f\x7f]/.test(name))) ||
                (requestedState != null && requestedState !== '' && whole(requestedState, 1) == null)
            )
                throw new SyncError('invalid', 'Enter an alliance name up to 50 characters and a positive state.');
            await core.validateChannel(context.userId, target.newAlliance.channelId);
            destination = {
                newAlliance: {
                    name,
                    state: requestedState === '' ? undefined : requestedState,
                    channelId: target.newAlliance.channelId
                }
            };
        }
        const checkAccess = () => {
            const current = authorize(context, false, destination.allianceId ?? null);
            if (
                destination.newAlliance &&
                !hasPermission(current.admin, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS)
            )
                throw new SyncError('permission', 'Alliance management permission is required.');
        };
        checkAccess();
        unchanged(game, config.revision, null, config.epoch);
        const seed = await lookupPlayer({ gameType: game, fid: input.fid, checkAccess });
        unchanged(game, config.revision, null, config.epoch);
        const state = whole(extract(seed.payload, mapping.state_field), 1);
        const tag = extract(seed.payload, mapping.tag_field);
        if (!state || typeof tag !== 'string' || !tag.trim() || tag.length > 30 || /[\x00-\x1f]/.test(tag))
            throw new SyncError('mapping', 'The seed player has no usable alliance tag and state.');
        const mappedName = extract(seed.payload, mapping.name_field);
        const sourceName =
            typeof mappedName === 'string' && mappedName.trim() && !/[\x00-\x1f\x7f]/.test(mappedName)
                ? mappedName.trim().slice(0, 100)
                : tag;
        const roster = await fetchPayload(game, mapping.path, { state, tag }, { checkAccess });
        const members = extract(roster.payload, mapping.members_path);
        if (!Array.isArray(members) || members.length > 2000)
            throw new SyncError('mapping', 'The roster must be an array with at most 2,000 members.');
        const players = [];
        let invalid = 0;
        const seen = new Set();
        for (const raw of members) {
            try {
                const id = playerId(extract(raw, mapping.fields.id));
                if (seen.has(id)) {
                    invalid++;
                    continue;
                }
                seen.add(id);
                players.push(readPlayer(raw, mapping.fields, id));
            } catch {
                invalid++;
            }
        }
        if (!players.length) throw new SyncError('mapping', 'The roster contains no usable public chief/governor IDs.');
        if (destination.newAlliance) {
            destination.newAlliance.name = String(
                destination.newAlliance.name || `[${tag}] ${sourceName}`.slice(0, 50)
            ).trim();
            destination.newAlliance.state = whole(destination.newAlliance.state || state, 1);
            if (
                !destination.newAlliance.name ||
                destination.newAlliance.name.length > 50 ||
                /[\x00-\x1f]/.test(destination.newAlliance.name) ||
                !destination.newAlliance.state
            )
                throw new SyncError('invalid', 'Enter an alliance name up to 50 characters and a positive state.');
        }
        checkAccess();
        unchanged(game, config.revision, null, config.epoch);
        const classified = players.map(profile => {
            const existing = store.player(profile.fid, game);
            return {
                ...profile,
                status: !existing ? 'add' : existing.alliance_id === destination.allianceId ? 'existing' : 'conflict'
            };
        });
        if (!classified.some(profile => profile.status === 'add'))
            throw new SyncError('duplicate', 'Every returned player is already registered. No players will be moved.');
        ensurePreviewSlot(context.userId);
        const token = crypto.randomBytes(24).toString('hex');
        const snapshot = {
            source: { name: sourceName, tag, state },
            destination,
            players: classified,
            invalid,
            capturedAt: now()
        };
        db.prepare(
            'INSERT INTO plugin_player_sync_import (token,user_id,game_type,revision,expires_at,snapshot) VALUES (?,?,?,?,?,?)'
        ).run(token, String(context.userId), game, config.revision, now() + 300000, JSON.stringify(snapshot));
        return { token, expiresAt: now() + 300000, ...snapshot };
    }

    async function confirmImport(context, token) {
        const { game } = authorize(context);
        if (typeof token !== 'string' || !/^[a-f0-9]{48}$/.test(token))
            throw new SyncError('expired', 'Choose a current import preview.');
        const before = db
            .prepare('SELECT * FROM plugin_player_sync_import WHERE token=? AND user_id=? AND game_type=?')
            .get(token, String(context.userId), game);
        if (!before || before.expires_at <= now())
            throw new SyncError('expired', 'This import preview expired or was already used.');
        const initial = JSON.parse(before.snapshot);
        let channel = null;
        if (initial.destination.newAlliance)
            channel = await core.validateChannel(context.userId, initial.destination.newAlliance.channelId);
        authorize(context, false, initial.destination.allianceId ?? null);
        return db.transaction(() => {
            const { admin } = authorize(context, false, initial.destination.allianceId ?? null);
            const row = db
                .prepare('SELECT * FROM plugin_player_sync_import WHERE token=? AND user_id=? AND game_type=?')
                .get(token, String(context.userId), game);
            if (!row || row.expires_at <= now() || row.revision !== store.config(game).revision)
                throw new SyncError('expired', 'This import preview expired, changed, or was already used.');
            connection(game);
            const snapshot = JSON.parse(row.snapshot);
            let allianceId = snapshot.destination.allianceId;
            if (allianceId != null) {
                const { alliances } = authorize(context, false, allianceId);
                const alliance = alliances.find(a => a.id === allianceId);
                if (
                    hash(
                        JSON.stringify([
                            alliance.id,
                            alliance.name,
                            alliance.state,
                            alliance.guide_id,
                            alliance.channel_id
                        ])
                    ) !== snapshot.destination.fingerprint
                )
                    throw new SyncError('changed', 'The destination alliance changed. Create a fresh preview.');
            } else {
                if (!hasPermission(admin, PERMISSIONS.ALLIANCE_MANAGEMENT, PERMISSIONS.FULL_ACCESS))
                    throw new SyncError('permission', 'Alliance management permission is required.');
                if (!snapshot.players.some(profile => profile.status === 'add' && !store.player(profile.fid, game)))
                    throw new SyncError('duplicate', 'No new players remain to import.');
                allianceId = core.createAlliance(snapshot.destination.newAlliance, admin, game, channel);
            }
            db.prepare('DELETE FROM plugin_player_sync_import WHERE token=?').run(token);
            let added = 0,
                existing = 0,
                conflicts = 0;
            const alliance = db.prepare('SELECT * FROM alliance WHERE id=? AND game_type=?').get(allianceId, game);
            for (const profile of snapshot.players) {
                const old = store.player(profile.fid, game);
                if (old) {
                    old.alliance_id === allianceId ? existing++ : conflicts++;
                    continue;
                }
                // Confirmation cannot expand its approved additions after a player is deleted.
                if (profile.status !== 'add')
                    throw new SyncError(
                        'changed',
                        'A previously registered roster member was removed. Create a fresh import preview.'
                    );
                core.addPlayer(profile.fid, alliance.state, allianceId, String(context.userId), game);
                if (
                    Object.keys(profile).some(key =>
                        ['nickname', 'furnace_level', 'state', 'image_url', 'power'].includes(key)
                    )
                ) {
                    store.apply(profile, game, allianceId, `import:${token}`, false);
                }
                added++;
            }
            return { allianceId, added, existing, conflicts, invalid: snapshot.invalid };
        })();
    }

    function cancelImport(context, token) {
        const { game } = authorize(context);
        if (typeof token !== 'string' || !/^[a-f0-9]{48}$/.test(token))
            throw new SyncError('expired', 'Choose a current import preview.');
        db.prepare('DELETE FROM plugin_player_sync_import WHERE token=? AND user_id=? AND game_type=?').run(
            token,
            String(context.userId),
            game
        );
        return { cancelled: true };
    }

    async function flushReports() {
        if (stopped || flushing) return;
        flushing = true;
        try {
            for (const alliance of db
                .prepare(
                    `SELECT DISTINCT a.* FROM alliance a JOIN plugin_player_sync_reports r ON r.alliance_id=a.id
                AND r.game_type=a.game_type WHERE r.sent_at IS NULL`
                )
                .all()) {
                if (stopped || !alliance.channel_id) continue;
                let rows = db
                    .prepare(
                        'SELECT * FROM plugin_player_sync_reports WHERE game_type=? AND alliance_id=? AND sent_at IS NULL ORDER BY id LIMIT 100'
                    )
                    .all(alliance.game_type, alliance.id);
                try {
                    if (!rows.length) continue;
                    const saved = rows[0].message_id ? JSON.parse(rows[0].message_id) : null;
                    let delivery = saved?.version === 1 && Array.isArray(saved.reports) ? saved : null;
                    if (delivery) {
                        rows = db
                            .prepare(
                                `SELECT * FROM plugin_player_sync_reports WHERE game_type=? AND alliance_id=? AND sent_at IS NULL
                            AND id IN (SELECT value FROM json_each(?)) ORDER BY id`
                            )
                            .all(alliance.game_type, alliance.id, JSON.stringify(delivery.reports));
                        if (rows.length !== delivery.reports.length) delivery = null;
                        if (!rows.length) continue;
                    }
                    const channel = await client.channels.fetch(alliance.channel_id);
                    if (
                        !channel?.isTextBased?.() ||
                        !channel.guildId ||
                        (alliance.guide_id && channel.guildId !== String(alliance.guide_id))
                    )
                        continue;
                    if (delivery?.channelId !== channel.id) delivery = null;
                    const lines = [];
                    const strings = core.reportStrings?.(alliance) || defaultStrings;
                    const labels = {
                        nickname: strings.nickname,
                        furnace_level: alliance.game_type === 'ks' ? strings.townCenter : strings.furnace,
                        state: strings.state,
                        power: strings.power
                    };
                    for (const field of ['nickname', 'furnace_level', 'state', 'power']) {
                        const changes = rows.flatMap(row =>
                            JSON.parse(row.changes)
                                .filter(c => c.field === field)
                                .map(change => ({ row, change }))
                        );
                        if (!changes.length) continue;
                        lines.push(`**${labels[field]}**`);
                        for (const { row, change } of changes) {
                            const format = value =>
                                value == null
                                    ? '—'
                                    : field === 'furnace_level'
                                      ? getFurnaceReadable(value, alliance.game_type)
                                      : field === 'power'
                                        ? Number(value).toLocaleString('en-US')
                                        : String(value);
                            lines.push(
                                `**${escapeMarkdown(String(row.nickname || `ID ${row.fid}`))}** (ID ${row.fid}): ${escapeMarkdown(format(change.old))} → **${escapeMarkdown(format(change.value))}**`
                            );
                        }
                    }
                    const chunks = [''];
                    for (const line of lines) {
                        if (chunks.at(-1).length + line.length + 1 > 3500) chunks.push('');
                        chunks[chunks.length - 1] += line + '\n';
                    }
                    // Persist stable batches and each acknowledgement; new rows cannot shift retry boundaries.
                    delivery ||= {
                        version: 1,
                        reports: rows.map(row => row.id),
                        channelId: channel.id,
                        chunks,
                        ids: []
                    };
                    const checkpoint = () =>
                        db
                            .prepare(
                                'UPDATE plugin_player_sync_reports SET message_id=? WHERE id=? AND sent_at IS NULL'
                            )
                            .run(JSON.stringify(delivery), rows[0].id);
                    checkpoint();
                    for (const [index, description] of delivery.chunks.entries()) {
                        if (index < delivery.ids.length) continue;
                        if (stopped) return;
                        const current = db
                            .prepare('SELECT channel_id,guide_id FROM alliance WHERE id=? AND game_type=?')
                            .get(alliance.id, alliance.game_type);
                        if (
                            !current ||
                            String(current.channel_id) !== channel.id ||
                            (current.guide_id && String(current.guide_id) !== channel.guildId)
                        ) {
                            throw new SyncError('changed', 'The reporting channel changed.');
                        }
                        const message = await channel.send({
                            embeds: [
                                new EmbedBuilder()
                                    .setTitle(`${alliance.name} · ${strings.title}`.slice(0, 256))
                                    .setColor(0x3498db)
                                    .setDescription(description)
                                    .setTimestamp()
                            ],
                            allowedMentions: { parse: [] },
                            nonce: hash(`${channel.id}:${delivery.reports.join(',')}:${index}`).slice(0, 24),
                            enforceNonce: true
                        });
                        delivery.ids.push(message.id);
                        checkpoint();
                    }
                    db.transaction(() => {
                        for (const row of rows)
                            db.prepare('UPDATE plugin_player_sync_reports SET sent_at=?,message_id=? WHERE id=?').run(
                                new Date(now()).toISOString(),
                                JSON.stringify(delivery.ids),
                                row.id
                            );
                    })();
                } catch {
                    /* Leave the outbox intact; the next tick retries delivery. */
                }
            }
        } finally {
            flushing = false;
        }
    }

    async function tick() {
        if (stopped || ticking) return;
        ticking = true;
        try {
            db.prepare('DELETE FROM plugin_player_sync_import WHERE expires_at<=?').run(now());
            for (const schedule of db
                .prepare(
                    `SELECT s.* FROM plugin_player_sync_schedule s JOIN alliance a ON a.id=s.alliance_id AND a.game_type=s.game_type
                WHERE s.enabled=1 AND s.next_at<=? ORDER BY s.next_at,a.priority`
                )
                .all(now())) {
                if (stopped) return;
                if (!core.enabledGames().includes(schedule.game_type)) continue;
                try {
                    connection(schedule.game_type);
                } catch {
                    continue;
                }
                try {
                    authorize(
                        { userId: schedule.created_by, gameType: schedule.game_type },
                        false,
                        schedule.alliance_id
                    );
                } catch {
                    db.prepare(
                        'UPDATE plugin_player_sync_schedule SET enabled=0 WHERE game_type=? AND alliance_id=?'
                    ).run(schedule.game_type, schedule.alliance_id);
                    continue;
                }
                const alliance = db.prepare('SELECT * FROM alliance WHERE id=?').get(schedule.alliance_id);
                await enqueue(schedule.game_type, alliance, schedule.created_by, true);
                if (stopped) return;
                db.prepare('UPDATE plugin_player_sync_schedule SET next_at=? WHERE game_type=? AND alliance_id=?').run(
                    now() + schedule.hours * 3600000,
                    schedule.game_type,
                    schedule.alliance_id
                );
            }
            await flushCatchups();
            if (stopped) return;
            await flushReports();
            if (!stopped) await core.startNext();
        } finally {
            ticking = false;
        }
    }

    function stop() {
        stopped = true;
        for (const controller of controllers.keys()) controller.abort();
        for (const timer of waking.values()) clearTimeout(timer);
        waking.clear();
        for (const row of db
            .prepare(
                `SELECT p.id FROM processes p JOIN plugin_player_sync_runs r ON r.process_id=p.id WHERE p.status='active'`
            )
            .all())
            pause(row.id, 'paused');
    }
    for (const row of db.prepare('SELECT game_type FROM plugin_player_sync_config').all())
        migrateQuota(store.config(row.game_type));
    return {
        apiVersion: 1,
        status,
        saveProfile,
        saveKey,
        setEnabled,
        test,
        details,
        syncNow,
        setSchedule,
        canRunProcess,
        executeProcess,
        enrichPlayer,
        lookupPlayer,
        previewImport,
        confirmImport,
        cancelImport,
        cancelRun,
        tick,
        stop,
        exportProfile: context => {
            authorize(context, true);
            return store.config(context.gameType).profile;
        },
        useExample: context => saveProfile(context, preset(gameFrom(context.gameType)))
    };
}
function wait(ms, signal) {
    return new Promise((resolve, reject) => {
        if (signal?.aborted) {
            reject(new SyncError('paused', 'Request cancelled.'));
            return;
        }
        const abort = () => {
            clearTimeout(timer);
            reject(new SyncError('paused', 'Request cancelled.'));
        };
        const timer = setTimeout(
            () => {
                signal?.removeEventListener('abort', abort);
                resolve();
            },
            Math.max(0, ms)
        );
        signal?.addEventListener('abort', abort, { once: true });
    });
}
module.exports = { createService };
