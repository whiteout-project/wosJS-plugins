const https = require('https');
const dns = require('dns').promises;
const { SyncError, publicUrl, isPublicAddress } = require('./profile');
const MAX_RESPONSE = 2 * 1024 * 1024;

async function requestJson(address, headers, signal, { deadline = Date.now() + 100000, maxBytes = MAX_RESPONSE } = {}) {
    const url = publicUrl(address);
    if (signal?.aborted) throw new SyncError('paused', 'Request cancelled.');
    const host = url.hostname.replace(/^\[|\]$/g, '');
    const records = await new Promise((resolve, reject) => {
        const timeout = setTimeout(
            () => finish(new SyncError('network', 'DNS lookup timed out.')),
            Math.max(1, deadline - Date.now())
        );
        const abort = () => finish(new SyncError('paused', 'Request cancelled.'));
        function finish(error, result) {
            clearTimeout(timeout);
            signal?.removeEventListener('abort', abort);
            error ? reject(error) : resolve(result);
        }
        signal?.addEventListener('abort', abort, { once: true });
        dns.lookup(host, { all: true, verbatim: true }).then(
            result => finish(null, result),
            () => finish(new SyncError('network', 'The API host could not be reached.'))
        );
    });
    if (signal?.aborted) throw new SyncError('paused', 'Request cancelled.');
    if (!records.length || records.some(record => !isPublicAddress(record.address)))
        throw new SyncError('invalid', 'The API host must resolve only to public addresses.');
    if (Date.now() >= deadline) throw new SyncError('network', 'The API request timed out.');
    const pinned = records[0];
    // Pin the validated DNS result while keeping the hostname for TLS certificate verification.
    return new Promise((resolve, reject) => {
        const req = https.get(
            url,
            {
                headers: { Accept: 'application/json', 'Accept-Encoding': 'identity', ...headers },
                signal,
                agent: false,
                lookup: (_host, options, done) => done(null, options.all ? [pinned] : pinned.address, pinned.family)
            },
            res => {
                res.on('error', () => reject(new SyncError('network', 'The API response was interrupted.')));
                res.on('aborted', () => reject(new SyncError('network', 'The API response was interrupted.')));
                if (res.statusCode !== 200) {
                    // Classify errors/redirects from headers; their body must not hide a 429 or 401.
                    resolve({ status: res.statusCode, headers: res.headers });
                    res.destroy();
                    return;
                }
                if (
                    Number(res.headers['content-length']) > maxBytes ||
                    (res.headers['content-encoding'] && res.headers['content-encoding'] !== 'identity')
                ) {
                    reject(new SyncError('response', 'The API response is too large or uses unsupported compression.'));
                    req.destroy();
                    return;
                }
                let bytes = 0;
                const chunks = [];
                res.on('data', chunk => {
                    bytes += chunk.length;
                    if (bytes > maxBytes) {
                        reject(new SyncError('response', 'The response exceeds the allowed size.'));
                        req.destroy();
                    } else chunks.push(chunk);
                });
                res.on('end', () => {
                    let payload;
                    try {
                        payload = JSON.parse(Buffer.concat(chunks).toString('utf8'));
                    } catch {
                        /* classified by the service */
                    }
                    resolve({ status: res.statusCode, headers: res.headers, payload });
                });
            }
        );
        const timer = setTimeout(() => req.destroy(new Error('timeout')), Math.max(1, deadline - Date.now()));
        req.on('close', () => clearTimeout(timer));
        req.on('error', () =>
            reject(
                new SyncError(
                    signal?.aborted ? 'paused' : 'network',
                    signal?.aborted ? 'Request cancelled.' : 'The API request failed or timed out.'
                )
            )
        );
    });
}

async function readSetupAttachment(file) {
    let url;
    try {
        url = new URL(file?.url);
    } catch {
        throw new SyncError('invalid', 'Choose one JSON attachment.');
    }
    if (
        !file?.name?.toLowerCase().endsWith('.json') ||
        file.size > 65536 ||
        !['cdn.discordapp.com', 'media.discordapp.net'].includes(url.hostname)
    )
        throw new SyncError('invalid', 'Choose one Discord JSON attachment up to 64 KiB.');
    const result = await requestJson(url.href, {}, undefined, { deadline: Date.now() + 20000, maxBytes: 65536 });
    if (result.status !== 200 || !result.payload)
        throw new SyncError('invalid', 'The setup attachment could not be read as JSON.');
    return result.payload;
}
module.exports = { requestJson, readSetupAttachment, MAX_RESPONSE };
