const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    ChannelType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    FileUploadBuilder,
    LabelBuilder,
    AttachmentBuilder,
    FileBuilder,
    ThumbnailBuilder,
    SectionBuilder,
    MessageFlags,
    escapeMarkdown
} = require('discord.js');
const baseline = require('./locales/en.json').plugins['player-sync'];
const { preset, SyncError, imageUrl } = require('./profile');
const { readSetupAttachment } = require('./transport');
const { getFurnaceReadable } = require('../../src/functions/Players/furnaceReadable');

function createDiscordUI(
    service,
    { getUserInfo, enabledGames, readAttachment = readSetupAttachment, getEmoji = () => null }
) {
    const locale = userId => getUserInfo(userId).lang?.plugins?.['player-sync'] || baseline;
    const text = value => escapeMarkdown(String(value ?? '—').slice(0, 500));
    const context = (interaction, game) => ({ userId: interaction.user.id, gameType: game });
    const id = (action, game, userId, argument) =>
        `ps_${action}${argument == null ? '' : `_${argument}`}_${game}_${userId}`;
    function button(label, customId, style = ButtonStyle.Secondary, disabled = false, emoji = null) {
        const component = new ButtonBuilder()
            .setLabel(label.slice(0, 80))
            .setCustomId(customId)
            .setStyle(style)
            .setDisabled(disabled);
        if (emoji) component.setEmoji(emoji);
        return component;
    }

    function rows(buttons) {
        const result = [];
        for (let i = 0; i < buttons.length; i += 5)
            result.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
        return result;
    }

    function render(
        interaction,
        game,
        content,
        { buttons = [], controls = [], files = [], busy = false, image = null } = {}
    ) {
        const t = locale(interaction.user.id);
        const state = service.status(context(interaction, game));
        const emojiKeys = {
            setup: '1038',
            alliances: '1005',
            sync: '1033',
            import: '1020',
            details: '1026',
            help: '1017'
        };
        const main = new ContainerBuilder()
            .setAccentColor(2417109)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `### ${t.title} · ${game.toUpperCase()}\n${t.intro}\n\n` +
                        `${t.provider}: **${text(state.provider || t.notConfigured)}** · ${state.enabled ? t.enabled : t.disabled}\n` +
                        `${state.keyPresent ? t.keySet : t.noKey} · ${state.tested ? t.tested : t.notTested} · ${t.usage}: ${state.usage.used}/${state.limits?.perDay || '—'}`
                )
            )
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        const menu = ['setup', 'alliances', 'sync', 'import', 'details', 'help']
            .filter(action => action !== 'setup' || state.isOwner)
            .map(action =>
                button(
                    t[action],
                    id(action, game, interaction.user.id),
                    ButtonStyle.Secondary,
                    busy,
                    getEmoji(interaction.user.id, emojiKeys[action])
                )
            );
        menu.push(
            button(
                state.canManageAlliances ? t.back : t.backPlayers,
                `${state.canManageAlliances ? 'alliance' : 'player'}_management_${interaction.user.id}`,
                ButtonStyle.Secondary,
                busy,
                getEmoji(interaction.user.id, '1019')
            )
        );
        main.addActionRowComponents(...rows(menu));
        if (enabledGames().length > 1)
            main.addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId(`ps_game_${interaction.user.id}`)
                        .setPlaceholder(game.toUpperCase())
                        .setDisabled(busy)
                        .addOptions(
                            enabledGames().map(value => ({
                                label: value === 'ks' ? 'Kingshot' : 'Whiteout Survival',
                                value,
                                default: value === game
                            }))
                        )
                )
            );
        const mainLength = main
            .toJSON()
            .components.reduce((sum, component) => sum + (component.content?.length || 0), 0);
        const section = new ContainerBuilder().setAccentColor(0x3498db);
        const display = new TextDisplayBuilder().setContent(String(content).slice(0, 4000 - mainLength));
        image = imageUrl(image);
        if (image)
            section.addSectionComponents(
                new SectionBuilder()
                    .addTextDisplayComponents(display)
                    .setThumbnailAccessory(new ThumbnailBuilder().setURL(image))
            );
        else section.addTextDisplayComponents(display);
        if (controls.length) section.addActionRowComponents(...controls);
        if (buttons.length) section.addActionRowComponents(...rows(buttons));
        for (const file of files) section.addFileComponents(new FileBuilder().setURL(`attachment://${file.name}`));
        return {
            components: [main, new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true), section],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [] },
            attachments: [],
            files
        };
    }

    async function send(interaction, payload) {
        if (interaction.deferred || interaction.replied) return interaction.editReply(payload);
        if (interaction.isButton?.() || interaction.isStringSelectMenu?.() || interaction.isChannelSelectMenu?.())
            return interaction.update(payload);
        return interaction.reply({ ...payload, flags: payload.flags | MessageFlags.Ephemeral });
    }

    function overview(state, t) {
        return (
            `${state.enabled ? t.ready : t.setupHelp}\n\n**${t.pendingReports}:** ${state.pendingReports}\n**${t.runs}**\n` +
            (state.runs
                .slice(0, 8)
                .map(
                    run =>
                        `#${run.id} · ${t.statuses[run.status] || run.status} · ${run.done}/${run.done + run.failed + run.pending}${run.reason ? ` · ${t.errors[run.reason] || run.reason}` : ''}`
                )
                .join('\n') || t.none)
        );
    }

    async function show(interaction, game = enabledGames()[0]) {
        let t = baseline;
        try {
            t = locale(interaction.user.id);
            const state = service.status(context(interaction, game));
            await send(
                interaction,
                render(interaction, game, overview(state, t), {
                    buttons: [button(t.refresh, id('status', game, interaction.user.id))]
                })
            );
        } catch (error) {
            await errorReply(interaction, t, error, game);
        }
    }

    async function errorReply(interaction, t, error, game) {
        try {
            const content = t.errors[error?.code] || t.errors.response;
            if (interaction.deferred || interaction.replied) {
                let payload;
                try {
                    payload = render(interaction, game, content);
                    payload.components.at(-1).setAccentColor(0xe74c3c);
                } catch {
                    // Restricted/unloaded services cannot rebuild an authorized navigation menu.
                    payload = {
                        components: [
                            new ContainerBuilder()
                                .setAccentColor(0xe74c3c)
                                .addTextDisplayComponents(new TextDisplayBuilder().setContent(content))
                        ],
                        attachments: [],
                        flags: MessageFlags.IsComponentsV2,
                        allowedMentions: { parse: [] }
                    };
                }
                return await interaction.editReply(payload);
            }
            return await interaction.reply({ content, flags: MessageFlags.Ephemeral });
        } catch {
            /* Expired/deleted Discord interactions cannot receive an error reply. */
        }
    }

    async function showSetup(interaction, game, notice = '', advanced = false) {
        const t = locale(interaction.user.id);
        const state = service.status(context(interaction, game));
        if (!state.isOwner) throw new SyncError('permission');
        const actions = advanced
            ? ['connection', 'fields', 'limits', 'paste', 'upload', 'export', 'removeKey']
            : ['example', 'key', 'test', state.enabled ? 'disable' : 'enable', 'advanced'];
        await send(
            interaction,
            render(interaction, game, `${notice}\n${advanced ? `### ${t.advanced}\n` : ''}${t.setupHelp}`, {
                buttons: actions.map(action =>
                    button(
                        t[action],
                        id(action, game, interaction.user.id),
                        action === 'enable'
                            ? ButtonStyle.Success
                            : action === 'removeKey'
                              ? ButtonStyle.Danger
                              : ButtonStyle.Secondary,
                        (action === 'enable' && !state.tested) ||
                            (action === 'test' && !state.configured) ||
                            (action === 'removeKey' && !state.keyPresent) ||
                            (action === 'export' && !state.profile)
                    )
                )
            })
        );
    }

    async function alliancePicker(interaction, game, mode, page = 0) {
        const t = locale(interaction.user.id);
        const state = service.status(context(interaction, game));
        const pages = Math.max(1, Math.ceil(state.alliances.length / 24));
        page = Math.max(0, Math.min(pages - 1, page));
        const alliances = state.alliances.slice(page * 24, (page + 1) * 24);
        const options = alliances.map(alliance => ({
            label: alliance.name.slice(0, 100),
            value: String(alliance.id),
            description:
                `${t.state} ${alliance.state ?? '—'} · ${alliance.playerCount} · ${alliance.enabled ? t.enabled : t.disabled} · ${alliance.hours}h`.slice(
                    0,
                    100
                )
        }));
        if (mode === 'sync') options.unshift({ label: t.all.slice(0, 100), value: 'all' });
        if (mode === 'import' && state.canManageAlliances)
            options.unshift({ label: t.newAlliance.slice(0, 100), value: 'new' });
        const controls = options.length
            ? [
                  new ActionRowBuilder().addComponents(
                      new StringSelectMenuBuilder()
                          .setCustomId(id(`pick-${mode}`, game, interaction.user.id))
                          .setPlaceholder(t.chooseAlliance)
                          .addOptions(options)
                  )
              ]
            : [];
        const buttons =
            pages > 1
                ? [
                      button(
                          t.previous,
                          id(mode, game, interaction.user.id, page - 1),
                          ButtonStyle.Secondary,
                          page === 0,
                          getEmoji(interaction.user.id, '1019')
                      ),
                      button(
                          t.next,
                          id(mode, game, interaction.user.id, page + 1),
                          ButtonStyle.Secondary,
                          page === pages - 1,
                          getEmoji(interaction.user.id, '1034')
                      )
                  ]
                : [];
        if (mode === 'sync')
            buttons.push(
                button(t.refresh, id('status', game, interaction.user.id)),
                button(t.stop, id('stop', game, interaction.user.id))
            );
        await send(
            interaction,
            render(interaction, game, mode === 'import' ? t.importHelp : t.scheduleHelp, { controls, buttons })
        );
    }

    function modal(interaction, game, action, title, inputs, argument) {
        const form = new ModalBuilder()
            .setCustomId(id(`form-${action}`, game, interaction.user.id, argument))
            .setTitle(title.slice(0, 45));
        for (const input of inputs) {
            if (input.options) {
                form.addLabelComponents(
                    new LabelBuilder().setLabel(input.label.slice(0, 45)).setStringSelectMenuComponent(
                        new StringSelectMenuBuilder()
                            .setCustomId(input.key)
                            .setMinValues(1)
                            .setMaxValues(1)
                            .addOptions(
                                input.options.map(option => ({ ...option, default: option.value === input.value }))
                            )
                    )
                );
                continue;
            }
            form.addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId(input.key)
                        .setLabel(input.label.slice(0, 45))
                        .setStyle(input.long ? TextInputStyle.Paragraph : TextInputStyle.Short)
                        .setRequired(input.required !== false)
                        .setMaxLength(input.max || (input.long ? 4000 : 200))
                        .setValue(String(input.value ?? '').slice(0, input.max || (input.long ? 4000 : 200)))
                )
            );
        }
        return interaction.showModal(form);
    }

    async function runPicker(interaction, game, page = 0) {
        const t = locale(interaction.user.id);
        const runs = service
            .status(context(interaction, game))
            .runs.filter(run => ['active', 'queued'].includes(run.status));
        const pages = Math.max(1, Math.ceil(runs.length / 25));
        page = Math.max(0, Math.min(page, pages - 1));
        const controls = runs.length
            ? [
                  new ActionRowBuilder().addComponents(
                      new StringSelectMenuBuilder()
                          .setCustomId(id('pick-stop', game, interaction.user.id))
                          .setPlaceholder(t.chooseRun)
                          .addOptions(
                              runs.slice(page * 25, (page + 1) * 25).map(run => ({
                                  label: `#${run.id} · ${t.statuses[run.status]} · ${run.done}/${run.done + run.failed + run.pending}`.slice(
                                      0,
                                      100
                                  ),
                                  value: String(run.id)
                              }))
                          )
                  )
              ]
            : [];
        const buttons =
            pages > 1
                ? [
                      button(
                          t.previous,
                          id('stop', game, interaction.user.id, page - 1),
                          ButtonStyle.Secondary,
                          page === 0
                      ),
                      button(
                          t.next,
                          id('stop', game, interaction.user.id, page + 1),
                          ButtonStyle.Secondary,
                          page === pages - 1
                      )
                  ]
                : [];
        return send(interaction, render(interaction, game, runs.length ? t.chooseRun : t.none, { controls, buttons }));
    }

    async function listener(interaction) {
        if (!interaction.customId?.startsWith('ps_')) return;
        const parts = interaction.customId.split('_');
        const userId = parts.at(-1);
        let t = baseline;
        try {
            t = locale(interaction.user.id);
            if (userId !== interaction.user.id) throw new SyncError('permission');
            let game = parts.at(-2);
            const action = parts[1];
            if (action === 'open') return await show(interaction);
            if (action === 'game') return await show(interaction, interaction.values[0]);
            const ctx = context(interaction, game);
            const state = service.status(ctx);
            const argument = parts.slice(2, -2).join('_');
            if (action.startsWith('form-')) {
                await interaction.deferReply({ flags: MessageFlags.Ephemeral });
                const value = key => interaction.fields.getTextInputValue(key).trim();
                const kind = action.slice(5);
                if (
                    ['key', 'connection', 'fields', 'limits', 'paste', 'upload', 'test'].includes(kind) &&
                    !state.isOwner
                )
                    throw new SyncError('permission');
                const profile = state.profile || preset(game);
                if (kind === 'key') service.saveKey(ctx, value('secret'));
                else if (kind === 'connection')
                    service.saveProfile(ctx, {
                        ...profile,
                        base_url: value('base'),
                        player_path: value('path'),
                        auth_header: value('header'),
                        fields: { ...profile.fields, id: value('id') }
                    });
                else if (kind === 'fields')
                    service.saveProfile(ctx, {
                        ...profile,
                        fields: {
                            ...profile.fields,
                            ...Object.fromEntries(
                                ['name', 'level', 'kingdom', 'power', 'avatar'].map(key => [key, value(key)])
                            )
                        }
                    });
                else if (kind === 'limits')
                    service.saveProfile(ctx, {
                        ...profile,
                        per_minute: Number(value('minute')),
                        per_day: Number(value('day'))
                    });
                else if (kind === 'paste') service.saveProfile(ctx, value('json'));
                else if (kind === 'upload') {
                    const files = interaction.fields.getUploadedFiles('config');
                    if (files?.size !== 1) throw new SyncError('invalid');
                    service.saveProfile(ctx, await readAttachment(files.first()));
                } else if (kind === 'schedule') {
                    const on = (interaction.fields.getStringSelectValues?.('auto')?.[0] ?? value('auto')).toLowerCase();
                    if (!['on', 'off'].includes(on)) throw new SyncError('invalid');
                    service.setSchedule(ctx, Number(argument), { hours: Number(value('hours')), enabled: on === 'on' });
                    return await alliancePicker(interaction, game, 'alliances');
                } else if (kind === 'stop') {
                    service.cancelRun(ctx, value('run'));
                    return await show(interaction, game);
                } else if (kind === 'test' || kind === 'details') {
                    await send(interaction, render(interaction, game, t.processing, { busy: true }));
                    const result =
                        kind === 'test'
                            ? (await service.test(ctx, value('fid'))).profile
                            : service.details(ctx, value('fid'));
                    const body = `### ${t.profile}\nID ${result.fid}\n${t.nickname}: ${text(result.nickname)}\n${t.level}: ${getFurnaceReadable(result.furnace_level, game)}\n${t.state}: ${result.state_override ?? result.state ?? '—'}\n${t.power}: ${result.power?.toLocaleString() ?? '—'}\n${t.lastSync}: ${result.profile_synced_at || '—'}`;
                    return await send(
                        interaction,
                        render(interaction, game, body, {
                            image: result.image_url,
                            buttons:
                                kind === 'test' && !service.status(ctx).enabled
                                    ? [button(t.enable, id('enable', game, userId), ButtonStyle.Success)]
                                    : []
                        })
                    );
                } else if (kind === 'import' || kind === 'new') {
                    await send(interaction, render(interaction, game, t.processing, { busy: true }));
                    const target =
                        kind === 'import'
                            ? { allianceId: Number(argument) }
                            : { newAlliance: { channelId: argument, name: value('name'), state: value('state') } };
                    const preview = await service.previewImport(ctx, { fid: value('fid'), target });
                    const count = status => preview.players.filter(player => player.status === status).length;
                    const destination =
                        preview.destination.newAlliance?.name ||
                        state.alliances.find(alliance => alliance.id === preview.destination.allianceId)?.name;
                    const content =
                        `### ${t.preview}\n${t.expires}\n\n${t.source}: **${text(preview.source.name)}** (${text(preview.source.tag)}, ${preview.source.state})\n${t.destination}: **${text(destination)}**\n` +
                        `${preview.destination.newAlliance ? `${t.state}: ${preview.destination.newAlliance.state} · <#${preview.destination.newAlliance.channelId}>\n` : ''}` +
                        `${t.add}: ${count('add')} · ${t.existing}: ${count('existing')} · ${t.conflict}: ${count('conflict')} · ${t.invalid}: ${preview.invalid}\n\n` +
                        preview.players
                            .slice(0, 12)
                            .map(player => `${player.fid} · ${text(player.nickname)} · ${t[player.status]}`)
                            .join('\n');
                    return await send(
                        interaction,
                        render(interaction, game, content, {
                            buttons: [
                                button(t.confirm, id('confirm', game, userId, preview.token), ButtonStyle.Success),
                                button(t.cancel, id('cancel', game, userId, preview.token), ButtonStyle.Danger)
                            ],
                            files: [
                                new AttachmentBuilder(Buffer.from(JSON.stringify(preview, null, 2)), {
                                    name: 'alliance-import-preview.json'
                                })
                            ]
                        })
                    );
                }
                return await showSetup(interaction, game, t.saved);
            }
            if (
                [
                    'key',
                    'connection',
                    'fields',
                    'limits',
                    'paste',
                    'upload',
                    'test',
                    'example',
                    'enable',
                    'disable',
                    'removeKey',
                    'export',
                    'advanced'
                ].includes(action) &&
                !state.isOwner
            )
                throw new SyncError('permission');
            if (action === 'status') return await show(interaction, game);
            if (action === 'setup') return await showSetup(interaction, game);
            if (action === 'advanced') return await showSetup(interaction, game, '', true);
            if (['alliances', 'sync', 'import'].includes(action))
                return await alliancePicker(interaction, game, action, Number(argument) || 0);
            if (action === 'help') return await send(interaction, render(interaction, game, t.helpText));
            if (action === 'example') {
                service.useExample(ctx);
                return await showSetup(interaction, game, t.saved);
            }
            if (action === 'enable' || action === 'disable') {
                service.setEnabled(ctx, action === 'enable');
                return await showSetup(interaction, game, t.saved);
            }
            if (action === 'removeKey') {
                service.saveKey(ctx, '');
                return await showSetup(interaction, game, t.saved);
            }
            if (action === 'export')
                return await send(
                    interaction,
                    render(interaction, game, t.export, {
                        files: [
                            new AttachmentBuilder(Buffer.from(JSON.stringify(service.exportProfile(ctx), null, 2)), {
                                name: `player-sync-${game}.json`
                            })
                        ]
                    })
                );
            if (action === 'key')
                return await modal(interaction, game, 'key', t.key, [{ key: 'secret', label: t.newKey, max: 500 }]);
            const profile = state.profile || preset(game);
            if (action === 'connection')
                return await modal(interaction, game, action, t.connection, [
                    { key: 'base', label: t.baseUrl, value: profile.base_url },
                    { key: 'path', label: t.playerPath, value: profile.player_path, max: 1000 },
                    { key: 'header', label: t.authHeader, value: profile.auth_header, max: 60 },
                    { key: 'id', label: t.idField, value: profile.fields.id, required: false }
                ]);
            if (action === 'fields')
                return await modal(
                    interaction,
                    game,
                    action,
                    t.fields,
                    ['name', 'level', 'kingdom', 'power', 'avatar'].map((key, index) => ({
                        key,
                        label: [t.nameField, t.levelField, t.stateField, t.powerField, t.avatarField][index],
                        value: profile.fields[key],
                        required: false
                    }))
                );
            if (action === 'limits')
                return await modal(interaction, game, action, t.limits, [
                    { key: 'minute', label: t.minute, value: profile.per_minute },
                    { key: 'day', label: t.day, value: profile.per_day }
                ]);
            if (action === 'paste')
                return await modal(interaction, game, action, t.paste, [{ key: 'json', label: t.json, long: true }]);
            if (action === 'upload')
                return await interaction.showModal(
                    new ModalBuilder()
                        .setCustomId(id('form-upload', game, userId))
                        .setTitle(t.upload.slice(0, 45))
                        .addLabelComponents(
                            new LabelBuilder()
                                .setLabel(t.file)
                                .setDescription(t.fileHelp)
                                .setFileUploadComponent(
                                    new FileUploadBuilder()
                                        .setCustomId('config')
                                        .setRequired(true)
                                        .setMinValues(1)
                                        .setMaxValues(1)
                                )
                        )
                );
            if (action === 'test' || action === 'details')
                return await modal(interaction, game, action, t[action], [{ key: 'fid', label: t.playerId, max: 16 }]);
            if (action === 'stop') return await runPicker(interaction, game, Number(argument) || 0);
            if (action === 'pick-stop') {
                await interaction.deferUpdate();
                service.cancelRun(ctx, interaction.values[0]);
                return await show(interaction, game);
            }
            if (action === 'pick-alliances') {
                const alliance = state.alliances.find(a => a.id === Number(interaction.values[0]));
                if (!alliance) throw new SyncError('permission');
                return await modal(
                    interaction,
                    game,
                    'schedule',
                    t.alliances,
                    [
                        { key: 'hours', label: t.hours, value: alliance.hours },
                        {
                            key: 'auto',
                            label: t.auto,
                            value: alliance.enabled ? 'on' : 'off',
                            options: [
                                { label: t.enabled, value: 'on' },
                                { label: t.disabled, value: 'off' }
                            ]
                        }
                    ],
                    alliance.id
                );
            }
            if (action === 'pick-sync') {
                await interaction.deferUpdate();
                const result = await service.syncNow(
                    ctx,
                    interaction.values[0] === 'all' ? null : [Number(interaction.values[0])]
                );
                return await send(
                    interaction,
                    render(
                        interaction,
                        game,
                        `${t.queued}: ${result.processIds.join(', ') || t.none}\n${t.skipped}: ${result.skipped}`,
                        { buttons: [button(t.refresh, id('status', game, userId))] }
                    )
                );
            }
            if (action === 'pick-import') {
                if (interaction.values[0] === 'new')
                    return await send(
                        interaction,
                        render(interaction, game, t.chooseChannel, {
                            controls: [
                                new ActionRowBuilder().addComponents(
                                    new ChannelSelectMenuBuilder()
                                        .setCustomId(id('newchannel', game, userId))
                                        .setChannelTypes(ChannelType.GuildText)
                                        .setMinValues(1)
                                        .setMaxValues(1)
                                )
                            ]
                        })
                    );
                return await modal(
                    interaction,
                    game,
                    'import',
                    t.import,
                    [{ key: 'fid', label: t.playerId, max: 16 }],
                    interaction.values[0]
                );
            }
            if (action === 'newchannel')
                return await modal(
                    interaction,
                    game,
                    'new',
                    t.import,
                    [
                        { key: 'fid', label: t.playerId, max: 16 },
                        { key: 'name', label: t.allianceName, required: false, max: 50 },
                        { key: 'state', label: t.allianceState, required: false }
                    ],
                    interaction.values[0]
                );
            if (action === 'confirm' || action === 'cancel') {
                await interaction.deferUpdate();
                const result =
                    action === 'confirm'
                        ? await service.confirmImport(ctx, argument)
                        : service.cancelImport(ctx, argument);
                return await send(
                    interaction,
                    render(
                        interaction,
                        game,
                        action === 'confirm'
                            ? `${t.imported}\n${t.add}: ${result.added} · ${t.existing}: ${result.existing} · ${t.conflict}: ${result.conflicts} · ${t.invalid}: ${result.invalid}`
                            : t.cancelled
                    )
                );
            }
        } catch (error) {
            await errorReply(interaction, t, error, parts.at(-2));
        }
    }
    return { listener, show, render };
}
module.exports = { createDiscordUI };
